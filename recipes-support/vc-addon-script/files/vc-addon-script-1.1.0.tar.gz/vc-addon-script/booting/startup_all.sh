#!/bin/bash

## Observe errors by this scripts with
##   systemctl status vcstartup.service

## Subnet number for Debug and RSwitch port
IP24_eth0=192.168.178
IP24_switch=192.168.0

## Default gateway on Debug port
#IP_gw=192.168.178.1
IP_gw=192.168.178.61

## Derive IP and MAC address from host name
ecu=`echo $HOSTNAME | egrep -o '[[:digit:]]+'`
echo "Run on ECU $ecu"
mac=000$ecu
mac1=${mac: -2} 
mac2=${mac: -4:2} 

case "$1" in
start)
    ##----- Section 1: General settings for the VC Box -----
    
    ## switch off the 8 LEDs on front of box
    i2cset -y 5 0x4d 0 0xff  #leds 0..3 off
    i2cset -y 5 0x4d 1 0xff  #leds 4..7 off

    ## Enable AVBES in R-Car as debug port
    ifconfig eth0 hw ether 74:90:50:00:$ecu:EE
    ifconfig eth0 up || exit 1
    ifconfig eth0 $IP24_eth0.$ecu/24

    ## Configure R-CAR debug port for 100Mbps or 1Gbps (= 1000Mbps)
    /home/root/vc/booting/eth0speed.sh 100 || exit 1

    ## Configure default router of the R-Car debug port
    route add default gw $IP_gw


    ##----- Section 2: Setup RSwitch -----

    ## load kernel module for the RSwitch
    modprobe rswitch2 || exit 1

    ## Initialise the CPU side switch interface
    ifconfig tsngw hw ether 74:90:50:$mac2:$mac1:CC
    ifconfig tsngw up ${IP24_switch}.$ecu/24 || exit 1

    ## Initialise all interfaces
    ##   no IP address allowed
    ##   to change in Slave mode, set master-phy off
    ##   Interface tsn7 is only allowed with 100 Mbps, can be switched to Eth1 and MCU
    ifconfig tsn4 hw ether 74:90:50:$mac2:$mac1:08
    ifconfig tsn4 up || exit 1
    ethtool -s tsn4 speed 1000 
    ethtool --set-priv-flags tsn4 master-phy on

    ifconfig tsn5 hw ether 74:90:50:$mac2:$mac1:10
    ifconfig tsn5 up || exit 1
    ethtool -s tsn5 speed 1000 
    ethtool --set-priv-flags tsn5 master-phy on

    if [ -d /sys/class/net/tsn6 ]; then
        ifconfig tsn6 hw ether 74:90:50:$mac2:$mac1:20
        ifconfig tsn6 up || exit 1
        ethtool -s tsn6 speed 100 
        ethtool --set-priv-flags tsn6 master-phy on
    elif [ -d /sys/class/net/eth1 ]; then
        ifconfig eth1 hw ether 74:90:50:$mac2:$mac1:21
        ifconfig eth1 up || exit 1
        ethtool -s eth1 speed 100 duplex full autoneg on
    else
        ifconfig tsn0 hw ether 74:90:50:$mac2:$mac1:22
 	ifconfig tsn0 up || exit 1
      	ethtool -s tsn0 speed 100
        #temporary, to be moved into driver/dtb
        echo 471 > /sys/class/gpio/export
        echo out > /sys/class/gpio/gpio471/direction
        echo 1   > /sys/class/gpio/gpio471/value  
    fi

    ifconfig tsn7 hw ether 74:90:50:$mac2:$mac1:30
    ifconfig tsn7 up || exit 1
    ethtool -s tsn7 speed 1000
    ethtool --set-priv-flags tsn7 master-phy on


    ##----- Section 3: Load the switch configuration  -----

    ## Example: L2 switch broadcast routing and learning
    rswitch2tool -c fwd -f /home/root/vc/configuration/fwd_L2switch_example1.xml || exit 1

    ;;

stop)
    ifconfig eth0 down

    ifconfig tsn4 down
    ifconfig tsn5 down
    if [ -d /sys/class/net/tsn6 ]; then
        ifconfig tsn6 down
    fi
    if [ -d /sys/class/net/eth1 ]; then
        ifconfig eth1 down
    fi
    if [ -d /sys/class/net/tsn0 ]; then
        ifconfig tsn0 down
    fi
    ifconfig tsn7 down
    ifconfig tsngw down

    rmmod rswitch2

    ## switch off the 7 LEDs and set 5 to orange on front of box
    i2cset -y 5 0x4d 0 0xff  #leds 0..3 off
    i2cset -y 5 0x4d 1 0xbf  #leds 4..7 off
    ;;

force-reload|restart)
    $0 stop
    $0 start
    ;;

*)
    echo "Usage: $0 {start|stop}"
    exit 1
    ;;
esac

exit 0
