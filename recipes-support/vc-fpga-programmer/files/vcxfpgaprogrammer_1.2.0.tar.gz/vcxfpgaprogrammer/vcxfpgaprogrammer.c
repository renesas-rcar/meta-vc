/*
* @brief vcx board fpga programmer tool
*
* vcxfpgaprogrammer
*  - Programs Bitfile to VCx boards
*  - 
*
* exit codes
*  - 0 success
*  - 1 command-line error (usage error)
*  - 2 (unused)
*  - 3 execution error
*
* @author
* Asad Kamal
*
*/




#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>
#include <unistd.h>
#include <stdint.h>
#include <dirent.h>

#include <sys/ioctl.h>
#include <time.h>
#include <signal.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <net/if.h>
#include <arpa/inet.h>
#include <math.h>
#include <pthread.h>
#include <poll.h>
#include <errno.h>
#include <include/linux/renesas_vc2_usrspace.h> 
#define DEVICE_NAME "/dev/"VC2_FPGA_PLTFRM_DEVICE_NAME
#define DEFAULT_BITFILE_PATH "/usr/lib/firmware/vehicle-computer/"
#define VCXFPGAPROGRAMMER_VERSION  "1.2.0"
#ifndef NOT
#define  NOT !
#endif

#ifndef AND
#define AND &&
#endif

#ifndef OR
#define OR ||
#endif


#define bool int
#define FALSE                       0
#define TRUE                        1
#if 0
#define RSWITCH2TOOL_VERSION          "0.0.1"

#define DEFAULT_CONFIG_FILE         "/etc/rst/switch_static.xml"
#define DEFAULT_BIT_FILE         "/home/root/bitfile.bin"


#define ARRAY_SIZE(arr) (sizeof(arr) / sizeof((arr)[0]))
#define MIN(a,b)        (((a)<(b))?(a):(b))
#define MAX(a,b)        (((a)>(b))?(a):(b))
#endif
int             gFDdebug = -1;






bool   configbitfile    = FALSE;
bool   page1_adr_is_set = FALSE;
bool   erasebitfile     = FALSE;
char * gOptBitFile      = "";
char * gProgName        = NULL;
unsigned int         gOpt_FPGA_Address        = 0;
const unsigned int   Fpga_Flash_Memory_Offset = 0x04000000;
unsigned int         Fpga_Page1_Start_Address = 0x01580000;
unsigned int         Fpga_Update_Address      = 0;





/*Getopt options */
static struct option LongOptions[] =
{
    { "help",       no_argument,       NULL, 'h' },
    { "configure",  required_argument, NULL, 'c' },
    { "report",     required_argument, NULL, 'r' },
    { "file",       required_argument, NULL, 'f' },
    { "version",    no_argument,       NULL, 'v' },
    { "erase",      no_argument,       NULL, 'e' },
    {  NULL,        0,                 NULL      },
};

/*
* Usage() : vcxfpgaprogrammer tool help print
*/
void usage(void)
{
    printf("\nVCX Program FPGA Bitfile\n"
    "%s flags \n"
    "  Bit File\n"
    "   -b {file}, --b={file}, --bitfile={file}  Store a new Bitfile in the Flash Memory at StartAddress\n"
    "  Page 1 Start Address in Flash Memory\n"
    "   -p 0x{StartAddess},                      Replace the default Start Address value 0x0158_0000 by a new one\n"
    "                                            StartAddress needs to be 64 kBytes aligned\n"
    "                                            0x0001_0000 <= StartAddress <= 0x7FFF_0000\n"
    "  Erase Flash\n"
    "   -e, --e, --erase                         Erase the Flash Memory starting on the StartAddress\n"
    "  Version number\n"
    "   -v, --v, --version                       Display the version\n"
    "   -h, --h, --help                          Displays help information\n"
    "\n"
    , gProgName);
}

/*
* Close_Drivers() : Close the driver file descriptors
*/
static bool Close_Drivers(void)
{
    
    if (gFDdebug != -1)
    {
        close(gFDdebug);
        gFDdebug = -1;
    }

    return TRUE;
}






static int erase_flash(void)
{
    struct vc2_fpga_pltfrm_memory  Register_New;
    int x = 0;
    int ret = 0;
    int sector_count = 0;
    
    gFDdebug = open(DEVICE_NAME, O_RDWR | O_SYNC);
    if (gFDdebug < 0)
    {
        fprintf(stderr, "ERROR: Open '%s' failed: %d(%s) \n", DEVICE_NAME, errno, strerror(errno));
        return FALSE;
    }
    /* For debugging of one access only
    Register_New.Address = 0x100500C;
    Register_New.value = (Fpga_Update_Address - 0x04000000) / 0x100 + 0x02;
    Register_New.file_write_enable = 0;
    if ((ret = ioctl(gFDdebug, VC2_FPGA_PLTFRM_IOCTL_WRITEBITFILE, &Register_New)) != 0)
        fprintf(stderr, "\nERROR: VC2_FPGA_PLTFRM_IOCTL_WRITEBITFILE failed(%d) on address %08x: %s \n", ret, Register_New.Address, strerror(errno));

    return 0;
    */

    Fpga_Update_Address = Fpga_Flash_Memory_Offset + Fpga_Page1_Start_Address;
    printf("\tStarting Flash Memory Page 1 erasing from address 0x%08x to 0x%08x\n",Fpga_Page1_Start_Address, Fpga_Page1_Start_Address * 2);
    printf("\tErasing of the flash will take around %3d minutes\n", (((2 * (Fpga_Page1_Start_Address / 0x10000)) / 60) + 1));
    
    for(x = (Fpga_Update_Address - 0x04000000) / 0x100 + 0x02; x < (Fpga_Update_Address - 0x04000000) / 0x100 * 2 + 0x02; x=x+0x100)
    {
        
        printf("\t\tErasing Sector 0x%08x",Fpga_Page1_Start_Address + sector_count * 0x10000);
        Register_New.address = 0x100500C;
        Register_New.value = x;
        Register_New.raw = 1;
        if ((ret = ioctl(gFDdebug, VC2_FPGA_PLTFRM_IOCTL_WRITEMEMORY, &Register_New)) != 0)
        {
            fprintf(stderr, "\nERROR: VC2_FPGA_PLTFRM_IOCTL_WRITEMEMORY failed(%d): %s \n", ret, strerror(errno));
            Close_Drivers();
            return 3;
        }


       
        sleep(2);
        sector_count++;
        printf(" -> %3.2f %% of the requested area is erased    \r",(float) sector_count * 0x10000 / Fpga_Page1_Start_Address * 100);
        fflush(stdout);
    }
    printf("\nErasing Flash finished\n\n");
    return 0;




}

static bool Set_RUP(void)
{
    FILE    *bitfilefp = NULL;
    unsigned char *buffer;
    uint32_t filesz = 0;
    int i = 0;
    int ret = 0;
    uint32_t write_word = 0;
    bitfilefp = fopen(gOptBitFile, "rb");

    printf("  Configuring bitfile\n");
    struct vc2_fpga_pltfrm_memory  Register_New;
    if (bitfilefp == NULL)
    {
        fprintf(stderr, "ERROR: unable to open BitFile '%s'-%s\n", gOptBitFile, strerror(errno));
        return FALSE;
    }
    fseek(bitfilefp, 0L, SEEK_END);
    filesz = ftell(bitfilefp);
    rewind(bitfilefp);
    buffer = (char*)malloc(filesz * sizeof(char));
    fread(buffer,filesz,1,bitfilefp);

	//already stripped file?
	if (buffer[0x00] == 0x3a && buffer[0x01] == 0x65 && buffer[0x02] == 0x80 && buffer[0x03] == 0x00 &&
	    buffer[0x04] == 0x20 && buffer[0x05] == 0x00 && buffer[0x06] == 0x00 && buffer[0x07] == 0x00)
	{
        fprintf(stderr, "  Detected as stripped binary\n");
	}
	//to be stripped
	else if (buffer[0x20] == 0x3a && buffer[0x21] == 0x65 && buffer[0x22] == 0x80 && buffer[0x23] == 0x00 &&
	         buffer[0x24] == 0x20 && buffer[0x25] == 0x00 && buffer[0x26] == 0x00 && buffer[0x27] == 0x00)
	{
        fprintf(stderr, "  Detected as un-stripped binary\n");
		buffer += 0x20;
	}
	else {
        fprintf(stderr, "ERROR: Unknown binary format (expect 3a 65 80 00 20 00 00 00)\n");
        return FALSE;
    }

    gFDdebug = open(DEVICE_NAME, O_RDWR | O_SYNC);
    if (gFDdebug < 0)
    {
        fprintf(stderr, "ERROR: Open '%s' failed: %d(%s) \n", DEVICE_NAME, errno, strerror(errno));
        return FALSE;
    }

    printf("  Bitfile will be now stored at Flash Memory Page 1 on address 0x%08x\n",Fpga_Page1_Start_Address);
	//return 0;
	for(i = 0; i < ((filesz+3)/4); i ++)
    {
        write_word =  buffer[(i*4)] | buffer[(i*4) + 1] << 8 | buffer[(i*4) + 2] << 16 | buffer[(i*4) + 3] << 24;
        Register_New.address = Fpga_Update_Address + i*4;
        Register_New.value = write_word;
        Register_New.raw = 1;
        if ((ret = ioctl(gFDdebug, VC2_FPGA_PLTFRM_IOCTL_WRITEMEMORY, &Register_New)) != 0)
        {
            fprintf(stderr, "\nERROR: VC2_FPGA_PLTFRM_IOCTL_WRITEMEMORY failed(%d): %s \n", ret, strerror(errno));
            Close_Drivers();
            return 3;
        }
    }
    printf("  Bitfile stored\n");

    Close_Drivers();
    fclose(bitfilefp);
    return 0;
}














/*
* main()        : Initial main function to the r switch tool
* arg1 - argc   : Count for the user input arguements
* arg2 - argv   : pointer to user input arguements
*/
int main(int argc, char **argv)
{
    int OptCase = 0;
    int OptionIndex = 0;
    char def_bfile_path[100]  = DEFAULT_BITFILE_PATH;
    char *OptArg = NULL;
    DIR *d;
    struct dirent *dir;
    

    gProgName = strchr(argv[0], '/');               //searches user input arguments for the character /
    gProgName = gProgName ? 1+gProgName : argv[0];  //if / is found, then?
    
    
    
    

    while (EOF != (OptCase = getopt_long(argc, argv, "-hf:c:r:vx:y:X:b:p:e", LongOptions, &OptionIndex)))    //Reads user option input until it runs out
    {
        OptArg = optarg;
        switch (OptCase)    //determines which command was received from user
        {
        case 1:
            fprintf(stderr, "\nERROR: Unknown Parameter - %s\n", OptArg);
            usage();
            return 1;
        case 'b':
            gOptBitFile = optarg;

            printf("  Input Bit file : %s\n", gOptBitFile);    //after receiving the file name, outputs it to console
            if( access( gOptBitFile, F_OK ) != -1 )
            {
                printf("Storing new bitfile to Flash Memory Page 1 at 0x%x\n", Fpga_Page1_Start_Address);
                erase_flash();
                Set_RUP();
                configbitfile = 1;
            }
            else
            {
                fprintf(stderr,  "\nERROR: File not present in current path' \n");
                printf("Following files available in default bitfile path %s \n",DEFAULT_BITFILE_PATH);
                d = opendir(DEFAULT_BITFILE_PATH);
                if (d)
                {
                    while ((dir = readdir(d)) != NULL)
                    {
                        if(!strncmp(dir->d_name, ".", 1))
                        {
                            continue;
                        }
                        printf("%s\n", strcat(def_bfile_path,dir->d_name));
                        strcpy(def_bfile_path, DEFAULT_BITFILE_PATH);
                        
                    }
                    closedir(d);
                }
                return 1;
            }
            
            break;
        case 'p':
            //eliminate_(optarg);
            printf("Setting new Flash Memory Page 1 Start Address\n");
            if (sscanf(optarg, "0x%x", &gOpt_FPGA_Address) != 1)
            {
                fprintf(stderr,  "\n\nERROR: command-line format is '-p 0xnnnn to set Flash Memory Page 1 Start Address' \n");
                usage();
                return 1;
            }
            Fpga_Page1_Start_Address = gOpt_FPGA_Address;
            if ((Fpga_Page1_Start_Address * 2) < 0x00010000)
            {
                fprintf(stderr,  "\n\nERROR: Start Address is too small; smallest Start Address is 0x00010000' \n");
                usage();
                return 1;
            }
            if ((Fpga_Page1_Start_Address * 2) > 0x7FFF0000)
            {
                fprintf(stderr,  "\n\nERROR: Start Address is too big; because of this the erasing would go out of memory' \n");
                usage();
                return 1;
            }
            printf("\tNew Flash Memory Page 1 Start Address is now 0x%08x\n\n", Fpga_Page1_Start_Address);
            page1_adr_is_set = 1;
            break;
        case 'e':
            printf("Erasing Flash Memory starting at 0x%x\n", Fpga_Page1_Start_Address);
            erase_flash();
            return 0;
            break;
        case 'v':
            printf("%s  Version : %s\n", gProgName, VCXFPGAPROGRAMMER_VERSION);    //Displays the version
            return 0;
        case 'h':
            usage();
            return 0;
        default:
            fprintf(stderr, "\nERROR: Command-line error - unknown parameter\n");
            usage();
            return 1;
        }
    }


   

    if ((NOT erasebitfile) AND (NOT configbitfile) AND (NOT page1_adr_is_set))    //checks whether anything with ethernet, forwarding engine or registers is being done
    {
        fprintf(stderr, "ERROR : At least '-b' or '-e' are required \n");    //have to select at least one of the three
        usage();
        return 1;
    }

    
    


    

    
    return 0;
}


/*
* Change History
  2020-08-28 0.0.1 AK Initial version
*/

/*
* Local variables:
* Mode: C
* tab-width: 4
* indent-tabs-mode: nil
* c-basic-offset: 4
* End:
* vim: ts=4 expandtab sw=4
*/
