// gcc -Wall -O2 mem.c -o mem

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <stdint.h>
#include <sys/mman.h>

static void usage(char *argv0)
{
	fprintf(stderr, "%s ?options? addr ?value?\n"
		"Read/write value from/to physical address addr\n"
	    "  Options\n"
        "    -b     Byte access (8 bit)\n"
        "    -s     Short access (16 bit)\n"
        "    -w     Word access (32 bit, default)\n"
		"\n"
        "    -a     AND mode. [addr] &= value\n"
        "    -A     AND mode. [addr] &= ~value  (vaue is inverted mask)\n"
        "    -o     OR mode.  [addr] |= value\n"
		"\n"
        "    -r     Print a read back value after read\n"
        "    -v     Verbose, prints also the address\n"
	    "  Parameters\n"
		"    addr    Hexadecimal dump address (0x is optional, '_' are ignored)\n"
		"    value   Hexadecimal value to be written (0x is optional, '_' are ignored)\n"
	    "When no value is given, the current value at addr is printed (read operation)\n"
		"\n"
		"Example:\n"
		"  %s -rv df98_1050 -A 1\n"
		"            Clears the bit [0] at 0xdf981050 and print the read back value\n"
		, argv0, argv0);
	exit(EXIT_FAILURE);
}

static const char short_options[] = "bswaAorv";


int main(int argc, char **argv)
{
	int fd;
	int page_size;
	void *map, *ptr;
	off_t offset;

	long addr, value, old;
	char *s;

//default parameters
	int width = 4;
	int readBack = 0;
	int doWrite = 0;
	int verbose = 0;
	enum {DO, AND, OR, ANDINV} mode = DO;

//parameters from command line
	for (;;) {
		int c;
		if ((c = getopt(argc, argv, short_options)) == -1)
			break;

		switch (c) {
			case 'b' :
				width = 1;
				break;
			case 's' :
				width = 2;
				break;
			case 'w' :
				width = 4;
				break;

			case 'a' :
				mode = AND;
				break;
			case 'A' :
				mode = ANDINV;
				break;
			case 'o' :
				mode = OR;
				break;

			case 'r' :
				readBack = 1;
				break;
			case 'v' :
				verbose = 1;
				break;

			default :
				fprintf(stderr, "Usage:\n");
				usage(argv[0]);
		}
	}

	if (optind+1 != argc && optind+2 != argc) {
		fprintf(stderr, "Error: Incorrect number of parameters\n");
		usage(argv[0]);
	}
	//printf("%d %d\n", optind, argc);

	//addr is always 1st parameter
	s = argv[optind];
	while ((s=strchr(argv[optind], '_')) != NULL)
		strcpy(s, s+1);
	addr = strtoul(argv[optind], &s, 16); /* fix as hex */
	if (*s != 0) {
		fprintf(stderr, "Error: Incorrect address\n");
		usage(argv[0]);
	}

	if (optind+2 == argc) {
		s = argv[optind];
		while ((s=strchr(argv[optind+1], '_')) != NULL)
			strcpy(s, s+1);
		value = strtoul(argv[optind+1], &s, 16); /* fix as hex */
		doWrite = 1;
		if (*s != 0) {
			fprintf(stderr, "Error: Incorrect value number\n");
			usage(argv[0]);
		}
	}
	else
		value = 0;
	//printf("addr=%lx  value=%lx  width=%d  readBack=%d  doWrite=%d  mode=%d\n", addr, value, width, readBack, doWrite, mode);

	if (width != 1 && (addr & (width-1))) {
		fprintf(stderr, "Error: For %d bit access address=%08lx needs to be %d byte alligned\n", width*8, addr, width);
		return -1;
	}
	if (mode != DO && !doWrite) {
		fprintf(stderr, "Error: For '%s' mode a value is required\n", (mode==AND)?"and":"or");
		return -1;
	}

//Map it
	fd = open("/dev/mem", (((doWrite)?O_RDWR:O_RDONLY) | O_SYNC));
	if (fd < 0) {
		fprintf(stderr, "Error: Cannot open \"/dev/mem\" for %s\n", (doWrite)?"writing":"reading");
		return -1;
	}

	page_size = getpagesize();
	offset = addr & ~(page_size-1);

	map = (char*)mmap(NULL, page_size, PROT_READ | ((doWrite)?PROT_WRITE:0), MAP_SHARED, fd, offset);
	if (map == MAP_FAILED) {
		fprintf(stderr, "Error: Cannot map address %lx to %lx\n", offset, offset+page_size-1);
		return -1;
	}
	//move pointer to the correct position
	ptr = (char*)map + (addr & (page_size-1));

//Access it
	if (doWrite) {
		if (verbose)
			printf("[%08lx] = ", addr);
		switch (width) {
		case 4:
			if (mode != DO) {
				old = *(uint32_t*)ptr;
				if (verbose)
					printf("%08lx %s%08lx = ", old, (mode==AND)?"& ":(mode==OR)?"| ":"& ~", value);
				if (mode == AND)
					value &= old;
				else if (mode == ANDINV)
					value = old & ~value;
				else
					value |= old;
			}
			if (verbose)
				printf("%08lx\n", value);
			*(uint32_t*)ptr = value;
			break;
		case 2:
			if (mode != DO) {
				old = *(uint16_t*)ptr;
				if (verbose)
					printf("%04lx %s%04lx = ", old, (mode==AND)?"& ":(mode==OR)?"| ":"& ~", value);
				if (mode == AND)
					value &= old;
				else if (mode == ANDINV)
					value = old & ~value;
				else
					value |= old;
			}
			if (verbose)
				printf("%04lx\n", value);
			*(uint16_t*)ptr = value;
			break;
		default: //1
			if (mode != DO) {
				old = *(uint8_t*)ptr;
				if (verbose)
					printf("%02lx %s%02lx = ", old, (mode==AND)?"& ":(mode==OR)?"| ":"& ~", value);
				if (mode == AND)
					value &= old;
				else if (mode == ANDINV)
					value = old & ~value;
				else
					value |= old;
			}
			if (verbose)
				printf("%02lx\n", value);
			*(uint8_t*)ptr = value;
			break;
		}
	}

	if (!doWrite || readBack) {
		if (verbose)
			printf("[%08lx] is ", addr);
		switch (width) {
		case 4:
			printf("%08x\n", *((uint32_t*)ptr));
			break;
		case 2:
			printf("%04x\n", *((uint16_t*)ptr));
			break;
		default: //1
			printf("%02x\n", *((uint8_t*)ptr));
			break;
		}
	}



#if 0
		end = 16;
		for (int i=0; lines && o<page_size; i++) {
			if (lines == 1)
				end = lend;
			//printf("\033[36m  start=%d  lines=%d  end=%d  addr=%lx  i=%d\033[m\n", start, lines, end, addr, i);
			printf("%04lx_%04lx: ", addr>>16, addr&0xfff0);
			for (int j=0; j<16/width; j++) {
				if (j<start || j>end) {
					switch (width) {
					case 4:
						printf("           ");
						break;
					case 2:
						printf("     ");
						break;
					default: //1
						printf("   ");
						break;
					}
				}
				else {
					if (width==4) {
						uint32_t v = ((int32_t*)&map[o])[0];
						if (tty && ((v==0) != ttyState)) {
							ttyState = (v==0);
							printf((ttyState) ? "\033[%s;1m" : "\033[m", colour);
						}
						printf(" %04x_%04x ", v>>16, v&0xffff);
					}
					else if (width==2) {
						uint16_t v = ((int16_t*)&map[o])[0];
						if (tty && ((v==0) != ttyState)) {
							ttyState = (v==0);
							printf((ttyState) ? "\033[%s;1m" : "\033[m", colour);
						}
						printf(" %04x", ((int16_t*)&map[o])[0]&0xffff);
					}
					else {
						uint8_t v = ((int8_t*)&map[o])[0];
						if (tty && ((v==0) != ttyState)) {
							ttyState = (v==0);
							printf((ttyState) ? "\033[%s;1m" : "\033[m", colour);
						}
						printf(" %02x", map[o]&0xff);
					}
					o += width;
				}
				if (j%4==3)
					printf(" ");
			}

			if (width==1) {
				o -= 16;
				printf(" ");
				for (int j=0; j<16/width; j++) {
					unsigned char c = map[o];
					if (c < 0x20 || c >= 0x7f) c = '.';
					printf((j<start || j>end)?" ":"%c", c);
					if (j%8==7)
						printf(" ");
					o++;
				}
			}

			if (ttyState) {
				ttyState = 0;
				printf("\033[m");
			}

			printf("\n");
			start = 0;
			addr = (addr&~15) + 16;
			lines--;
		}
#endif

	if (munmap(map, page_size) == -1) {
		fprintf(stderr, "Error: Cannot unmap address %lx\n", offset);
		return -1;
	}

	close(fd);
	return 0;
}
