// gcc -Wall -O2 dump.c -o dump

#define MAXCNT    0x4000
#define DEFCNT    0x0080
#define ZEROCOLOR "37"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <stdint.h>
#include <sys/mman.h>

static void usage(char *argv0)
{
	fprintf(stderr, "%s ?options? addr ?cnt?\n"
		"Dumps cnt bytes from physical address addr\n"
	    "  Options\n"
        "    -w n    Width of n-byte numbers (n=1,2,4). Default is 4\n"
	    "    -c n    Colour code of zero numbers. Default is %s (white)\n"
	    "  Parameters\n"
		"    addr    Hexadecimal dump address (0x is optional, '_' are ignored)\n"
		"    cnt     Number of printed bytes. Default is %d. Maximum is 0x%x\n"
	    "Colour codes are only generated on tty output. Use these vt100 codes\n"
	    "  30:black 31:red 32:green 33:yellow 34:blue 35:magenta 36:cyan 37:white\n"
		, argv0, ZEROCOLOR, DEFCNT, MAXCNT);
	exit(EXIT_FAILURE);
}

static const char short_options[] = "w:c:";


int main(int argc, char **argv)
{
	int fd;
	int page_size;
	char *map;
	off_t offset;

	long addr;
	int cnt;
	int width;
	int start, lines, end, lend;
	int o;
	char *s;
	const char *colour;

//Check if stdout is a tty, if not colour codes are disabled
	int tty, ttyState;
	tty = isatty(fileno(stdout));

//default parameters
	cnt = DEFCNT;
	width = 4;
	colour = ZEROCOLOR;

//parameters from command line
	for (;;) {
		int c;
		if ((c = getopt(argc, argv, short_options)) == -1)
			break;

		switch (c) {
			case 'w' :
				width = strtoul(optarg, &s, 0);  /* allows hex, oct etc */
				if ((width != 1 && width != 2 && width != 4) || *s != 0) {
					fprintf(stderr, "Error: Parameter -w%d is out of range\n", width);
					usage(argv[0]);
				}
				break;

			case 'c' :
				colour = optarg;
				break;

			default :
				fprintf(stderr, "Error: Unknown parameter \"%c\"\n", c);
				usage(argv[0]);
		}
	}

	if (optind+1 != argc && optind+2 != argc) {
		fprintf(stderr, "Error: Incorrect number of parameters\n");
		usage(argv[0]);
	}

	//addr is always 1st parameter
	s = argv[optind];
	while ((s=strchr(argv[optind], '_')) != NULL)
		strcpy(s, s+1);
	addr = strtoul(argv[optind], &s, 16); /* fix to hex */
	if (*s != 0) {
		fprintf(stderr, "Error: Incorrect address\n");
		usage(argv[0]);
	}

	if (optind+2 == argc) {
		cnt = strtoul(argv[optind+1], &s, 0); /* allows hex, oct etc */
		if (cnt <= 0 || cnt > MAXCNT || *s != 0) {
			fprintf(stderr, "Error: Invalid cnt parameter\n");
			usage(argv[0]);
		}
	}
	//printf("addr=%lx  cnt=%x  width=%d  colour='%s'\n", addr, cnt, width, colour);

	if (width != 1 && (addr & (width-1) || (addr+cnt) & (width-1))) {
		fprintf(stderr, "Error: For %d bit access address=%08lx to %08lx needs to be %d byte alligned\n", width*8, addr, addr+cnt, width);
		return -1;
	}
	//return 0;

//And dump
	fd = open("/dev/mem", (O_RDONLY | O_SYNC));
	if (fd < 0) {
		fprintf(stderr, "Error: Cannot open \"/dev/mem\" for reading\n");
		return -1;
	}
	page_size = getpagesize();

	lines = (cnt+(addr & 0x0f)+15)/16;

	switch (width) {
	case 4:
		printf(" Address    +00        +04        +08        +0C\n"
				"------------------------------------------------------\n");
		break;
	case 2:
		printf(" Address    +00       +04        +08       +0C\n"
				"----------------------------------------------------\n");
		break;
	default: //1
		printf(" Address    +00          +04          +08          +0C          ASCII\n"
				"--------------------------------------------------------------  -----------------\n");
		break;
	}

	ttyState = 0;
	while (lines) {

		offset = addr & ~(page_size-1);
		o = addr & (page_size-1);
		start = (addr & 0x0f) / width;
		lend = ((addr + cnt -1) & 0x0f) / width;
		//printf("\033[36m  addr=%lx  page_size=%x  offset=%lx  o=%x  lines=%d  start=%d  lend=%d\033[m\n", addr, page_size, offset, o, lines, start, lend);

		map = (char*)mmap(NULL, page_size, PROT_READ, MAP_SHARED, fd, offset);
		if (map == MAP_FAILED) {
			fprintf(stderr, "Error: Cannot open map address %lx to %lx\n", offset, offset+page_size);
			return -1;
		}

		end = 16;
		for (int i=0; lines && o<page_size; i++) {
			if (lines == 1)
				end = lend;
			//printf("\033[36m  start=%d  lines=%d  end=%d  addr=%lx  i=%d\033[m\n", start, lines, end, addr, i);
			printf("%04lx_%04lx: ", addr>>16, addr&0xfff0);
			for (int j=0; j<16/width; j++) {
				if (j<start || j>end) {
					switch (width) {
					case 4:
						printf("           ");
						break;
					case 2:
						printf("     ");
						break;
					default: //1
						printf("   ");
						break;
					}
				}
				else {
					if (width==4) {
						uint32_t v = ((int32_t*)&map[o])[0];
						if (tty && ((v==0) != ttyState)) {
							ttyState = (v==0);
							printf((ttyState) ? "\033[%s;1m" : "\033[m", colour);
						}
						printf(" %04x_%04x ", v>>16, v&0xffff);
					}
					else if (width==2) {
						uint16_t v = ((int16_t*)&map[o])[0];
						if (tty && ((v==0) != ttyState)) {
							ttyState = (v==0);
							printf((ttyState) ? "\033[%s;1m" : "\033[m", colour);
						}
						printf(" %04x", ((int16_t*)&map[o])[0]&0xffff);
					}
					else {
						uint8_t v = ((int8_t*)&map[o])[0];
						if (tty && ((v==0) != ttyState)) {
							ttyState = (v==0);
							printf((ttyState) ? "\033[%s;1m" : "\033[m", colour);
						}
						printf(" %02x", map[o]&0xff);
					}
					o += width;
				}
				if (j%4==3)
					printf(" ");
			}

			if (width==1) {
				o -= 16;
				printf(" ");
				for (int j=0; j<16/width; j++) {
					unsigned char c = map[o];
					if (c < 0x20 || c >= 0x7f) c = '.';
					printf((j<start || j>end)?" ":"%c", c);
					if (j%8==7)
						printf(" ");
					o++;
				}
			}

			if (ttyState) {
				ttyState = 0;
				printf("\033[m");
			}

			printf("\n");
			start = 0;
			addr = (addr&~15) + 16;
			lines--;
		}

		if (munmap(map, page_size) == -1) {
			fprintf(stderr, "Error: Cannot unmap address %lx\n", offset);
			return -1;
		}
	}


	close(fd);
	return 0;
}
