#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <stdint.h>
#include <sys/mman.h>

#define RSW2_BASE_FPGA   0xC9040000   //VC3
#define RSW2_BASE_S4     0xe68c0000   //VC4
#define RSW3_BASE_FPGA   0x30000000   //VC4+FPGA
#define RSW2_SIZE        0x00030000

// #define RSW2_BASE_SERDES 0xE6444000   //VC4
// #define RSW2_SIZE_SERDES 0x1000

#include "rswitch.h"

#define MAX_DATA 0x1000


static volatile uint32_t *rsw2;
static volatile uint32_t *rmac;
static int isRSW2 = 1;

static int do_read = 0;
static int do_write = 0;
int port = -1;
int id = -1;
int dev = -1;
int reg = -1;
int data[MAX_DATA];
int datacnt = 0;
int readcnt = 1;
int verbose = 0;

#define CLAUSE22 -2


//------------------------------------------------------------------------------
static void usage(char *argv0)
{
	fprintf(stderr, "%s ?options? action port id dev reg ?data ...?\n"
	    "Dumps the RSW2 status\n"
	    "  Options:\n"
	    "    -f          Use VC3/FPGA base address %08x instead of S4 %08x\n"
	    "    -F          Use VC4/FPGA base address %08x instead\n"
		"    -n N        Specifies number or reads (default 1)\n"
		"    -v          Verbose mode\n"
	    "  action:       (at any position in  parameter list)\n"
	    "    read        read from PHY via MDIO\n"
	    "    write       write to PHY via MDIO\n"
	    "  port          interface number (0 to %d)\n"
		"  id            PHY id (MDI address)\n"
	    "  dev           sub-device number in PHY. Use . for Clause 22 access\n"
	    "  reg           register number in PHY\n"
	    "  data          data to be written (up to %d / %x)\n"
		"\n"
		"Example\n"
		"%s read 0 1 3 1 0x901    --read the link register for88Q2112 on port=0 id=3\n"
	    , argv0
	    , RSW2_BASE_FPGA, RSW2_BASE_S4, RSW3_BASE_FPGA
		, RSWITCH_MAX_NUM_ETHA-1
		, MAX_DATA, MAX_DATA
		, argv0
	);
	exit(EXIT_FAILURE);
}


//------------------------------------------------------------------------------
static inline uint32_t read32(unsigned offset)
{
	//printf("\nread32(%x) as rmac[%x / %x]\n", offset, offset/4, offset); fflush(stdout);
	//usleep(10000);
	return rmac[offset/4];
}

static inline void write32(unsigned offset, uint32_t data)
{
	//printf("\nwrite32(%x, %x) to rmac[%x / %x]\n", offset, data, offset/4, offset); fflush(stdout);
	//usleep(10000);
	rmac[offset/4] = data;
}


static int waitPoll(unsigned offset, unsigned shift, unsigned mask, unsigned exp)
{
	uint32_t value;
	for (int i = 0; i < 5; i++) {
		value = read32(offset);
		if (((value >> shift) & mask) == exp)
			return value;
		usleep(100);
	}
	fprintf(stderr, "Error timeout when read rsw2[%x / %x].  value=%08x  shift=%d  mask=%08x  exp=%08x\n",
		offset/4, offset, value, shift, mask, exp);
	exit(-1);
}

#define MPSM  0x000
#define MPIC  0x004
#define MMIS1 0x220
#define MMIS1_PAACS 2
#define MMIS1_PRACS 0

//------------------------------------------------------------------------------
uint32_t mdio_read(int id, int dev, int reg)
{
	uint32_t addr;
	uint32_t ret;

	if (dev == CLAUSE22) {
		addr = (reg << 8) | (id << 3);

		/* Read frame */
		write32(MPSM, (2<<13) | addr | 9);
		waitPoll(MPSM, 0, 1, 0);

		ret = read32(MPSM) >> 16;
	}
	else {
		addr = (reg << 16) | (dev << 8) | (id << 3);

		/* Clear completion flags */
		write32(MMIS1, 0x0f);

		/* Submit address to PHY (MDIO_ADDR_C45 << 13) */
		write32(MPSM, (0<<13) | addr | 5);
		waitPoll(MMIS1, MMIS1_PAACS, 1, 1);
		/* Clear address completion flag */
		write32(MMIS1, 1<<MMIS1_PAACS);

		/* Read PHY register */
		write32(MPSM, (3<<13) | addr | 5);
		waitPoll(MMIS1, MMIS1_PRACS, 1, 1);
		ret = read32(MPSM) >> 16;
		/* Clear read completion flag */
		write32(MMIS1, 1<<MMIS1_PRACS);
	}
	return ret;
}

//------------------------------------------------------------------------------
int main(int argc, char **argv)
{
	int fd;
	int page_size;
	long addr, etha_offset;
	uint32_t v;
	//char *s;

	//check the alignment
	page_size = getpagesize();
	addr = RSW2_BASE_S4;
	if ((addr & ~(page_size-1)) != addr) {
		fprintf(stderr, "CPU page size of %08x does not fit to RSW2 base address %08lx\n", page_size, addr);
		return -1;
	}

	//parameters from command line
	if (argc <= 1)
		usage(argv[0]);
	for (int i=1; i< argc; i++) {
		if (!strcmp("read", argv[i]))
			do_read = 1;
		else if (!strcmp("write", argv[i]))
			do_write = 1;

		else if (!strcmp("-f", argv[i]))
			addr = RSW2_BASE_FPGA;
		else if (!strcmp("-v", argv[i]))
			verbose = 1;
		else if (!strcmp("-F", argv[i])) {
			addr = RSW3_BASE_FPGA;
			isRSW2 = 0;
		}
		else if (!strcmp("-n", argv[i])) {
			char *end;
			readcnt = strtol(argv[i+1], &end, 0);
			if (*end || readcnt >= MAX_DATA  || readcnt<=0) {
				fprintf(stderr, "Invalid number read data requested\n");
				return -1;
			}
		}
		else if (!strcmp(".", argv[i])) {
			dev = CLAUSE22;
		}
		else {
			long v;
			char *end;
			v = strtol(argv[i], &end, 0);
			//printf("%ld %d\n", v, *end);
			if (*end || v < 0 || datacnt>=MAX_DATA) { // not a complete integer
				fprintf(stderr, "Unexpected parameter '%s'.\n", argv[i]);
				usage(argv[0]);
			}
			if (port==-1) {
				port = v;
				if (port >= RSWITCH_MAX_NUM_ETHA) {
					fprintf(stderr, "port number %d out of range\n", port);
					return -1;
				}
			}
			else if (id==-1) {
				id = v;
				if ((id&0x1f)!=id) {
					fprintf(stderr, "PHY id %d out of range\n", id);
					return -1;
				}
			}
			else if (dev==-1) {
				dev = v;
				if ((dev&0x1f)!=dev) {
					fprintf(stderr, "sub-device number %d/%x out of range\n", dev, dev);
					return -1;
				}
			}
			else if (reg==-1) {
				reg = v;
				if ((reg&0xffff)!=reg || (dev==CLAUSE22 && (reg&0x1f)!=reg)) {
					fprintf(stderr, "port number %d/%x out of range\n", reg, reg);
					return -1;
				}
			}
			else {
				data[datacnt] = v;
				datacnt++;
			}
		}
	}
	if (isRSW2)
		etha_offset = 0xa000 + 0x2000 * port;
	else
		etha_offset = 0x1d000 + 0x2000 * port;
	if (verbose) {
		if (dev != CLAUSE22)
			fprintf(stderr, "#MDIO %04lx_%04lx C45:  port=%d  id=%d  dev=%d/%x  reg=%d/%x  #data=%d/%x\n", (addr+etha_offset+0x1000)>>16, (addr+etha_offset+0x1000)&0xffff, port, id, dev, dev, reg, reg, datacnt, datacnt);
		else
			fprintf(stderr, "#MDIO %04lx_%04lx C22:  port=%d  id=%d  reg=%d/%x  #data=%d/%x\n", (addr+etha_offset+0x1000)>>16, (addr+etha_offset+0x1000)&0xffff, port, id, reg, reg, datacnt, datacnt);
	}

	if (reg==-1) {
		fprintf(stderr, "Missing phy register address\n");
		return -1;
	}
	if (do_write && datacnt==0) {
		fprintf(stderr, "Missing data for writing\n");
		return -1;
	}
	if (!do_write && !do_read) {
		fprintf(stderr, "Missing read|write\n");
		return -1;
	}


	//open the memory dump
	fd = open("/dev/mem", (O_RDWR | O_SYNC));
	if (fd < 0) {
		fprintf(stderr, "Error: Cannot open \"/dev/mem\" for reading\n");
		return -1;
	}

	//map the RSW2/RMAC SFR
	//printf("Use RSW2 @%08lx + %x\n", addr, (RSW2_SIZE+page_size-1)/page_size*page_size);
	rsw2 = (uint32_t*) mmap(NULL, (RSW2_SIZE+page_size-1)/page_size*page_size, PROT_READ|PROT_WRITE, MAP_SHARED, fd, addr);
	rmac = &rsw2[(etha_offset+0x1000)/4];

	//Check if RSW2 is clocked
	if (isRSW2 && rsw2[0x9000/4]!=0x00112222) {
		fprintf(stderr, "Cannot read version of RSW2. Not clocked? (read %08x)\n", rsw2[0x9000/4]);
		return -1;
	}
	else if (!isRSW2 && rsw2[0x1c000/4]!=0x00333333) {
		fprintf(stderr, "Cannot read version of RSW3. FPGA connected? (read %08x)\n", rsw2[0x9000/4]);
		return -1;
	}
	//Check if ETHA is clocked
	if (isRSW2 && (rsw2[0x9008/4]&0x10003) != 0x10003) {
		fprintf(stderr, "ETHA not active. Driver loaded? (read %08x)\n", rsw2[0x9008/4]);
		return -1;
	}
	else if (!isRSW2 && (rsw2[0x1c008/4]&0x10003) != 0x10003) {
		fprintf(stderr, "ETHA not active.  Driver loaded? (read %08x)\n", rsw2[0x1c008/4]);
		return -1;
	}

	//printf("MPSM=%08x  %08x \n", read32(MPSM), rsw2[((0x1d000+0x2000*port)+0x1000+MPSM)/4]);
	//printf("MPIC=%08x  %08x \n", read32(MPIC), rsw2[((0x1d000+0x2000*port)+0x1000+MPIC)/4]);

	if (do_read) {
		for (int i=0; i<readcnt; i++) {
			v = mdio_read(id, dev, reg);
			if (readcnt != 1)
				printf("%d:%04x %04x\n", dev, reg, v);
			else
				printf("%04x\n", v);
			reg++;
		}
	}

	//All done
	close(fd);
	return 0;
}

