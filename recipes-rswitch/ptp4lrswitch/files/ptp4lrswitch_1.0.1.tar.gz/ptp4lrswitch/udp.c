/**
 * @file udp.c
 * @note Copyright (C) 2011 Richard Cochran <richardcochran@gmail.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <net/if.h>
#include <netdb.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <unistd.h>

#include "contain.h"
#include "print.h"
#include "sk.h"
#include "ether.h"
#include "transport_private.h"
#include "udp.h"

#define EVENT_PORT        319
#define GENERAL_PORT      320
#define PTP_PRIMARY_MCAST_IPADDR "224.0.1.129"
#define PTP_PDELAY_MCAST_IPADDR  "224.0.0.107"

struct udp {
	struct transport t;
	uint8_t ip[4];
	int ip_len;
	uint8_t mac[MAC_LEN];
	int mac_len;
};

static int mcast_bind(int fd, int index)
{
	int err;
	struct ip_mreqn req;
	memset(&req, 0, sizeof(req));
	req.imr_ifindex = index;
	err = setsockopt(fd, IPPROTO_IP, IP_MULTICAST_IF, &req, sizeof(req));
	if (err) {
		pr_err("setsockopt IP_MULTICAST_IF failed: %m");
		return -1;
	}
	return 0;
}

static int mcast_join(int fd, int index, const struct sockaddr *grp, socklen_t grplen)
{
	int err, off = 0;
	struct ip_mreqn req;
	struct sockaddr_in *sa = (struct sockaddr_in *) grp;

	memset(&req, 0, sizeof(req));
	memcpy(&req.imr_multiaddr, &sa->sin_addr, sizeof(struct in_addr));
	req.imr_ifindex = index;
	err = setsockopt(fd, IPPROTO_IP, IP_ADD_MEMBERSHIP, &req, sizeof(req));
	if (err) {
		pr_err("setsockopt IP_ADD_MEMBERSHIP failed: %m");
		return -1;
	}
	err = setsockopt(fd, IPPROTO_IP, IP_MULTICAST_LOOP, &off, sizeof(off));
	if (err) {
		pr_err("setsockopt IP_MULTICAST_LOOP failed: %m");
		return -1;
	}
	return 0;
}

static int udp_close(int PortNumber, struct transport *t, struct fdarray *fda)
{
	close(fda->fd[0]);
	close(fda->fd[1]);
	return 0;
}

static int open_socket(const char *name, struct in_addr mc_addr[2], short port)
{
	struct sockaddr_in addr;
	int fd, index, on = 1;

	memset(&addr, 0, sizeof(addr));
	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = htonl(INADDR_ANY);
	addr.sin_port = htons(port);

	fd = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP);
	if (fd < 0) {
		pr_err("Port %s: socket failed: %m", name);
		goto no_socket;
	}
	index = sk_interface_index(fd, name);
	if (index < 0)
		goto no_option;

	if (setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on))) {
		pr_err("Port %s: setsockopt SO_REUSEADDR failed: %m", name);
		goto no_option;
	}
	if (bind(fd, (struct sockaddr *) &addr, sizeof(addr))) {
		pr_err("Port %s: bind failed: %m", name);
		goto no_option;
	}
	if (setsockopt(fd, SOL_SOCKET, SO_BINDTODEVICE, name, strlen(name))) {
		pr_err("Port %s: setsockopt SO_BINDTODEVICE failed: %m", name);
		goto no_option;
	}
	addr.sin_addr = mc_addr[0];
	if (mcast_join(fd, index, (struct sockaddr *) &addr, sizeof(addr))) {
		pr_err("Port %s: mcast_join failed", name);
		goto no_option;
	}
	addr.sin_addr = mc_addr[1];
	if (mcast_join(fd, index, (struct sockaddr *) &addr, sizeof(addr))) {
		pr_err("Port %s: mcast_join failed", name);
		goto no_option;
	}
	if (mcast_bind(fd, index)) {
		goto no_option;
	}
	return fd;
no_option:
	close(fd);
no_socket:
	return -1;
}

enum { MC_PRIMARY, MC_PDELAY };

static struct in_addr mcast_addr[2];

static int udp_open(int PortNumber, struct transport *t, const char *name, struct fdarray *fda,
		    enum timestamp_type ts_type)
{
	struct udp *udp = container_of(t, struct udp, t);
	int efd, gfd;

	udp->mac_len = 0;
	if (sk_interface_macaddr(PortNumber, name, udp->mac, MAC_LEN) == 0)
		udp->mac_len = MAC_LEN;

	udp->ip_len = sk_interface_addr(PortNumber, name, AF_INET, udp->ip, sizeof(udp->ip));
	if (udp->ip_len == -1)
		udp->ip_len = 0;

	if (!inet_aton(PTP_PRIMARY_MCAST_IPADDR, &mcast_addr[MC_PRIMARY]))
		return -1;

	if (!inet_aton(PTP_PDELAY_MCAST_IPADDR, &mcast_addr[MC_PDELAY]))
		return -1;

	efd = open_socket(name, mcast_addr, EVENT_PORT);
	if (efd < 0)
		goto no_event;

	gfd = open_socket(name, mcast_addr, GENERAL_PORT);
	if (gfd < 0)
		goto no_general;

	if (sk_timestamping_init(PortNumber, efd, name, ts_type, TRANS_UDP_IPV4))
		goto no_timestamping;

	if (sk_general_init(PortNumber, gfd))
		goto no_timestamping;

	fda->fd[FD_EVENT] = efd;
	fda->fd[FD_GENERAL] = gfd;
	return 0;

no_timestamping:
	close(gfd);
no_general:
	close(efd);
no_event:
	return -1;
}

static int udp_recv(int PortNumber, struct transport *t, int fd, void *buf, int buflen, struct hw_timestamp *hwts)
{
	return sk_receive(PortNumber, fd, buf, buflen, hwts, 0);
}

static int udp_send(int PortNumber, struct transport *t, struct fdarray *fda, int event, int peer,
		    void *buf, int len, struct hw_timestamp *hwts)
{
	ssize_t cnt;
	int fd = event ? fda->fd[FD_EVENT] : fda->fd[FD_GENERAL];
	struct sockaddr_in addr;
	unsigned char junk[1600];

	memset(&addr, 0, sizeof(addr));
	addr.sin_family = AF_INET;
	addr.sin_addr = peer ? mcast_addr[MC_PDELAY] : mcast_addr[MC_PRIMARY];
	addr.sin_port = htons(event ? EVENT_PORT : GENERAL_PORT);

	/*
	 * Extend the payload by two, for UDP checksum correction.
	 * This is not really part of the standard, but it is the way
	 * that the phyter works.
	 */
	if (event == TRANS_ONESTEP)
		len += 2;

	cnt = sendto(fd, buf, len, 0, (struct sockaddr *)&addr, sizeof(addr));
	if (cnt < 1) {
		pr_err("PortDev[%u] sendto failed: %m", PortNumber);
		return cnt;
	}
	/*
	 * Get the time stamp right away.
	 */
	return event == TRANS_EVENT ? sk_receive(PortNumber, fd, junk, len, hwts, MSG_ERRQUEUE) : cnt;
}

static void udp_release(struct transport *t)
{
	struct udp *udp = container_of(t, struct udp, t);
	free(udp);
}

static int udp_physical_addr(int PortNumber, struct transport *t, uint8_t *addr)
{
	struct udp *udp = container_of(t, struct udp, t);
	if (udp->mac_len)
		memcpy(addr, udp->mac, udp->mac_len);
	return udp->mac_len;
}

static int udp_protocol_addr(int PortNumber, struct transport *t, uint8_t *addr)
{
	struct udp *udp = container_of(t, struct udp, t);
	if (udp->ip_len)
		memcpy(addr, &udp->ip, udp->ip_len);
	return udp->ip_len;
}

struct transport *udp_transport_create(void)
{
	struct udp *udp = calloc(1, sizeof(*udp));
	if (!udp)
		return NULL;
	udp->t.close = udp_close;
	udp->t.open  = udp_open;
	udp->t.recv  = udp_recv;
	udp->t.send  = udp_send;
	udp->t.release = udp_release;
	udp->t.physical_addr = udp_physical_addr;
	udp->t.protocol_addr = udp_protocol_addr;
	return &udp->t;
}
