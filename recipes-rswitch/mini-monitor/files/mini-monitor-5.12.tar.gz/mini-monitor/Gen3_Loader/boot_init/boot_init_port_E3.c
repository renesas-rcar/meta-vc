/**********************************************************/
/* Sample program : PORT initialization                   */
/* File Name      : boot_init_port.c                      */
/* Copyright (C) Renesas Electronics Corp. 2018.          */
/**********************************************************/

//=========================================================
//===== Setting for R-Car E3 ==============================
//=========================================================

#include "common.h"
#include "reg_rcargen3.h"
#include "boot_init_port_E3.h"
#include "boardid.h"


#define PFC_WR(m,n)   *((volatile uint32_t*)PFC_PMMR)=~(n);*((volatile uint32_t*)(m))=(n);

void InitPORT_E3(void)
{
#ifdef D3_V3M_E3
	InitMODSEL();
	InitIPSR();
	InitGPSR();
	InitIOCTRL();
	InitPUD();
	InitPUEN();
#endif
}

#ifdef D3_V3M_E3
//===== Static function ===================================

static void InitMODSEL(void)
{
	if(CHK_EBISU_ST){		// Ebisu Standard
		PFC_WR(PFC_MOD_SEL0,0x00000800);
		PFC_WR(PFC_MOD_SEL1,0x10000000);
	}else{					// Ebisu Specific
		PFC_WR(PFC_MOD_SEL0,0x00000000);
		PFC_WR(PFC_MOD_SEL1,0x00000000);
	}
}

static void InitIPSR(void)
{
	InitIPSR_SPI_E3();
}

static void InitGPSR(void)
{
	InitGPSR_SPI_E3();
}

static void InitIPSR_SPI_E3(void)
{
	if(CHK_EBISU_ST){		// Ebisu Standard
		PFC_WR(PFC_IPSR0,0x00000000);
		PFC_WR(PFC_IPSR1,0x00000000);
		PFC_WR(PFC_IPSR2,0x15620000);
		PFC_WR(PFC_IPSR3,0x50045551);
		PFC_WR(PFC_IPSR4,0x55555555);
		PFC_WR(PFC_IPSR5,0x55555555);
		PFC_WR(PFC_IPSR6,0x55525505);
		PFC_WR(PFC_IPSR7,0x00550115);
		PFC_WR(PFC_IPSR8,0x00000000);
		PFC_WR(PFC_IPSR9,0x00000000);
		PFC_WR(PFC_IPSR10,0x00000000);
		PFC_WR(PFC_IPSR11,0x08220000);
		PFC_WR(PFC_IPSR12,0x00000020);
		PFC_WR(PFC_IPSR13,0x00000011);
		PFC_WR(PFC_IPSR14,0x30000000);
		PFC_WR(PFC_IPSR15,0x00011003);
	}else{					// Ebisu Specific
		PFC_WR(PFC_IPSR0,0x00000000);
		PFC_WR(PFC_IPSR1,0x00000000);
		PFC_WR(PFC_IPSR2,0x05600000);
		PFC_WR(PFC_IPSR3,0x00000001);
		PFC_WR(PFC_IPSR4,0x00000000);
		PFC_WR(PFC_IPSR5,0x00000000);
		PFC_WR(PFC_IPSR6,0x00000000);
		PFC_WR(PFC_IPSR7,0x00000000);
		PFC_WR(PFC_IPSR8,0x00000000);
		PFC_WR(PFC_IPSR9,0x00000000);
		PFC_WR(PFC_IPSR10,0x00000000);
		PFC_WR(PFC_IPSR11,0x00000000);
		PFC_WR(PFC_IPSR12,0x00000000);
		PFC_WR(PFC_IPSR13,0x00000000);
		PFC_WR(PFC_IPSR14,0x00000000);
		PFC_WR(PFC_IPSR15,0x00000000);
	}
}

static void InitGPSR_SPI_E3(void)
{
	if(CHK_EBISU_ST){		// Ebisu Standard
		PFC_WR(PFC_GPSR0,0x0001BFEF);
		PFC_WR(PFC_GPSR1,0x006FFF3F);
		PFC_WR(PFC_GPSR2,0x0FBFFFFF);
		PFC_WR(PFC_GPSR3,0x00007FFF);
		PFC_WR(PFC_GPSR4,0x000007FF);
		PFC_WR(PFC_GPSR5,0x0000C399);
		PFC_WR(PFC_GPSR6,0x00039FEF);
	}else{					// Ebisu Specific
		PFC_WR(PFC_GPSR0,0x00000000);
		PFC_WR(PFC_GPSR1,0x00000002);
		PFC_WR(PFC_GPSR2,0x0F2FFFFF);
		PFC_WR(PFC_GPSR3,0x00000000);
		PFC_WR(PFC_GPSR4,0x000007FF);
		PFC_WR(PFC_GPSR5,0x00000300);
		PFC_WR(PFC_GPSR6,0x00000000);
	}
}

static void InitIOCTRL(void)
{
	if(CHK_EBISU_ST){		// Ebisu Standard
		PFC_WR(PFC_IOCTRL30,0x0007FFFF);
		PFC_WR(PFC_IOCTRL32,0xFFFFFFFE);
		PFC_WR(PFC_IOCTRL40,0x00000000);
	}else{					// Ebisu Specific
		PFC_WR(PFC_IOCTRL30,0x0007FFFF);
		PFC_WR(PFC_IOCTRL32,0xFFFFFFFE);
		PFC_WR(PFC_IOCTRL40,0x00000000);
	}
}

static void InitPUD(void)
{
	if(CHK_EBISU_ST){		// Ebisu Standard
		PFC_WR(PFC_PUD0,0x00080000);
		PFC_WR(PFC_PUD1,0xCE398464);
		PFC_WR(PFC_PUD2,0xA4C380F4);
		PFC_WR(PFC_PUD3,0x0000079F);
		PFC_WR(PFC_PUD4,0xFFF0FFFF);
		PFC_WR(PFC_PUD5,0x40000000);
	}else{					// Ebisu Specific
		PFC_WR(PFC_PUD0,0x000BF003);
		PFC_WR(PFC_PUD1,0xCFFFFFFF);
		PFC_WR(PFC_PUD2,0xFFE380F7);
		PFC_WR(PFC_PUD3,0xFFC0079F);
		PFC_WR(PFC_PUD4,0xFFFEFFFF);
		PFC_WR(PFC_PUD5,0xC0000000);
	}
}

static void InitPUEN(void)
{
	if(CHK_EBISU_ST){		// Ebisu Standard
		PFC_WR(PFC_PUEN0,0x00000000);
		PFC_WR(PFC_PUEN1,0x00300000);
		PFC_WR(PFC_PUEN2,0x00400074);
		PFC_WR(PFC_PUEN3,0x00000000);
		PFC_WR(PFC_PUEN4,0x07900600);
		PFC_WR(PFC_PUEN5,0x00000000);
	}else{					// Ebisu Specific
		PFC_WR(PFC_PUEN0,0x0003F003);
		PFC_WR(PFC_PUEN1,0x0BFFFFFF);
		PFC_WR(PFC_PUEN2,0xFFE30077);
		PFC_WR(PFC_PUEN3,0xFFC0079F);
		PFC_WR(PFC_PUEN4,0x207EF9E7);
		PFC_WR(PFC_PUEN5,0xC0000000);
	}
}
#endif
