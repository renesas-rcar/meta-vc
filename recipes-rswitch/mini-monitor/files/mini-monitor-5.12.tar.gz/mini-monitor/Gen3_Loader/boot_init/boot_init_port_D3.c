/**********************************************************/
/* Sample program : PORT initialization                   */
/* File Name      : boot_init_port.c                      */
/* Copyright (C) Renesas Electronics Corp. 2016.          */
/**********************************************************/

//=========================================================
//===== Setting for R-Car D3 ==============================
//=========================================================

#include "common.h"
#include "reg_rcargen3.h"
#include "boot_init_port_D3.h"
#include "boardid.h"


#define PFC_WR(m,n)   *((volatile uint32_t*)PFC_PMMR)=~(n);*((volatile uint32_t*)(m))=(n);

void InitPORT_D3(void)
{
#ifdef D3_V3M_E3
	InitMODSEL();
	InitIPSR();
	InitGPSR();
	InitIOCTRL();
	InitPUD();
	InitPUEN();
#endif
}

void InitIPSR_Area0_D3(void)
{
#if 0
	PFC_WR(PFC_IPSR0,0x00000001);
	PFC_WR(PFC_IPSR1,0x00000000);
	PFC_WR(PFC_IPSR2,0x00000000);
	PFC_WR(PFC_IPSR3,0x00000000);
	PFC_WR(PFC_IPSR4,0x00002000);
	PFC_WR(PFC_IPSR5,0x00000000);
	PFC_WR(PFC_IPSR6,0x00000000);
	PFC_WR(PFC_IPSR7,0x00000000);
	PFC_WR(PFC_IPSR8,0x11003301);
	PFC_WR(PFC_IPSR9,0x11111111);
	PFC_WR(PFC_IPSR10,0x00020000);
	PFC_WR(PFC_IPSR11,0x40000000);
	PFC_WR(PFC_IPSR12,0x00000000);
	PFC_WR(PFC_IPSR13,0x00000000);
#endif
}
void InitIPSR_SPI_D3(void)
{
	PFC_WR(PFC_IPSR0,0x00000001);
	PFC_WR(PFC_IPSR1,0x00000000);
	PFC_WR(PFC_IPSR2,0x00000000);
	PFC_WR(PFC_IPSR3,0x00000000);
	PFC_WR(PFC_IPSR4,0x00002000);
	PFC_WR(PFC_IPSR5,0x00000000);
	PFC_WR(PFC_IPSR6,0x00000000);
	PFC_WR(PFC_IPSR7,0x00000000);
	PFC_WR(PFC_IPSR8,0x11003301);
	PFC_WR(PFC_IPSR9,0x11111111);
	PFC_WR(PFC_IPSR10,0x00020000);
	PFC_WR(PFC_IPSR11,0x40000000);
	PFC_WR(PFC_IPSR12,0x00000000);
	PFC_WR(PFC_IPSR13,0x00000000);
}

void InitGPSR_Area0_D3(void)
{
#if 0
	PFC_WR(PFC_GPSR0,0x000001DF);
	PFC_WR(PFC_GPSR1,0x1FFFFFFF);
	PFC_WR(PFC_GPSR2,0x7FFFFFFF);
	PFC_WR(PFC_GPSR3,0x000003FF);
	PFC_WR(PFC_GPSR4,0xFC400F7E);
	PFC_WR(PFC_GPSR5,0x001BFFF8);
	PFC_WR(PFC_GPSR6,0x00003FFF);
#endif
}
void InitGPSR_SPI_D3(void)
{
	PFC_WR(PFC_GPSR0,0x000001DF);
	PFC_WR(PFC_GPSR1,0x1FFFFFFF);
	PFC_WR(PFC_GPSR2,0x7FFFFFFF);
	PFC_WR(PFC_GPSR3,0x000003FF);
	PFC_WR(PFC_GPSR4,0xFC400F7E);
	PFC_WR(PFC_GPSR5,0x001BFFF8);
	PFC_WR(PFC_GPSR6,0x00003FFF);
}

#ifdef D3_V3M_E3
//===== Static function ===================================

static void InitMODSEL(void)
{
	PFC_WR(PFC_MOD_SEL0,0x40A02000);
	PFC_WR(PFC_MOD_SEL1,0x00000000);
}

static void InitIPSR(void)
{
#ifdef Area0Boot
	InitIPSR_Area0_D3();
#else
	InitIPSR_SPI_D3();
#endif
}

static void InitGPSR(void)
{
#ifdef Area0Boot
	InitGPSR_Area0_D3();
#else
	InitGPSR_SPI_D3();
#endif
}

static void InitIOCTRL(void)
{
	PFC_WR(PFC_IOCTRL30,0xC00FFFFF);
	PFC_WR(PFC_IOCTRL32,0xFFFFFFFE);
	PFC_WR(PFC_IOCTRL40,0x00000000);
}

static void InitPUD(void)
{
	PFC_WR(PFC_PUD0,0x0043C000);
	PFC_WR(PFC_PUD1,0x000003FF);
	PFC_WR(PFC_PUD2,0xFFFFA000);
	PFC_WR(PFC_PUD3,0x3A0FFD8E);
	PFC_WR(PFC_PUD4,0x00000000);
	PFC_WR(PFC_PUD5,0x00000000);
}

static void InitPUEN(void)
{
	PFC_WR(PFC_PUEN0,0x0043C000);
	PFC_WR(PFC_PUEN1,0x000003FF);
	PFC_WR(PFC_PUEN2,0xFFFFA000);
	PFC_WR(PFC_PUEN3,0x3A0FFD8E);
	PFC_WR(PFC_PUEN4,0x00000000);
	PFC_WR(PFC_PUEN5,0x00000000);
}
#endif

