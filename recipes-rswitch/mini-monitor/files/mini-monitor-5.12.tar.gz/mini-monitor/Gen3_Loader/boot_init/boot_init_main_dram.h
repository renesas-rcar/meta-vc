void InitDramBoard(void);
void Mess_DdrBoard_Judge(char rtn);
