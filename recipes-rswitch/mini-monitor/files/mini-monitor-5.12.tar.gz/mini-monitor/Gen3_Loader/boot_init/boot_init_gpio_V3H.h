void InitGPIO_V3H(void);

static void InitPOSNEG(void);
static void InitIOINTSEL(void);
static void InitOUTDT(void);
static void InitINOUTSEL(void);
