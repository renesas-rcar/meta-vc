void InitGPIO_V3M(void);

static void InitPOSNEG(void);
static void InitIOINTSEL(void);
static void InitOUTDT(void);
static void InitINOUTSEL(void);
