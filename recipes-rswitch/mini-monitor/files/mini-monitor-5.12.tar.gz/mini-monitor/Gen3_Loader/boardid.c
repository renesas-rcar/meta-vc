/**********************************************************/
/* Sample program : Board ID Driver                       */
/* File Name      : boardid.c                             */
/* Copyright (C) Renesas Electronics Corp. 2016.          */
/**********************************************************/
#include "common.h"
#include "reg_rcargen3.h"
#include "boarddrv.h"
#include "boardid.h"
#include "cpudrv.h"
#include "iicdrv.h"
#include "i2cdrv.h"
#include "dmaspi.h"

uint32_t gPrrData;
uint32_t gPrr_Product;
uint32_t gPrr_Cut;
uint8_t gBoardId;
uint32_t gBoardId_FF_Flg;
uint32_t gBoardIdReadError;

//***************************************************************
//	CheckSoCBoard
//***************************************************************
void CheckSoCBoard(void)
{
	CheckSocProduct();				//set gPrrData,gPrr_Product,gPrr_Cut
	CheckBoardId();					//set gBoardId
}

//***************************************************************
//	Set global variable for board flag
//		gPrrData   ( PRR & 0x0000FFFF )
//		gPrr_Product
//		gPrr_Cut
//***************************************************************
void CheckSocProduct(void)
{	
	gPrrData = (*((volatile uint32_t*)PRR) & PRR_MASK );

	gPrr_Product = gPrrData & PRODUCT_MASK;
	gPrr_Cut     = gPrrData & CUT_MASK;
}


void CheckBoardId_DataFF(void)
{
	gBoardId_FF_Flg = 0;

//== When EEPROM is Initial value(BoardID=H'FF) ==
	if(gBoardId==0xFF){
		gBoardId_FF_Flg = 1;
		if(CHK_H3||CHK_M3||CHK_M3N){
			gBoardId =CheckBoard();
		}else if(CHK_V3M){
			gBoardId =CheckBoardV3M();
		}else if(CHK_V3H){
			gBoardId =BID_CONDOR;
		}else if(CHK_D3){
			gBoardId =BID_DRAAK;
		}else if(CHK_E3){
			gBoardId =BID_EBISU_4D;
		}
	}
}

void RcarM3wEs1xWa(void)
{
	if(CHK_M3_ES10){	//== R_CarM3_ES1.0 ==
		StartRtDma0_Descriptor();		//dummy DMA transfer by Descriptor
	}
}

void PutSocProduct(void)
{
	PutStr(" Product Code    : ",0);
	PutPrrSoc(0);	PutPrrCut(1);
}

void PutgPrrData(void)
{	
	char str[64];

	PutStr(" (PRR & H'FFFF = H'",0);
	Data2HexAscii(gPrrData,str,4);
	PutStr(str,0);
	PutStr(")",1);
}

void PutPrrSoc(char rtn)
{	
	switch(gPrr_Product){
		case PRODUCT_H3:  PutStr("R-Car H3"  ,rtn); break;
		case PRODUCT_M3:  PutStr("R-Car M3"  ,rtn); break;
		case PRODUCT_V3M: PutStr("R-Car V3M" ,rtn); break;
		case PRODUCT_D3:  PutStr("R-Car D3"  ,rtn); break;
		case PRODUCT_M3N: PutStr("R-Car M3-N",rtn); break;
		case PRODUCT_V3H: PutStr("R-Car V3H" ,rtn); break;
		case PRODUCT_E3:  PutStr("R-Car E3"  ,rtn); break;
		default: PutStr("Error : SOC code is not supported",rtn); break;
	}
}

void PutPrrCut(char rtn)
{	
	char str[64];

	PutStr(" ES",0);

	if(gPrrData==0x5210){ //R-CarM3 ES1.1/1.2
		PutStr("1.1/1.2",rtn);
		return;
	}
	if(gPrrData==0x5211){ //R-CarM3 ES1.3
		PutStr("1.3",rtn);
		return;
	}
	if(gPrrData==0x5810){ //R-CarD3 ES1.1
		PutStr("1.1",rtn);
		return;
	}
	Data2HexAscii(((gPrr_Cut&0xF0)+0x10),str,1);	PutStr(str,0);	DelStr(1);
	PutStr(".",0);
	Data2HexAscii(((gPrr_Cut<<4)&0xF0),str,1);		PutStr(str,0);	DelStr(1);
	PutStr("",rtn);
}


//***************************************************************
//	Set global variable for board ID. "gBoardId"
//***************************************************************

uint8_t BoardIdReadIicEeprom(void)
{
	uint32_t dataL;
	uint8_t bid;
	uint32_t err;

	InitIic(IIC_CH0);

	// 0x70 = Board ID
	err = RandomAddressReadIic(IIC_CH0,EEPROM_I2C_SLA,BOARD_ID_ADDR,&dataL,BOARD_ID_SIZE);
	if(err){
		gBoardIdReadError = 1;
		bid = 0xFF;
	}else{
		gBoardIdReadError = 0;
		bid = (dataL & 0xFF);
	}

	return bid;
}

uint8_t BoardIdReadI2cEeprom(void)
{
	uint32_t dataL;
	uint8_t bid;
	uint32_t err;

	InitI2c(I2C_CH0);

	// 0x70 = Board ID
	err = RandomAddressReadI2C(I2C_CH0,EEPROM_I2C_SLA,BOARD_ID_ADDR,&dataL,BOARD_ID_SIZE);
	if(err){
		gBoardIdReadError = 1;
		bid = 0xFF;
	}else{
		gBoardIdReadError = 0;
		bid = (dataL & 0xFF);
	}

	return bid;
}

void BoardIdWriteIicEeprom(uint8_t bid)
{
	uint32_t dataL;
	uint32_t i;

	InitIic(IIC_CH0);

	// 0x70 = Board ID
	dataL = bid;
	PageWriteIic(IIC_CH0,EEPROM_I2C_SLA,BOARD_ID_ADDR,&dataL,1);
	StartTMU0(1);	// Internal Write Cycle Time (max 5ms) - wait 10ms

	// 0x71-0x7F = Reserved (0xFF)
	dataL = 0xFF;
	for(i=1; i<BOARD_ID_SIZE_MAX; i++){
		PageWriteIic(IIC_CH0,EEPROM_I2C_SLA,BOARD_ID_ADDR+i,&dataL,1);
		StartTMU0(1);	// Internal Write Cycle Time (max 5ms) - wait 10ms
	}
}

void BoardIdWriteI2cEeprom(uint8_t bid)
{
	uint32_t dataL;
	uint32_t i;

	InitI2c(I2C_CH0);

	PutStr(" BoardIdWriteI2cEeprom ",1);

	// 0x70 = Board ID
	dataL = bid;
	PageWriteI2C(I2C_CH0,EEPROM_I2C_SLA,BOARD_ID_ADDR,&dataL,1);
	StartTMU0(1);	// Internal Write Cycle Time (max 5ms) - wait 10ms

	// 0x71-0x7F = Reserved (0xFF)
	dataL = 0xFF;
	for(i=1; i<BOARD_ID_SIZE_MAX; i++){
		PageWriteI2C(I2C_CH0,EEPROM_I2C_SLA,BOARD_ID_ADDR+i,&dataL,1);
		StartTMU0(1);	// Internal Write Cycle Time (max 5ms) - wait 10ms
	}
}
void CheckBoardId(void)
{
	uint8_t bid;

	// Check SoC : Get Board ID
	if( CHK_H3  ) bid = BoardIdReadIicEeprom();  // R-Car H3   : IIC EEPROM
	if( CHK_M3  ) bid = BoardIdReadIicEeprom();  // R-Car M3   : IIC EEPROM
	if( CHK_V3M ){
		bid = BoardIdReadI2cEeprom();            // R-Car V3M  : I2C0 EEPROM
		if(gBoardIdReadError) bid = BID_EAGLE_D; // R-Car V3M  : Fixed value for Eagle
	}
	if( CHK_D3  ) bid = BoardIdReadI2cEeprom();  // R-Car D3   : I2C0 EEPROM
	if( CHK_M3N ) bid = BoardIdReadIicEeprom();  // R-Car M3-N : IIC EEPROM
	if( CHK_V3H ) bid = BoardIdReadI2cEeprom();  // R-Car V3H  : I2C0 EEPROM
	if( CHK_E3  ) bid = BoardIdReadIicEeprom();  // R-Car E3   : IIC EEPROM

//	if(bid==0xFF)
//		PutStr(" bid=0xFF ",1);

	gBoardId = bid;
}

void WriteBoardId(uint8_t bid)
{
	// Check SoC : Set Board ID
	if( CHK_H3  ) BoardIdWriteIicEeprom(bid);  // R-Car H3   : IIC EEPROM
	if( CHK_M3  ) BoardIdWriteIicEeprom(bid);  // R-Car M3   : IIC EEPROM
	if( CHK_V3M ) BoardIdWriteI2cEeprom(bid);  // R-Car V3M  : I2C0 EEPROM
	if( CHK_D3  ) BoardIdWriteI2cEeprom(bid);  // R-Car D3   : I2C0 EEPROM
	if( CHK_M3N ) BoardIdWriteIicEeprom(bid);  // R-Car M3-N : IIC EEPROM
	if( CHK_V3H ) BoardIdWriteI2cEeprom(bid);  // R-Car V3H  : I2C0 EEPROM
	if( CHK_E3  ) BoardIdWriteIicEeprom(bid);  // R-Car E3   : IIC EEPROM

	CheckBoardId();
}

char *GetBoardIdNameString(uint8_t bid)
{
	switch(bid&BID_MASK){
		case BID_SALVATOR_X		: return "Salvator-X";
		case BID_KRIEK_LP4		: return "Kriek-LPDDR4";
		case BID_STARTERKIT_PRO	: return "Starter Kit Pro";
		case BID_EAGLE_D		: return "Eagle";
		case BID_SALVATOR_XS	: return "Salvator-XS";
		case BID_SALVATOR_MS	: return "Salvator-MS";
		case BID_CONDOR			: return "Condor";
		case BID_DRAAK			: return "Draak";
		case BID_EBISU_2D		: return "Ebisu-2D";
		case BID_EBISU_4D		: return "Ebisu-4D";
		case BID_KRIEK_DDR3		: return "Kriek-DDR3";
		case BID_STARTERKIT_PRE	: return "Starter Kit Premier";
		case BID_EAGLE_R		: return "Eagle-R";
		default             	: return "Unknown Board";
	}
}

void PutBoardIdName(char rtn)
{
	char *str;
	str = GetBoardIdNameString(gBoardId);
	PutStr(str,rtn);
}

char *GetBoardIdRevString(uint8_t bid)
{
	switch(bid&BREV_MASK){
		case BREV_000: return "0";
		case BREV_001: return "1";
		case BREV_010: return "2";
		case BREV_011: return "3";
		case BREV_100: return "4";
		case BREV_101: return "5";
		case BREV_110: return "6";
		case BREV_111: return "7";
	}
}

void PutBoardIdRev(char rtn)
{
	char *str;
	str = GetBoardIdRevString(gBoardId);
	PutStr(str,rtn);
}


uint8_t CheckBoard(void)
{
	uint8_t bid;

// Salvator / Kriek / StarterKit
	// Is "USB2_OVC" pin Open?
	if( !SSI_WS6_OpenCheck() ){
		// Connect=Salvator
		bid = BID_SALVATOR_X;
//		bid = BID_SALVATOR_XS;
		return bid;
	}
	// USB0_OVC:Open=Kriek or StarterKit
	if( !USB0_OVC_OpenCheck() ){
		// Connect=Kriek
		bid = BID_KRIEK_LP4;
//		bid = BID_KRIEK_DDR3;
		return bid;
	}else{
		// Open= StarterKit
		bid = BID_STARTERKIT_PRO;
//		bid = BID_STARTERKIT_PRE;
		return bid;
	}
}

uint8_t CheckBoardV3M(void)
{
	uint32_t dataL;
	uint8_t bid;
	uint32_t err;

	InitI2c(I2C_CH0);

	// 0x70 = Board ID
	err = RandomAddressReadI2C(I2C_CH0,EEPROM_I2C_SLA,BOARD_ID_ADDR,&dataL,BOARD_ID_SIZE);

	// I2C0 Access to EEPROM
	// Detect Error = Eagle / No Error = Eagle-R
	if(err){
		bid = BID_EAGLE_D;
	}else{
		bid = BID_EAGLE_R;
	}

	return bid;
}

void SelectBoard(uint32_t boadName)
{
	gBoardId = boadName;
}

void PutBoardName(char rtn)
{
//	PutStr(" Board Name   : ",0);

	if(CHK_SALVATOR){		PutStr("Salvator-X / Salvator-XS",rtn);				}		// BD_SALVATOR_X or BD_SALVATOR_X
	else if(CHK_KRIEK){		PutStr("Kriek",rtn);								}		// BD_KRIEK_LP4 or BD_KRIEK_DDR3
	else if(CHK_STARTERKIT){PutStr("Starter Kit Pro / Starter Kit Premier",rtn);}		// BD_STARTERKIT_PRO or BD_STARTERKIT_PRE
	else if(CHK_EAGLE_D){	PutStr("Eagle",rtn);								}
	else if(CHK_DRAAK){		PutStr("Draak",rtn);								}
	else if(CHK_CONDOR){	PutStr("Condor",rtn);								}
	else if(CHK_EBISU_2D){	PutStr("Ebisu-2D",rtn);								}
	else if(CHK_EBISU_4D){	PutStr("Ebisu-4D",rtn);								}
	else if(CHK_EAGLE_R){	PutStr("Eagle-R",rtn);								}
	else{					PutStr("Error : Board judge",rtn);					}
}





void Mess_Board_Judge(char rtn)
{	
#if BOARD_TYPE==0xFF
	PutStr(" Board Judge     : ",0);
	if(gBoardId_FF_Flg)	 //EEPROM Board-ID is initial value (Nothing is written)
		PutStr("Not Used Board-ID",rtn);
	else
		PutStr("Used Board-ID",rtn);
#endif /* BOARD_TYPE */
}


