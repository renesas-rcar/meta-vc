/**********************************************************/
/* Sample program : R-CarH3 Common Header                 */
/* File Name      : common.h                              */
/* Copyright (C) Renesas Electronics Corp. 2015.          */
/**********************************************************/
#ifndef	__COMMON_
#define	__COMMON_

#include <stdint.h>		//for uint32_t

#ifdef AArch64
typedef uint64_t    uintptr_t;
#define CPU_BYTE_SIZE			SIZE_64BIT
#endif

#ifdef AArch32
/* typedef uint32_t    uintptr_t; */
#define CPU_BYTE_SIZE			SIZE_32BIT
#endif


/******************************************************************************/
/* INCLUDE FILE                                                               */
/******************************************************************************/
#include "common_func.h"


#endif /* __COMMON_ */
