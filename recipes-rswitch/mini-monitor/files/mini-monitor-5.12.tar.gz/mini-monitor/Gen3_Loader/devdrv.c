/**********************************************************/
/* Sample program : R-CarH3 Device Driver                 */
/* File Name      : devdrv.h                              */
/* Copyright (C) Renesas Electronics Corp. 2015.          */
/**********************************************************/
#include "common.h"
#include "scifdrv0.h"
//#include "scifdrv1.h"
#include "scifdrv2.h"
#include "boardid.h"
#include "devdrv.h"
#include "init_scif.h"

/************************
	PutChar				*
*************************/

int32_t PutChar(char outChar)
{
	switch( gScifMainChNo ){
		case SCIF_CH0: PutCharSCIF0(outChar); break;	// Eagle / Condor
//		case SCIF_CH1: PutCharSCIF1(outChar); break;	// Condor(EX_MEM Board Debug Version)
		case SCIF_CH2: PutCharSCIF2(outChar); break;	// Salvator / Kriek / StarterKit / Draak / Ebisu
	}
	return(0);
}

/************************
	GetChar				*
*************************/

int32_t GetChar(char *inChar)
{
	switch( gScifMainChNo ){
		case SCIF_CH0: GetCharSCIF0(inChar); break;		// Eagle / Condor
//		case SCIF_CH1: GetCharSCIF1(inChar); break;		// Condor(EX_MEM Board Debug Version)
		case SCIF_CH2: GetCharSCIF2(inChar); break;		// Salvator / Kriek / StarterKit / Draak / Ebisu
	}
	return(0);
}

void WaitPutCharSendEnd(void)
{
	switch( gScifMainChNo ){
		case SCIF_CH0: WaitPutScif0SendEnd(); break;	// Eagle / Condor
//		case SCIF_CH1: WaitPutScif1SendEnd(); break;	// Condor(EX_MEM Board Debug Version)
		case SCIF_CH2: WaitPutScif2SendEnd(); break;	// Salvator / Kriek / StarterKit / Draak / Ebisu
	}
}
