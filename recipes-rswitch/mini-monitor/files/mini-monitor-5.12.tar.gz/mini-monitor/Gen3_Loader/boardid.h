/**********************************************************/
/* Sample program : Board ID Driver Header                */
/* File Name      : boardid.h                             */
/* Copyright (C) Renesas Electronics Corp. 2016.          */
/**********************************************************/
extern uint32_t gPrr_Product;
extern uint32_t gPrr_Cut;
extern uint8_t gBoardId;
extern uint32_t gBoardId_FF_Flg;


// SoC Chip Version
#define RCARH3_ES10				0x00004F00
#define RCARH3_ES11				0x00004F01

//PRODUCT_CODE (gPrr_Product)
#define PRR_MASK				0x0000FFFF
#define PRODUCT_MASK			0x0000FF00
#define PRODUCT_H3				0x00004F00		// R-Car H3
#define PRODUCT_M3				0x00005200		// R-Car M3
#define PRODUCT_V3M				0x00005400		// R-Car V3M
#define PRODUCT_V3H				0x00005600		// R-Car V3H
#define PRODUCT_D3				0x00005800		// R-Car D3
#define PRODUCT_M3N				0x00005500		// R-Car M3-N
#define PRODUCT_E3				0x00005700		// R-Car E3

//CUT_CODE (gPrr_Cut)
#define CUT_MASK				0x000000FF
#define CUT_ES10				0x00000000		// ES1.0
#define CUT_ES11				0x00000001		// ES1.1
#define CUT_ES20				0x00000010		// ES2.0 (M3W Ver1.1/Ver1.2)
#define CUT_ES21				0x00000011		// ES2.1 (M3W Ver1.3)
#define CUT_ES30				0x00000020		// ES3.0

#define CUT_ES1X				0x0000000F		// ES1.X (Ex.             gPrr_Cut <= CUT_ES1X)
#define CUT_ES2X				0x0000001F		// ES1.X (Ex. CUT_ES20 <= gPrr_Cut <= CUT_ES2X)
#define CUT_ES3X				0x0000002F		// ES1.X (Ex. CUT_ES30 <= gPrr_Cut <= CUT_ES3X)

// Mode pins
#define MD9_LOW					((0x0200 & *((volatile uint32_t*)RST_MODEMR)) == 0x0000 )
#define MD9_HIGH				((0x0200 & *((volatile uint32_t*)RST_MODEMR)) != 0x0000 )



//------------------------------------------------------------------------

// Board Name
#define CHK_SALVATOR_X		((gBoardId&BID_MASK)==BID_SALVATOR_X)
#define CHK_SALVATOR_XS		((gBoardId&BID_MASK)==BID_SALVATOR_XS)
#define CHK_SALVATOR		(CHK_SALVATOR_X||CHK_SALVATOR_XS)			// Salvator-X or Salvator-XS
#define CHK_STARTERKIT_PRO	((gBoardId&BID_MASK)==BID_STARTERKIT_PRO)
#define CHK_STARTERKIT_PRE	((gBoardId&BID_MASK)==BID_STARTERKIT_PRE)
#define CHK_STARTERKIT		(CHK_STARTERKIT_PRO||CHK_STARTERKIT_PRE)	// SK-Pro or SK-Premier
#define CHK_KRIEK_LP4		((gBoardId&BID_MASK)==BID_KRIEK_LP4)
#define CHK_KRIEK_DDR3		((gBoardId&BID_MASK)==BID_KRIEK_DDR3)
#define CHK_KRIEK			(CHK_KRIEK_LP4||CHK_KRIEK_DDR3)				// Kriek-LPDDR4 or Kriek-DDR3
#define CHK_EAGLE_D			((gBoardId&BID_MASK)==BID_EAGLE_D)			// Eagle-D (Dialog PMIC)
#define CHK_DRAAK			((gBoardId&BID_MASK)==BID_DRAAK)
#define CHK_CONDOR			((gBoardId&BID_MASK)==BID_CONDOR)
#define CHK_EBISU			(CHK_EBISU_2D||CHK_EBISU_4D)				// Ebisu
#define CHK_EBISU_ST		(CHK_EBISU_2D_ST||CHK_EBISU_4D_ST)			// Ebisu Standard
#define CHK_EBISU_SP		(CHK_EBISU_2D_SP||CHK_EBISU_4D_SP)			// Ebisu Specific
#define CHK_EBISU_2D		((gBoardId&BID_MASK)==BID_EBISU_2D)			// Ebisu DDRx2
#define CHK_EBISU_2D_ST		(CHK_EBISU_2D && MD9_LOW)					// Ebisu DDRx2 Standard
#define CHK_EBISU_2D_SP		(CHK_EBISU_2D && MD9_HIGH)					// Ebisu DDRx2 Specific
#define CHK_EBISU_4D		((gBoardId&BID_MASK)==BID_EBISU_4D)			// Ebisu DDRx4
#define CHK_EBISU_4D_ST		(CHK_EBISU_4D && MD9_LOW)					// Ebisu DDRx4 Standard
#define CHK_EBISU_4D_SP		(CHK_EBISU_4D && MD9_HIGH)					// Ebisu DDRx4 Specific
#define CHK_EAGLE_R			((gBoardId&BID_MASK)==BID_EAGLE_R)			// Eagle-R (Rohm PMIC)
#define CHK_EAGLE			(CHK_EAGLE_D||CHK_EAGLE_R)

// Board Revision
#define CHK_BREV0			((gBoardId&BREV_MASK)==BREV_000)
#define CHK_BREV1			((gBoardId&BREV_MASK)==BREV_001)
#define CHK_BREV2			((gBoardId&BREV_MASK)==BREV_010)
#define CHK_BREV3			((gBoardId&BREV_MASK)==BREV_011)
#define CHK_BREV4			((gBoardId&BREV_MASK)==BREV_100)
#define CHK_BREV5			((gBoardId&BREV_MASK)==BREV_101)
#define CHK_BREV6			((gBoardId&BREV_MASK)==BREV_110)
#define CHK_BREV7			((gBoardId&BREV_MASK)==BREV_111)

// Board Name & Revision
#define CHK_SALVATOR_X_REV10			(CHK_SALVATOR_X    &&CHK_BREV0)		// Salvator-X Rev1.0
#define CHK_SALVATOR_X_REV11			(CHK_SALVATOR_X    &&CHK_BREV1)		// Salvator-X Rev1.1
#define CHK_KRIEK_REV10					(CHK_KRIEK         &&CHK_BREV0)		// Kriek Rev1.0 (LPDDR4 4GB 2RANK)
#define CHK_STARTERKIT_PRO_REV10		(CHK_STARTERKIT_PRO&&CHK_BREV0)		// StarterKit Pro Rev1.0
#define CHK_EAGLE_D_REV10				(CHK_EAGLE_D       &&CHK_BREV0)		// Eagle Rev1.0
#define CHK_SALVATOR_XS_REV10			(CHK_SALVATOR_XS   &&CHK_BREV0)		// Salvator-XS Rev1.0
#define CHK_DRAAK_REV10					(CHK_DRAAK         &&CHK_BREV0)		// Draak Rev1.0
#define CHK_EBISU_REV10					(CHK_EBISU         &&CHK_BREV0)		// Ebisu Rev1.0
#define CHK_STARTERKIT_PRE_REV10_OB		(CHK_STARTERKIT_PRE&&CHK_BREV0)		// StarterKit Premier Rev1.0 OB
#define CHK_STARTERKIT_PRE_REV10_CE		(CHK_STARTERKIT_PRE&&CHK_BREV1)		// StarterKit Premier Rev1.0 CE
#define CHK_EAGLE_R_REV10				(CHK_EAGLE_R       &&CHK_BREV0)		// Eagle-R Rev1.0
#define CHK_KRIEK_LP4_8GB_2RANK			(CHK_KRIEK_LP4     &&CHK_BREV2)		// Kriek LPDDR4 8GB 2RANK
#define CHK_KRIEK_LP4_4GB_1RANK			(CHK_KRIEK_LP4     &&CHK_BREV3)		// Kriek LPDDR4 4GB 1RANK

// SoC Product
#define CHK_H3			(gPrr_Product==PRODUCT_H3)
#define CHK_M3			(gPrr_Product==PRODUCT_M3)
#define CHK_V3M			(gPrr_Product==PRODUCT_V3M)
#define CHK_V3H			(gPrr_Product==PRODUCT_V3H)
#define CHK_D3			(gPrr_Product==PRODUCT_D3)
#define CHK_M3N			(gPrr_Product==PRODUCT_M3N)
#define CHK_E3			(gPrr_Product==PRODUCT_E3)

// SoC Cut
#define CHK_ES10		(gPrr_Cut==CUT_ES10)
#define CHK_ES11		(gPrr_Cut==CUT_ES11)
#define CHK_ES1X		(gPrr_Cut<=CUT_ES1X)
#define CHK_ES20		(gPrr_Cut==CUT_ES20)
#define CHK_ES21		(gPrr_Cut==CUT_ES21) //M3 Ver1.3�ǉ�_20190402
#define CHK_ES2X		((CUT_ES20 <= gPrr_Cut) && (gPrr_Cut <= CUT_ES2X))
#define CHK_ES2X_GE		(CUT_ES20<=gPrr_Cut)
#define CHK_ES30		(gPrr_Cut==CUT_ES30)
#define CHK_ES3X		((CUT_ES30 <= gPrr_Cut) && (gPrr_Cut <= CUT_ES3X))
#define CHK_ES3X_GE		(CUT_ES30<=gPrr_Cut)

// Combination H3
#define CHK_H3_ES10		(CHK_H3 && CHK_ES10)
#define CHK_H3_ES11		(CHK_H3 && CHK_ES11)
#define CHK_H3_ES1X		(CHK_H3 && CHK_ES1X)
#define CHK_H3_ES20		(CHK_H3 && CHK_ES20)
#define CHK_H3_ES2X		(CHK_H3 && CHK_ES2X)
#define CHK_H3_ES2X_GE	(CHK_H3 && CHK_ES2X_GE)
#define CHK_H3_ES30		(CHK_H3 && CHK_ES30)
#define CHK_H3_ES3X		(CHK_H3 && CHK_ES3X)
#define CHK_H3_ES3X_GE	(CHK_H3 && CHK_ES3X_GE)

// Combination M3
#define CHK_M3_ES10		(CHK_M3 && CHK_ES10)
#define CHK_M3_ES11		(CHK_M3 && CHK_ES20)
#define CHK_M3_ES13		(CHK_M3 && CHK_ES21) //M3 Ver1.3�ǉ�_20190402
#define CHK_M3_ES1X		(CHK_M3_ES10 || CHK_M3_ES11)
#define CHK_M3_ES30		(CHK_M3 && CHK_ES30)
#define CHK_M3_ES3X		(CHK_M3 && CHK_ES3X)
#define CHK_M3_ES3X_GE	(CHK_M3 && CHK_ES3X_GE)

// Combination V3M
#define CHK_V3M_ES10	(CHK_V3M && CHK_ES10)
#define CHK_V3M_ES1X	(CHK_V3M && CHK_ES1X)

// Combination M3N
#define CHK_M3N_ES10	(CHK_M3N && CHK_ES10)

//------------------------------------------------------------------------

// Board ID = gBoardId

#define BOARD_ID_SIZE		1		// 1 Byte
#define BOARD_ID_SIZE_MAX	0x10	// 16 Byte

// IIC EEPROM
#define BOARD_ID_ADDR		0x70

// Board Revision = Board ID BIT[2:0]
#define BREV_MASK			0x07
#define BREV_000			0x00
#define BREV_001			0x01
#define BREV_010			0x02
#define BREV_011			0x03
#define BREV_100			0x04
#define BREV_101			0x05
#define BREV_110			0x06
#define BREV_111			0x07

// Board Code = Board ID BIT[7:3]
#define BID_MASK			0xF8
#define BID_SALVATOR_X		0x00	// 5'b00000 Salvator-X
#define BID_KRIEK_LP4		0x08	// 5'b00001 Kriek LPDDR4
#define BID_STARTERKIT_PRO	0x10	// 5'b00010 Starter Kit Pro (M3)
#define BID_EAGLE_D			0x18	// 5'b00011 Eagle-D (Dialog PMIC)
#define BID_SALVATOR_XS		0x20	// 5'b00100 Salvator-XS
#define BID_SALVATOR_MS		0x28	// 5'b00101 Salvator-MS
#define BID_CONDOR			0x30	// 5'b00110 Condor
#define BID_DRAAK			0x38	// 5'b00111 Draak
#define BID_EBISU_2D		0x40	// 5'b01000 Ebisu DDRx2
#define BID_KRIEK_DDR3		0x48	// 5'b01001 Kriek DDR3
#define BID_STARTERKIT_PRE	0x58	// 5'b01011 Starter Kit Premier (H3)
#define BID_EBISU_4D		0x68	// 5'b01101 Ebisu DDRx4
#define BID_EAGLE_R			0x70	// 5'b01110 Eagle-R (Rohm PMIC)
/*
#define BID_RESERVED		0x50	// 5'b01010 
#define BID_RESERVED		0x60	// 5'b01100 
#define BID_RESERVED		0x78	// 5'b01111 
#define BID_RESERVED		0x80	// 5'b10000 
#define BID_RESERVED		0x88	// 5'b10001 
#define BID_RESERVED		0x90	// 5'b10010 
#define BID_RESERVED		0x98	// 5'b10011 
#define BID_RESERVED		0xA0	// 5'b10100 
#define BID_RESERVED		0xA8	// 5'b10101 
#define BID_RESERVED		0xB0	// 5'b10110 
#define BID_RESERVED		0xB8	// 5'b10111 
#define BID_RESERVED		0xC0	// 5'b11000 
#define BID_RESERVED		0xC8	// 5'b11001 
#define BID_RESERVED		0xD0	// 5'b11010 
#define BID_RESERVED		0xD8	// 5'b11011 
#define BID_RESERVED		0xE0	// 5'b11100 
#define BID_RESERVED		0xE8	// 5'b11101 
#define BID_RESERVED		0xF0	// 5'b11110 
#define BID_RESERVED		0xF8	// 5'b11111 
*/

//------------------------------------------------------------------------

void CheckSoCBoard(void);

void CheckSocProduct(void);
void CheckBoardId_DataFF(void);
void RcarM3wEs1xWa(void);
void PutSocProduct(void);
void PutgPrrData(void);
void PutPrrSoc(char rtn);
void PutPrrCut(char rtn);

uint8_t BoardIdReadIicEeprom(void);
uint8_t BoardIdReadI2cEeprom(void);
void BoardIdWriteIicEeprom(uint8_t bid);
void BoardIdWriteI2cEeprom(uint8_t bid);
void CheckBoardId(void);
void WriteBoardId(uint8_t bid);
char *GetBoardIdNameString(uint8_t bid);
void PutBoardIdName(char rtn);
char *GetBoardIdRevString(uint8_t bid);
void PutBoardIdRev(char rtn);

uint8_t CheckBoard(void);
uint8_t CheckBoardV3M(void);
void SelectBoard(uint32_t boadName);
void PutBoardName(char rtn);

void Mess_Board_Judge(char rtn);
