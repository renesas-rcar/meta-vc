#define BOOT_EXBUS		0x00000000
#define SCIF_CH0		0
#define SCIF_CH1		1
#define SCIF_CH2		2

extern uint32_t gScifMainChNo;

void SetScifFlagDefault(void);
void InitScif(void);
