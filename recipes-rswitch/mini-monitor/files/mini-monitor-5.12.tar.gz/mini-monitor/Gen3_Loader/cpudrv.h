uint32_t GetGpioInputLevel( uint32_t gp, uint32_t bit );
void PowerOnTmu0(void);
void StartTMU0usec(uint32_t tenuSec);
void StartTMU0(uint32_t tenmSec);
