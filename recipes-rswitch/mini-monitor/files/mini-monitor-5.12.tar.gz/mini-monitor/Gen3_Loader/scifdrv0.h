/**********************************************************/
/* Sample program : R-CarH3 SCIF Driver Header            */
/* File Name      : scifdrv0.h                              */
/* Copyright (C) Renesas Electronics Corp. 2015.          */
/**********************************************************/
#ifndef	__SCIFDRV0_
#define	__SCIFDRV0_

#include <stdint.h>		//for uint32_t

int32_t PutCharSCIF0(char outChar);
int32_t GetCharSCIF0(char *inChar);
void PowerOnScif0(void);
void WaitPutScif0SendEnd(void);
void InitScif0_SCIFCLK(void);


#endif /* __SCIFDRV0_ */
