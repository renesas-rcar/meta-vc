/**********************************************************/
/* Sample program : R-CarH3 Boot Loader                   */
/* File Name      : bootloader.c                          */
/* Copyright (C) Renesas Electronics Corp. 2015.          */
/**********************************************************/

#include "bootloader.h"
#include "bit.h"
#include "reg_rcargen3.h"
#include "rpcdrv.h"
#include "dmaspi.h"
#include "common.h"
#include "devdrv.h"
#include "cpudrv.h"
#include "boardid.h"
#include "boot_init_main_dram.h"
#include "armmulticore.h"
#include "cnt_led.h"

extern uint32_t ddrBackup;		//0:ColdBoot, 1:WarmBoot(DDR-BackUp), 2:WarmBoot Timeout Error
uint32_t prgStartAd;

#define ADDR_SEC_BOOT_KEY_CERT_TOP					0xE6300C00
#define ADDR_DRAM_USER_PROGRAM_CERT_TOP				0x40000000
#define ADDR_DRAM_USER_PROGRAM_LOAD					(ADDR_DRAM_USER_PROGRAM_CERT_TOP + 0x154)
#define ADDR_DRAM_USER_PROGRAM_SIZE_LEN_IN_WORDS	(ADDR_DRAM_USER_PROGRAM_CERT_TOP + 0x264)
#define ADDR_RPC_MEM_TOP		0x08000000			//RPC memory space 0x08000000-0x0BFFFFFF = 64MBytes
#define ROM_OK	0x00000000

void BOOT_MessageSim(void);
void BOOT_Message(uint32_t md);
uint32_t ReadFlashID(uint32_t dev);
uint32_t BootLoaderMain(void);
void mem_copy(uint32_t prgStartAd, uint32_t sector_Ad, uint32_t accessSize);
void mem_copy_SysDmac(uint32_t prgStartAd, uint32_t sector_Ad, uint32_t accessSize);
void mem_copy_RtDmac(uint32_t prgStartAd, uint32_t sector_Ad, uint32_t accessSize);

const char *const bootStartMess[4] = {
	"R-Car Gen3 Sample Loader V5.12 2019.06.17",
#ifdef H3_M3
	" For Salvator , Kriek , and StarterKit.(R-CarH3/R-CarM3)",
#endif
#ifdef V3H
	" For Condor.(R-CarV3H)",
#endif
#ifdef D3_V3M_E3
#ifdef E3_DDR_X4
	" For Eagle , Draak , and Ebisu-4D.",
#endif
#ifdef E3_DDR_X2
	" For Eagle , Draak , and Ebisu-2D.",
#endif
#endif
	0,
};


//-----------------------------------------------------------------------------
//	INIT Message
//-----------------------------------------------------------------------------
void InitMessage(void)
{
	PutStr(" INITIAL SETTING : ",0);
	if(gBoardId_FF_Flg){
		PutBoardName(0);
	}else{
		PutBoardIdName(0);
	}
	PutStr(" / ",0);
	PutPrrSoc(0);	PutPrrCut(1);
}

//-----------------------------------------------------------------------------
//	BOOT Message
//-----------------------------------------------------------------------------
void BOOT_Message(uint32_t md)
{
	uint32_t midr=0;
	uint32_t cpuName=0;
	uint32_t rmr=0;
	uint32_t mpidr=0;
	uint32_t cpuNum=0;
	uint32_t aarch=0;
	uint32_t cpu=0;
	uint32_t ddr=0;
	uint32_t ddrPhy=0;
	uint32_t dev=0;
	uint32_t auth=0;
	uint32_t authsel=0;
	uint32_t readID=0;
	uint32_t clksel=0;
	uint32_t readDevId1=0;
	uint32_t readDevId2=0;
	uint32_t readFamilyID=0;
	char str[64];

//=============================================================================
	PutStr(" CPU / BOOT MODE : ",0);

	// ARM Core
	//------------------------------------------------------
	// MIDR������CA57/CA53����
	//------------------------------------------------------
	// [15:4]  = PartNum      : CA57=0xD07 / CA53=0xD03 / CR7=0xC17
	midr = GetMIDR();
	cpuName = (midr&BIT15_4)>>4;
	if(cpuName==0xD07){
		rmr = GetRMR();
		if(rmr&BIT0) PutStr("AArch64 CA57",0);
		else         PutStr("AArch32 CA57",0);
	}else if(cpuName==0xD03){
		rmr = GetRMR();
		if(rmr&BIT0) PutStr("AArch64 CA53",0);
		else         PutStr("AArch32 CA53",0);
	}else if(cpuName==0xC17){
		PutStr("CR7",0);
	}else{
		PutStr("Unknown Core",0);
	}

	//------------------------------------------------------
	// MPIDR������CPU�ԍ�����
	//------------------------------------------------------
	// [1:0]   = CPU ID : 0x0, 0x1, 0x2, 0x3
	mpidr = GetMPIDR();
	cpuNum = (mpidr&BIT1_0);
	if(cpuNum==0)      PutStr("-CPU0",0);
	else if(cpuNum==1) PutStr("-CPU1",0);
	else if(cpuNum==2) PutStr("-CPU2",0);
	else if(cpuNum==3) PutStr("-CPU3",0);

	PutStr(" / ",0);

	// CPU Mode
	if(CHK_V3M){
		cpu = (md & 0x00000080) >> 7;
		if(cpu == 0x1) 			PutStr("CR7",0);				//MD7=1 : CortexR7 boot
		else					PutStr("CA53",0);				//MD7=0 : CortexA53 boot
	}else if(CHK_D3){
								PutStr("CA53",0);				//CortexA53 boot
	}else if(CHK_M3N){
		cpu = (md & 0x000000C0) >> 6;
		if(cpu == 0x3) 			PutStr("CR7",0);				//MD7=1,MD6=1 : CortexR7 boot
		else if(cpu == 0x0)		PutStr("CA57",0);				//MD7=0,MD6=0 : CortexA57 boot
		else					PutStr("Unknown",0);
	}else if(CHK_V3H||CHK_E3){
		cpu = (md & 0x000000C0) >> 6;
		if(cpu == 0x3) 			PutStr("CR7",0);				//MD7=1,MD6=1 : CortexR7 boot
		else if(cpu == 0x1)		PutStr("CA53",0);				//MD7=0,MD6=1 : CortexA53 boot
		else					PutStr("Unknown",0);
	}else{	// H3,M3
		cpu = (md & 0x000000C0) >> 6;
		if(cpu == 0x3) 			PutStr("CR7",0);				//MD7=1,MD6=1 : CortexR7 boot
		else if(cpu == 0x0)		PutStr("CA57",0);				//MD7=0,MD6=0 : CortexA57 boot
		else if(cpu == 0x1)		PutStr("CA53",0);				//MD7=0,MD6=1 : CortexA53 boot
		else					PutStr("Unknown",0);
	}
	PutStr(" Boot Mode ",0);

	// MD15
	aarch = (md & 0x00008000) >> 15;
	if(aarch == 0x0)	PutStr("(MD15:AArch32)",1);	//MD15=0 : AArch32
	else				PutStr("(MD15:AArch64)",1);	//MD15=1 : AArch64

//=============================================================================
	PutStr(" DRAM            : ",0);
	if(CHK_V3M){
		ddr = (md & 0x00080000) >> 19;
		if(ddr == 0x0)			PutStr("DDR3L DDR1600",0);		//MD19=0 : DDR1600
		else if(ddr == 0x1)		PutStr("DDR3L DDR1333",0);		//MD19=1 : DDR1333
	}else if(CHK_D3){
		ddr = (md & 0x00080000) >> 19;
		if(ddr == 0x0)			PutStr("DDR3/3L DDR1600",0);	//MD19=0 : DDR1600
		else if(ddr == 0x1)		PutStr("DDR3/3L DDR1866",0);	//MD19=1 : DDR1866
	}else if(CHK_E3){
		ddr = (md & 0x00080000) >> 19;
		if(ddr == 0x0)			PutStr("DDR3 DDR1600",0);		//MD19=0 : DDR1600
		else if(ddr == 0x1)		PutStr("DDR3 DDR1856",0);		//MD19=1 : DDR1856
	}else if(CHK_M3||CHK_M3N){
		ddrPhy = (md & 0x08000000) >> 27;
		ddr    = (md & 0x000A0000) >> 17;
		if(ddrPhy == 0x0){			//LPDDR4
			if(ddr == 0x0)		PutStr("LPDDR4 DDR3200",0);		//MD19=0,MD17=0 : DDR3200
			else if(ddr == 0x1)	PutStr("LPDDR4 DDR2800",0);		//MD19=0,MD17=1 : DDR2800
			else if(ddr == 0x4)	PutStr("LPDDR4 DDR2400",0);		//MD19=1,MD17=0 : DDR2400
			else if(ddr == 0x5)	PutStr("LPDDR4 DDR1600",0);		//MD19=1,MD17=1 : DDR1600
		}else if(ddrPhy == 0x1){	//DDR3L
//			ddr = (md & 0x000A0000) >> 17;
			if(ddr == 0x0)		PutStr("[MD19,17==0,0] DDR3 2133",0);		//MD19=0,MD17=0 : DDR3_2133
			else if(ddr == 0x1)	PutStr("[MD19,17==0,1] DDR3 2133",0);		//MD19=0,MD17=1 : DDR3_2133
			else if(ddr == 0x4)	PutStr("[MD19,17==1,0] DDR3/3L DDR1866",0);	//MD19=1,MD17=0 : DDR3_1866
			else if(ddr == 0x5)	PutStr("[MD19,17==1,1] DDR3/3L DDR1600",0);	//MD19=1,MD17=1 : DDR3_1600
		}
	}else if(CHK_V3H){
		ddr = (md & 0x00080000) >> 19;
		if(ddr == 0x0)			PutStr("LPDDR4 DDR3200",0);		//MD19=0 : LPDDR4-3200
		else if(ddr == 0x1)		PutStr("LPDDR4 DDR1600",0);		//MD19=1 : LPDDR4-1600
	}else{	// H3,M3
		ddr = (md & 0x000A0000) >> 17;
		if(ddr == 0x0)			PutStr("LPDDR4 DDR3200",0);		//MD19=0,MD17=0 : DDR3200
		else if(ddr == 0x1)		PutStr("LPDDR4 DDR2800",0);		//MD19=0,MD17=1 : DDR2800
		else if(ddr == 0x4)		PutStr("LPDDR4 DDR2400",0);		//MD19=1,MD17=0 : DDR2400
		else if(ddr == 0x5)		PutStr("LPDDR4 DDR1600",0);		//MD19=1,MD17=1 : DDR1600
		else 					PutStr("Unknown setting",0);
	}

#ifdef DDR_8GB_1RANK			//Only R-CarH3 
	PutStr(" / 8GB_1RANK",1);
#elif  defined DDR_8GB_2RANK	//Only R-CarH3 
	PutStr(" / 8GB_2RANK",1);
#else
	PutStr("",1);
#endif

//=============================================================================
	PutStr(" DEVICE          : ",0);
	dev = (md & 0x0000001E) >> 1;

	if( (dev == 0x2) || (dev == 0x3) ){		//HyperFlash
		readID = ReadFlashID(dev);
	}else{
		ReadQspiFlashID64(&readDevId1,&readDevId2);
		readID       = readDevId1;
		readFamilyID = readDevId2 & 0x0000FF00;			//07h,06h,04h:�}�X�N
	}

	if(dev == 0x2)			//MD[4:1]=0010
	{
		if(readID == S26KS512_DEVICE_ID){
			if(CHK_D3||CHK_E3){
				PutStr("HyperFlash(S26KS512) at 150MHz DMA",1);	// HyperFlash on SiP
			}else{
				PutStr("HyperFlash(S26KS512) at 160MHz DMA",1);	// HyperFlash on SiP
			}
		}else{
			PutStr("HyperFlash(",0);	Data2HexAscii(readID,str,4);	PutStr("0x",0);		PutStr(str,0);	PutStr(") at 160MHz DMA",1);
		}
	}else if(dev == 0x3)		//MD[4:1]=0011
	{
		if(readID == S26KS512_DEVICE_ID)	PutStr("HyperFlash(S26KS512) at 80MHz DMA",1);	// HyperFlash on SiP
		else		{
			PutStr("HyperFlash(",0);	Data2HexAscii(readID,str,4);	PutStr("0x",0);		PutStr(str,0);	PutStr(") at 80MHz DMA",1);
		}
	}else if(dev == 0x4)		//MD[4:1]=0100
	{
		if(readFamilyID == FS_S_FAMILY){
			if(readID == S25FS128_DEVICE_ID)		PutStr("QSPI Flash(S25FS128) at 40MHz DMA",1);	// QSPI Flash on Board
			else if(readID == S25FS512_DEVICE_ID)	PutStr("QSPI Flash(S25FS512) at 40MHz DMA",1);	// QSPI Flash on Board (Eagle Board)
			else{
				PutStr("QSPI Flash(",0);	Data2HexAscii(readID,str,4);	PutStr("0x",0);		PutStr(str,0);	PutStr(") at 40MHz DMA",1);
			}
		}else if(readFamilyID == FL_S_FAMILY){
			if(readID == S25FL512_DEVICE_ID)		PutStr("QSPI Flash(S25FL512) at 40MHz DMA",1);	// QSPI Flash on QSPI Board
			else{
				PutStr("QSPI Flash(",0);	Data2HexAscii(readID,str,4);	PutStr("0x",0);		PutStr(str,0);	PutStr(") at 40MHz DMA",1);
			}
		}
	}else if(dev == 0x5)		//MD[4:1]=0101
	{
		PutStr("eMMC at 25MHz x1 bus DMA",1);	// eMMC on Salvator
	}else if(dev == 0x6)		//MD[4:1]=0110
	{
		if(readFamilyID == FS_S_FAMILY){
			if(readID == S25FS128_DEVICE_ID)		PutStr("QSPI Flash(S25FS128) at ",0);	// QSPI Flash on Board
			else if(readID == S25FS512_DEVICE_ID)	PutStr("QSPI Flash(S25FS512) at ",1);	// QSPI Flash on Board (Eagle Board)
			else{
				PutStr("QSPI Flash(",0);	Data2HexAscii(readID,str,4);	PutStr("0x",0);		PutStr(str,0);	PutStr(") at ",0);
			}
		}else if(readFamilyID == FL_S_FAMILY){
			if(readID == S25FL512_DEVICE_ID)	PutStr("QSPI Flash(S25FL512) at ",0);		// QSPI Flash on QSPI Board
			else{
				PutStr("QSPI Flash(",0);	Data2HexAscii(readID,str,4);	PutStr("0x",0);		PutStr(str,0);	PutStr(") at ",0);
			}
		}

		clksel = (*((volatile uint32_t*)MFISBTSTSR) & 0x0000FF00) >> 8;	
		if(clksel == 0x0)			PutStr("80MHz DMA(FAST_READ)",1);
		else if(clksel == 0x1)		PutStr("130MHz DMA(FAST_READ)",1);
		else if(clksel == 0x2)		PutStr("40MHz DMA(QOR)",1);
		else if(clksel == 0x3)		PutStr("80MHz DMA(QOR)",1);
		else if(clksel == 0x4)		PutStr("40MHz DMA(QIOR)",1);
		else if(clksel == 0x5)		PutStr("80MHz DMA(QIOR)",1);
		else 						PutStr("40MHz DMA(FAST_READ)",1);
	}else if(dev == 0x7)		//MD[4:1]=0111
	{
		if(readFamilyID == FS_S_FAMILY){
			if(readID == S25FS128_DEVICE_ID)		PutStr("QSPI Flash(S25FS128) at ",0);	// QSPI Flash on Board
			else if(readID == S25FS512_DEVICE_ID)	PutStr("QSPI Flash(S25FS512) at ",1);	// QSPI Flash on Board (Eagle Board)
			else{
			PutStr("QSPI Flash(",0);	Data2HexAscii(readID,str,4);	PutStr("0x",0);		PutStr(str,0);	PutStr(") at ",0);
			}
		}else if(readFamilyID == FL_S_FAMILY){
			if(readID == S25FL512_DEVICE_ID)	PutStr("QSPI Flash(S25FL512) at ",0);		// QSPI Flash on QSPI Board
			else{
			PutStr("QSPI Flash(",0);	Data2HexAscii(readID,str,4);	PutStr("0x",0);		PutStr(str,0);	PutStr(") at ",0);
			}
		}
		
		clksel = (*((volatile uint32_t*)MFISBTSTSR) & 0x0000FF00) >> 8;	
		if(clksel == 0x0)			PutStr("80MHz DMA(4FAST_READ)",1);
		else if(clksel == 0x1)		PutStr("130MHz DMA(4FAST_READ)",1);
		else if(clksel == 0x2)		PutStr("80MHz DMA(OCTAL)",1);
		else if(clksel == 0x3)		PutStr("160MHz DMA(OCTAL)",1);
		else if(clksel == 0x4)		PutStr("80MHz DMA(OCTAL)",1);
		else if(clksel == 0x5)		PutStr("160MHz DMA(OCTAL)",1);
		else 						PutStr("40MHz DMA(4FAST_READ)",1);
	}
	else if(dev == 0xD)		//MD[4:1]=1101
	{
		PutStr("eMMC at 50MHz x8 bus DMA",1);	// eMMC on Salvator
	}else PutStr("Unknown",1);
	
//=============================================================================
	PutStr(" BOOT            : ",0);
	auth = (md & 0x00000020) >> 5;
	if(auth == 0x0)		//MD5=0
	{
		PutStr("Secure Boot",0);
		authsel = (*((volatile uint32_t*)MFISBTSTSR) & 0x01000000) >> 24;
		if(authsel == 0x0)		PutStr("(w/o verification)",1);		//
		else if(authsel == 0x1)	PutStr("(with verification)",1);	//
	}else if(auth == 0x1)	PutStr("Normal Boot",1);	///MD5=1
	else 					PutStr("Unknown",1);

//=============================================================================
	if(CHK_V3M){
	
	}else if(CHK_D3){
	
	}else if(CHK_E3){
		PutStr(" BACKUP          : ",0);
		if(ddrBackup==COLD_BOOT){				PutStr("DDR Cold Boot",1);
		}else if(ddrBackup==WARM_BOOT){			PutStr("DDR Warm Boot",1);
		}else if(ddrBackup==WARM_BOOT_TIMEOUT){ PutStr("DDR Warm Boot Timeout Error",1);
		}else{ 									PutStr("Unknown",1);
		}
	}else{	// H3,M3,V3H
#ifdef H3_M3
		if(CHK_H3||CHK_M3||CHK_M3N){
			PutStr(" BACKUP          : ",0);
			if(ddrBackup==COLD_BOOT){				PutStr("DDR Cold Boot",1);
			}else if(ddrBackup==WARM_BOOT){			PutStr("DDR Warm Boot",1);
			}else if(ddrBackup==WARM_BOOT_TIMEOUT){
				PutStr("DDR Warm Boot Timeout Error",1);
				PutStr(" SW7,SW8 Setting OK? (SW7=1pin-side, SW8-1=ON)",1);
				PutStr(" Response of BKUP_TRG signal cannot be confirmed.",1);
				PutStr(" WARMBOOT canceled.",1);
			}else{
				PutStr("Unknown",1);
			}
		}
#endif
#ifdef V3H
		if(CHK_V3H){
			PutStr(" BACKUP          : ",0);
			if(ddrBackup==COLD_BOOT){				PutStr("DDR Cold Boot",1);
			}else if(ddrBackup==WARM_BOOT){			PutStr("DDR Warm Boot",1);
			}else if(ddrBackup==WARM_BOOT_TIMEOUT){
				PutStr("DDR Warm Boot Timeout Error",1);
				PutStr(" SW1 Setting OK? (SW1=ALL ON)",1);
				PutStr(" Response of BKUP_TRG signal cannot be confirmed.",1);
				PutStr(" WARMBOOT canceled.",1);
			}else{
				PutStr("Unknown",1);
			}
		}
#endif
	}
}


uint32_t ReadFlashID(uint32_t dev)
{
	uint32_t readData[2];
	uint32_t readID=0;
	
	switch(dev)
	{
		case 0x2:	//MD[4:1]=0010 : HyperFlash 160MHz DMA
		case 0x3:	//MD[4:1]=0011 : HyperFlash 80MHz DMA
			readID = ReadHyperFlashID(readData);
			ResetHyperFlash();
			break;
		case 0x4:	//MD[4:1]=0100 : QSPI Flash 40MHz DMA
		case 0x6:	//MD[4:1]=0110 : QSPI Flash 80MHz DMA
		case 0x7:	//MD[4:1]=0111 : Octal Flash 160/80MHz DMA
			readID = ReadQspiFlashID(readData);
			break;
		default:
			readID = 0;
			break;
	}
	return(readID);
}


uint32_t BootLoaderMain(void)
{
	uint32_t md=0;
	uint32_t dev=0;
	uint32_t mode=0;
	uint32_t accessSize=0;
	uint32_t offset=0;
	uint32_t rtn_val=0;
	uint32_t dataL=0;
	uint32_t readData[2];
	uint32_t sector04_Ad=0;
	char str[64];
	uint32_t sourceRpcMemAdd=0;
	uint32_t workReadSize=0;
	uint32_t workAdd=0;


//	qos_init();

//-----------------------------------------------------------------------------
//	MD pin check
//-----------------------------------------------------------------------------
	md = *((volatile uint32_t*)RST_MODEMR);
	
#ifdef MESS_ON
	PutStr(" ",1);
	PutMess(bootStartMess);

	Mess_Board_Judge(1);

#ifdef H3_M3
	if(CHK_H3||CHK_M3||CHK_M3N){
		Mess_DdrBoard_Judge(1);		//Display code [dram_config:_board_judge]
	}
#endif
#ifdef V3H
	Mess_DdrBoard_Judge(1);			//Display code [dram_config:_board_judge]
#endif
	InitMessage();
	BOOT_Message(md);
#endif

	dev = (md & 0x0000001E) >> 1;
	if(dev == 0x2) mode = HYPER_FLASH;		//MD[4:1]=0010 : HyperFlash 160MHz DMA
	else if(dev == 0x3)	mode = HYPER_FLASH;	//MD[4:1]=0011 : HyperFlash 80MHz DMA
	else if(dev == 0x4)	mode = QSPI_FLASH;	//MD[4:1]=0100 : QSPI Flash 40MHz DMA
	else if(dev == 0x6)	mode = QSPI_FLASH;	//MD[4:1]=0110 : QSPI Flash 80MHz DMA
//	else if(dev == 0x7)	mode = QSPI_FLASH;	//MD[4:1]=0111 : Octal Flash 160/80MHz DMA

//-----------------------------------------------------------------------------
//	User Program Image
//-----------------------------------------------------------------------------

//RPC Manual Read
    if(mode == HYPER_FLASH)    //HyperFlash
    {
        ReadHyperFlashData8Byte(ADDR_SECTOR_03_TOP,&prgStartAd);				//User Program Addr :0x000C0000 (SPI_Add)
        ReadHyperFlashData8Byte((ADDR_SECTOR_03_TOP + 0x4),&accessSize);		//User Program Data Size(word size) :0x000C0004  (SPI_Add)
    }
    else
	{
		SingleReadQspiFlashData4Byte(ADDR_SECTOR_03_TOP,&prgStartAd);			//User Program Addr :0x000C0000 (SPI_Add)
		SingleReadQspiFlashData4Byte((ADDR_SECTOR_03_TOP + 0x4),&accessSize);	//User Program Data Size(word size) :0x000C0004  (SPI_Add)
	}
	accessSize = accessSize * 4;												//User Program Data Size
	sector04_Ad = (ADDR_RPC_MEM_TOP + ADDR_SECTOR_04_TOP);						//from SPI NOR Flash: 0x00100000

//	RPC External Address Area Read mode settings
	InitRPC_ExtMode(mode);
//==DMA==
	mem_copy(prgStartAd, sector04_Ad, accessSize);

//===========    R-CarV3H�p AArch32 Kick�Ή�    =======================================================
#ifdef AArch32
#ifdef KICK_CA53
#ifdef MESS_ON
	Data2HexAscii(prgStartAd,str,4);
	PutStr(" Set CA53 Boot Address : 0x",0);
	PutStr(str,1);
	WaitPutCharSendEnd();
	PutStr(" WAKE UP CA53",1);
	WaitPutCharSendEnd();
#endif
	SetBootAddress(CA53_CPU0, (uintptr_t)prgStartAd);	// AArch32 boot -> CA53(AArch64)	[Condor�̃��C������AAArch64(MD15=1)�̏ꍇ����]
	WakeupArmCore(CA53_CPU0);

	CntLedNR();		//while(1);
#endif
#endif
//=====================================================================================================

#ifdef MESS_ON
	Data2HexAscii(prgStartAd,str,4);
	PutStr(" jump to 0x",0);
	PutStr(str,1);
	WaitPutCharSendEnd();
#endif

	return(prgStartAd);					//AArch64�AAArch32(Kick=NA)
}



//=============================================================================
//
// Memory Copy from HyperFlash to SystemRAM
//
//=============================================================================
void mem_copy(uint32_t prgStartAd, uint32_t sector_Ad, uint32_t accessSize)
{
	if(CHK_V3M||CHK_V3H){	// Eagle,Condor (R-CarV3x Only)
		mem_copy_RtDmac(prgStartAd, sector_Ad, accessSize);
	}else{					// Salvator / Kriek / StarterKit / Draak / Ebisu (Other:R-CarH3x/M3x/E3/D3)
		mem_copy_SysDmac(prgStartAd, sector_Ad, accessSize);
	}
}

void mem_copy_SysDmac(uint32_t prgStartAd, uint32_t sector_Ad, uint32_t accessSize)
{
	uint32_t paddingOffset=0;
	uint32_t accessCount=0;
	
	if((CHK_H3) && (CHK_ES1X)){	//== R_CarH3_ES1.X ==
		paddingOffset = (accessSize + 0x3F ) & ~0x3F;		//calculate padding size (64byte)
	}else{
		paddingOffset = (accessSize + 0xFF ) & ~0xFF;		//calculate padding size (256byte)
	}
	//accessCount = accessSize/64;
	accessCount = paddingOffset >> 6;
	
	//DMA Setting
	InitDma01_Data(prgStartAd, sector_Ad, accessCount);
	StartDma01();
	WaitDma01();
	WaitRpcTxEnd();
	DisableDma01();
	ClearDmaCh01();
}

void mem_copy_RtDmac(uint32_t prgStartAd, uint32_t sector_Ad, uint32_t accessSize)
{
	uint32_t paddingOffset=0;
	uint32_t accessCount=0;


	paddingOffset = (accessSize + 0xFF ) & ~0xFF;			//calculate padding size (256byte)

	//accessCount = accessSize/64;
	accessCount = paddingOffset >> 6;

	//DMA Setting
	InitRtDmaCh0(prgStartAd, sector_Ad, accessCount);
	StartRtDmaCh0_15();
	WaitRtDmaCh0();
	WaitRpcTxEnd();
	DisableRtDmaCh0();
	ClearRtDmaCh0();
}

