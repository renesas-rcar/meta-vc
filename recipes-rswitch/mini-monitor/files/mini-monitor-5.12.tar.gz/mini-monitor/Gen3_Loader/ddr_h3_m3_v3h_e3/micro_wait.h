/**********************************************************/
/* Sample program : Dummy Header                          */
/* File Name      : micro_wait.h                          */
/* Copyright (C) Renesas Electronics Corp. 2018.          */
/**********************************************************/

#pragma once

#include <stdint.h>
#include "cpudrv.h"

static inline void micro_wait(uint32_t time)
{
	if(time<10) StartTMU0usec(1);
	else{
		if(time%10) StartTMU0usec(time/10+1);
		else        StartTMU0usec(time/10);
	}
}

