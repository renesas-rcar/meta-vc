/**********************************************************/
/* Sample program : Dummy Header                          */
/* File Name      : iic_dvfs.h                            */
/* Copyright (C) Renesas Electronics Corp. 2018.          */
/**********************************************************/

#pragma once

#include <stdint.h>
#include "i2cdrv.h"
#include "iicdrv.h"
#include "boardid.h"

#undef PMIC_BKUP_MODE_CNT				// BKUP Mode Cnt
#undef PMIC_QLLM_CNT


static inline int32_t rcar_iic_dvfs_recieve(uint8_t slAddr, uint8_t regAddr, uint8_t *rdData)
{
	uint32_t err, rdData32;

	if(CHK_V3H){
		InitI2c(I2C_CH0);
		err = RandomAddressReadI2C(I2C_CH0, slAddr<<1,regAddr,&rdData32,1);
	}
	else{
		err = RandomAddressReadIic0(slAddr<<1,regAddr,&rdData32,1);
	}
	*rdData = rdData32;

	if(err) return -1;
	return 0;
}

static inline int32_t rcar_iic_dvfs_send(uint8_t slAddr, uint8_t regAddr, uint8_t wrData)
{
	uint32_t err, wrData32;

	wrData32 = wrData;
	if(CHK_V3H){
		InitI2c(I2C_CH0);
		err = PageWriteI2C(I2C_CH0, slAddr<<1,regAddr,&wrData32,1);
	}else{
		err = PageWriteIic0(slAddr<<1,regAddr,&wrData32,1);
	}

	if(err) return -1;
	return 0;
}

