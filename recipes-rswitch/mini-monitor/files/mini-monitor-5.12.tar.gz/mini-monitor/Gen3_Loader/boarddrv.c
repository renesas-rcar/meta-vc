#include "common.h"
#include "reg_rcargen3.h"
#include "bit.h"
#include "cpudrv.h"
#include "boardid.h"
#include "boarddrv.h"

// Connect = return 0
// Open    = return 1
uint32_t SSI_WS6_OpenCheck(void)
{
	uint32_t dataL, down, up;

	// Pull-Up/Down Enable (PUEN5[22]=1)
	dataL = *((volatile uint32_t*)PFC_PUEN5);
	dataL |= (BIT22);
	*((volatile uint32_t*)PFC_PMMR)  = ~dataL;
	*((volatile uint32_t*)PFC_PUEN5) =  dataL;
	while( 0 == (BIT22 & *((volatile uint32_t*)PFC_PUEN5)) );  // wait 1

	// Pull-Down-Enable (PUD5[22]=0, PUEN5[22]=1)
	dataL = *((volatile uint32_t*)PFC_PUD5);
	dataL &= ~(BIT22);
	*((volatile uint32_t*)PFC_PMMR) = ~dataL;
	*((volatile uint32_t*)PFC_PUD5) =  dataL;
	while( 0 != (BIT22 & *((volatile uint32_t*)PFC_PUD5)) );  // wait 0
	StartTMU0usec(1);										  // wait 10us
	down = GetGpioInputLevel(6,15);	// GPSR6[15]=SSI_WS6

	// Pull-Up-Enable (PUD5[22]=1, PUEN5[22]=1)
	dataL = *((volatile uint32_t*)PFC_PUD5);
	dataL |= (BIT22);
	*((volatile uint32_t*)PFC_PMMR) = ~dataL;
	*((volatile uint32_t*)PFC_PUD5) =  dataL;
	while( 0 == (BIT22 & *((volatile uint32_t*)PFC_PUD5)) );  // wait 1
	StartTMU0usec(1);										  // wait 10us
	up = GetGpioInputLevel(6,15);	// GPSR6[15]=SSI_WS6

	// Pull-Up/Down Disable (PUEN5[22]=0)
	dataL = *((volatile uint32_t*)PFC_PUEN5);
	dataL &= ~(BIT22);
	*((volatile uint32_t*)PFC_PMMR)  = ~dataL;
	*((volatile uint32_t*)PFC_PUEN5) =  dataL;
	while( 0 != (BIT22 & *((volatile uint32_t*)PFC_PUEN5)) );  // wait 0

	// Compare
	if( down == up ){
		// Same = Connect
		return 0;
	}else{
		// Diff = Open
		return 1;
	}
}


// Connect = return 0
// Open    = return 1
uint32_t USB0_OVC_OpenCheck(void)
{
	uint32_t dataL, down, up;

	// Pull-Up/Down Enable (PUD6[0]=1)
	dataL = *((volatile uint32_t*)PFC_PUEN6);
	dataL |= (BIT0);
	*((volatile uint32_t*)PFC_PMMR)  = ~dataL;
	*((volatile uint32_t*)PFC_PUEN6) =  dataL;
	while( 0 == (BIT0 & *((volatile uint32_t*)PFC_PUEN6)) );  // wait 1

	// Pull-Down-Enable (PUD6[0]=0, PUEN6[0]=1)
	dataL = *((volatile uint32_t*)PFC_PUD6);
	dataL &= ~(BIT0);
	*((volatile uint32_t*)PFC_PMMR) = ~dataL;
	*((volatile uint32_t*)PFC_PUD6) =  dataL;
	while( 0 != (BIT0 & *((volatile uint32_t*)PFC_PUD6)) );  // wait 0
	StartTMU0usec(1);										 // wait 10us
	down = GetGpioInputLevel(6,25);	// GPSR6[25]=USB0_OVC

	// Pull-Up-Enable (PUD6[0]=1, PUEN6[22]=1)
	dataL = *((volatile uint32_t*)PFC_PUD6);
	dataL |= (BIT0);
	*((volatile uint32_t*)PFC_PMMR) = ~dataL;
	*((volatile uint32_t*)PFC_PUD6) =  dataL;
	while( 0 == (BIT0 & *((volatile uint32_t*)PFC_PUD6)) );  // wait 1
	StartTMU0usec(1);										 // wait 10us
	up = GetGpioInputLevel(6,25);	// GPSR6[25]=USB0_OVC

	// Pull-Up/Down Disable (PUEN6[22]=0)
	dataL = *((volatile uint32_t*)PFC_PUEN6);
	dataL &= ~(BIT0);
	*((volatile uint32_t*)PFC_PMMR)  = ~dataL;
	*((volatile uint32_t*)PFC_PUEN6) =  dataL;
	while( 0 != (BIT0 & *((volatile uint32_t*)PFC_PUEN6)) );  // wait 0

	// Compare
	if( down == up ){
		// Same = Connect
		return 0;
	}else{
		// Diff = Open
		return 1;
	}
}
