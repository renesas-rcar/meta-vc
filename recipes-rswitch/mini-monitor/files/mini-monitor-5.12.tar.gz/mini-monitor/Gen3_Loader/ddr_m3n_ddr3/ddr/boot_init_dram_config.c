/*
 * Copyright (c) 2015-2018, Renesas Electronics Corporation. All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

/*******************************************************************************
 *	NUMBER OF BOARD CONFIGRATION
 *	PLEASE DEFINE
 ******************************************************************************/
#define BOARDNUM 4
/*******************************************************************************
 *	PLEASE SET board number or board judge function
 ******************************************************************************/
//#define BOARD_JUDGE_AUTO
#ifdef BOARD_JUDGE_AUTO
static uint32_t _board_judge(void);
static uint32_t boardcnf_get_brd_type(void) {
		return _board_judge();
}
#else
static uint32_t boardcnf_get_brd_type(void) {
//		return (0);
		return _ddr3_board_judge_bid();
}
#endif

/*******************************************************************************
 *	BOARD CONFIGRATION
 *	PLEASE DEFINE boardcnfs[]
 ******************************************************************************/
struct _boardcnf_ch {
	/*0x00... 2Gbit/16bit x2
	 *0x02... 4Gbit/16bit x2
	 *0x04... 8Gbit/16bit x2
	 *0xff...NO_MEMORY
	 */
	uint8_t	 ddr_density[CS_CNT];
	/*SoC caX([15][14]....[3][2][1][0]) -> MEM caY: */
	uint64_t ca_swap;
	/*SoC dqsX([3][2][1][0]) -> MEM dqsY: */
	uint16_t dqs_swap;
	/*SoC dq([7][6][5][4][3][2][1][0]) -> MEM dqY/dm:  (8 means DM)*/
	uint32_t dq_swap[SLICE_CNT];
	/*SoC dm -> MEM dqY/dm:  (8 means DM)*/
	uint8_t dm_swap[SLICE_CNT];
	/* write traing pattern
 	 * (DM,DQ7,....DQ0) x BL16
 	 */
	uint16_t wdqlvl_patt[16];
	/* delay adjustment is ps*/
	int8_t cacs_adj[20];
	int8_t dm_adj_w[SLICE_CNT];
	int8_t dq_adj_w[SLICE_CNT*8];
	int8_t dm_adj_r[SLICE_CNT];
	int8_t dq_adj_r[SLICE_CNT*8];

}__attribute__ ((aligned(64)));

struct _boardcnf {
	/* ch in use */
	uint8_t phyvalid;
	/* use ddr mode : DDR3L=1, DDR3=0 */
	uint8_t ddr_mode;
	/* use speed bins table */
	uint8_t ddr_speed_bins;
	/* default CA/CS delay value */
	uint16_t cacs_dly;
	/* default CA/CS delay adjust value in ps*/
	int16_t cacs_dly_adj;
	/* default DQ/DM delay value for write*/
	uint16_t dqdm_dly_w;
	/* default DQ/DM delay value for read*/
	uint16_t dqdm_dly_r;
	struct _boardcnf_ch ch[DRAM_CH_CNT];
}__attribute__ ((aligned(64)));

/* write traing pattern
 * (DM,DQ7,....DQ0) x BL16
 */
#define WDQLVL_PAT {\
	0x00AA,\
	0x0055,\
	0x00AA,\
	0x0155,\
	0x01CC,\
	0x0133,\
	0x00CC,\
	0x0033,\
	0x00F0,\
	0x010F,\
	0x01F0,\
	0x010F,\
	0x00F0,\
	0x00F0,\
	0x000F,\
	0x010F}

static const struct _boardcnf boardcnfs[BOARDNUM] = {
/*
 * boardcnf[0] RENESAS KRIEK-DDR3 board w M3-W
 */
{
	0x03,		/* phyvalid */
	0x00,		/* ddr mode */
	0x00,		/* speed bins tbl */
	0x2c0,		/* cacs_dly */
	0x000,		/* cacs_dly_adj */
	0x300,		/* dqdm_dly_w */
	0x0a0,		/* dqdm_dly_r */
	{
/*ch[0]*/	{
/*ddr_density[]*/	{ 0x02, 0xff }, 	// 4Gbit(16x256M) x 2chip
/*ca_swap*/		0x2D391AC8F07B654E,
/*dqs_swap*/		0x3201,
/*dq_swap[]*/		{ 0x74516320, 0x71436520, 0x06245731, 0x61472530 },
/*dm_swap[]*/		{ 0x08, 0x08, 0x08, 0x08 },
/*wdqlvl_patt[]*/	WDQLVL_PAT,
/*cacs_adj*/		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
/*dm_adj_w*/		{ 0, 0, 0, 0 },
/*dqdm_adj_w*/		{ 0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0},
/*dm_adj_r*/		{ 0, 0, 0, 0 },
/*dqdm_adj_r*/		{ 0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0}
		},
/*ch[1]*/	{
/*ddr_density[]*/	{0x02, 0xff}, 
/*ca_swap*/		0x1E3B2AC8F069745D,
/*dqs_swap*/		0x3201,
/*dq_swap[]*/		{ 0x75413620, 0x40527631, 0x15374620, 0x57143620 },
/*dm_swap[]*/		{ 0x08, 0x08, 0x08, 0x08 },
/*wdqlvl_patt[]*/	WDQLVL_PAT,
/*cacs_adj*/		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
/*dm_adj_w*/		{ 0, 0, 0, 0 },
/*dqdm_adj_w*/		{ 0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0},
/*dm_adj_r*/		{ 0, 0, 0, 0 },
/*dqdm_adj_r*/		{ 0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0}
		}
	}
},
/*
 * boardcnf[1] RENESAS KRIEK-DDR3L board w M3-W
 */
{
	0x03,		/* phyvalid */
	0x01,		/* ddr mode */
	0x00,		/* speed bins tbl */
	0x2c0,		/* cacs_dly */
	0x000,		/* cacs_dly_adj */
	0x300,		/* dqdm_dly_w */
	0x0a0,		/* dqdm_dly_r */
	{
/*ch[0]*/	{
/*ddr_density[]*/	{ 0x02, 0xff }, 	// 4Gbit(16x256M) x 2chip
/*ca_swap*/		0x2D391AC8F07B654E,
/*dqs_swap*/		0x3201,
/*dq_swap[]*/		{ 0x74516320, 0x71436520, 0x06245731, 0x61472530 },
/*dm_swap[]*/		{ 0x08, 0x08, 0x08, 0x08 },
/*wdqlvl_patt[]*/	WDQLVL_PAT,
/*cacs_adj*/		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
/*dm_adj_w*/		{ 0, 0, 0, 0 },
/*dqdm_adj_w*/		{ 0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0},
/*dm_adj_r*/		{ 0, 0, 0, 0 },
/*dqdm_adj_r*/		{ 0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0}
		},
/*ch[1]*/	{
/*ddr_density[]*/	{0x02, 0xff}, 
/*ca_swap*/		0x1E3B2AC8F069745D,
/*dqs_swap*/		0x3201,
/*dq_swap[]*/		{ 0x75413620, 0x40527631, 0x15374620, 0x57143620 },
/*dm_swap[]*/		{ 0x08, 0x08, 0x08, 0x08 },
/*wdqlvl_patt[]*/	WDQLVL_PAT,
/*cacs_adj*/		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
/*dm_adj_w*/		{ 0, 0, 0, 0 },
/*dqdm_adj_w*/		{ 0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0},
/*dm_adj_r*/		{ 0, 0, 0, 0 },
/*dqdm_adj_r*/		{ 0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0}
		}
	}
},
/*
 * boardcnf[2] RENESAS KRIEK-DDR3 board w M3-N
 */
{
	0x01,		/* phyvalid */
	0x00,		/* ddr mode */
	0x00,		/* speed bins tbl */
	0x340,		/* cacs_dly */
	0x000,		/* cacs_dly_adj */
	0x2c0,		/* dqdm_dly_w */
	0x0a0,		/* dqdm_dly_r */
	{
/*ch[0]*/	{
/*ddr_density[]*/	{ 0x02, 0xff }, 	// 4Gbit(16x256M) x 2chip
/*ca_swap*/		0x2D391AC8F07B654E,
/*dqs_swap*/		0x3201,
/*dq_swap[]*/		{ 0x74516320, 0x71436520, 0x06245731, 0x61472530 },
/*dm_swap[]*/		{ 0x08, 0x08, 0x08, 0x08 },
/*wdqlvl_patt[]*/	WDQLVL_PAT,
/*cacs_adj*/		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
/*dm_adj_w*/		{ 0, 0, 0, 0 },
/*dqdm_adj_w*/		{ 0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0},
/*dm_adj_r*/		{ 0, 0, 0, 0 },
/*dqdm_adj_w*/		{ 0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0}
		}
	}
},
/*
 * boardcnf[3] RENESAS KRIEK-DDR3L board w M3-N
 */
{
	0x01,		/* phyvalid */
	0x01,		/* ddr mode */
	0x00,		/* speed bins tbl */
	0x340,		/* cacs_dly */
	0x000,		/* cacs_dly_adj */
	0x2c0,		/* dqdm_dly_w */
	0x0a0,		/* dqdm_dly_r */
	{
/*ch[0]*/	{
/*ddr_density[]*/	{ 0x02, 0xff }, 	// 4Gbit(16x256M) x 2chip
/*ca_swap*/		0x2D391AC8F07B654E,
/*dqs_swap*/		0x3201,
/*dq_swap[]*/		{ 0x74516320, 0x71436520, 0x06245731, 0x61472530 },
/*dm_swap[]*/		{ 0x08, 0x08, 0x08, 0x08 },
/*wdqlvl_patt[]*/	WDQLVL_PAT,
/*cacs_adj*/		{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
/*dm_adj_w*/		{ 0, 0, 0, 0 },
/*dqdm_adj_w*/		{ 0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0},
/*dm_adj_r*/		{ 0, 0, 0, 0 },
/*dqdm_adj_r*/		{ 0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0,
			  0, 0, 0, 0, 0, 0, 0, 0}
		}
	}
}
};
/*******************************************************************************
 *	EXTAL CLOCK DEFINITION
 *	PLEASE DEFINE HOW TO JUDGE BORAD CLK
 ******************************************************************************/
/*
 * RENESAS KRIEK-DDR3 BOARD EXAMPLE
 * judge by md14/md13
 *
 * 16.66MHz CLK,DIV= 50,3  (md14,md13==0,0)
 * 20.00MHz CLK,DIV= 60,3  (md14,md13==0,1)
 * 25.00MHz CLK,DIV= 75,3  (md14,md13==1,0)
 * 33.33MHz CLK,DIV=100,3  (md14,md13==1,1)
*/
void boardcnf_get_brd_clk(uint32_t brd, uint32_t *clk, uint32_t *div) {
	uint32_t md;
	md = (mmio_read_32(RST_MODEMR)>>13)&0x3;
	switch(md){
		case 0x0 : *clk = 50; *div = 3; break;
		case 0x1 : *clk = 60; *div = 3; break;
		case 0x2 : *clk = 75; *div = 3; break;
		case 0x3 : *clk =100; *div = 3; break;
	}
	(void)brd;
}

/*******************************************************************************
 *	DDR MBPS TARGET
 *	PLEASE DEFINE HOW TO JUDGE DDR BPS
 ******************************************************************************/
/*
//DDR3-xxxx (judge_ by md19,17): Mbps
//DDR3-2133 (md19,17==0,0) : 2133
//DDR3-2133 (md19,17==0,1) : 2133
//DDR3-1866 (md19,17==1,0) : 1866
//DDR3-1600 (md19,17==1,1) : 1600
*/

void boardcnf_get_ddr_mbps(uint32_t brd, uint32_t *mbps, uint32_t *div) {
	uint32_t md;

	md = (mmio_read_32(RST_MODEMR)>>17) & 0x05;

	switch(md){
		case 0x0 : *mbps = 6400; *div = 3; break; // 6400/3=2133Mbps
		case 0x1 : *mbps = 6400; *div = 3; break; // 6400/3=2133Mbps
		case 0x4 : *mbps = 5600; *div = 3; break; // 5600/3=1866Mbps
		case 0x5 : *mbps = 1600; *div = 1; break; // 1600/1=1600Mbps
		default  : *mbps = 1600; *div = 1; break; // 1600/1=1600Mbps
	}
	(void)brd;
}

/*******************************************************************************
 *	DRAM PARAMETER DEFINITON
 ******************************************************************************/
#define JS1_FREQ_TBL_NUM 6
struct _jedec_spec1 {
	uint16_t fx3;	// (Mbps X 3)/2
	uint8_t  RL;	// CL cycle
	uint8_t  WL;	// CWL cycle
	uint16_t tRCD;	// tRCD,tRP[ps]
	uint16_t tRC;	// tRC[ps]
	uint16_t tRAS;	// tRAS[ps]
	uint16_t tRRD;	// tRRD[ps]
	uint16_t tFAW;	// tFAW[ps]
	uint16_t tXP;	// tXP[ps]
	uint16_t tCKE;	// tCKE[ps]

	uint16_t MR0;
	uint8_t  MR2;
};

const struct _jedec_spec1 js1[4][JS1_FREQ_TBL_NUM] = {
{
/*	{Mbps*3/2, CL,CWL, tRCD,  tRC,   tRAS,  tRRD,  tFAW,  tXP,  tCKE, MR0,    MR2	},				*/
	{ 1600,     7,  6, 13125, 50625, 37500, 10000, 50000, 7500, 5625, 0x0930, 0x08	},	/* DDR3-1066F/ 7- 7- 7	*/
	{ 2000,     9,  7, 13500, 49500, 36000,  7500, 45000, 6000, 5625, 0x0B50, 0x10	},	/* DDR3-1333H/ 9- 9- 9	*/
	{ 2400,    11,  8, 13750, 48750, 35000,  7500, 40000, 6000, 5000, 0x0D70, 0x18	},	/* DDR3-1600K/11-11-11	*/
	{ 2800,    13,  9, 13910, 47910, 34000,  6000, 35000, 6000, 5000, 0x0F14, 0x20	},	/* DDR3-1866M/13-13-13	*/
	{ 3200,    14, 10, 13090, 46090, 33000,  6000, 35000, 6000, 5000, 0x0124, 0x28	},	/* DDR3-2133N/14-14-14	*/
	{ 3600,    14, 10, 13090, 46090, 33000,  6000, 35000, 6000, 5000, 0x0124, 0x28	}	/* DDR3-?????/(dummy) */
},{
/*	{Mbps*3/2, CL,CWL, tRCD,  tRC,   tRAS,  tRRD,  tFAW,  tXP,  tCKE, MR0,    MR2	},				*/
	{ 1600,     7,  6, 13125, 50625, 37500, 10000, 50000, 7500, 5625, 0x0930, 0x08	},	/* DDR3-1066F/ 7- 7- 7	*/
	{ 2000,     9,  7, 13500, 49500, 36000,  7500, 45000, 6000, 5625, 0x0B50, 0x10	},	/* DDR3-1333H/ 9- 9- 9	*/
	{ 2400,    10,  8, 12500, 47500, 35000,  7500, 40000, 6000, 5000, 0x0D60, 0x18	},	/* DDR3-1600J/10-10-10	*/
	{ 2800,    12,  9, 12840, 46840, 34000,  6000, 35000, 6000, 5000, 0x0F04, 0x20	},	/* DDR3-1866L/12-12-12	*/
	{ 3200,    13, 10, 12155, 45155, 33000,  6000, 35000, 6000, 5000, 0x0114, 0x28	},	/* DDR3-2133M/13-13-13	*/
	{ 3600,    13, 10, 12155, 45155, 33000,  6000, 35000, 6000, 5000, 0x0114, 0x28	}	/* DDR3-?????/(dummy) */
},{
/*	{Mbps*3/2, CL,CWL, tRCD,  tRC,   tRAS,  tRRD,  tFAW,  tXP,  tCKE, MR0,    MR2	},				*/
	{ 1600,     6,  6, 11250, 48750, 37500, 10000, 50000, 7500, 5625, 0x0920, 0x08	},	/* DDR3-1066E/ 6- 6- 6	*/
	{ 2000,     8,  7, 12000, 48000, 36000,  7500, 45000, 6000, 5625, 0x0B40, 0x10	},	/* DDR3-1333G/ 8- 8- 8	*/
	{ 2400,     9,  8, 11250, 46250, 35000,  7500, 40000, 6000, 5000, 0x0D50, 0x18	},	/* DDR3-1600H/ 9- 9- 9	*/
	{ 2800,    11,  9, 11770, 45770, 34000,  6000, 35000, 6000, 5000, 0x0F70, 0x20	},	/* DDR3-1866K/11-11-11	*/
	{ 3200,    12, 10, 11220, 44220, 33000,  6000, 35000, 6000, 5000, 0x0104, 0x28	},	/* DDR3-2133L/12-12-12	*/
	{ 3600,    12, 10, 11220, 44220, 33000,  6000, 35000, 6000, 5000, 0x0104, 0x28	}	/* DDR3-?????/(dummy) */
},{
/*	{Mbps*3/2, CL,CWL, tRCD,  tRC,   tRAS,  tRRD,  tFAW,  tXP,  tCKE, MR0,    MR2	},				*/
	{ 1600,     6,  6, 11250, 48750, 37500, 10000, 50000, 7500, 5625, 0x0920, 0x08	},	/* DDR3-1066E/ 6- 6- 6	*/
	{ 2000,     7,  7, 10500, 46500, 36000,  7500, 45000, 6000, 5625, 0x0B30, 0x10	},	/* DDR3-1333F/ 7- 7- 7	*/
	{ 2400,     9,  8, 11250, 46250, 35000,  7500, 40000, 6000, 5000, 0x0D50, 0x18	},	/* DDR3-1600H/ 9- 9- 9	*/
	{ 2800,    10,  9, 10700, 44700, 34000,  6000, 35000, 6000, 5000, 0x0F60, 0x20	},	/* DDR3-1866J/10-10-10	*/
	{ 3200,    11, 10, 10825, 43285, 33000,  6000, 35000, 6000, 5000, 0x0170, 0x28	},	/* DDR3-2133K/11-11-11	*/
	{ 3600,    11, 10, 10825, 43285, 33000,  6000, 35000, 6000, 5000, 0x0170, 0x28	}	/* DDR3-?????/(dummy) */
}
};

#ifdef BOARD_JUDGE_AUTO
/*******************************************************************************
 *	SAMPLE board detect function
 ******************************************************************************/

static uint32_t _board_judge(void) {
	uint32_t brd;
	/* RENESAS Kriek-DDR3 board */
	if(PRR_PRODUCT_M3 == Prr_Product) {
//		brd = 0; // DDR3
		brd = 1; // DDR3L
	} else {
//		brd = 2; // DDR3
		brd = 3; // DDR3L
	}
	return brd;
}
#endif
