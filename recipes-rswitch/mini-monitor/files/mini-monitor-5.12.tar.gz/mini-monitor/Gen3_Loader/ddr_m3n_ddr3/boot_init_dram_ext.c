/**********************************************************/
/* Sample program : Init Dram Extend Functions            */
/* File Name      : boot_init_dram_ext.c                  */
/* Copyright (C) Renesas Electronics Corp. 2015.          */
/**********************************************************/

#include "boot_init_dram_ext.h"
#include "boardid.h"
#include "debug.h"

uint32_t gBoardcnf;			//Used Gen3 Board Loader/minimonitor

uint32_t _board_judge_bid(void)
{
	uint32_t brd = 0xFFFFFFFF;

	if(CHK_H3){
		if(CHK_KRIEK){
			if(CHK_H3_ES1X){	// Kriek + PM3SoC = 4GB
				brd = BOARD_PM3SOC_KRIEK_4GB;
			}else{				// Kriek + H3NSoC = 4GB
				brd = BOARD_H3NSOC_KRIEK_4GB;
			}
		}else{
			if(CHK_H3_ES1X){	// H3-ES1.x SiP = 4GB
				brd = BOARD_H3SIP_ES1x_4GB;
			}else{				// H3-ES2.x~ SiP = 4GB
				brd = BOARD_H3SIP_4GB;
			}
		}
	}else if(CHK_M3){
		if(CHK_KRIEK){				// Kriek + M3SoC = 4GB
			brd = BOARD_M3SOC_KRIEK_4GB;
		}else if(CHK_STARTERKIT){	// StarterKit + M3SiP = 2GB
			brd = BOARD_M3SIP_2GB;
		}else{						// Salvator + M3SiP = 4GB
			brd = BOARD_M3SIP_4GB_2RANK;
		}
	}else if(CHK_M3N){
		if(CHK_KRIEK){				// Kriek + M3NSoC = 2GB
			brd = BOARD_M3NSOC_KRIEK_2GB;
		}else{						// Salvator + M3NSiP = 2GB
			brd = BOARD_M3NSIP_2GB;
		}
	}else if(CHK_V3H){
			brd = BOARD_V3HSOC_2GB;	// Condor + V3HSoC = 2GB
	}

//----------------------// Add for H3SiP-8GB
#ifdef DDR_8GB_1RANK
	if(brd==BOARD_H3SIP_4GB     ) brd=BOARD_H3SIP_8GB_1RANK;		// boardcnf[14] RENESAS SALVATOR-X board with H3SIP_ver2.0/3.0-16Gbit-1rank
#endif
#ifdef DDR_8GB_2RANK
	if(brd==BOARD_H3SIP_4GB     ) brd=BOARD_H3SIP_8GB_2RANK;		// boardcnf[8] RENESAS SALVATOR-X board with H3SIP_ver2.0-2rank
	if(brd==BOARD_H3SIP_ES1x_4GB) brd=BOARD_H3SIP_ES1x_8GB_2RANK;	// boardcnf[6] RENESAS SALVATOR-X board with H3SIP-2rank
#endif
//----------------------// Add for H3SiP-8GB

	gBoardcnf=brd;

	if(brd==0xFFFFFFFF){
		NOTICE("\n");
		NOTICE("_board_judge_bid() returns 0xFFFFFFFF\n");
	}

	INFO("boardcnfs[%d]", brd);

	return brd;
}



uint32_t _ddr3_board_judge_bid(void)
{
	uint32_t brd = 0xFFFFFFFF;

	if(CHK_M3){
#ifdef DDR3
		brd = 0; // DDR3
#elif  defined DDR3L
		brd = 1; // DDR3L
#endif
	}else if(CHK_M3N){
#ifdef DDR3
		brd = 2; // DDR3
#elif  defined DDR3L
		brd = 3; // DDR3L
#endif
	}

	gBoardcnf=brd;

	if(brd==0xFFFFFFFF){
		NOTICE("\n");
		NOTICE("_board_judge_bid() returns 0xFFFFFFFF\n");
	}

	INFO("boardcnfs[%d]", brd);

	return brd;
}
