/**********************************************************/
/* Sample program : Init Dram Extend Functions            */
/* File Name      : boot_init_dram_ext.h                  */
/* Copyright (C) Renesas Electronics Corp. 2015.          */
/**********************************************************/

#ifndef _BOOT_INIT_DRAM_EXT_H_
#define _BOOT_INIT_DRAM_EXT_H_

#include <stdint.h>



// not use qos_init
#define ddr_qos_init_setting

// DDR Backup
#define RCAR_SYSTEM_SUSPEND	1
#define PMIC_ROHM_BD9571	1

// E3	DRAM size ( Settings for E3)
#define RCAR_DRAM_DDR3L_MEMCONF  0		// 1GB

// Board Type
#define BOARD_M3SIP_4GB_2RANK		0	// boardcnf[0] RENESAS SALVATOR-X board with M3SIP(2RANK)
#define BOARD_M3SOC_KRIEK_4GB		1	// boardcnf[1] RENESAS KRIEK board with M3PKG
#define BOARD_H3SIP_ES1x_4GB		2	// boardcnf[2] RENESAS SALVATOR-X board with H3SIP-1rank
#define BOARD_M3SIP_2GB				3	// boardcnf[3] RENESAS Starter Kit board with M3SIP(1RANK)
#define BOARD_H3SOC_ES1x_SALM_4GB	4	// boardcnf[4] RENESAS SALVATOR-M(1rank) board with H3SoC
#define BOARD_M3SOC_KRIEK_2GB		5	// boardcnf[5] RENESAS KRIEK-1ch board with M3PKG
#define BOARD_H3SIP_ES1x_8GB_2RANK	6	// boardcnf[6] RENESAS SALVATOR-X board with H3SIP-2rank
#define BOARD_H3SIP_4GB				7	// boardcnf[7] RENESAS SALVATOR-X board with H3SIP_ver2.0-1rank
#define BOARD_H3SIP_8GB_2RANK		8	// boardcnf[8] RENESAS SALVATOR-X board with H3SIP_ver2.0-2rank
#define BOARD_H3SOC_SALM_4GB		9	// boardcnf[9] RENESAS SALVATOR-MS(1rank) board with H3SoC_VER2.0
#define BOARD_M3NSOC_KRIEK_2GB		10	// boardcnf[10] RENESAS Kriek(2rank) board with M3N
#define BOARD_M3NSIP_2GB			11	// boardcnf[11] RENESAS SALVATOR-X board with M3N SiP-2rank
#define BOARD_V3HSOC_2GB			12	// boardcnf[12] RENESAS CONDOR board with V3H
#define BOARD_PM3SOC_KRIEK_4GB		13	// boardcnf[13] RENESAS KRIEK board with PM3
#define BOARD_H3SIP_8GB_1RANK		14	// boardcnf[14] RENESAS SALVATOR-X board with H3SIP_ver2.0/3.0-16Gbit-1rank
#define BOARD_H3NSOC_KRIEK_4GB		15	// boardcnf[15] RENESAS KRIEK board with H3N

uint32_t _board_judge_bid(void);


//Add M3N
uint32_t _ddr3_board_judge_bid(void);
#define DDR_BACKUPMODE



#endif
