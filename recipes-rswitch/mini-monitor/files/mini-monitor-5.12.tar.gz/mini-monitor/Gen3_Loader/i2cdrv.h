/**********************************************************/
/* Sample program : I2C Driver Header                     */
/* File Name      : i2cdrv.h                              */
/* Copyright (C) Renesas Electronics Corp. 2015.          */
/**********************************************************/

#ifndef __I2CDRV_H_
#define __I2CDRV_H_

uint32_t RandomAddressReadI2C(uint32_t chNo, uint32_t slAdd, uint32_t accessAdd, uint32_t *rdBuf, uint32_t rdCount);
uint32_t PageWriteI2C(uint32_t chNo,uint32_t slAdd,uint32_t accessAdd,uint32_t *wrBuf,uint32_t wrCount);
void InitI2cPinFunction(uint32_t chNo);
void PowerOnI2c(uint32_t chNo);
void InitI2c(uint32_t chNo);

///////////////////////////////////////////////////////
// I2C Error Define
///////////////////////////////////////////////////////
#define I2C_ERROR				1
#define I2C_NACK_ERROR			2
#define I2C_TIMEOUT_ERROR		3

///////////////////////////////////////////////////////
// �e���W���[���Ŏg�p����I2C CH�w��
///////////////////////////////////////////////////////
// R-CarD3
//#define EEPROM_I2C			(GetI2cFlag())
#define EEPROM_I2C		I2C_CH0

///////////////////////////////////////////////////////
// SoC��I2C�`���l���̒�`
///////////////////////////////////////////////////////
#define I2C_CH0			0x00
#define I2C_CH1			0x01
#define I2C_CH2			0x02
#define I2C_CH3			0x03
#define I2C_CH4			0x04
#define I2C_CH5			0x05
#define I2C_CH6			0x06

#define IIC_CH0			0x10

#define	I2C_WRITE			0x00
#define	I2C_READ			0x01


///////////////////////////////////////////////////////
// �e���W���[���Ŏg�p����I2C CH�w��
///////////////////////////////////////////////////////
#define AUDIO_I2C			I2C_CH2
#define IOEX_I2C			I2C_CH4
#define CLKGEN_I2C			I2C_CH4
#define VCLK5_I2C			I2C_CH4
#define VIDEO_IN_I2C		I2C_CH4
#define C_SENSE_I2C			I2C_CH4
#define PMIC_IIC			IIC_CH0
#define EEPROM_IIC			IIC_CH0

///////////////////////////////////////////////////////
// SlaveAddress List (�A�h���X��)
///////////////////////////////////////////////////////
// ===== I2C_CH2 =====
// 0x20  AK4613_I2C_SLA           : Fixed
// ===== I2C_CH4 =====
// 0x40  IOEX_I2C_SLA             : Fixed
// 0x44  ADV7482_CP_I2C_SLA       : Programmable
// 0x4C  ADV7482_DPLL_I2C_SLA     : Programmable
// 0x62  ADV7482_INFO_I2C_SLA     : Programmable
// 0x64  ADV7482_REPEATER_I2C_SLA : Programmable
// 0x68  ADV7482_HDMI_I2C_SLA     : Programmable
// 0x6C  ADV7482_EDID_I2C_SLA     : Programmable
// 0x74  ADV7482_HDCP_I2C_SLA     : Fixed
// 0x82  ADV7482_CEC_I2C_SLA      : Programmable
// 0x90  ADV7482_CSI_TXB_I2C_SLA  : Programmable
// 0x94  ADV7482_CSI_TXA_I2C_SLA  : Programmable
// 0xA0  ADV7482_E_EDID_I2C_SLA   : Fixed
// 0xD0  CLKGEN_I2C_SLA           : Fixed
// 0xD4  VCLK5_I2C_SLA            : Fixed
// 0xE0  ADV7482_IO_I2C_SLA       : Fixed
// 0xF0  ADV7482_CBUS_I2C_SLA     : Programmable
// 0xF2  ADV7482_SDP_I2C_SLA      : Programmable
// 0xF8  MAX9611_VDD_I2C_SLA      : Fixed
// 0xFE  MAX9611_DVFS_I2C_SLA     : Fixed
// ===== I2C_IIC =====
// 0x60  PMIC_I2C_SLA             : Fixed
// 0xA0  EEPROM_I2C_SLA           : Fixed


///////////////////////////////////////////////////////
// I2C-SSI-CODEC
///////////////////////////////////////////////////////

// AK4613 register
#define	AK4613_I2C_SLA		0x20		// 8bits

#define	AK4613_POW_MNG1		0x00
#define	AK4613_POW_MNG2		0x01
#define	AK4613_POW_MNG3		0x02
#define	AK4613_CTRL1		0x03
#define	AK4613_CTRL2		0x04
#define	AK4613_DE_EMPH1		0x05
#define	AK4613_DE_EMPH2		0x06
#define	AK4613_OVERFLOW		0x07
#define	AK4613_ZERO_DET		0x08
#define	AK4613_IN_CTRL		0x09
#define	AK4613_OUT_CTRL		0x0A
#define	AK4613_LOUT1_VOL	0x0B
#define	AK4613_ROUT1_VOL	0x0C
#define	AK4613_LOUT2_VOL	0x0D
#define	AK4613_ROUT2_VOL	0x0E
#define	AK4613_LOUT3_VOL	0x0F
#define	AK4613_ROUT3_VOL	0x10
#define	AK4613_LOUT4_VOL	0x11
#define	AK4613_ROUT4_VOL	0x12
#define	AK4613_LOUT5_VOL	0x13
#define	AK4613_ROUT5_VOL	0x14
#define	AK4613_LOUT6_VOL	0x15
#define	AK4613_ROUT6_VOL	0x16

///////////////////////////////////////////////////////
// Audio Clock Synthesizer
///////////////////////////////////////////////////////

// CS2000-CP(Clock Synthesizer,Audio Clock)
#define	CS2000CP_I2C_SLA		0x9E

#define CS2000CP_DeviceID		0x01
#define CS2000CP_DeviceCtrl		0x02
#define CS2000CP_DeviceCfg1		0x03
#define CS2000CP_DeviceCfg2		0x04
#define CS2000CP_GlobalCfg		0x05
#define CS2000CP_32BitRatio0_0	0x06	// Ratio0-LSB
#define CS2000CP_32BitRatio0_1	0x07
#define CS2000CP_32BitRatio0_2	0x08
#define CS2000CP_32BitRatio0_3	0x09	// Ratio0-MSB
#define CS2000CP_32BitRatio1_0	0x0A	// Ratio1-LSB
#define CS2000CP_32BitRatio1_1	0x0B
#define CS2000CP_32BitRatio1_2	0x0C
#define CS2000CP_32BitRatio1_3	0x0D	// Ratio1-MSB
#define CS2000CP_32BitRatio2_0	0x0E	// Ratio2-LSB
#define CS2000CP_32BitRatio2_1	0x0F
#define CS2000CP_32BitRatio2_2	0x10
#define CS2000CP_32BitRatio2_3	0x11	// Ratio2-MSB
#define CS2000CP_32BitRatio3_0	0x12	// Ratio3-LSB
#define CS2000CP_32BitRatio3_1	0x13
#define CS2000CP_32BitRatio3_2	0x14
#define CS2000CP_32BitRatio3_3	0x15	// Ratio3-MSB
#define CS2000CP_FunctCfg1		0x16
#define CS2000CP_FunctCfg2		0x17
#define CS2000CP_FunctCfg3		0x1E


///////////////////////////////////////////////////////
// Versaclock5
///////////////////////////////////////////////////////

// 5P49V5923A register
#define VCLK5_I2C_SLA		0xD4		// 8bits

#define VCLK5_OTP_CTRL		0x00		// OTP Control
#define VCLK5_DEVICE_ID		0x01		// Device ID for Chip Identification
#define VCLK5_FREE_RAM0		0x80		// 0x80-0x8F : may be used for any purpose


///////////////////////////////////////////////////////
// I/O Expander
///////////////////////////////////////////////////////

// PCA9654E register
#define IOEX_I2C_SLA		0x40		// 8bits

#define IOEX_IN_PORT		0x00		// Register0: Input Port Register
#define IOEX_OUT_PORT		0x01		// Register1: Output Port Register
#define IOEX_POL_INV		0x02		// Register2: Polarity Inversion Register
#define IOEX_CONFIG			0x03		// Register3: Configuration Register


///////////////////////////////////////////////////////
// Clock Generator
///////////////////////////////////////////////////////

// 9FGV0841 register
#define CLKGEN_I2C_SLA		0xD0		// 8bits

#define CLKGEN_OUT_EN		0x00		// Byte 0: Output Enable Register
#define CLKGEN_SSRB_CTRL	0x01		// Byte 1: SS Readback and Control Register
#define CLKGEN_SLEW_RATE	0x02		// Byte 2: DIF Slew Rate Control Register
#define CLKGEN_REF_CTRL		0x03		// Byte 3: Nominal Vhigh Amplitude Control/ REF Control Register
//							0x04		// Byte 4: Reserved
#define CLKGEN_VENDOR_ID	0x05		// Byte 5: Revision and Vendor ID Register
#define CLKGEN_DEVICE_ID	0x06		// Byte 6: Device Type/Device ID
#define CLKGEN_BYTE_COUNT	0x07		// Byte 7: Byte Count Register


///////////////////////////////////////////////////////
// VIN_CSI2
///////////////////////////////////////////////////////

// ADV7482 Slave Address Bridge
#define IO_SLA			ADV7482_IO_I2C_SLA		
#define DPLL_SLA		ADV7482_DPLL_I2C_SLA	
#define CP_SLA			ADV7482_CP_I2C_SLA		
#define HDMI_RX_SLA		ADV7482_HDMI_RX_I2C_SLA	
#define EDID_SLA		ADV7482_EDID_I2C_SLA	
#define REPEATER_SLA	ADV7482_REPEATER_I2C_SLA
#define INFO_SLA		ADV7482_INFO_I2C_SLA	
#define CBUS_SLA		ADV7482_CBUS_I2C_SLA	
#define CEC_SLA			ADV7482_CEC_I2C_SLA		
#define SDP_SLA			ADV7482_SDP_I2C_SLA		
#define CSI_TXB_SLA		ADV7482_CSI_TXB_I2C_SLA	
#define CSI_TXA_SLA		ADV7482_CSI_TXA_I2C_SLA	
#define E_EDID_SLA		ADV7482_E_EDID_I2C_SLA	
#define HDCP_SLA		ADV7482_HDCP_I2C_SLA	

// ADV7482W register
#define ADV7482_IO_I2C_SLA			0xE0		// 8bits: IO        Map(Fixed)
#define ADV7482_DPLL_I2C_SLA		0x4C		// 8bits: DPLL      Map(Programmable)
#define ADV7482_CP_I2C_SLA			0x44		// 8bits: CP        Map(Programmable)
#define ADV7482_HDMI_RX_I2C_SLA		0x68		// 8bits: HDMI Rx   Map(Programmable)
#define ADV7482_EDID_I2C_SLA		0x6C		// 8bits: EDID      Map(Programmable)
#define ADV7482_REPEATER_I2C_SLA	0x64		// 8bits: Repeater  Map(Programmable)
#define ADV7482_INFO_I2C_SLA		0x62		// 8bits: InfoFrame Map(Programmable)
#define ADV7482_CBUS_I2C_SLA		0xF0		// 8bits: CBUS      Map(Programmable)
#define ADV7482_CEC_I2C_SLA			0x82		// 8bits: CEC       Map(Programmable)
#define ADV7482_SDP_I2C_SLA			0xF2		// 8bits: SDP       Map(Programmable)
#define ADV7482_CSI_TXB_I2C_SLA		0x90		// 8bits: CSI-TXB   Map(Programmable)
#define ADV7482_CSI_TXA_I2C_SLA		0x94		// 8bits: CSI-TXA   Map(Programmable)
#define ADV7482_E_EDID_I2C_SLA		0xA0		// 8bits: Internal E-EDID(Fixed)
#define ADV7482_HDCP_I2C_SLA		0x74		// 8bits: HDCP Registers(Fixed)

// IO Map
#define ADV7482_IO_DPLL_ADDR		0xF3		// DPLL      Map Slave Address Register
#define ADV7482_IO_CP_ADDR			0xF4		// CP        Map Slave Address Register
#define ADV7482_IO_HDMI_RX_ADDR		0xF5		// HDMI Rx   Map Slave Address Register
#define ADV7482_IO_EDID_ADDR		0xF6		// EDID      Map Slave Address Register
#define ADV7482_IO_REPEATER_ADDR	0xF7		// Repeater  Map Slave Address Register
#define ADV7482_IO_INFO_FRAME_ADDR	0xF8		// InfoFrame Map Slave Address Register
#define ADV7482_IO_CBUS_ADDR		0xF9		// CBUS      Map Slave Address Register
#define ADV7482_IO_CEC_ADDR			0xFA		// CEC       Map Slave Address Register
#define ADV7482_IO_SDP_ADDR			0xFB		// SDP       Map Slave Address Register
#define ADV7482_IO_CSI_TXB_ADDR		0xFC		// CSI-TXB   Map Slave Address Register
#define ADV7482_IO_CSI_TXA_ADDR		0xFD		// CSI-TXA   Map Slave Address Register
#define ADV7482_IO_MAIN_RESET		0xFF		// RESET PIN AND CONTROLS

// HDMI RX Repeater Map
#define ADV7482_REP_P_EDID_SIZE		0x70		// primary_edid_size[3:0], HDMI RX Repeater Map, Address 0x70[7:4]
#define ADV7482_REP_S_EDID_SIZE		0x7E		// secondary_edid_size[3:0], HDMI RX Repeater Map, Address 0x7E[7:4]
#define ADV7482_REP_EDID_AREA_SEL1	0x7A		// edid_sram_space_select[1:0], HDMI RX Repeater Map, Address 0x7A[1:0]
//                                              // edid_segment_pointer[2:0], HDMI RX Repeater Map, Address 0x7A[6:4]
#define ADV7482_REP_EDID_AREA_SEL2	0x7D		// dual_edid_enable_port_a, HDMI RX Repeater Map, Address 0x7D[0]



///////////////////////////////////////////////////////
// Current-Sensor
///////////////////////////////////////////////////////

// MAX9611 register
#define MAX9611_DVFS_I2C_SLA	0xFE		// 8bits: DVFS0.8V
#define MAX9611_VDD_I2C_SLA		0xF8		// 8bits: VDD0.8V

#define MAX9611_CSA_MSB			0x00		// CSA DATA BYTE 1 (MSBs)
#define MAX9611_CSA_LSB			0x01		// CSA DATA BYTE 1 (LSBs)
#define MAX9611_RSP_MSB			0x02		// RS+ DATA BYTE 1 (MSBs)
#define MAX9611_RSP_LSB			0x03		// RS+ DATA BYTE 1 (LSBs)
#define MAX9611_OUT_MSB			0x04		// OUT DATA BYTE 1 ( MSBs)
#define MAX9611_OUT_LSB			0x05		// OUT DATA BYTE 1 (LSBs)
#define MAX9611_SET_MSB			0x06		// SET DATA BYTE 1 (MSBs)
#define MAX9611_SET_LSB			0x07		// SET DATA BYTE 1 (LSBs)
#define MAX9611_TEMP_MSB		0x08		// TEMP DATA BYTE 1 (MSBs)
#define MAX9611_TEMP_LSB		0x09		// TEMP DATA BYTE 1 (LSBs)
#define MAX9611_CTRL1			0x0A		// CONTROL REGISTER 1
#define MAX9611_CTRL2			0x0B		// CONTROL REGISTER 2


///////////////////////////////////////////////////////
// EEPROM
///////////////////////////////////////////////////////

// BR24T01FVM-W register
#define EEPROM_I2C_SLA			0xA0		// 8bits


///////////////////////////////////////////////////////
// PMIC
///////////////////////////////////////////////////////

// BD9571MWV-M register
#define PMIC_IIC_SLA			0x60		// 8bits

#define PMIC_VENDOR_CODE		0x00		// Vendor Code  - 0xDB:Rohm
#define PMIC_PRODUCT_CODE		0x01		// Product Code - 0x60:BD9571
#define PMIC_PRODUCT_REV		0x02		// Product Revision
#define PMIC_I2C_SMOD			0x10		// I2C FuSa Mode
#define PMIC_I2C_MD2_E1			0x11		// I2C MD2_E1 Bit 1
#define PMIC_I2C_MD2_E1_P		0x12		// I2C MD2_E1 Bit 2
#define PMIC_BKUP_MODE_CNT		0x20		// BKUP Mode Cnt
#define PMIC_BKUP_MODE_STS		0x21		// BKUP Mode Status
#define PMIC_BKUP_RECOV_CNT		0x22		// BKUP Recovery Cnt
#define PMIC_BKUP_CTRL_TIM_CNT	0x23		// BKUP CTRL Tim Cnt
#define PMIC_WAIT_BKUP_WDT_CNT	0x24		// WaitBKUP WDT Cnt
#define PMIC_128H_TIM_CNT		0x26		// 128H Tim Cnt
#define PMIC_QLLM_CNT			0x27		// QLLM Cnt
#define PMIC_AVS_SET_MONI		0x31		// AVS Set Moni
#define PMIC_AVS_VD09_VID0		0x32		// AVS VD09 VID0
#define PMIC_AVS_VD09_VID1		0x33		// AVS VD09 VID1
#define PMIC_AVS_VD09_VID2		0x34		// AVS VD09 VID2
#define PMIC_AVS_VD09_VID3		0x35		// AVS VD09 VID3
#define PMIC_AVS_DVFS_VID0		0x36		// AVS DVFS VID0
#define PMIC_AVS_DVFS_VID1		0x37		// AVS DVFS VID1
#define PMIC_AVS_DVFS_VID2		0x38		// AVS DVFS VID2
#define PMIC_AVS_DVFS_VID3		0x39		// AVS DVFS VID3
#define PMIC_VD18_VID			0x42		// VD18 VID
#define PMIC_VD25_VID			0x43		// VD25 VID
#define PMIC_VD33_VID			0x44		// VD33 VID
#define PMIC_DVFS_VINIT			0x50		// DVFS Vinit
#define PMIC_DVFS_SET_VMAX		0x52		// DVFS SetVmax
#define PMIC_DVFS_BOOSTVID		0x53		// DVFS BoostVID
#define PMIC_DVFS_SET_VID		0x54		// DVFS SetVID
#define PMIC_DVFS_MONI_VDAC		0x55		// DVFS MoniVDAC
#define PMIC_DVFS_PGD_CNT		0x56		// DVFS PGD Cnt
#define PMIC_GPIO_DIR			0x60		// GPIO Dir
#define PMIC_GPIO_OUT			0x61		// GPIO Out
#define PMIC_GPIO_IN			0x62		// GPIO In
#define PMIC_GPIO_DEB			0x63		// GPIO Deb
#define PMIC_GPIO_INT_SET		0x64		// GPIO Int Set
#define PMIC_GPIO_INT			0x65		// GPIO Int
#define PMIC_GPIO_INT_MASK		0x66		// GPIO IntMask
#define PMIC_REG_KEEP1			0x70		// REG Keep1
#define PMIC_REG_KEEP2			0x71		// REG Keep2
#define PMIC_REG_KEEP3			0x72		// REG Keep3
#define PMIC_REG_KEEP4			0x73		// REG Keep4
#define PMIC_REG_KEEP5			0x74		// REG Keep5
#define PMIC_REG_KEEP6			0x75		// REG Keep6
#define PMIC_REG_KEEP7			0x76		// REG Keep7
#define PMIC_REG_KEEP8			0x77		// REG Keep8
#define PMIC_REG_KEEP9			0x78		// REG Keep9
#define PMIC_REG_KEEP10			0x79		// REG Keep10
#define PMIC_STATE				0x80		// PMIC Internal Status
#define PMIC_PROTECT_ERROR0		0x81		// Protection Error Status0
#define PMIC_PROTECT_ERROR1		0x82		// Protection Error Status1
#define PMIC_PROTECT_ERROR2		0x83		// Protection Error Status2
#define PMIC_PROTECT_ERROR3		0x84		// Protection Error Status3
#define PMIC_PROTECT_ERROR4		0x85		// Protection Error Status4
#define PMIC_INT_INTREQ			0x90		// INT IntReq
#define PMIC_INT_INTMASK		0x91		// INT IntMASK

#define PMIC_WRITE_PROTECT		0x4F		// Write Protect
#define PMIC_ACCESS_KEY			0xFF		// Access Key

#endif
