#include "common.h"
#include "boardid.h"
#include "init_scif.h"
#include "scifdrv0.h"
#include "scifdrv2.h"
#include "reg_rcargen3.h"


uint32_t gScifMainChNo;

void SetScifFlagDefault(void)
{
	uint32_t md,bootmd;

	if(CHK_V3M){					//======== V3M ==============
		gScifMainChNo = SCIF_CH0;
	}else if(CHK_V3H){				//======== V3H ==============
			gScifMainChNo = SCIF_CH0;	//Other
	}else{							//======== H3/M3/D3/E3 ======
		gScifMainChNo = SCIF_CH2;
	}
}

void InitScif(void)
{
	switch( gScifMainChNo ){
		case SCIF_CH0: InitScif0_SCIFCLK(); break;
		case SCIF_CH2: 
			if(CHK_D3||CHK_E3){
//				InitScif2_INTERNAL();					// S3D4
				InitScif2_INTERNAL_S3D1();				// S3D1
			}else{
				InitScif2_SCIFCLK();
			}
			break;
	}
}