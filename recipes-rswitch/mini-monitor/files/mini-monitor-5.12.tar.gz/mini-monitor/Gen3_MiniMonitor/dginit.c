#include	"common.h"
#include	"dgtable.h"
#include	"dginit.h"
#include	"i2cdrv.h"

extern uintptr_t gUDump[3];
extern uintptr_t gUMem[3];

extern uint32_t gUreg[17];
extern uint32_t gDumpMode;
extern uint32_t gDumpStatus;
extern uint32_t gSPIDump[3];

extern uint32_t gIic0Mem[3];
extern uint32_t gIic0Dump[3];

extern uint32_t gI2c0Mem[3];
extern uint32_t gI2c0Dump[3];

extern uint32_t gIic0SlvAdd;
extern uint32_t gI2c0SlvAdd;

void	InitSysMon( void )
{
	unsigned char	dataB;
	int16_t			i;

	gUDump[0] =  gUMem[0] =  0;
	gUDump[1] =  gUMem[1] =  255;

	gSPIDump[0] =  0;
	gSPIDump[1] =  255;

	gDumpMode	= SIZE_8BIT;
	gDumpStatus	= DISABLE;

	gIic0SlvAdd = EEPROM_I2C_SLA;
	gI2c0SlvAdd = EEPROM_I2C_SLA;

	gIic0Mem[0] =  0;
	gIic0Mem[1] = 32;
 	gIic0Dump[0] =  0;
 	gIic0Dump[1] = 0x3F;

	gI2c0Mem[0] =  0;
	gI2c0Mem[1] = 32;
 	gI2c0Dump[0] =  0;
 	gI2c0Dump[1] = 0x3F;

#ifdef AArch32
	for ( i = 0 ; i < 17 ; i ++ )	{
		gUreg[i] =  0;
	}
	gUreg[ARM_CPSR  ]	=  0x0000011F;
	gUreg[ARM_R13(SP)]	=  0x500FFFF0;
	gUreg[ARM_R15(PC)]	=  0x50000000;
#endif

	for ( i = 0 ; i < 500 ; i ++ )	{
		;
	}
}

