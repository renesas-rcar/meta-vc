#include	"common.h"
#include	"main.h"
#include	"dgtable.h"
#include	"bit.h"
#include	"cpudrv.h"
#include	"boardid.h"

extern const char *const StartMessMonitor[START_MESS_MON_LINE];
extern const char *const VersionDate[VERSION_DATE_LINE];
extern const com_menu MonCom[COMMAND_UNIT];

char gKeyBuf[64];
int32_t gComNo;
uint32_t gDumpStatus;

void Main(void)
{
	InitMain();
	StartMessMinimonitor();

	Mess_Board_Judge(1);

#ifndef SpiBoot
#ifdef H3_M3
	if(CHK_H3||CHK_M3||CHK_M3N){
//		Mess_Board_Judge(1);
		Mess_DdrBoard_Judge(1);		//Display code [dram_config:_board_judge]
	}
#endif
#ifdef V3H
		Mess_DdrBoard_Judge(1);		//Display code [dram_config:_board_judge]
#endif
#endif
	StartMessBoard();
	DecCom();
}

void InitMain(void)
{
	InitSysMon();
}

void StartMessMinimonitor( void )
{
	PutStr("  ",1);
	PutMess1LineDisRtn(StartMessMonitor);
	PutMess(VersionDate);
	PutMessWorkMemory();
}

void StartMessBoard( void )
{
	PutStr(" Board Name      : ",0);
	if(gBoardId_FF_Flg){
		PutBoardName(1);
	}else{
		PutBoardIdName(1);
	}
	PutSocProduct();
	PutStr("  ",1);
}

void DecCom(void)
{
	char tmp[64],chCnt,chPtr;

	while(1){
		PutStr(">",0);
		GetStr(gKeyBuf,&chCnt);
		if(chCnt!=0){
			gDumpStatus = DISABLE;
		}
		if((chCnt==0)&&(gDumpStatus == ENABLE)){
			dgDump();
		}
		chPtr=0;
		GetStrBlk(gKeyBuf,tmp,&chPtr,0);
		if(chPtr!=1){
			ChgLtl2Lrg(tmp);
			if(!CmpCom(tmp)){
				(MonCom[gComNo].comProg)();
			}
			else PutStr("command not found",1);
		}
	}
}

long CmpCom(char *str)
{
	char *cmpStr,*tmpStr,err;
	gComNo = 0;
	while(TBL_END!=MonCom[gComNo].comStr){
		err=0; tmpStr = str;
		cmpStr = MonCom[gComNo].comStr;
		while(*tmpStr!=0){
			if(*tmpStr == *cmpStr){
				tmpStr++; cmpStr++;
			}else{
				err=1; break;
			}
		}
		if((!err)&&(*cmpStr==0)){
			return(0);
		}
		gComNo++;
	}
	return(1);
}


void PutMessWorkMemory( void )
{
	PutStr(" Work Memory     : ",0);
	if(CHK_V3H){
		PutStr("RT-SRAM",1);
	}else if(CHK_D3||CHK_E3){
#ifdef SpiBoot
		PutStr("SDRAM",1);
#else
		PutStr("SystemRAM",1);
#endif
	}else{
		PutStr("SystemRAM",1);
	}
}
