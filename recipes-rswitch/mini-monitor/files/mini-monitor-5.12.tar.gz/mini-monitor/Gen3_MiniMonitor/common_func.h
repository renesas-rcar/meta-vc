#define		DIS_RTN				0		/* Disable Return		*/
#define		ENB_RTN				1		/* Enable Return		*/
#define		OK				  0x1

#ifndef NULL
#define		NULL			  0x0
#endif

#define		INT_CODE		0x25		/* "%"					*/
#define		BS_CODE			0x08		/* "BS"					*/
#define		CR_CODE			0x0d		/* "CR"					*/
#define		SP_CODE			0x20		/* "LF"					*/
#define		LF_CODE			0x0a		/* "LF"					*/

#define		SIZE_8BIT		1			// Old name : BYTE_SIZE
#define		SIZE_16BIT		2			// Old name : WORD_SIZE
#define		SIZE_32BIT		4			// Old name : LONG_SIZE
#define		SIZE_64BIT		8			// New

/****************************
	Module Proto Type		*
****************************/
int32_t PutMess(const char *const mess[]);
int32_t PutMess1LineDisRtn(const char *const mess[]);
int32_t	PutStr(const char *str,char rtn);
int32_t	GetStr(char *str,char *chCnt);
uint32_t Hex2DecAscii(int32_t hexdata,char *str,int32_t *chcnt);
void DelStr(int32_t delCnt);
void ChgLtl2Lrg(char *str);
char HexAscii2Data(unsigned char *buf,uint32_t *data);
char HexAscii2Data_64(unsigned char *buf,uintptr_t *data);
char Data2HexAscii(uint32_t data,char *buf,char size);
char Data2HexAscii_64(uintptr_t data,char *buf,char size);
void SoftDelay(uint32_t loop);
char WaitKeyIn_YorN(void);
int32_t	GetStr_MemEd(char *str,char *chCnt);
char *memcpy(char *s1,char *s2,unsigned long n);
uint64_t __aeabi_llsl(uint64_t val, uint32_t shift);
uint64_t __aeabi_llsr(uint64_t val, uint32_t shift);
