void DisplayDump(uintptr_t stAdd,uintptr_t dumpSize,uint32_t width);
void ChgDumpAsciiCode(uintptr_t chCode,char *buf,char chPtr,uint32_t width);
void ChgDumpAsciiStr(char *buf);
void Get1ByteMem(uintptr_t readAdd,uintptr_t *readData,uint32_t  width);
void Put1ByteMem(uintptr_t writeAdd,uintptr_t writeData,uint32_t width);
void DisplayMemEd(uintptr_t mem1st,uint32_t width,uint32_t verifyFlg);
