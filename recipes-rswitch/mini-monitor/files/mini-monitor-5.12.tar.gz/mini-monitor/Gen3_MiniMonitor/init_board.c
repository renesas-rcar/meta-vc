#include "common.h"
#include "bit.h"
#include "reg_rcargen3.h"
#include "boardid.h"
#include "init_board.h"
#include "cpudrv.h"
#include "boot_init_port_H3.h"
#include "boot_init_port_M3.h"
#include "boot_init_port_D3.h"
#include "boot_init_port_V3M.h"
#include "boot_init_port_V3H.h"
#include "boot_init_port_E3.h"
#include "boot_init_gpio_H3.h"
#include "boot_init_gpio_M3.h"
#include "boot_init_gpio_V3M.h"
#include "boot_init_gpio_D3.h"
#include "boot_init_gpio_V3H.h"
#include "boot_init_gpio_E3.h"
#include "boot_init_lbsc_H3M3.h"

uint32_t gPcbVer;


//***************************************************************
// PFC GPIO Initial setting  branch main.
//***************************************************************
void Init_PFC_GPIO(void)
{
#ifdef SpiBoot
	if(CHK_H3){
		InitPORT_H3();
		InitGPIO_H3();
	}else if(CHK_M3||CHK_M3N){
		InitPORT_M3();
		InitGPIO_M3();
	}else if(CHK_V3M){
		InitPORT_V3M();
		InitGPIO_V3M();
	}else if(CHK_D3){
		InitPORT_D3();
		InitGPIO_D3();
	}else if(CHK_V3H){
		InitPORT_V3H();
		InitGPIO_V3H();
	}else if(CHK_E3){
		InitPORT_E3();
		InitGPIO_E3();
	}
#else
#ifdef H3_M3
	if(CHK_H3){
		InitPORT_H3();
		InitGPIO_H3();
	}else if(CHK_M3||CHK_M3N){
		InitPORT_M3();
		InitGPIO_M3();
	}
#endif
#ifdef V3H
	if(CHK_V3H){
		InitPORT_V3H();
		InitGPIO_V3H();
	}
#endif
#ifdef V3M
	if(CHK_V3M){
		InitPORT_V3M();
		InitGPIO_V3M();
	}
#endif
#ifdef D3
	if(CHK_D3){
		InitPORT_D3();
		InitGPIO_D3();
	}
#endif
#ifdef E3
	if(CHK_E3){
		InitPORT_E3();
		InitGPIO_E3();
	}
#endif

#endif
}

//***************************************************************
// InitEtherPhyReset
//***************************************************************
void InitEtherPhyReset(void)
{
	if( (CHK_SALVATOR_XS) || (CHK_KRIEK_LP4) || (CHK_EAGLE_D) || (CHK_EBISU_ST) || (CHK_EAGLE_R) ){
		EtherPhyReset();
	}
	else if( (CHK_SALVATOR_X) || (CHK_STARTERKIT) || (CHK_KRIEK_DDR3) || (CHK_CONDOR) || (CHK_EBISU_SP) ){
		//GPIO reset is not required. Specifications are satisfied with the circuit.
	}
	else if( CHK_DRAAK ){
		//GPIO reset is not required. EtherAVB reset Continues for Low output.
	}
}

void EtherPhyReset()
{
	SetEtherPhyRes(0);
	StartTMU0(2);
	SetEtherPhyRes(1);
}

void SetEtherPhyRes(uint32_t lvl)
{
	// lvl=0:ETHER RESET "L"
	// lvl=1:ETHER RESET "H"

	if(CHK_H3||CHK_M3||CHK_M3N){
		if(lvl) *((volatile uint32_t*)(GPIO_OUTDT2)) |=  BIT10;	// 1 = "H"
		else    *((volatile uint32_t*)(GPIO_OUTDT2)) &= ~BIT10;	// 0 = "L"
	}else if(CHK_V3M){
		if(lvl) *((volatile uint32_t*)(GPIO_OUTDT1)) |=  BIT16;	// 1 = "H"
		else    *((volatile uint32_t*)(GPIO_OUTDT1)) &= ~BIT16;	// 0 = "L"
	}else if(CHK_D3){
		if(lvl) *((volatile uint32_t*)(GPIO_OUTDT5)) |=  BIT18;	// 1 = "H"
		else    *((volatile uint32_t*)(GPIO_OUTDT5)) &= ~BIT18;	// 0 = "L"
	}else if(CHK_E3){
		if(lvl) *((volatile uint32_t*)(GPIO_OUTDT1)) |=  BIT20;	// 1 = "H"
		else    *((volatile uint32_t*)(GPIO_OUTDT1)) &= ~BIT20;	// 0 = "L"
	}else if(CHK_V3H){
		if(lvl) *((volatile uint32_t*)(GPIO_OUTDT1)) |=  BIT16;	// 1 = "H"
		else    *((volatile uint32_t*)(GPIO_OUTDT1)) &= ~BIT16;	// 0 = "L"
		if(lvl) *((volatile uint32_t*)(GPIO_OUTDT4)) |=  BIT22;	// 1 = "H" (GEther)
		else    *((volatile uint32_t*)(GPIO_OUTDT4)) &= ~BIT22;	// 0 = "L" (GEther)
	}
}



//LBSC:Gen3����
void InitLBSC(void)
{
	if((CHK_H3)||(CHK_M3||CHK_M3N)){
		InitLBSC_H3M3();
	}else if(CHK_V3M){
		InitLBSC_H3M3();
	}else if(CHK_D3){
		InitLBSC_H3M3();
	}else if(CHK_V3H){
		InitLBSC_H3M3();
	}
}

void ChangeLBSC_Area0(void)
{
#ifdef SpiBoot

	if(CHK_H3){
		InitIPSR_Area0_H3();
		InitGPSR_Area0_H3();
	}else if(CHK_M3||CHK_M3N){
		InitIPSR_Area0_M3();
		InitGPSR_Area0_M3();
	}else if(CHK_V3M){
		InitIPSR_Area0_V3M();
		InitGPSR_Area0_V3M();
	}else if(CHK_D3){
		InitIPSR_Area0_D3();
		InitGPSR_Area0_D3();
	}else if(CHK_V3H){
		InitIPSR_Area0_V3H();
		InitGPSR_Area0_V3H();
	}else{
		PutStr("R-Car XX ",1);	WaitPutCharSendEnd();
		PutStr("Error : SOC code is not supported",0);
	}
#else
#ifdef H3_M3
	if(CHK_H3){
		InitIPSR_Area0_H3();
		InitGPSR_Area0_H3();
	}else if(CHK_M3||CHK_M3N){
		InitIPSR_Area0_M3();
		InitGPSR_Area0_M3();
	}
#endif
#ifdef V3H
	if(CHK_V3H){
		InitIPSR_Area0_V3H();
		InitGPSR_Area0_V3H();
	}
#endif
#ifdef V3M
	if(CHK_V3M){
		InitIPSR_Area0_V3M();
		InitGPSR_Area0_V3M();
	}
#endif
#ifdef D3
	if(CHK_D3){
		InitIPSR_Area0_D3();
		InitGPSR_Area0_D3();
	}
#endif
#ifdef E3
	if(CHK_E3){
	}
#endif
	else{
		PutStr("R-Car XX ",1);	WaitPutCharSendEnd();
		PutStr("Error : SOC code is not supported",0);
	}

#endif
}
void ChangeLBSC_Spi(void)
{
#ifdef SpiBoot

	if(CHK_H3){
		InitIPSR_SPI_H3();
		InitGPSR_SPI_H3();
	}else if(CHK_M3||CHK_M3N){
		InitIPSR_SPI_M3();
		InitGPSR_SPI_M3();
	}else if(CHK_V3M){
		InitIPSR_SPI_V3M();
		InitGPSR_SPI_V3M();
	}else if(CHK_D3){
		InitIPSR_SPI_D3();
		InitGPSR_SPI_D3();
	}else if(CHK_V3H){
		InitIPSR_SPI_V3H();
		InitGPSR_SPI_V3H();
	}else if(CHK_E3){
	
	}else{
		PutStr("R-Car XX ",1);	WaitPutCharSendEnd();
		PutStr("Error : SOC code is not supported",0);
	}

#else

#ifdef H3_M3
	if(CHK_H3){
		InitIPSR_SPI_H3();
		InitGPSR_SPI_H3();
	}else if(CHK_M3||CHK_M3N){
		InitIPSR_SPI_M3();
		InitGPSR_SPI_M3();
	}
#endif
#ifdef V3H
	if(CHK_V3H){
		InitIPSR_SPI_V3H();
		InitGPSR_SPI_V3H();
	}
#endif
#ifdef V3M
	if(CHK_V3M){
		InitIPSR_SPI_V3M();
		InitGPSR_SPI_V3M();
	}
#endif
#ifdef D3
	if(CHK_D3){
		InitIPSR_SPI_D3();
		InitGPSR_SPI_D3();
	}
#endif
#ifdef E3
	if(CHK_E3){
		
	}
#endif
	else{
		PutStr("R-Car XX ",1);	WaitPutCharSendEnd();
		PutStr("Error : SOC code is not supported",0);
	}

#endif
}


#ifdef COM_IIC_ON
void SelPcbVersion(void)
{
	char str[64];
	char		chCnt;
	uint32_t	loop;

	gPcbVer =0;

	PutStr("",1);
	PutStr("-----------------------------------------------",1);
	PutStr("Please select the revision of the board.",1);
	PutStr(" 1 : RTP0RC7795SIPB0010S / RTP0RC7796SIPB0010S ",1);
	PutStr(" 2 : RTP0RC7795SIPB0011S / RTP0RC7796SIPB0011S ",1);
	PutStr(" 3 : RTP0RC7795SIPB0012S / RTP0RC7796SIPB0012S ",1);
	PutStr("-----------------------------------------------",1);
	loop=1;
	while(loop){
		PutStr("  Select board(1-3)>",0);
		GetStr(str,&chCnt);
		  switch(str[0]){
			case '1':
				gPcbVer = RC7795SIPB0010S;
				loop=0;
				break;
			case '2':
				gPcbVer = RC7795SIPB0011S;
				loop=0;
				break;
			case '3':
				gPcbVer = RC7795SIPB0012S;
				loop=0;
				break;
		  }
	}
}
#endif

