int32_t TPRAMCK( uint8_t *startAddr, uint8_t *endAddr );
void dgRamTest(void);
void dgSetPmicEeprom(void);
void dgSetPmicEepromM3N_WA(void);
void SetPmicEeprom(void);
void dgReadPmicEeprom(void);
void ReadPmicEeprom(void);
void dgClearPmicEeprom(void);
void ClearPmicEeprom(void);
void dgSetIIC0(void);
void SetIIC0(void);
void SetSlvAdd(uint32_t *setAdd);
void dgSetIIC0_X(uint32_t *setAdd);
void dgMemEdit_Iic0(void);
void MemEdit_Iic0(void);
void DisplayMemEd_Iic0(uintptr_t mem1st,uint32_t width,uint32_t verifyFlg);
void Put1ByteMem_Iic0(uintptr_t writeAdd,uintptr_t writeData,uint32_t width);
void Get1ByteMem_Iic0(uintptr_t readAdd,uintptr_t *readData,uint32_t  width);
void DisplayDump_Iic0(uintptr_t stAdd,uintptr_t dumpSize,uint32_t  width);

void DisplayDump_Pmic(uintptr_t stAdd,uintptr_t dumpSize,uint32_t  width);

void dgSetI2C0(void);
void SetI2C0(void);

void dgMemEdit_I2c0(void);
void MemEdit_I2c0(void);
void DisplayMemEd_I2c0(uintptr_t mem1st,uint32_t width,uint32_t verifyFlg);
void Put1ByteMem_I2c0(uintptr_t writeAdd, uintptr_t writeData,uint32_t width);
void Get1ByteMem_I2c0(uintptr_t readAdd,uintptr_t *readData,uint32_t  width);
void DisplayDump_I2c0(uintptr_t stAdd,uintptr_t dumpSize,uint32_t  width);
void dgDdrTest(void);
void dgDdrTest_8GB(void);
uint32_t PutDdrErrInfo();
uint32_t CkExtendDdrRamCheck( void* ramAddr );
uint32_t CkExtendDdrRamCheck_8GB( void* ramAddr );
uint32_t CkExtendDdrRamCheck_M3_8GB( void* ramAddr );
uint32_t RamCheckTest1(uintptr_t Load_workStartAdd);
uint32_t CkExtendDdrRamCheck1Ptn( void* ramAddr );
void dgDdrTest_2GB(void);


void SetBoardID(void);
void SetBoardIdData(uint8_t *bid);
void debug_PrrCode(void);
