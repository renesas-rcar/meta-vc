int32_t CheckAndFillData8Bit( uint8_t *startAddr, uint8_t *endAddr, uint8_t writeData, uint8_t checkData );
int32_t FillData8Bit( uint8_t *startAddr, uint8_t *endAddr, uint8_t writeData );
int32_t CheckData8Bit( uint8_t *startAddr, uint8_t *endAddr, uint8_t checkData );
int32_t WriteIncData8Bit( uint8_t *startAddr, uint8_t *endAddr, uint8_t startData );
int32_t CheckIncData8Bit( uint8_t *startAddr, uint8_t *endAddr, uint8_t startData );
