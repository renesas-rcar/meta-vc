#include "common.h"
#include "dgtable.h"
#include "common2.h"
#include "dgmodul1.h"
#include "devdrv.h"

extern char gKeyBuf[64];


/*********************************************************/
/* Hex Ascii str -> HexData                              */
/*********************************************************/
char DecodeHexAscStr(uintptr_t *para, char *buf)
{
	char value;
	uintptr_t tmpData;

	value = HexAscii2Data_64((unsigned char*)buf,&tmpData);
	if(value==1){					/* Error */
		return(1);
	}
	else if(value==0){
		*para = tmpData;
	}
	return(0);						/* Normal End   */
}

/*********************************************************/
/* Hex Ascii str -> HexData (para1st, para2nd)           */
/*********************************************************/
char DecodeHexAscStr2(uintptr_t *para1st,
					  uintptr_t *para2nd,
					  char *buf)
{
	char value;
	uintptr_t tmpData;

	value = HexAscii2Data_64((unsigned char*)buf,&tmpData);
	if(value==1){					/* Error */
		return(1);
	}
	else if(value==0){
		if(tmpData < *para1st){
			return(2);				/* Error(Address Size Error) */
		}
		else{
			*para2nd = tmpData - *para1st;
		}
	}
	return(0);						/* Normal End   */
}

/***********************************************************/
/*        Decode Format01                                  */
/* COM <start Add>[ (<End Add>)] (RET)                     */
/*        Dump,                                            */
/***********************************************************/
char DecodeForm01(uintptr_t *para1st,
				  uintptr_t *para2nd)
{
	char tmp[64],chPtr,endCh,getCnt,value;

	chPtr= getCnt = 0;
	do{
	 endCh=GetStrBlk(gKeyBuf,tmp,&chPtr,0);
		switch(getCnt){
		/*********** Ana 1st parameter <start Add> **********/
		 case 1:
			if(DecodeHexAscStr(para1st,tmp)==1)
				return(1);					/* Syntax Error */
			break;
		/*********** Ana 2nd parameter <End Add>   **********/
		 case 2:
			if(value=DecodeHexAscStr2(para1st,para2nd,tmp))
				return(value);				/* 1:Syntax Error  2:Address Size Error */
			break;
		}
	 getCnt++;
	}while(endCh);
	return(0);								/* Normal End   */
}

/***********************************************************/
/*        Decode Format02                                  */
/* COM <start Add>  (RET)                                  */
/*        ME,                                              */
/***********************************************************/
char DecodeForm02(uintptr_t *para1st)
{
	char tmp[64],chPtr,endCh,getCnt,value;

	chPtr= getCnt = 0;
	do{
	 endCh=GetStrBlk(gKeyBuf,tmp,&chPtr,0);
		switch(getCnt){
		/*********** "ME" Block parameter  ****************/
		 case 0:
			if(endCh==0)					/* non set start Add = Error */
				return(1);
			break;
		/*********** Ana 1st parameter <start Add> ********/
		 case 1:
			if(DecodeHexAscStr(para1st,tmp)==1)
				return(1);					/* Syntax Error */
			break;
		}
	 getCnt++;
	}while(endCh);
	return(0);
}

/***********************************************************/
/*        Decode Format02_1                                */
/* COM <start Add>  (RET)                                  */
/*        G                                                */
/***********************************************************/
char DecodeForm02_1(uintptr_t *para1st)
{
#ifdef COM_LG_ON

	char tmp[64],chPtr,endCh,getCnt,value;

	chPtr= getCnt = 0;
	do{
	 endCh=GetStrBlk(gKeyBuf,tmp,&chPtr,0);
		switch(getCnt){
		/*********** "ME" Block parameter  ****************/
		 case 0:
			if(endCh==0)					/* non set start Add */
				return(2);
			break;
		/*********** Ana 1st parameter <start Add> ********/
		 case 1:
			if(DecodeHexAscStr(para1st,tmp)==1)
				return(1);					/* Syntax Error */
			break;
		}
	 getCnt++;
	}while(endCh);
	return(0);

#endif
}

/***********************************************************/
/*        Decode Format03                                  */
/* COM <start Add> <End Add> <data>(RET)                   */
/*        Fill	                                           */
/***********************************************************/
char DecodeForm03(uintptr_t *para1st,
				 uintptr_t  *para2nd,
				 uintptr_t  *para3rd,
				 uint32_t   *setPara)
{
#ifdef COM_F_ON

	char tmp[64],chPtr,endCh,getCnt,value;

	*setPara = 0;
	chPtr= getCnt = 0;
	do{
	 endCh=GetStrBlk(gKeyBuf,tmp,&chPtr,0);
		switch(getCnt){
		/*********** "F"Command  Block parameter  ****************/
		 case 0:
			if(endCh==0)					/* non set start Add = Error */
				return(1);
			break;
		/*********** Ana 1st parameter <start Add> **********/
		 case 1:
			if(DecodeHexAscStr(para1st,tmp)==1)
				return(1);					/* Syntax Error */
			else
				*setPara = 0x01;
			break;
		/*********** Ana 2nd parameter <End Add>   **********/
		 case 2:
			if(value=DecodeHexAscStr2(para1st,para2nd,tmp))
				return(value);				/* 1:Syntax Error  2:Address Size Error */
			else
				*setPara = 0x02;
			break;
		/*********** Ana 3rd parameter <data> ***************/
		 case 3:
			if(DecodeHexAscStr(para3rd,tmp)==1)
				return(1);					/* Syntax Error */
			else
				*setPara = 0x03;
			break;
		}
	 getCnt++;
	}while(endCh);
	return(0);

#endif
}

/***********************************************************/
/*        Decode Format04                                  */
/* COM <start Add> <End Add> <data>(RET)                   */
/*        MV                                               */
/***********************************************************/
char DecodeForm04(uintptr_t *para1st,
				  uintptr_t *para2nd,
				  uintptr_t *para3rd,
				  uint32_t *setPara)
{
#ifdef COM_MV_ON

	char tmp[64],chPtr,endCh,getCnt,value;

	*setPara = 0;
	chPtr= getCnt = 0;
	do{
	 endCh=GetStrBlk(gKeyBuf,tmp,&chPtr,0);
		switch(getCnt){
		/*********** "MV"Command  Block parameter  ****************/
		 case 0:
			if(endCh==0)					/* non set start Add = Error */
				return(1);
			break;
		/*********** Ana 1st parameter <start Add> **********/
		 case 1:
			if(DecodeHexAscStr(para1st,tmp)==1)
				return(1);					/* Syntax Error */
			else
				*setPara = 0x01;
			break;
		/*********** Ana 2nd parameter <End Add>   **********/
		 case 2:
			if(DecodeHexAscStr(para2nd,tmp)==1)
				return(1);					/* Syntax Error */
			else
				*setPara = 0x02;
			break;
		/*********** Ana 3rd parameter <data> ***************/
		 case 3:
			if(DecodeHexAscStr(para3rd,tmp)==1)
				return(1);					/* Syntax Error */
			else
				*setPara = 0x03;
			break;
		}
	 getCnt++;
	}while(endCh);
	return(0);

#endif
}

/***********************************************************/
/*        Decode Format5                                   */
/* COM <start Add>(<End Add>/@<byte>)(RET)                 */
/*        RAMCK,                                           */
/***********************************************************/
char DecodeForm5(uintptr_t *para1st,
				 uintptr_t *para2nd,
				 uint32_t *setPara)
{

#ifdef COM_RAMCK_ON

	char tmp[64],tmp2[64],chPtr,chPtr2,endCh,getCnt,value;
	uintptr_t tmpData;

	*setPara = 0;
	chPtr= getCnt = 0;
	do{
	 endCh=GetStrBlk(gKeyBuf,tmp,&chPtr,0);
		switch(getCnt){
		/*********** "RAMCK" Block parameter  *************/
		 case 0:
			if(endCh==0)					/* non set start Add */
				return(2);
			break;
		/*********** Ana 1st parameter  *******************/
		 case 1:
			 value = HexAscii2Data_64((unsigned char*)tmp,para1st);
			 if(value ==0 ) *setPara |= 0x01;
			 else  return(1);
			break;
		/*********** Ana 2nd parameter  *******************/
		 case 2:
		 	 value = HexAscii2Data_64((unsigned char*)tmp,&tmpData);
			 if(value ==0 ){
				 *setPara |= 0x02;
				 if(*para1st>tmpData)	return(2);
				 else{	*setPara |= 0x02;
						*para2nd = (tmpData - *para1st) + 0x01 ;
				 }
			 }
			 else if(value ==3 ){    /* find @ */
				chPtr2 = 1;
				GetStrBlk(tmp,tmp2,&chPtr2,0);
				if(HexAscii2Data_64((unsigned char*)tmp2,para2nd)) return(1);
				*setPara |= 0x02;
			 }else	 return(1);
			break;
		}
	 if(endCh==';'){
		if(GetStrBlk(gKeyBuf,tmp,&chPtr,0))
			return(1);
		endCh=0;
		*setPara |= 0x08;
	 }
	 getCnt++;
	}while(endCh);
	return(0);
	
#endif
}
