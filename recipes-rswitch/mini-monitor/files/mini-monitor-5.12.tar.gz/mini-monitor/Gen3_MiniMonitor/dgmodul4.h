#define		CHANGE_OFF		0
#define		CHANGE_ON		1

#define		SYSTEMRAM_SADD				0xE6300000
#define		SYSTEMRAM_IPL_SADD			0xE6302000
#define		PUBLICRAM_EADD				0xE635FFFF

#define		RTRAM_SADD					0xEB200000		//V3H Only
#define		RTRAM_IPL_SADD				0xEB202600		//V3H Only
#define		RTRAM_EADD					0xEB2FFFFF		//V3H Only

#define		LS_WORK_DRAM_SADD			0x50000000
#define		LS_WORK_DRAM_EADD_192K		0x5002FFFF
#define		LS_WORK_DRAM_EADD_16K		0x50003FFF
#define		LS_WORK_DRAM_EADD_64M		0x53FFFFFF

//#define	WORK_SPI_LOAD_AREA	0x60000000
#define		WORK_SPI_LOAD_AREA	0x58000000

//----------------------------------------------------------------------
//                            Memory Size / Sector Size
//QspiFlash Board  (S25FL512):  64MByte   / 256KByte
//OnBoard QspiFlash(S25FS128):  16MByte   / 256KByte
//HyperFlash (on R-CarH3-SiP):  64MByte   / 256KByte
//----------------------------------------------------------------------
//Spi/Hyper���ʂ�Sector Area���́AS25FL512_xx�Ƃ���#define��`

//Hyper Flash / QSPI Flash(S25FL512)
#define		S25FL512_SA_SIZE			0x0040000
//#define	S25FL512_SA_SIZE			0x0000100		//==DEBUG==
#define		S25FL512_SA00_STARTAD		0x0000000
#define		S25FL512_SA01_STARTAD		0x0040000
#define		S25FL512_SA02_STARTAD		0x0080000
#define		S25FL512_SA03_STARTAD		0x00C0000		//User Add,Size
#define		S25FL512_SA04_STARTAD		0x0100000		//User Image
#define		S25FL512_END_ADDRESS		0x3FFFFFF

//#define	S25S128_END_ADDRESS			0x0FFFFFF
#define		S25S128_END_ADDRESS			0x0FF7FFF		//�㔼32KByte�����Łi�p�����[�^�G���A�ɂ��j

#define		SPIBOOT_UPRG_ST_AD			0x00C0000		//USER PROGRAM Address (MiniMonitor)
#define		SPIBOOT_UPRG_SIZE			0x00C0004		//USER PROGRAM Size    (MiniMonitor)

//=====     Address specification at SPi boot     =================================================
#define		SPIBOOT_BTROM_PARA			0x0000000		//Boot ROM Parameters (4Byte)  //4P4E�ŏ���
#define		SPIBOOT_A_IPL_ADD			0x0000D54		//A-side IPL address  (4Byte)  //4P4E�ŏ���
#define		SPIBOOT_A_IPL_SIZE			0x0000E64		//A-side IPL data size(4Byte)  //4P4E�ŏ���
#define		SPIBOOT_B_IPL_ADD			0x0001154		//B-side IPL address  (4Byte)  //4P4E�ŏ���
#define		SPIBOOT_B_IPL_SIZE			0x0001264		//B-side IPL data size(4Byte)  //4P4E�ŏ���
//--R-CarV3H Only--
#define		V3H_SPIBOOT_A_IPL_ADD		0x0003154		//A-side IPL address  (4Byte)  //4P4E�ŏ���
#define		V3H_SPIBOOT_A_IPL_SIZE		0x0003264		//A-side IPL data size(4Byte)  //4P4E�ŏ���
#define		V3H_SPIBOOT_B_IPL_ADD		0x0004154		//B-side IPL address  (4Byte)  //4P4E�ŏ���
#define		V3H_SPIBOOT_B_IPL_SIZE		0x0004264		//B-side IPL data size(4Byte)  //4P4E�ŏ���
//=================================================================================================

#define		ONBOARD_QSPI				0x00000001		//S25FS128S
#define		QSPI_BOARD					0x00000002		//S25FL512S
#define		HYPER_FLASH					0x00000003		//S26KS512S
#define		ONBOARD_QSPI_512M			0x00000004		//S25FS512S

//SpiFlash Manufacture and Device ID:ID-CFI Address[03h-00h]		//03h �}�X�N
//#define	ONBOARD_QSPI				0x4D182001		//ID�l	S25FS128S
#define		DEVID_S25FS128S				0x00182001		//ID�l	S25FS128S (03h:4Dh)
#define		DEVID_S25FL512S				0x00200201		//ID�l	S25FL512S (03h:xxh)
#define		DEVID_S26KS512S				0x007E0001		//ID�l  S26KS512S
#define		DEVID_S25FS512S				0x00200201		//ID�l	S25FS512S (03h:4Dh)

//SpiFlash Famiry ID:ID-CFI Address[05h]
#define		FS_S_FAMILY					0x00008100		//On Board SpiFlashMemory
#define		FL_S_FAMILY					0x00008000		//Ex Board SpiFlashMemory

#define		SPIBOOT_FLASH_CLOCK_PARA	0x0000004		//Flash Clock Parameters (4Byte)  //4P4E�ŏ���  //Add 2016.03.23 ����J
#define		SPIBOOT_DUMMY_CYCLE_PARA	0x0000008		//Dummy Cycle Parameters (4Byte)  //4P4E�ŏ���  //Add 2016.03.23 ����J

void dgGen3LoadSpiflash0(void);
void SelQspiFlashSetSw(void);
void SelQspiFlashSetSw_Salvator(void);
void SelQspiFlashSetSw_Eagle(void);
void InitRPC_Mode(void);
uint32_t CheckQspiFlashId(void);
int32_t CkQspiFlash0ClearSectorSize(uint32_t rdBufAdd,uint32_t spiFlashStatAdd,uint32_t checkSize,uint32_t accessSize);
int32_t CkQspiFlash1ClearSectorSize(uint32_t rdBufAdd,uint32_t spiFlashStatAdd,uint32_t checkSize,uint32_t accessSize);
int32_t CkQspiFlash2ClearSectorSize(uint32_t rdBufAdd,uint32_t spiFlashStatAdd,uint32_t checkSize,uint32_t accessSize);
int32_t CkHyperFlashClearSectorSize(uint32_t rdBufAdd,uint32_t spiFlashStatAdd,uint32_t checkSize,uint32_t accessSize);
void mem_copy(uint32_t prgStartAd, uint32_t sector_Ad, uint32_t accessSize);
void mem_copy_SysDmac(uint32_t prgStartAd, uint32_t sector_Ad, uint32_t accessSize);
void mem_copy_RtDmac(uint32_t prgStartAd, uint32_t sector_Ad, uint32_t accessSize);

void dgGen3LoadSpiflash0_2(void);
void XLoadSpiflash0_2(void);

void SetData(uint32_t *setAdd);
int32_t CkSpiFlashAllF(int32_t sAdd,int32_t cap);
void SetAddInputKey(uint32_t *Address);
void dgGen3InfoSpiflash0_SA0(void);
int32_t CheckDataChange(uintptr_t checkAdd);
void dgGen3InfoSetSpiflash0_SA0(void);
void dgGen3InfoSpiflash0(void);
void dgGen3InfoSetSpiflash0(void);
void dgClearSpiflash0(void);

void WriteCopytoFlash(void);
void SelCopyFlashMemory(void);
void SelCopyFlashMemory_Salvator(void);
void SelCopyFlashMemory_Eagle(void);
void SetFlashMemory(uint32_t selectFlash);

void ExtModeOn(void);



// ����J
void dgGen3InfoSpiflash0_SA0_Ver2(void);
void dgGen3InfoSetSpiflash0_SA0_Ver2(void);
