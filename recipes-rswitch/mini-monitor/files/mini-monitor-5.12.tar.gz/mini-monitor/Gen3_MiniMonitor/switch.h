#define BOARD_COUNT	11

//BOARD_CODE
//===== No change of board code number. ===================================
#define BD_SALVATOR_X			0x00000000	// R-Car H3_SIP/M3_SIP
#define BD_KRIEK_LP4			0x00000001	// R-Car M3
#define BD_STARTERKIT_PRO		0x00000002	// R-Car M3_SIP
#define BD_EAGLE				0x00000003	// R-Car V3M	( EAGLE / EAGLE-R )
#define BD_SALVATOR_XS			0x00000004	// R-Car H3_SIP/M3_SIP
#define BD_DRAAK				0x00000005	// R-Car D3
#define BD_STARTERKIT_PRE		0x00000006	// R-Car H3_SIP
#define BD_KRIEK_DDR3			0x00000007	// R-Car M3
#define BD_CONDOR				0x00000008	// R-Car V3H
#define BD_EBISU				0x00000009	// R-Car E3		( EBISU_2D / EBISU4D )



typedef struct	prg_tbl {
	void	(*program)();
} prg_tbl;

//== SPI / HYPER Interface Message ==========================================
//-- other ------------------------------------------------------------------
void SwChgOnBoard_QSPI0_other(void);
void SwChgExSPI_QSPI0_other(void);
void SwChgHyperFlash_other(void);
void SwChgOnBoard_QSPI0_512M_other(void);

//-- SALBATOR ---------------------------------------------------------------
void SwChgOnBoard_QSPI0_SALVATOR(void);
void SwChgExSPI_QSPI0_SALVATOR(void);
void SwChgHyperFlash_SALVATOR(void);

//-- KRIEK / DRAAK ----------------------------------------------------------
void SwChgOnBoard_QSPI0_KRIEK_DRAAK(void);
void SwChgExSPI_QSPI0_KRIEK_DRAAK(void);
void SwChgHyperFlash_KRIEK_DRAAK(void);

//-- STARTER KIT ------------------------------------------------------------
void SwChgOnBoard_QSPI0_SKIT(void);
void SwChgExSPI_QSPI0_SKIT(void);
void SwChgHyperFlash_SKIT(void);

//-- EAGLE ------------------------------------------------------------------
void SwChgOnBoard_QSPI0_128_EAGLE(void);
void SwChgExSPI_QSPI0_EAGLE(void);
void SwChgOnBoard_QSPI0_512_EAGLE(void);


//== LBSC EX_MEM Board Interface Message ======================================
//-- other ------------------------------------------------------------------
void SwChgLbscArea_other(void);
//-- SALBATOR ---------------------------------------------------------------
//-- KRIEK ------------------------------------------------------------------
void SwChgLbscArea_SALVATOR_KRIEK(void);
//-- EAGLE ------------------------------------------------------------------
void SwChgLbscArea_EAGLE(void);

void MessBoardFlagError(void);


