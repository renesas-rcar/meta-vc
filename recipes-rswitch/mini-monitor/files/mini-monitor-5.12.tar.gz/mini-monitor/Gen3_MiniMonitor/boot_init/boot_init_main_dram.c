#include "ddr_init_e3.h"								// Ebisu
#include "ddr_init_d3.h"								// Draak
#include "ddr_init_v3m.h"								// Eagle
#include "boot_init_dram.h"								// Salvator / Kriek / StarterKit / Condor
#include "reg_rcargen3.h"
#include "boarddrv.h"
#include "boardid.h"
#include "cpudrv.h"
#include "common_func.h"

extern uint32_t gBoardcnf;		//dram_config:_board_judge


//***************************************************************
// DDR Initial setting  branch main.
//***************************************************************
// �����SoC�Ƃ��{�[�h����DDR�̏����ݒ肪�قȂ�ꍇ�́A�����ݒ�֐��̒��ŕ���B
void InitDramBoard(void)
{
	uint32_t md=0;
	uint32_t ddr=0;
	uint32_t ddrPhy=0;

#if defined(H3_M3) || defined(V3H)

//	if(CHK_M3N||(CHK_M3)){			//  Kriek(M3N/M3)�ɂ�DDR3���ڃ{�[�h����B���b�Z�[�W�\����SW�ݒ�m�F�B�B
//		if(CHK_KRIEK){
//			md = *((volatile uint32_t*)RST_MODEMR);
//			ddrPhy = (md & 0x08000000) >> 27;
//			PutStr("",1);
//			if(ddrPhy == 0x0)		{	PutStr(" InitDram  MD27=Low  (LPDDR4)",1);		}
//			else if(ddrPhy == 0x1)	{	PutStr(" InitDram  MD27=High (DDR3/DDR3L)",1);	}
//		}
//	}
	InitDram();						//  LPDDR4��DDR3�p�Ɠ����֐��������ݒ�R�[�h�͈قȂ�̂Œ��ӁBmakefile��DDR�����ݒ�t�H���_(LPDDR4 or DDR3)���w�肵�đΉ��B


#endif
#ifdef V3M
	md = *((volatile uint32_t*)RST_MODEMR);
	ddr = (md & 0x00080000) >> 19;
	if(CHK_V3M){
		if(ddr == 0x0){				// MD19 : ON(0)  = DDR3L-1600
			pll3_freq_change_bypmode_1583();
			if(init_ddr_v3m1583()){ /*	PutStr("return = 1",1);		*/	}
			else{				    /*	PutStr("return = -",1);		*/	}
		}
		else if(ddr == 0x1){		// MD19 : OFF(1) = DDR3L-1333
			pll3_freq_change_bypmode_1316();
			if(init_ddr_v3m1316()){ /*	PutStr("return = 1",1);		*/	}
			else{					/*	PutStr("return = -",1);     */	}
		}
	}
#endif
#ifdef D3
	md = *((volatile uint32_t*)RST_MODEMR);
	ddr = (md & 0x00080000) >> 19;
	if(CHK_D3){
		if(ddr == 0x0){
			if(init_ddr_d31600()){	/*	PutStr("return = 1",1);		*/	}
			else{					/*	PutStr("return = -",1);		*/	}
		}else if(ddr == 0x1){
			if(init_ddr_d31866()){	/*	PutStr("return = 1",1);		*/	}
			else{					/*	PutStr("return = -",1);		*/	}
		}
	}
#endif
#ifdef E3
	if(CHK_E3){
		InitDram();					// "ddr_init_e3.c"
	}
#endif
}

#if defined(H3_M3) || defined(V3H)
//boot_init_dram_regdef.h    RCAR_DDR_VERSION        "rev.0.28"
//boot_init_dram_config.c   static uint32_t _board_judge(void) �ɍ��킹��
void Mess_DdrBoard_Judge(char rtn)
{	
	PutStr(" DDR_Init        : ",0);

#if BOARD_TYPE==0xFF

#if defined(DDR3) || defined(DDR3L)
	switch(gBoardcnf){
		case 0:			PutStr("boardcnf[0] KRIEK-DDR3  board w M3",rtn);		break;
		case 1:			PutStr("boardcnf[1] KRIEK-DDR3L board w M3",rtn);		break;
		case 2:			PutStr("boardcnf[2] KRIEK-DDR3  board w M3N",rtn);		break;
		case 3:			PutStr("boardcnf[3] KRIEK-DDR3L board w M3N",rtn);		break;
		default:
			PutStr("boardcnf[-] Error : not supported",rtn);
			break;
	}
#else
	switch(gBoardcnf){
		case 0:			PutStr("boardcnf[0] Salvator (M3SIP)",rtn);								break;
		case 1:			PutStr("boardcnf[1] Kriek (LPDDR4 8Gbit 2rank)",rtn);					break;	//M3_4GB�p_2Rank
		case 2:			PutStr("boardcnf[2] Salvator / Starter Kit (H3SIP_VER1.X-1rank)",rtn);	break;
		case 3:			PutStr("boardcnf[3] Starter Kit (M3SIP-1rank)",rtn);					break;
		case 7:			PutStr("boardcnf[7] Salvator / Starter Kit (H3SIP_VER2.0-1rank)",rtn);	break;
		case 6:			PutStr("boardcnf[6] Salvator (H3SIP-2rank)",rtn);						break;	//H3_8GB�p_2Rank
		case 8:			PutStr("boardcnf[8] Salvator (H3SIP_VER2.0/3.0-2rank)",rtn);			break;	//H3_8GB�p_2Rank
		case 10:		PutStr("boardcnf[10] Kriek (M3N-2rank)",rtn);							break;
		case 11:		PutStr("boardcnf[11] Salvator (M3N SIP-2rank)",rtn);					break;
		case 12:		PutStr("boardcnf[12] Condor (V3H)",rtn);								break;
		case 13:		PutStr("boardcnf[13] Kriek (PM3)",rtn);									break;
		case 14:		PutStr("boardcnf[14] Salvator (H3SIP_VER2.0/3.0-1rank)",rtn);			break;	//H3_8GB�p_1Rank
		case 15:		PutStr("boardcnf[15] Kriek (H3N)",rtn);									break;
		case 18:		PutStr("boardcnf[18] Salvator (M3SIP_VER3.0~-16Gbit 2rank)",rtn);		break;	//M3_8GB�p_2Rank
		case 19:		PutStr("boardcnf[19] Salvator (M3SIP_VER1.3~-16Gbit 1rank)",rtn);		break;	//M3_4GB�p_1Rank
		case 20:		PutStr("boardcnf[20] Kriek (LPDDR4 16Gbit 2rank)",rtn);					break;	//M3_8GB�p_2Rank
		case 21:		PutStr("boardcnf[21] Kriek (LPDDR4 16Gbit 1rank)",rtn);					break;	//M3_4GB�p_1Rank
		default:
			PutStr("boardcnf[-] Error : not supported",rtn);
			break;
	}
#endif

#else /* BOARD_TYPE */
	PutStr("boardcnf[-] Custom board",rtn);
#endif /* BOARD_TYPE */
	
}
#endif


