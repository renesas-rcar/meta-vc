#include "common.h"
#include "bit.h"
#include "spiflash1drv.h"
#include "rpcqspidrv.h"
#include "dgtable.h"


#ifdef COM_SPI_ON		//ifdef COM_SPI_ON �i�{�h���C�o�t�@�C���S�āj

extern uint32_t gSelectQspiFlash;

//////////////////////////////////////////////////////////////////////////////////////
//
// QSPI SPI-FLASH  S25FS128S
//
//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////
// Qspi:Fast Read    (S25FL512S�Ɠ���)
//////////////////////////////////
void FastRdQspiFlashS25s128s(uint32_t sourceSpiAdd,uint32_t destinationAdd,uint32_t byteCount)
{
	uint32_t sourceAdd;

	InitRPC_QspiFlash4FastReadExtMode();

	sourceAdd = SPI_IOADDRESS_TOP + sourceSpiAdd;

//	copy : spi_ioaddress (H'08000000�`)-> destinationAdd (H'60000000�`�j
	mem_copy(destinationAdd, sourceAdd, byteCount);
}

//////////////////////////////////
// Qspi:Fast Read  (FAST_READ 0Bh)
//////////////////////////////////
void FastRd3adQspiFlashS25s128s (uint32_t sourceSpiAdd,uint32_t destinationAdd,uint32_t byteCount)
{
	uint32_t sourceAdd;

	InitRPC_QspiFlashFastReadExtMode();

	sourceAdd = SPI_IOADDRESS_TOP + sourceSpiAdd;
//	copy : spi_ioaddress (H'08000000�`)-> destinationAdd (H'60000000�`�j
	mem_copy(destinationAdd, sourceAdd, byteCount);
}



//////////////////////////////////
// Qspi:Fast Read  (4FAST_READ 0Ch)  �}�j���A�����[�h   (S25FL512S�Ɠ���)
//////////////////////////////////
void FastRdManuQspiFlashS25s128s(uint32_t sourceSpiAdd,uintptr_t destinationAdd,uint32_t byteCount)
{
	uint32_t		readAdd;
	uint32_t		rdData;
	
	rdData=destinationAdd;

	for(readAdd=sourceSpiAdd ; readAdd<(sourceSpiAdd+byteCount) ; readAdd+=4){
		SingleFastReadQspiFlashData4Byte(readAdd, &rdData);
		*((uint32_t *) destinationAdd) = rdData;
		destinationAdd +=4;
	}
}


//add 2016.01.19
//////////////////////////////////
// Qspi:Quad I/O Read   (Quad I/O Read EBh)
//////////////////////////////////
void QuadIORdQspiFlashS25s128s(uint32_t sourceSpiAdd,uint32_t destinationAdd,uint32_t byteCount)
{
	uint32_t sourceAdd;

	EnableQuadModeQspiFlashS25fs128s();		//WriteAnyRegister

	InitRPC_ExtMode_QuadIORead();

	sourceAdd = SPI_IOADDRESS_TOP + sourceSpiAdd;
//	copy : spi_ioaddress (H'08000000�`)-> destinationAdd (H'60000000�`�j
	mem_copy(destinationAdd, sourceAdd, byteCount);
}

//////////////////////////////////
// Qspi:Write Enable
//////////////////////////////////
// rpcdrv.c �̊֐��őΉ�
//	WriteCommandQspiFlash(0x00060000);	//WRITE ENABLE


//////////////////////////////////
// Qspi:Read Status
//////////////////////////////////
// rpcdrv.c �̊֐��őΉ�
//	ReadStatusQspiFlash(rdStatus);



//////////////////////////////////////
// Qspi:Read Configuration register
//////////////////////////////////////
// rpcdrv.c �̊֐��őΉ�
// void ReadConfigRegQspiFlash(uint32_t *cnfigReg)

//////////////////////////////////////
// Qspi:Write register
//////////////////////////////////////
// rpcdrv.c �̊֐��őΉ�
// void WriteRegisterQspiFlash(uint32_t statusReg, uint32_t configReg)

	
#if 0		//S25s128s�ł́AWriteRegisterQspiFlash_Byte2()�͎g�p���Ȃ��BS25fl512s����OK�B���Ȃ��B
			//S25s128s�� 0x01 : Write (Status & Configuration) Register�R�}���h��CR1NV�ւ̏������ׁ݂̈B
#endif

//////////////////////////////////////////
// Qspi:Set SectorErase256kb mode (CR3V[1]=1   0:64kb 1:256kb)
//////////////////////////////////////////
void SetSectorErase256kbQspiFlashS25s128s(void)
{
	unsigned char readData;
	uint32_t status;
	uint32_t addr;

	char str[64];		//DEBUG

	addr = (uint32_t) SPIREG_CR3V;

// Read Any Register CR3V[1]�ݒ�m�F
//	PutStr("=== READ :Read Any Register (RDAR 65h) =====",1);	//********************* DEBUG
	ReadAnyRegisterQspiFlash(addr,&readData);
//	Data2HexAscii(addr,str,4);									//********************* DEBUG
//	PutStr("RDAR        :H' ",0);			PutStr(str,1);		//********************* DEBUG
//	Data2HexAscii(readData,str,4);								//********************* DEBUG
//	PutStr("RDAR[CR3V]  :H' ",0);			PutStr(str,1);		//********************* DEBUG

	if(!(readData & BIT1)){
//		PutStr("256KB Erase mode set!",1);			//DEBUG Message
		WriteCommandQspiFlash(0x00060000);			//WRITE ENABLE
		readData |= BIT1;							// Bit1=Block Erase Size  1:256KB , 0:64KB
//		readData |= (BIT1|BIT3);					// Bit1=Block Erase Size  1:256KB , 0:64KB  , Bit3=4KB Erase 1:Disable , 0:Enable //Change 2015.07.24
// Write Any Register CR3V[1] ��1�ɐݒ�
//		PutStr("=== SET: Write Any Register (WRAR 71h) =====",1);	//********************* DEBUG
		WriteAnyRegisterQspiFlash(addr,readData);

//Data2HexAscii(addr,str,4);								//********************* DEBUG
//PutStr("WRAR        :H' ",0);		PutStr(str,1);		//********************* DEBUG
//Data2HexAscii(readData,str,4);							//********************* DEBUG
//PutStr("WRAR[CR3V]  :H' ",0);		PutStr(str,1);		//********************* DEBUG

		while(1){
			ReadStatusQspiFlash(&status);
			if( !(status & BIT0) )	break;
		}
	}
// Read Any Register CR3V[1]�ݒ�m�F
//	PutStr("=== READ :Read Any Register (RDAR 65h) =====",1);	//********************* DEBUG
//	ReadAnyRegisterQspiFlash(addr,&readData);
//	Data2HexAscii(addr,str,4);									//********************* DEBUG
//	PutStr("RDAR        :H' ",0);			PutStr(str,1);		//********************* DEBUG
//	Data2HexAscii(readData,str,4);								//********************* DEBUG
//	PutStr("RDAR[CR3V]  :H' ",0);			PutStr(str,1);		//********************* DEBUG
}



//////////////////////////////////////////
// Qspi:Sector Erase (256kB)	
//////////////////////////////////////////
//4SE DCh
void SectorErase256kbQspiFlashS25s128s(uint32_t addr)
{
	uint32_t status;
	char str[64];		//DEBUG

	WriteCommandQspiFlash(0x00060000);	//WRITE ENABLE
	SectorErase4QspiFlash(addr);

	while(1){
		ReadStatusQspiFlash(&status);
//Data2HexAscii(status,str,4);				//********************* DEBUG
//PutStr("Read[RDSR1 05h]  :H' ",0);		//********************* DEBUG
//PutStr(str,1);							//********************* DEBUG
		if( (status & BIT5) ){				//Add 2015.07.23  //DEBUG===
			PutStr("Erase Error",0);		//DEBUG===
			break;							//DEBUG===
		}									//DEBUG===
		if( !(status & BIT0) )	break;
	}
}

//Add 2015.07.18
//SE D8h    
void SectorErase256kbQspiFlashS25s128s_D8(uint32_t addr)
{
	uint32_t status;

	WriteCommandQspiFlash(0x00060000);	//WRITE ENABLE
	SectorEraseQspiFlash(addr);

	while(1){
		ReadStatusQspiFlash(&status);
		if( !(status & BIT0) )	break;
	}
}



//////////////////////////////////////////
// Qspi:Parameter 4-kB Sector Erase  SA0�擪�i�㔼�j32KByte�p
//////////////////////////////////////////
//4P4E 21h
void ParameterSectorErase4kbQspiFlashS25s128s(uint32_t addr)
{
	uint32_t status;
	char str[64];		//DEBUG

	WriteCommandQspiFlash(0x00060000);	//WRITE ENABLE
	ParameterSectorErase4QspiFlash(addr);

	while(1){
		ReadStatusQspiFlash(&status);
//Data2HexAscii(status,str,4);				//********************* DEBUG
//PutStr("Read[RDSR1 05h]  :H' ",0);		//********************* DEBUG
//PutStr(str,1);							//********************* DEBUG
		if( (status & BIT5) ){				//Add 2015.07.23
			PutStr("Erase Error",0);
			break;
		}
		if( !(status & BIT0) )	break;
	}
}





//////////////////////////////////////////
// Qspi:Bulk Erase (All)
//////////////////////////////////////////
int32_t BulkEraseQspiFlashS25s128s(void)
{
	uint32_t status;
	int32_t errFlag;

	errFlag = NORMAL_END;

	WriteCommandQspiFlash(0x00060000);	//WRITE ENABLE
	WriteCommandQspiFlash(0x00600000);	//Bulk Erase (BE 60h)

	while(1){
		ReadStatusQspiFlash(&status);
		if( (status & BIT5) ){				//Add 2015.07.23  //DEBUG===
//			PutStr("Erase Error",0);		//DEBUG===
			errFlag=ERROR_END;
			break;							//DEBUG===
		}									//DEBUG===
		if( !(status & BIT0) )	break;		//BIT0  1:Device Busy  0:Ready Device is in Standby
	}
	return(errFlag);
}




//////////////////////////////////////////
// Qspi:Page Program (4PP:12h)  (S25FL512S�Ɠ���)
//////////////////////////////////////////
// wrCount:Max256
void PageProgramQspiFlashS25s128s(uint32_t addr,uint32_t writeData)
{
//	uint32_t wrData,rdData,i,status,loopCount,dummyRd;
	uint32_t status;

	WriteCommandQspiFlash(0x00060000);	//WRITE ENABLE
	WriteData4ppQspiFlash(addr, writeData);

//Add 2015.07.21
	while(1){
		ReadStatusQspiFlash(&status);
		if( !(status & BIT0) )	break;
	}
}

//CS�A�T�[�g�ێ� (256Byte�A���A�N�Z�X �f�t�H���g)
void PageProgramQspiFlashS25s128s_CsCont(uint32_t addr, uint32_t *writeData,uint32_t byteCount)
{
	uint32_t loopCount;
	uint32_t status;

	loopCount = (byteCount>>2);

	WriteCommandQspiFlash(0x00060000);	//WRITE ENABLE
	WriteData4ppQspiFlash_CsCont(addr, writeData,loopCount);
//Add 2015.07.21
	while(1){
		ReadStatusQspiFlash(&status);
		if( !(status & BIT0) )	break;
	}
}


//���C�g�o�b�t�@���g�p�����t���b�V���ւ̏����� (256�o�C�g�P��)
//add          = SpiFlash Address
//source_addr  = �������ރf�[�^����������Ă���擪�A�h���X�i��������256�o�C�g���̃f�[�^�������݁j
//4PP
void PageProgramWithBuffeQspiFlashS25s128s(uint32_t addr, uint32_t source_addr)
{
	uint32_t status;


	WriteCommandQspiFlash(0x00060000);	//WRITE ENABLE
//	WriteData4ppWithBufferQspiFlash(addr,source_addr);			//4PP
	WriteDataPpWithBufferQspiFlash(addr,source_addr);			//PP

//Add
	while(1){
		ReadStatusQspiFlash(&status);
		if( !(status & BIT0) )	break;
	}

}








//////////////////////////////////////////
// Qspi:Quad Page Program 
//////////////////////////////////////////
//S25s128s QuadProgram�Ȃ�






//��spiflash1drv_1.c
//////////////////////////////////////////
// Qspi:Page Program (4PP:12h) S25fl512s�Ɠ���
//////////////////////////////////////////
void SaveDataQspiFlashS25s128s(uintptr_t srcAdd,uint32_t svFlashAdd,uint32_t svSize)
{
	uint32_t flashAdd;
	uint32_t writeData;

	for(flashAdd=svFlashAdd;flashAdd<(svFlashAdd+svSize);flashAdd+=4){
		writeData = *(volatile uint32_t*)srcAdd;
	    PageProgramQspiFlashS25s128s(flashAdd,writeData);
		srcAdd = srcAdd + 4;
	}

//	unsigned char *bufPtr;
//	unsigned long flashAdd;
//	bufPtr = (unsigned char*)srcAdd;
//	for(flashAdd=svFlashAdd;flashAdd<(svFlashAdd+svSize);flashAdd+=256){
//	    PageProgramQspiFlash(flashAdd,bufPtr,256,1);
//	    bufPtr = (unsigned char*)(bufPtr+256);
//	}
}
//(256Byte�A���A�N�Z�X �f�t�H���g)		//Byte
void SaveDataQspiFlashS25s128s_CsCont_Byte(uintptr_t srcAdd,uint32_t svFlashAdd,uint32_t svSize)
{
	unsigned char *bufPtr;
	uint32_t flashAdd;

	bufPtr = (unsigned char*)srcAdd;
	for(flashAdd=svFlashAdd;flashAdd<(svFlashAdd+svSize);flashAdd+=256){
//	    PageProgramQspiFlash(flashAdd,bufPtr,256,1);
		PageProgramQspiFlashS25s128s_CsCont(flashAdd,(uint32_t *)bufPtr,256);
	    bufPtr = (unsigned char*)(bufPtr+256);
	}
}
//(256Byte�A���A�N�Z�X �f�t�H���g)		//Long
void SaveDataQspiFlashS25s128s_CsCont(uintptr_t srcAdd,uint32_t svFlashAdd,uint32_t svSize)
{
//	unsigned char *bufPtr;
	uint32_t *bufPtr;
	uint32_t flashAdd;

	bufPtr = (uint32_t*)srcAdd;
	for(flashAdd=svFlashAdd;flashAdd<(svFlashAdd+svSize);flashAdd+=256){
//	    PageProgramQspiFlash(flashAdd,bufPtr,256,1);
		PageProgramQspiFlashS25s128s_CsCont(flashAdd,bufPtr,256);
	    bufPtr = (uint32_t*)(bufPtr+(256/4));
	}
}


void SaveDataWithBuffeQspiFlashS25s128s(uint32_t srcAdd,uint32_t svFlashAdd,uint32_t svSize)
{
	uint32_t flashAdd;
	uint32_t writeDataAdd;

	WriteCommandQspiFlash(0x00060000);	//WRITE ENABLE

	writeDataAdd = srcAdd;
	for(flashAdd=svFlashAdd;flashAdd<(svFlashAdd+svSize);flashAdd+=256){	//256byte:RPC Write Buffer size
		PageProgramWithBuffeQspiFlashS25s128s(flashAdd, writeDataAdd);
		writeDataAdd = writeDataAdd + 256;
	}
}

//////////////////////////////////////////
// Qspi:Quad Page Program 
//////////////////////////////////////////
//QSPI Program�Ȃ�




void SectorEraseQspiFlashS25s128s(uint32_t EraseStatAdd,uint32_t EraseEndAdd)
{
//�Z�N�^�����ł͂Ȃ��A�A�h���X�����ō쐬
//�Z�N�^�P�ʂ� H'40000 (256Kbyte)��

	uint32_t	sectorAd;
	uint32_t	SectorStatTopAdd,SectorEndTopAdd;

//	char str[64];		//DEBUG

	SectorStatTopAdd = EraseStatAdd & 0xFFFC0000;		//0x40000�P�ʂɃ}�X�N
	SectorEndTopAdd  = EraseEndAdd  & 0xFFFC0000;		//0x40000�P�ʂɃ}�X�N

//MON Debug
//				Data2HexAscii(SectorStatTopAdd,str,4);							//********************* DEBUG
//				PutStr(" SectorStatTopAdd        : ",0);						//********************* DEBUG
//				PutStr(str,1);													//********************* DEBUG
//				Data2HexAscii(SectorEndTopAdd,str,4);							//********************* DEBUG
//				PutStr(" SectorEndTopAdd         : ",0);						//********************* DEBUG
//				PutStr(str,1);													//********************* DEBUG
///MON Debug




//OnBoardWQspi�Ή� �ǉ�
//	if(gSelectQspiFlash ==ONBOARD_QSPI){
		SetSectorErase256kbQspiFlashS25s128s();
//	}

	for(sectorAd =SectorStatTopAdd;sectorAd<=SectorEndTopAdd;sectorAd=sectorAd+0x40000 ){
		SectorErase256kbQspiFlashS25s128s(sectorAd);
		PutStr(".",0);
	}
	PutStr("Erase Completed ",1);
}

void ParameterSectorEraseQspiFlashS25s128s(uint32_t EraseStatAdd,uint32_t EraseEndAdd)
{
//�Z�N�^�����ł͂Ȃ��A�A�h���X�����ō쐬
//�Z�N�^�P�ʂ� H'1000 (4Kbyte)��

	uint32_t	sectorAd;
	uint32_t	SectorStatTopAdd,SectorEndTopAdd;

	char str[64];		//DEBUG

	SectorStatTopAdd = EraseStatAdd & 0xFFFFF000;		//0x1000�P�ʂɃ}�X�N
	SectorEndTopAdd  = EraseEndAdd  & 0xFFFFF000;		//0x1000�P�ʂɃ}�X�N

//MON Debug
//				Data2HexAscii(SectorStatTopAdd,str,4);							//********************* DEBUG
//				PutStr(" SectorStatTopAdd        : ",0);						//********************* DEBUG
//				PutStr(str,1);													//********************* DEBUG
//				Data2HexAscii(SectorEndTopAdd,str,4);							//********************* DEBUG
//				PutStr(" SectorEndTopAdd         : ",0);						//********************* DEBUG
//				PutStr(str,1);													//********************* DEBUG
///MON Debug

	for(sectorAd =SectorStatTopAdd;sectorAd<=SectorEndTopAdd;sectorAd=sectorAd+0x1000 ){
//		SectorErase256kbQspiFlashS25s128s(sectorAd);
		ParameterSectorErase4kbQspiFlashS25s128s(sectorAd);
		PutStr(".",0);
//				Data2HexAscii(sectorAd,str,4);							//********************* DEBUG
//				PutStr(" EraseAd         : ",0);						//********************* DEBUG
//				PutStr(str,1);											//********************* DEBUG
	}
	PutStr("Erase Completed ",1);
}


void SectorRdQspiFlashS25s128s(uint32_t spiStatAdd,uint32_t distRamAdd)
{
//1�Z�N�^���[�h�֐�
//�Z�N�^�����ł͂Ȃ��A�A�h���X�����ō쐬

	uint32_t	SectorStatTopAdd,readSize;
	unsigned char	*bufPtr;

	char str[64];		//DEBUG

	SectorStatTopAdd = spiStatAdd & 0xFFFC0000;		//0x40000�P�ʂɃ}�X�N
	readSize  = 0x40000;							//S25FL512:1�Z�N�^�T�C�Y 0x40000
//	bufPtr    = (unsigned char*)distRamAdd;

//MON Debug
//				PutStr(" -------- SectorReadQspi1Flash --------  : ",1);	//********************* DEBUG
//				Data2HexAscii(spiStatAdd,str,4);							//********************* DEBUG
//				PutStr(" spiStatAdd        : ",0);							//********************* DEBUG
//				PutStr(str,1);												//********************* DEBUG
//				Data2HexAscii(SectorStatTopAdd,str,4);						//********************* DEBUG
//				PutStr(" SectorStatTopAdd  : ",0);							//********************* DEBUG
//				PutStr(str,1);												//********************* DEBUG
//				Data2HexAscii(distRamAdd,str,4);							//********************* DEBUG
//				PutStr(" distRamAdd        : ",0);							//********************* DEBUG
//				PutStr(str,1);												//********************* DEBUG
///MON Debug

//	QuadIORdQspiFlashS25s128s(SectorStatTopAdd,distRamAdd,readSize);	//add 2016.01.19
//	FastRdManuQspiFlashS25s128s(SectorStatTopAdd,distRamAdd,readSize);
//	FastRdQspiFlashS25s128s(SectorStatTopAdd,distRamAdd,readSize);
	FastRd3adQspiFlashS25s128s(SectorStatTopAdd,distRamAdd,readSize);
}











#endif

