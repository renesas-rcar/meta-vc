#include "common.h"
#include "dgtable.h"
#include "dgmodul1.h"
#include "dgmodul2.h"
#include "devdrv.h"
#include "ramckmdl.h"
#include "common2.h"
#include "pmicdrv.h"
#include "dgmodul3.h"
#include "iicdrv.h"
#include "i2cdrv.h"
#include "cpudrv.h"
#include "boardid.h"
#include "init_board.h"

extern uint32_t gIic0Mem[3];
extern uint32_t gIic0Dump[3];
extern uint32_t gI2c0Mem[3];
extern uint32_t gI2c0Dump[3];

uintptr_t gSubErrAdd;
uintptr_t gSubErrData;
uintptr_t gSubTrueData;

uint32_t gIic0SlvAdd;
uint32_t gI2c0SlvAdd;

uint32_t gPmicRev;
uint32_t gPmicVdd;
uint32_t gPmicProduct;

int32_t TPRAMCK( uint8_t *startAddr, uint8_t *endAddr )
{
#ifdef COM_RAMCK_ON

	FillData8Bit( startAddr, endAddr, 0x00 );
	if( CheckAndFillData8Bit( startAddr, endAddr, 0x55, 0x00 ) ) return ERROR_END;
	if( CheckAndFillData8Bit( startAddr, endAddr, 0xAA, 0x55 ) ) return ERROR_END;
	if( CheckAndFillData8Bit( startAddr, endAddr, 0xFF, 0xAA ) ) return ERROR_END;
	if( CheckData8Bit( startAddr, endAddr, 0xFF ) ) return ERROR_END;

	WriteIncData8Bit( startAddr, endAddr, 0x00 );
	if( CheckIncData8Bit( startAddr, endAddr, 0x00 ) ) return ERROR_END;
	return NORMAL_END;

#endif
}

void dgRamTest(void)
{
#ifdef COM_RAMCK_ON

#ifdef AArch64
	uint64_t ramck1st,ramck2nd;
#endif
#ifdef AArch32
	uint32_t ramck1st,ramck2nd;
#endif
	
	uint32_t setPara;

	char decRtn;
	char str[10];

	ramck1st=ramck2nd=0x0;
	decRtn = DecodeForm5(&ramck1st,&ramck2nd,&setPara);
	if(!(setPara&0x3)){
		PutStr("Syntax Error",1);	return;
	}else if(decRtn==1){
		PutStr("Syntax Error",1);	return;
	}else if(decRtn==2){
		PutStr("Address Size Error",1);	return;
	}else

	PutStr("== RAM CHECK (Byte Access) ===",1);
	PutStr("- Marching Data Check --------",1);
	PutStr(" [ Write H'00               ]",1);
	PutStr(" [ Check H'00 -> Write H'55 ]",1);
	PutStr(" [ Check H'55 -> Write H'AA ]",1);
	PutStr(" [ Check H'AA -> Write H'FF ]",1);
	PutStr(" [ Check H'FF               ]",1);
	PutStr("- Decoder Pattern Check ------",1);
	PutStr(" [ Write H'00,H'01,H'02 ... ]",1);
	PutStr(" [ Check H'00,H'01,H'02 ... ]",1);
	PutStr("CHECK RESULT",0);

	if(TPRAMCK( ((uint8_t *)ramck1st),((uint8_t *)(ramck1st+ramck2nd)) ) ){
		PutStr("---->NG",1);
		Data2HexAscii_64(gSubErrAdd,str,CPU_BYTE_SIZE);
		PutStr("ERROR ADDRESS:",0); PutStr(str,1);
		Data2HexAscii_64(gSubErrData,str,CPU_BYTE_SIZE);
		PutStr("ERROR DATA   :",0); PutStr(str,1);
		Data2HexAscii_64(gSubTrueData,str,CPU_BYTE_SIZE);
		PutStr("TRUE DATA    :",0); PutStr(str,1);
		return;
	}else{
		PutStr("---->OK",1);
	}

#endif
}

int32_t	PutStrPmicRev(const char *str,char rtn)
{
#ifdef COM_IIC_ON
	while(*str){
		if(*str!='0'){
			PutChar(*str);
		}
		str++;
	}
	if(rtn == 1){
		PutChar(CR_CODE);
		PutChar(LF_CODE);
	}
	return(0);
#endif
}

void dgSetPmicEeprom(void)
{
#ifdef COM_IIC_ON

	if( (CHK_SALVATOR) || (CHK_KRIEK) || (CHK_STARTERKIT) || (CHK_V3H) || (CHK_EBISU) || (CHK_EAGLE_R) ){
		gPmicVdd = NORMAL_VOLTAGE;
		SetPmicEeprom();
	}
	else{
		PutStr("=== not supported command ===",1);
	}

#endif
}

void dgSetPmicEepromM3N_WA(void)
{
#ifdef COM_IIC_ON

//	if( (CHK_SALVATOR) || (CHK_KRIEK) || (CHK_STARTERKIT) ){
	if( CHK_SALVATOR ){			//SALVATOR board requested.
		PutStr("Version to set AVS_VD09_VID0=0.75V ",1);
//		PutStr("Set Data AVS VD09 VID0(0x4B)=0.75V (y/n)",0);
//		if( WaitKeyIn_YorN() ){	// Return1=N
//			PutStr("",1);
//			return;
//		}
		gPmicVdd = LOW_VOLTAGE;
		SetPmicEeprom();
	}
	else{
		PutStr("=== not supported command ===",1);
	}

#endif
}


void SetPmicEeprom(void)
{
#ifdef COM_IIC_ON

	char str[64];
	uint32_t fwRev;
	uint32_t rdData;
	uintptr_t dmp1st,dmp2nd;

//	dmp1st = gIic0Dump[0];				/* Start Address */
//	dmp2nd = gIic0Dump[1];				/* End   Address */
	dmp1st = 0;							/* Start Address */
	dmp2nd = 0x3F;						/* End   Address */

//	if(gPmicVdd == LOW_VOLTAGE){
//		PutStr("Set Data AVS VD09 VID0(0x4B)=0.75V",1);
//	}

	gPmicProduct = GetPmicPrdct();
//		PutStr("PMIC-Product Code     : H'",0);
//		Data2HexAscii(gPmicProduct,str,1);
//		PutStr(str,1);
	PutStr("PMIC-Product          : ",0);
	switch( gPmicProduct ){
		case PMIC_BD9571: PutStr("BD9571",1); break;
		case PMIC_BD9576: PutStr("BD9576",1); break;	//Eagle-R
		case PMIC_BD9574: PutStr("BD9574",1); break;	//Ebisu_BD9574
		default:          PutStr(" ---- ",1); break;
	}

	gPmicRev = GetPmicRev();
	PutStr("PMIC-Product Revision : ",0);
	Data2HexAscii(gPmicRev,str,1);		
	PutStr(str,1);

	fwRev = GetPmicEepromFwRev();
	PutStr("Now Read PMIC-EEPROM Firmware Rev.",0);
	Data2HexAscii(fwRev,str,1);		PutStr(str,1);

	DisplayDump_Pmic(dmp1st,dmp2nd,SIZE_8BIT);
	PutStr("",1);

	if(gPmicProduct==PMIC_BD9571)	{
//PMIC-Product Revision����
		if(gPmicRev<=PMIC_REV01)	{		//OLD PMIC��Salvator�̏ꍇ ��I�����j���[����I��
			if(CHK_SALVATOR){
				PutStr("Update the Firmware Rev of PMIC-EEPROM.OK?(y/n)",0);
				if( WaitKeyIn_YorN() ){	// Return1=N
					PutStr("",1);
					return;
				}
				SelPcbVersion();			//set gPcbVer
				PutStr("",1);
			}
		}
	}

	PutStr("Write PMIC-EEPROM Firmware Rev.",0);
	rdData=SetPmicEepromFwRev();
	Data2HexAscii(rdData,str,1);	PutStr(str,0);
	PutStr(" OK?(y/n)",0);
	if( WaitKeyIn_YorN() ){	// Return1=N
		PutStr("",1);
		return;
	}
	PutStr("",1);
	if(SetPmicEepromData() ){
		//Error
	}
	else{
		PutStr("Write...complete.",1);
		PutStr("Read PMIC-EEPROM",1);
		DisplayDump_Pmic(dmp1st,dmp2nd,SIZE_8BIT);
	}
#endif
}

void dgReadPmicEeprom(void)
{
#ifdef COM_IIC_ON

	if( (CHK_SALVATOR) || (CHK_KRIEK) || (CHK_STARTERKIT) || (CHK_V3H) || (CHK_EBISU) || (CHK_EAGLE_R) ){
		ReadPmicEeprom();
	}
	else{
		PutStr("=== not supported command ===",1);
	}

#endif
}
void ReadPmicEeprom(void)
{
#ifdef COM_IIC_ON

	PutStr("Read PMIC-EEPROM  OK?(y/n)",0);
	if( WaitKeyIn_YorN() ){	// Return1=N
	    DelStr(26);
		return;
	}
    DelStr(26);
	gPmicProduct = GetPmicPrdct();
	PutGetPmicEepromData();

#endif
}

void dgClearPmicEeprom(void)
{
#ifdef COM_IIC_ON

	if( (CHK_SALVATOR) || (CHK_KRIEK) || (CHK_STARTERKIT) || (CHK_V3H) || (CHK_EBISU) || (CHK_EAGLE_R) ){
		ClearPmicEeprom();
	}
	else{
		PutStr("=== not supported command ===",1);
	}

#endif
}
void ClearPmicEeprom(void)
{
#ifdef COM_IIC_ON

//	PutStr("Clear PMIC-EEPROM(Address=H'00-H'35)) OK?(y/n)",0);
	PutStr("Clear PMIC-EEPROM OK?(y/n)",0);
	if( WaitKeyIn_YorN() ){	// Return1=N
	    DelStr(46);
		return;
	}
    DelStr(46);
	PutStr("Clear...",0);
	if(SetPmicEepromDataFF()){
		//Error
	}else{
		PutStr("OK",1);
	}

#endif
}

#if 0
void SelPcbVersion(void)
{
#ifdef COM_IIC_ON

	char str[64];
	char		chCnt;
	uint32_t	loop;
	uint32_t	size;

	PutStr("",1);
	PutStr("Please select clear size.",1);
	PutStr("1 : All Clear    ",1);
	PutStr("2 : PMIC area only (Address=H'00-H'35)",1);
	loop=1;
	while(loop){
		PutStr("  Select (1-2)>",0);
		GetStr(str,&chCnt);
		  switch(str[0]){
			case '1':
				size = 0x7F;
				loop=0;
				break;
			case '2':
				size = 0x35
				loop=0;
				break;
		  }
	}
#endif

}
#endif



void dgSetIIC0(void)
{
#ifdef COM_IIC_ON

	if( (CHK_SALVATOR) || (CHK_KRIEK) || (CHK_STARTERKIT) || (CHK_EBISU) ){
		SetIIC0();
	}
	else{
		PutStr("=== not supported command ===",1);
	}

#endif
}

void SetIIC0(void)
{
#ifdef COM_IIC_ON

	char str[64];
	uint32_t loop;
	char chCnt;
	char strAscii[32];

	PutStr("Now IIC0-SLAVE ADDRESS:H'",0);
	Data2HexAscii(gIic0SlvAdd,strAscii,1);		PutStr(strAscii,1);

	PutStr(" 0 : INPUT SLAVE ADDRESS ",1);
	PutStr(" 1 : Power IC BD957xMWV-M  H'60",1);
	PutStr(" 2 : EEPROM   BR24T01FVM-W H'A0",1);
	loop=1;
	while(loop){
		PutStr("  Please select (0-2) >",0);
		GetStr(str,&chCnt);
		switch(str[0]){
			case '0':
				SetSlvAdd(&gIic0SlvAdd);
				loop=0;	
				break;
			case '1':
				gIic0SlvAdd = PMIC_IIC_SLA;
				loop=0;	
				break;
			case '2':
				gIic0SlvAdd = EEPROM_I2C_SLA;
				loop=0;
				break;
			case 'X':
			case 'x':
				dgSetIIC0_X(&gIic0SlvAdd);
				loop=0;
				break;
		  }
	}
	PutStr("  Set IIC0-SLAVE ADDRESS : H'",0);
	Data2HexAscii(gIic0SlvAdd,strAscii,1);		PutStr(strAscii,1);
	InitIic(IIC_CH0);

#endif
}

void SetSlvAdd(uint32_t *setAdd)
{
#ifdef COM_IIC_ON

	char		buf[16],key[16],chCnt,chPtr;
	uint32_t	loop;
	uint32_t 	wrData;
	char str[64];

	loop =1;

	PutStr("  Please Input Slave address ",1);
	while(loop){
		PutStr("  Set Address : H'",0);
		GetStr(key,&chCnt);
		chPtr=0;
		if(!GetStrBlk(key,buf,&chPtr,0)){
			if(chPtr==1){									/* Case Return */

			}else if(chPtr > (char)((SIZE_8BIT<<1)+1) ){	/* Case Data Size Over */
				PutStr("  Syntax Error",1);
			}else{
				if(HexAscii2Data((unsigned char*)buf,&wrData)){
					PutStr("  Syntax Error",1);
				}else{
					*setAdd = wrData;
					loop =0;
				}
			}
		}else{
			PutStr("  Syntax Error",1);
		}
	}

#endif
}

void dgSetIIC0_X(uint32_t *setAdd)
{
#ifdef COM_IIC_ON

	char str[64];
	uint32_t loop;
	char chCnt;

	PutStr("",1);
	PutStr("================================",1);
	PutStr("===  Special selection menu  ===",1);
	PutStr("================================",1);
	PutStr(" 1 : xxxxxxxxxxxxx  H'60",1);
	PutStr(" 2 : yyyyyyyyyyyyy  H'A0",1);
	loop=1;
	while(loop){
		PutStr("  Please select (1-2) >",0);
		GetStr(str,&chCnt);
		switch(str[0]){
			case '1':
				*setAdd = PMIC_IIC_SLA;
				loop=0;	
				break;
			case '2':
				*setAdd = EEPROM_I2C_SLA;
				loop=0;
				break;
		  }
	}

#endif
}

void dgSetI2C0(void)
{
#ifdef COM_IIC_ON

	if( CHK_V3H || CHK_D3 || CHK_V3M ){		//D3��EEPROM�̂ݑΉ������ADebug�p�ɔC�ӂ�SLAVE�A�h���X�ݒ�ł���悤�ɋ��BEagle�����l�B
		SetI2C0();
	}
	else{
		PutStr("=== not supported command ===",1);
	}

#endif
}

void SetI2C0(void)
{
#ifdef COM_IIC_ON

	char str[64];
	uint32_t loop;
	char chCnt;
	char strAscii[32];

	PutStr("Now I2C0-SLAVE ADDRESS:H'",0);
	Data2HexAscii(gI2c0SlvAdd,strAscii,1);		PutStr(strAscii,1);

	PutStr(" 0 : INPUT SLAVE ADDRESS ",1);
	PutStr(" 1 : Power IC BD957xMWV-M  H'60",1);
	PutStr(" 2 : EEPROM   BR24T01FVM-W H'A0",1);
	loop=1;
	while(loop){
		PutStr("  Please select (0-2) >",0);
		GetStr(str,&chCnt);
		switch(str[0]){
			case '0':
				SetSlvAdd(&gI2c0SlvAdd);
				loop=0;	
				break;
			case '1':
				gI2c0SlvAdd = PMIC_IIC_SLA;
				loop=0;	
				break;
			case '2':
				gI2c0SlvAdd = EEPROM_I2C_SLA;
				loop=0;
				break;
		  }
	}
	PutStr("  Set I2C0-SLAVE ADDRESS : H'",0);
	Data2HexAscii(gI2c0SlvAdd,strAscii,1);		PutStr(strAscii,1);
	InitI2c(I2C_CH0);

#endif
}






void dgMemEdit_Iic0(void)
{
#ifdef COM_IIC_ON

	if( (CHK_SALVATOR) || (CHK_KRIEK) || (CHK_STARTERKIT) || (CHK_EBISU) ){
		MemEdit_Iic0();
	}
	else{
		PutStr("=== not supported command ===",1);
	}

#endif
}

void MemEdit_Iic0(void)
{
#ifdef COM_IIC_ON

	uint32_t verifyFlg;
	uintptr_t mem1st;
	char decRtn;
	char strAscii[32];

	verifyFlg = VERIFY_ON;
//	verifyFlg = VERIFY_OFF;

	mem1st = gIic0Mem[0];					/* Start Address */
	decRtn = DecodeForm02(&mem1st);

	if(decRtn == 1)
		PutStr("Syntax Error",1);
	else if(decRtn == 0){
		PutStr("Now IIC0-SLAVE ADDRESS:H'",0);
		Data2HexAscii(gIic0SlvAdd,strAscii,1);		PutStr(strAscii,1);

		DisplayMemEd_Iic0(mem1st,SIZE_8BIT,verifyFlg);
		gIic0Mem[0] = gIic0Mem[0]+1;	/* Start Address */
	}

#endif
}

void DisplayMemEd_Iic0(uintptr_t mem1st,uint32_t width,uint32_t verifyFlg)
{
#ifdef COM_IIC_ON

	uintptr_t readData,wrData;
	char mEnd,buf[32],key[32],chCnt,chPtr;

	mEnd = 0;
		while(!mEnd){
			Data2HexAscii_64(mem1st,buf,CPU_BYTE_SIZE);
			PutStr(buf,0); PutStr(" ",0);
			Get1ByteMem_Iic0(mem1st,&readData,width);
			Data2HexAscii_64(readData,buf,(char)width);
			PutStr(buf,0); PutStr(" ? ",0);
			GetStr_MemEd(key,&chCnt);
			chPtr=0;
			if(!GetStrBlk(key,buf,&chPtr,0)){
				if(chPtr==1){								/* Case Return */
					mem1st += width;
				}else if((buf[0]=='.')){					/* Case End */
					mEnd = 1;
				}else if((buf[0]=='^')){					/* Case ^ */
					mem1st -= width;
				}else if(chPtr > (char)((width<<1)+1) ){	/* Case Data Size Over */
					PutStr("Syntax Error",1);
				}else{
					if(HexAscii2Data_64((unsigned char*)buf,&wrData)){
						PutStr("Syntax Error",1);
					}else{									/* Case Mem Edit  */
						Put1ByteMem_Iic0(mem1st,wrData,width);
						if(verifyFlg == VERIFY_ON){
							Get1ByteMem_Iic0(mem1st,&readData,width);
							if(wrData!=readData)	PutStr("Verify Error",1);
						}
						mem1st += width;
					}
				}
			}else{
				PutStr("Syntax Error",1);
			}
		}
	gIic0Mem[0] = mem1st;

#endif
}

void Put1ByteMem_Iic0(uintptr_t writeAdd,
				 uintptr_t writeData,
				 uint32_t width)
{
#ifdef COM_IIC_ON

	uint32_t dataL;

	dataL = writeData;
	PageWriteIic(PMIC_IIC, gIic0SlvAdd, writeAdd, &dataL, 1);
	StartTMU0(1);			//Wait 10ms  (�y�[�W���C�g�T�C�N���̏������ݎ���:5ms[Max])	

#endif
}

void Get1ByteMem_Iic0(uintptr_t readAdd,uintptr_t *readData,uint32_t  width)
{
#ifdef COM_IIC_ON

	uint32_t dataL;

	RandomAddressReadIic(PMIC_IIC, gIic0SlvAdd, readAdd, &dataL, 1);
	*readData = dataL;

#endif
}


void DisplayDump_Pmic(uintptr_t stAdd,uintptr_t dumpSize,uint32_t  width)
{	
	if(CHK_H3||CHK_M3||CHK_M3N||CHK_E3){
		DisplayDump_Iic0(stAdd,dumpSize,width);
	}else if(CHK_V3H||CHK_V3M){
		DisplayDump_I2c0(stAdd,dumpSize,width);
	}
}


void DisplayDump_Iic0(uintptr_t stAdd,uintptr_t dumpSize,uint32_t  width)
{
#ifdef COM_IIC_ON

	char buf[32],asciiBuf[20];
	uintptr_t readAdd,readData;
	uint32_t  blankCnt,byte_count;

	gIic0SlvAdd = EEPROM_I2C_SLA;

	byte_count=0x0;

	/********* Dump Data 1Line All Display *********************/
	if(!((dumpSize&0x0000000F)==0x0000000F)){
		dumpSize=dumpSize|0x0000000F;
	}
	for(readAdd=stAdd;readAdd<=(stAdd+dumpSize);readAdd+=width){
		/********* Dump Address Display ************************/
		if((!(byte_count&0x0000000F))||(byte_count==0)){
			Data2HexAscii_64(readAdd,buf,CPU_BYTE_SIZE);
			PutStr(buf,0);
			PutStr("  ",0);
		}
		Get1ByteMem_Iic0(readAdd,&readData,width);
		Data2HexAscii_64(readData,buf,(char)width);
		ChgDumpAsciiCode(readData,asciiBuf,(char)(byte_count&0xF),(char)width);
		/********* Dump Data Display blank ********************/
		if(!(byte_count&0x8)){
			PutStr(buf,0);
			for(blankCnt=0;blankCnt<width;blankCnt++) PutStr(" ",0);
		}
		else{
			for(blankCnt=0;blankCnt<width;blankCnt++) PutStr(" ",0);
			PutStr(buf,0);
		}
		if( ((width==SIZE_8BIT )&&((byte_count&0xF)==0xF))||
			((width==SIZE_16BIT)&&((byte_count&0xF)==0xE))||
			((width==SIZE_32BIT)&&((byte_count&0xF)==0xC))||
			((width==SIZE_64BIT)&&((byte_count&0xF)==0x8))  ){
				ChgDumpAsciiStr(asciiBuf);
				PutStr("  ",0);
				PutStr(asciiBuf,1);
		}
		byte_count+=width;
	}

#endif
}







void dgMemEdit_I2c0(void)
{
#ifdef COM_I2C_ON

	if(CHK_D3||CHK_V3H||CHK_V3M){		// Draak / Condor�@/ Eagle�iD���f�o�b�O�p�ɃR�}���h���j
		MemEdit_I2c0();
	}
	else{
		PutStr("=== not supported command ===",1);
	}

#endif
}

void MemEdit_I2c0(void)
{
#ifdef COM_I2C_ON

	uint32_t verifyFlg;
	uintptr_t mem1st;
	char decRtn;
	char strAscii[32];

//	if(CHK_DRAAK){
		InitI2c(EEPROM_I2C);
//	}


	verifyFlg = VERIFY_ON;
//	verifyFlg = VERIFY_OFF;

	mem1st = gI2c0Mem[0];					/* Start Address */
	decRtn = DecodeForm02(&mem1st);

	if(decRtn == 1)
		PutStr("Syntax Error",1);
	else if(decRtn == 0){
		PutStr("Now I2C0-SLAVE ADDRESS:H'",0);
		Data2HexAscii(gI2c0SlvAdd,strAscii,1);		PutStr(strAscii,1);

		DisplayMemEd_I2c0(mem1st,SIZE_8BIT,verifyFlg);
		gI2c0Mem[0] = gI2c0Mem[0]+1;	/* Start Address */
	}

#endif
}

void DisplayMemEd_I2c0(uintptr_t mem1st,uint32_t width,uint32_t verifyFlg)
{
#ifdef COM_I2C_ON

	uintptr_t readData,wrData;
	char mEnd,buf[32],key[32],chCnt,chPtr;

	mEnd = 0;
		while(!mEnd){
			Data2HexAscii_64(mem1st,buf,CPU_BYTE_SIZE);
			PutStr(buf,0); PutStr(" ",0);
			Get1ByteMem_I2c0(mem1st,&readData,width);
			Data2HexAscii_64(readData,buf,(char)width);
			PutStr(buf,0); PutStr(" ? ",0);
			GetStr_MemEd(key,&chCnt);
			chPtr=0;
			if(!GetStrBlk(key,buf,&chPtr,0)){
				if(chPtr==1){								/* Case Return */
					mem1st += width;
				}else if((buf[0]=='.')){					/* Case End */
					mEnd = 1;
				}else if((buf[0]=='^')){					/* Case ^ */
					mem1st -= width;
				}else if(chPtr > (char)((width<<1)+1) ){	/* Case Data Size Over */
					PutStr("Syntax Error",1);
				}else{
					if(HexAscii2Data_64((unsigned char*)buf,&wrData)){
						PutStr("Syntax Error",1);
					}else{									/* Case Mem Edit  */
						Put1ByteMem_I2c0(mem1st,wrData,width);
						if(verifyFlg == VERIFY_ON){
							Get1ByteMem_I2c0(mem1st,&readData,width);
							if(wrData!=readData)	PutStr("Verify Error",1);
						}
						mem1st += width;
					}
				}
			}else{
				PutStr("Syntax Error",1);
			}
		}
	gI2c0Mem[0] = mem1st;

#endif
}

void Put1ByteMem_I2c0(uintptr_t writeAdd,
				 uintptr_t writeData,
				 uint32_t width)
{
#ifdef COM_I2C_ON

	uint32_t dataL;

	dataL = writeData;
	PageWriteI2C(EEPROM_I2C, gI2c0SlvAdd, writeAdd, &dataL, 1);
	StartTMU0(1);			//Wait 10ms  (�y�[�W���C�g�T�C�N���̏������ݎ���:5ms[Max])	

#endif
}

void Get1ByteMem_I2c0(uintptr_t readAdd,uintptr_t *readData,uint32_t  width)
{
#ifdef COM_I2C_ON

	uint32_t dataL;

	RandomAddressReadI2C(EEPROM_I2C, gI2c0SlvAdd, readAdd, &dataL, 1);
	*readData = dataL;

#endif
}

void DisplayDump_I2c0(uintptr_t stAdd,uintptr_t dumpSize,uint32_t  width)
{
#ifdef COM_IIC_ON

	char buf[32],asciiBuf[20];
	uintptr_t readAdd,readData;
	uint32_t  blankCnt,byte_count;

	gI2c0SlvAdd = EEPROM_I2C_SLA;

	byte_count=0x0;

	/********* Dump Data 1Line All Display *********************/
	if(!((dumpSize&0x0000000F)==0x0000000F)){
		dumpSize=dumpSize|0x0000000F;
	}
	for(readAdd=stAdd;readAdd<=(stAdd+dumpSize);readAdd+=width){
		/********* Dump Address Display ************************/
		if((!(byte_count&0x0000000F))||(byte_count==0)){
			Data2HexAscii_64(readAdd,buf,CPU_BYTE_SIZE);
			PutStr(buf,0);
			PutStr("  ",0);
		}
		Get1ByteMem_I2c0(readAdd,&readData,width);
		Data2HexAscii_64(readData,buf,(char)width);
		ChgDumpAsciiCode(readData,asciiBuf,(char)(byte_count&0xF),(char)width);
		/********* Dump Data Display blank ********************/
		if(!(byte_count&0x8)){
			PutStr(buf,0);
			for(blankCnt=0;blankCnt<width;blankCnt++) PutStr(" ",0);
		}
		else{
			for(blankCnt=0;blankCnt<width;blankCnt++) PutStr(" ",0);
			PutStr(buf,0);
		}
		if( ((width==SIZE_8BIT )&&((byte_count&0xF)==0xF))||
			((width==SIZE_16BIT)&&((byte_count&0xF)==0xE))||
			((width==SIZE_32BIT)&&((byte_count&0xF)==0xC))||
			((width==SIZE_64BIT)&&((byte_count&0xF)==0x8))  ){
				ChgDumpAsciiStr(asciiBuf);
				PutStr("  ",0);
				PutStr(asciiBuf,1);
		}
		byte_count+=width;
	}

#endif
}


uintptr_t	gErrDdrAdd;
uint32_t gErrDdrData,gTrueDdrData;

#ifdef AArch64
void dgDdrTest(void)
{
#ifdef COM_DDRCK_ON

	uint32_t readData;

	PutStr("=== DDR R/W CHECK ====",1);
//==================== R-Car H3 =============================
	if( (CHK_H3) && (!CHK_KRIEK) ){
		PutStr("=== Memory map H3 ====",1);
//CH0 Check
		readData = *((volatile uint32_t*)0x0000000410000000);	//Access Check
		PutStr("Check:0x04_10000000 ... ",0);
		if( CkExtendDdrRamCheck((void*)0x0000000410000000) ){	PutStr(" Fail!",1);	PutDdrErrInfo();
			PutStr("Next channel Test OK?(y/n)",0);
			if( WaitKeyIn_YorN() ){	// Return1=N
				DelStr(26);		return;
			}DelStr(26);
		}else{
			PutStr(" Pass!",1);
		}
//CH1 Check
		PutStr("Check:0x05_00000100 ... ",0);
		if( CkExtendDdrRamCheck((void*)0x0000000500000100) ){	PutStr(" Fail!",1);	PutDdrErrInfo();
			PutStr("Next channel Test OK?(y/n)",0);
			if( WaitKeyIn_YorN() ){	// Return1=N
			    DelStr(26);		return;
			}DelStr(26);
		}else{
			PutStr(" Pass!",1);
		}
//CH2 Check
		PutStr("Check:0x06_00000100 ... ",0);
		if( CkExtendDdrRamCheck((void*)0x0000000600000100) ){	PutStr(" Fail!",1);	PutDdrErrInfo();
			PutStr("Next channel Test OK?(y/n)",0);
			if( WaitKeyIn_YorN() ){	// Return1=N
			    DelStr(26);		return;
			}DelStr(26);
		}else{
			PutStr(" Pass!",1);
		}
//CH3 Check
		PutStr("Check:0x07_00000100 ... ",0);
		if( CkExtendDdrRamCheck((void*)0x0000000700000100) ){	PutStr(" Fail!",1);	PutDdrErrInfo();
			return;
		}
		PutStr(" Pass!",1);	
	}
//==================== R-Car M3 / H3N(Kriek) ===============
	else if( (CHK_M3) || ((CHK_H3) && (CHK_KRIEK))  ){
		PutStr("=== Memory map M3/H3N(Kriek) ====",1);
//CH0 Check
		readData = *((volatile uint32_t*)0x0000000410000000);	//Access Check
		PutStr("Check:0x04_10000000 ... ",0);
		if( CkExtendDdrRamCheck((void*)0x0000000410000000) ){	PutStr(" Fail!",1);	PutDdrErrInfo();
			PutStr("Next channel Test OK?(y/n)",0);
			if( WaitKeyIn_YorN() ){	// Return1=N
			    DelStr(26);		return;
			}
			DelStr(26);
		}else{
			PutStr(" Pass!",1);
		}
//CH2 Check
		PutStr("Check:0x06_00000100 ... ",0);
		if( CkExtendDdrRamCheck((void*)0x0000000600000100) ){	PutStr(" Fail!",1);	PutDdrErrInfo();
				return;
		}else{
			PutStr(" Pass!",1);
		}
	}
//==================== R-Car V3M/D3/V3H/M3N/E3 ======================
	else if((CHK_V3M)||(CHK_D3)||(CHK_V3H)||(CHK_M3N)||(CHK_E3)){
		PutStr("=== V3M/D3/V3H/M3N/E3 (Memory controller is only channel 1) ===",1);
//CH0 Check
		readData = *((volatile uint32_t*)0x0000000410000000);	//Access Check
		PutStr("Check:0x04_10000000 ... ",0);
		if( CkExtendDdrRamCheck((void*)0x0000000410000000) ){	PutStr(" Fail!",1);	PutDdrErrInfo();
				return;
		}else{
			PutStr(" Pass!",1);
		}
	}

#endif
}
#endif

#ifdef AArch32
void dgDdrTest(void)
{
#ifdef COM_DDRCK_ON
	uint32_t readData;

	PutStr("=== DDR R/W CHECK === [Only check of CH0 side.]",1);
	readData = *((volatile uint32_t*)0x50000000);			//Access Check
	PutStr("Check:0x50000000 ... ",0);
	if( CkExtendDdrRamCheck((void*)0x50000000) ){			PutStr(" Fail!",1);	PutDdrErrInfo();
		return;
	}
	else{
		PutStr(" Pass!",1);
	}

#endif
}
#endif



#ifdef AArch64
//CH0_2GB��DDR�ݒ�m�F�p�B�@�O��1GB�ƌ㔼1GB�G���A�̊e4Mbyte���ȈՃ`�F�b�N�B
void dgDdrTest_2GB(void)
{
#ifdef COM_DDRCK2_ON

	uint32_t readData;

	PutStr("for 2GB DDR check (not check all sizes)",1);
	PutStr("H'04_10000000-H'04_103FFFFF ",0);
//	readData = *((volatile uint32_t*)0x0000000410000000);	//Access Check
	if( CkExtendDdrRamCheck((void*)0x0000000410000000) ){	PutStr(" Fail!",1);	PutDdrErrInfo();
			return;
	}else{
		PutStr(" Pass!",1);
	}
	PutStr("H'04_40000000-H'04_403FFFFF ",0);
//	readData = *((volatile uint32_t*)0x0000000440000000);	//Access Check
	if( CkExtendDdrRamCheck((void*)0x0000000440000000) ){	PutStr(" Fail!",1);	PutDdrErrInfo();
			return;
	}else{
		PutStr(" Pass!",1);
	}

#endif
}
#endif

#ifdef AArch32
void dgDdrTest_2GB(void)
{
#ifdef COM_DDRCK2_ON
	uint32_t readData;

	PutStr("for 2GB DDR check (not check all sizes)",1);
	PutStr("H'50000000-H'503FFFFF ",0);
	if( CkExtendDdrRamCheck((void*)0x50000000) ){			PutStr(" Fail!",1);	PutDdrErrInfo();
		return;
	}
	else{
		PutStr(" Pass!",1);
	}
	PutStr("Check:H'80000000-H'803FFFFF ",0);
	if( CkExtendDdrRamCheck((void*)0x80000000) ){			PutStr(" Fail!",1);	PutDdrErrInfo();
		return;
	}
	else{
		PutStr(" Pass!",1);
	}

#endif
}
#endif



void dgDdrTest_8GB(void)		//H3/M3(8GByte) only 
{
#ifdef COM_DDRCK2_ON
	uint32_t readData;

	PutStr("=== DDR R/W CHECK ====",1);
//==================== R-Car H3 =============================
	if(CHK_H3){
		PutStr("=== Memory map H3 (8GByte) ====",1);
//CH0 Check
		readData = *((volatile uint32_t*)0x0000000400000000);			//Access Check
		PutStr("Check:0x04_00000000 ... ",0);
		if( CkExtendDdrRamCheck((void*)0x0000000400000000) ){	PutStr(" Fail!",1);	PutDdrErrInfo();
			PutStr("Next Area Test OK?(y/n)",0);
			if( WaitKeyIn_YorN() ){	// Return1=N
			    DelStr(26);		return;
			}
			DelStr(26);
		}else
			PutStr(" Pass!",1);
		PutStr("Check:0x04_40000000 ... ",0);
		if( CkExtendDdrRamCheck((void*)0x0000000440000000) ){	PutStr(" Fail!",1);	PutDdrErrInfo();
			PutStr("Next channel Test OK?(y/n)",0);
			if( WaitKeyIn_YorN() ){	// Return1=N
		    	DelStr(26);		return;
			}
			DelStr(26);
		}else{
			PutStr(" Pass!",1);
		}
//CH1 Check
		PutStr("Check:0x05_00000000 ... ",0);
		if( CkExtendDdrRamCheck((void*)0x0000000500000000) ){	PutStr(" Fail!",1);		PutDdrErrInfo();
			PutStr("Next Area Test OK?(y/n)",0);
			if( WaitKeyIn_YorN() ){	// Return1=N
			    DelStr(26);		return;
			}
			DelStr(26);
		}else{
			PutStr(" Pass!",1);
		}
		PutStr("Check:0x05_40000000 ... ",0);
		if( CkExtendDdrRamCheck((void*)0x0000000540000000) ){	PutStr(" Fail!",1);		PutDdrErrInfo();
			PutStr("Next channel Test OK?(y/n)",0);
			if( WaitKeyIn_YorN() ){	// Return1=N
			    DelStr(26);		return;
			}
			DelStr(26);
		}else{
			PutStr(" Pass!",1);
		}
//CH2 Check
		PutStr("Check:0x06_00000000 ... ",0);
		if( CkExtendDdrRamCheck((void*)0x0000000600000000) ){	PutStr(" Fail!",1);		PutDdrErrInfo();
			PutStr("Next Area Test OK?(y/n)",0);
			if( WaitKeyIn_YorN() ){	// Return1=N
			    DelStr(26);		return;
			}
			DelStr(26);
		}else{
			PutStr(" Pass!",1);
		}
		PutStr("Check:0x06_40000000 ... ",0);
		if( CkExtendDdrRamCheck((void*)0x0000000640000000) ){	PutStr(" Fail!",1);		PutDdrErrInfo();
			PutStr("Next channel Test OK?(y/n)",0);
			if( WaitKeyIn_YorN() ){	// Return1=N
			    DelStr(26);		return;
			}
			DelStr(26);
		}else{
			PutStr(" Pass!",1);
		}
//CH3 Check
		PutStr("Check:0x07_00000000 ... ",0);
		if( CkExtendDdrRamCheck((void*)0x0000000700000000) ){	PutStr(" Fail!",1);		PutDdrErrInfo();
			PutStr("Next Area Test OK?(y/n)",0);
			if( WaitKeyIn_YorN() ){	// Return1=N
			    DelStr(26);		return;
			}
			DelStr(26);
		}
		PutStr(" Pass!",1);
		PutStr("Check:0x07_40000000 ... ",0);
		if( CkExtendDdrRamCheck((void*)0x0000000740000000) ){	PutStr(" Fail!",1);		PutDdrErrInfo();
			return;
		}
		PutStr(" Pass!",1);
		
		
//Add test :1RANK,2RANK support =============================
		PutStr("2GBx4 Check Start OK?(y/n)",0);
		if( WaitKeyIn_YorN() ){	// Return1=N
			PutStr("",1);		    return;
		}else{
			PutStr("",1);
			PutStr("== 2GBx4 Check ================",1);
			PutStr("Check:0x04_00000000--0x04_7FFFFFFF ... ",0);
			if( CkExtendDdrRamCheck_8GB((void*)0x0000000400000000) ){	PutStr(" Fail!",1);	PutDdrErrInfo();
				PutStr("Next channel Test OK?(y/n)",0);
				if( WaitKeyIn_YorN() ){	// Return1=N
			    	DelStr(26);		return;
				}
				DelStr(26);
			}else{
				PutStr(" Pass!",1);
			}
			PutStr("Check:0x05_00000000--0x05_7FFFFFFF ... ",0);
			if( CkExtendDdrRamCheck_8GB((void*)0x0000000500000000) ){	PutStr(" Fail!",1);	PutDdrErrInfo();
				PutStr("Next channel Test OK?(y/n)",0);
				if( WaitKeyIn_YorN() ){	// Return1=N
			    	DelStr(26);		return;
				}
				DelStr(26);
			}else{
				PutStr(" Pass!",1);
			}
			PutStr("Check:0x06_00000000--0x06_7FFFFFFF ... ",0);
			if( CkExtendDdrRamCheck_8GB((void*)0x0000000600000000) ){	PutStr(" Fail!",1);	PutDdrErrInfo();
				PutStr("Next channel Test OK?(y/n)",0);
				if( WaitKeyIn_YorN() ){	// Return1=N
			    	DelStr(26);		return;
				}
				DelStr(26);
			}else{
				PutStr(" Pass!",1);
			}
			PutStr("Check:0x07_00000000--0x07_7FFFFFFF ... ",0);
			if( CkExtendDdrRamCheck_8GB((void*)0x0000000700000000) ){	PutStr(" Fail!",1);	PutDdrErrInfo();
				PutStr("Next channel Test OK?(y/n)",0);
				if( WaitKeyIn_YorN() ){	// Return1=N
			    	DelStr(26);		return;
				}
				DelStr(26);
			}else{
				PutStr(" Pass!",1);
			}
		}
	}

//==================== R-Car M3 =============================
	else if(CHK_M3){
		PutStr("=== Memory map M3 (8GByte) ====",1);
//CH0 Check
		readData = *((volatile uint32_t*)0x0000000400000000);			//Access Check
		PutStr("Check:0x04_00000000 ... ",0);
		if( CkExtendDdrRamCheck((void*)0x0000000400000000) ){	PutStr(" Fail!",1);	PutDdrErrInfo();
			PutStr("Next Area Test OK?(y/n)",0);
			if( WaitKeyIn_YorN() ){	// Return1=N
			    DelStr(26);		return;
			}
			DelStr(26);
		}else{
			PutStr(" Pass!",1);
		}
		PutStr("Check:0x04_40000000 ... ",0);
		if( CkExtendDdrRamCheck((void*)0x0000000440000000) ){	PutStr(" Fail!",1);	PutDdrErrInfo();
			PutStr("Next channel Test OK?(y/n)",0);
			if( WaitKeyIn_YorN() ){	// Return1=N
		    	DelStr(26);		return;
			}
			DelStr(26);
		}else{
			PutStr(" Pass!",1);
		}

		PutStr("Check:0x04_80000000 ... ",0);
		if( CkExtendDdrRamCheck((void*)0x0000000480000000) ){	PutStr(" Fail!",1);	PutDdrErrInfo();
			PutStr("Next Area Test OK?(y/n)",0);
			if( WaitKeyIn_YorN() ){	// Return1=N
			    DelStr(26);		return;
			}
			DelStr(26);
		}else{
			PutStr(" Pass!",1);
		}
		
		PutStr("Check:0x04_C0000000 ... ",0);
		if( CkExtendDdrRamCheck((void*)0x00000004C0000000) ){	PutStr(" Fail!",1);	PutDdrErrInfo();
			PutStr("Next Area Test OK?(y/n)",0);
			if( WaitKeyIn_YorN() ){	// Return1=N
			    DelStr(26);		return;
			}
			DelStr(26);
		}else{
			PutStr(" Pass!",1);
		}
		
//CH2 Check
		PutStr("Check:0x06_00000000 ... ",0);
		if( CkExtendDdrRamCheck((void*)0x0000000600000000) ){	PutStr(" Fail!",1);		PutDdrErrInfo();
			PutStr("Next Area Test OK?(y/n)",0);
			if( WaitKeyIn_YorN() ){	// Return1=N
			    DelStr(26);		return;
			}
			DelStr(26);
		}else{
			PutStr(" Pass!",1);
		}
		PutStr("Check:0x06_40000000 ... ",0);
		if( CkExtendDdrRamCheck((void*)0x0000000640000000) ){	PutStr(" Fail!",1);		PutDdrErrInfo();
			PutStr("Next channel Test OK?(y/n)",0);
			if( WaitKeyIn_YorN() ){	// Return1=N
			    DelStr(26);		return;
			}
			DelStr(26);
		}else{
			PutStr(" Pass!",1);
		}
		
		PutStr("Check:0x06_80000000 ... ",0);
		if( CkExtendDdrRamCheck((void*)0x0000000680000000) ){	PutStr(" Fail!",1);		PutDdrErrInfo();
			PutStr("Next channel Test OK?(y/n)",0);
			if( WaitKeyIn_YorN() ){	// Return1=N
			    DelStr(26);		return;
			}
			DelStr(26);
		}else{
			PutStr(" Pass!",1);
		}
		
		PutStr("Check:0x06_C0000000 ... ",0);
		if( CkExtendDdrRamCheck((void*)0x00000006C0000000) ){	PutStr(" Fail!",1);		PutDdrErrInfo();
			PutStr("Next Test OK?(y/n)",0);
			if( WaitKeyIn_YorN() ){	// Return1=N
			    DelStr(18);		return;
			}
			DelStr(18);
		}else{
			PutStr(" Pass!",1);
		}
		
//Add test : =============================
		PutStr("4GBx2 Check Start OK?(y/n)",0);
		if( WaitKeyIn_YorN() ){	// Return1=N
			PutStr("",1);		    return;
		}else{
			PutStr("",1);
			PutStr("== 4GBx2 Check ================",1);
			PutStr("Check:0x04_00000000--0x04_FFFFFFFF ... ",0);
			if( CkExtendDdrRamCheck_M3_8GB((void*)0x0000000400000000) ){	PutStr(" Fail!",1);	PutDdrErrInfo();
				PutStr("Next channel Test OK?(y/n)",0);
				if( WaitKeyIn_YorN() ){	// Return1=N
			    	DelStr(26);		return;
				}
				DelStr(26);
			}else{
				PutStr(" Pass!",1);
			}
			PutStr("Check:0x06_00000000--0x06_FFFFFFFF ... ",0);
			if( CkExtendDdrRamCheck_M3_8GB((void*)0x0000000600000000) ){	PutStr(" Fail!",1);	PutDdrErrInfo();
				PutStr("Next channel Test OK?(y/n)",0);
				if( WaitKeyIn_YorN() ){	// Return1=N
			    	DelStr(26);		return;
				}
				DelStr(26);
			}else{
				PutStr(" Pass!",1);
			}
		}
	}
	
	else{
		PutStr("=== This command is for R-CarH3_M3(8GB). ====",1);
	}
#endif
}









uint32_t PutDdrErrInfo()
{
//#ifdef COM_DDRCK_ON
#if defined(COM_DDRCK_ON) || defined(COM_DDRCK2_ON) || defined(COM_DBG_ON)

	char str[64];

	PutStr(" error address  : H'",0);	Data2HexAscii_64(gErrDdrAdd,str,CPU_BYTE_SIZE);	PutStr(str,1);
	PutStr(" error data     : H'",0);	Data2HexAscii(gErrDdrData,str,4);	PutStr(str,1);
	PutStr(" true  data     : H'",0);	Data2HexAscii(gTrueDdrData,str,4);	PutStr(str,1);

#endif
}

//�e�X�g�͈� 4Mbyte�FH'xx000100-xx4000FF
uint32_t CkExtendDdrRamCheck( void* ramAddr )
{
//#ifdef COM_DDRCK_ON
#if defined(COM_DDRCK_ON) || defined(COM_DDRCK2_ON) || defined(COM_DBG_ON)

	volatile uint32_t *read_adr;
	uint32_t data;
	uint32_t loop, i;
	char str[64];

	read_adr = (uint32_t *)ramAddr;

	PutStr("Data=0x5A5A5A5A",0);

	/* Write */
	data = 0x5A5A5A5A;
	for (loop = 0; loop < 0x100000; loop++) {
		read_adr[loop] = data;
	}

	/* Verify */
	data = 0x5A5A5A5A;
	for (loop = 0; loop < 0x100000; loop++) {
		if (read_adr[loop] != data) {
			gErrDdrAdd   = (uintptr_t)&read_adr[loop];
			gErrDdrData  = read_adr[loop];
			gTrueDdrData = data;
			return(ERROR_END);
		}
	}

	DelStr(15);
	PutStr("Data=0xA5A5A5A5",0);

	/* Write */
	data = 0xA5A5A5A5;
	for (loop = 0; loop < 0x100000; loop++) {
		read_adr[loop] = data;
	}

	/* Verify */
	data = 0xA5A5A5A5;
	for (loop = 0; loop < 0x100000; loop++) {
		if (read_adr[loop] != data) {
			gErrDdrAdd   = (uintptr_t)&read_adr[loop];
			gErrDdrData  = read_adr[loop];
			gTrueDdrData = data;
			return(ERROR_END);
		}
	}

	DelStr(15);
	PutStr("Data=0x12345678",0);
 
	/* Write */
	data = 0x12345678;
	for (loop = 0; loop < 0x100000; loop++) {
		read_adr[loop] = data;
		data += 0x11111111;
	}

	/* Verify */
	data = 0x12345678;
	for (loop = 0; loop < 0x100000; loop++) {
		if (read_adr[loop] != data) {
			gErrDdrAdd   = (uintptr_t)&read_adr[loop];
			gErrDdrData  = read_adr[loop];
			gTrueDdrData = data;
			return(ERROR_END);
		}
		data += 0x11111111;
	}

	DelStr(15);

	return(NORMAL_END);

#endif
}


//�e�X�g�͈� 2GByte�FH'00000000-H'7FFFFFFF
uint32_t CkExtendDdrRamCheck_8GB( void* ramAddr )
{
#ifdef COM_DDRCK2_ON	
//#if defined(COM_DDRCK_ON) || defined(COM_DDRCK2_ON) || defined(COM_DBG_ON)

	volatile uint32_t *read_adr;
	uint32_t data;
	uint32_t loop, i;
	char str[64];

	read_adr = (uint32_t *)ramAddr;

	/* Write */
	data = 0x12345678;
	for (loop = 0; loop < 0x20000000; loop++) {
		read_adr[loop] = data;
		data += 0x11111111;
	}
	/* Verify */
	data = 0x12345678;
	for (loop = 0; loop < 0x20000000; loop++) {
		if (read_adr[loop] != data) {
			gErrDdrAdd   = (uintptr_t)&read_adr[loop];
			gErrDdrData  = read_adr[loop];
			gTrueDdrData = data;
			return(ERROR_END);
		}
		data += 0x11111111;
	}
	return(NORMAL_END);

#endif
}


//�e�X�g�͈� M3 4GByte�FH'00000000-H'FFFFFFFF
uint32_t CkExtendDdrRamCheck_M3_8GB( void* ramAddr )
{
#ifdef COM_DDRCK2_ON	
//#if defined(COM_DDRCK_ON) || defined(COM_DDRCK2_ON) || defined(COM_DBG_ON)
	
	volatile uint32_t *read_adr;
	uint32_t data;
	uint32_t loop, i;
	char str[64];

	read_adr = (uint32_t *)ramAddr;

	/* Write */
	data = 0x12345678;
	for (loop = 0; loop < 0x40000000; loop++) {
		read_adr[loop] = data;
		data += 0x11111111;
	}
	/* Verify */
	data = 0x12345678;
	for (loop = 0; loop < 0x40000000; loop++) {
		if (read_adr[loop] != data) {
			gErrDdrAdd   = (uintptr_t)&read_adr[loop];
			gErrDdrData  = read_adr[loop];
			gTrueDdrData = data;
			return(ERROR_END);
		}
		data += 0x11111111;
	}
	return(NORMAL_END);

#endif
}












uint32_t RamCheckTest1(uintptr_t Load_workStartAdd)
{
	if(CkExtendDdrRamCheck1Ptn((void*)Load_workStartAdd)){
		PutStr("RAM Check : NG",1);	PutDdrErrInfo();
		return(ERROR_END);
	}
	else{
		return(NORMAL_END);
	}
}

//�Ȉ�RAM�`�F�b�N:DDRCk�x�[�X�Ńe�X�g��1�p�^�[���݂̂Ɋȑf��
//�e�X�g�͈� 4Mbyte�FH'xx000100-xx4000FF
uint32_t CkExtendDdrRamCheck1Ptn( void* ramAddr )
{

	volatile uint32_t *read_adr;
	uint32_t data;
	uint32_t loop, i;
	char str[64];

	read_adr = (uint32_t *)ramAddr;

	/* Write */
	data = 0x12345678;
	for (loop = 0; loop < 0x100000; loop++) {
		read_adr[loop] = data;
		data += 0x11111111;
	}
	/* Verify */
	data = 0x12345678;
	for (loop = 0; loop < 0x100000; loop++) {
		if (read_adr[loop] != data) {
			gErrDdrAdd   = (uintptr_t)&read_adr[loop];
			gErrDdrData  = read_adr[loop];
			gTrueDdrData = data;
			return(ERROR_END);
		}
		data += 0x11111111;
	}
	return(NORMAL_END);
}




//======================== DEBUG Command ===========================
void SetBoardID(void)
{
#ifdef COM_DBG_ON

	char str[64];
	uint32_t loop;
	char chCnt;
	char strAscii[32];
	uint8_t bid;
	
	gIic0SlvAdd = EEPROM_I2C_SLA;		//Salvator/Kriek/StarterKit
	gI2c0SlvAdd = EEPROM_I2C_SLA;		//Draak

	
	CheckBoardId();						//Read EEprom Set gBoardId
	PutStr("Now Board ID : ",0);
	PutBoardIdName(0);

	PutStr(" (H'",0);
	Data2HexAscii(gBoardId,strAscii,1);		PutStr(strAscii,0);
	PutStr(")",1);

	PutStr("Change Board ID OK? (y/n)",0);
	if( WaitKeyIn_YorN() ){	// Return1=N
		PutStr("",1);
		return;
	}
	PutStr("",1);
	PutStr("==============================",1);
	PutStr(" 0 : INPUT BOARD ID           ",1);
	PutStr(" 1 : Salvator-X         (H'00)",1);
	PutStr(" 2 : Kriek(LP4)         (H'08)",1);
	PutStr(" 3 : Starter Kit Pro    (H'10)",1);
	PutStr(" 4 : Salvator-XS        (H'20)",1);
	PutStr(" 5 : Draak              (H'38)",1);
	PutStr(" 6 : Starter Kit Premier(H'58)",1);
	PutStr(" 7 : Condor             (H'30)",1);
	PutStr(" 8 : Ebisu-2D           (H'40)",1);
	PutStr(" 9 : Ebisu-4D           (H'68)",1);
	PutStr(" A : Kriek(DDR3)        (H'48)",1);
	PutStr(" B : Eagle-R            (H'70)",1);
	PutStr(" Z : Exit                     ",1);
	PutStr("==============================",1);
	loop=1;
	while(loop){
		PutStr(" Please select (0~B or Z) >",0);
		GetStr(str,&chCnt);
		switch(str[0]){
			case '0':	SetBoardIdData(&bid);	loop=0;		break;
			case '1':	bid=BID_SALVATOR_X;		loop=0;		break;
			case '2':	bid=BID_KRIEK_LP4;		loop=0;		break;
			case '3':	bid=BID_STARTERKIT_PRO;	loop=0;		break;
			case '4':	bid=BID_SALVATOR_XS;	loop=0;		break;
			case '5':	bid=BID_DRAAK;			loop=0;		break;
			case '6':	bid=BID_STARTERKIT_PRE;	loop=0;		break;
			case '7':	bid=BID_CONDOR;			loop=0;		break;
			case '8':	bid=BID_EBISU_2D;		loop=0;		break;
			case '9':	bid=BID_EBISU_4D;		loop=0;		break;
			case 'a':
			case 'A':	bid=BID_KRIEK_DDR3;		loop=0;		break;
			case 'b':
			case 'B':	bid=BID_EAGLE_R;		loop=0;		break;
			case 'z':
			case 'Z':
				return;
		  }
	}
//	BoardIdWriteIicEeprom(bid);
	WriteBoardId(bid);
	
	CheckBoardId();			//Read EEprom Set gBoardId
	PutStr("Now Board ID : ",0);
	PutBoardIdName(0);
	PutStr(" (H'",0);
	Data2HexAscii(gBoardId,strAscii,1);		PutStr(strAscii,0);
	PutStr(")",1);

#endif
}

void SetBoardIdData(uint8_t *bid)
{
#ifdef COM_DBG_ON

	char		buf[16],key[16],chCnt,chPtr;
	uint32_t	loop;
	uint32_t 	wrData;
	char str[64];

	loop =1;

	PutStr("  Please Input Data ",1);
	while(loop){
		PutStr("  Set Boad ID : H'",0);
		GetStr(key,&chCnt);
		chPtr=0;
		if(!GetStrBlk(key,buf,&chPtr,0)){
			if(chPtr==1){									/* Case Return */

			}else if(chPtr > (char)((SIZE_8BIT<<1)+1) ){	/* Case Data Size Over */
				PutStr("  Syntax Error",1);
			}else{
				if(HexAscii2Data((unsigned char*)buf,&wrData)){
					PutStr("  Syntax Error",1);
				}else{
					*bid = wrData;
					loop =0;
				}
			}
		}else{
			PutStr("  Syntax Error",1);
		}
	}

#endif
}

//DEBUG===
#ifdef COM_DBG_ON				//ifdef COM_DBG_ON ��������

void debug_PrrCode(void)
{
	PutSocProduct();
	PutgPrrData();
}

#endif


