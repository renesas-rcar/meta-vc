#define ADDITION					0x00000000
#define SUBTRACTION					0x00000001


// LF Work Memory
#define DramArea3_SADD				0x50000000
#define DramArea3_EADD				0x53FFFFFF
#define FlashArea1_SADD				0x04000000	//FLASH MEMORY �v���O������A�h���X

#define LS_WORK_DRAM_SADD			0x50000000

void	dgLoad(void);
int32_t	GetStr_ByteCount(char *str,uint32_t getByteCount);
void	dgLoadFlash(void);
char	dgLS_Load_Offset2(uint32_t *maxADD ,uint32_t *minADD);
