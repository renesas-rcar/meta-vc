#include "common.h"
#include "bit.h"
#include "spiflash2drv.h"
#include "rpcqspidrv.h"
#include "dgtable.h"

#ifdef COM_SPI_ON		//ifdef COM_SPI_ON �i�{�h���C�o�t�@�C���S�āj

extern uint32_t gSelectQspiFlash;

//////////////////////////////////////////////////////////////////////////////////////
//
// QSPI SPI-FLASH  S25FS512S
//
//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////
// Qspi:Fast Read 
//////////////////////////////////
//void FastRdQspiFlashS25s128s(uint32_t sourceSpiAdd,uint32_t destinationAdd,uint32_t byteCount)
void FastRdQspiFlashS25s512s(uint32_t sourceSpiAdd,uint32_t destinationAdd,uint32_t byteCount)
{
	uint32_t sourceAdd;

	InitRPC_QspiFlash4FastReadExtMode();

	sourceAdd = SPI_IOADDRESS_TOP + sourceSpiAdd;

//	copy : spi_ioaddress (H'08000000�`)-> destinationAdd (H'60000000�`�j
	mem_copy(destinationAdd, sourceAdd, byteCount);
}

//////////////////////////////////
// Qspi:Fast Read  (FAST_READ 0Bh)
//////////////////////////////////
//void FastRd3adQspiFlashS25s128s (uint32_t sourceSpiAdd,uint32_t destinationAdd,uint32_t byteCount)



//////////////////////////////////
// Qspi:Fast Read  (4FAST_READ 0Ch)  �}�j���A�����[�h   (S25FL512S�Ɠ���)
//////////////////////////////////
//void FastRdManuQspiFlashS25s128s(uint32_t sourceSpiAdd,uintptr_t destinationAdd,uint32_t byteCount)

//////////////////////////////////
// Qspi:Quad Read  (4QIOR ECh)    �}�j���A�����[�h  (S25FL512S�Ɠ����R�}���h�Ȃ��B�قȂ�)
//////////////////////////////////

//////////////////////////////////
// Qspi:Quad I/O Read   (Quad I/O Read EBh)
//////////////////////////////////
//void QuadIORdQspiFlashS25s128s(uint32_t sourceSpiAdd,uint32_t destinationAdd,uint32_t byteCount)

//add 2018.10.18
//////////////////////////////////
// Qspi:Quad I/O Read   (4Quad I/O Read ECh)
//////////////////////////////////
void QuadIORdQspiFlashS25s512s(uint32_t sourceSpiAdd,uint32_t destinationAdd,uint32_t byteCount)
{
	uint32_t sourceAdd;

//	EnableQuadModeQspiFlashS25fs128s();		//WriteAnyRegister
	EnableQuadModeQspiFlashS25fs512s();		//WriteAnyRegister

//	InitRPC_ExtMode_QuadIORead();
	InitRPC_ExtMode_4QuadIORead();

	sourceAdd = SPI_IOADDRESS_TOP + sourceSpiAdd;
//	copy : spi_ioaddress (H'08000000�`)-> destinationAdd (H'60000000�`�j
	mem_copy(destinationAdd, sourceAdd, byteCount);
}


//////////////////////////////////
// Qspi:Write Enable
//////////////////////////////////
// rpcdrv.c �̊֐��őΉ�
//	WriteCommandQspiFlash(0x00060000);	//WRITE ENABLE


//////////////////////////////////
// Qspi:Read Status
//////////////////////////////////
// rpcdrv.c �̊֐��őΉ�
//	ReadStatusQspiFlash(rdStatus);


//////////////////////////////////////////
// Qspi:Enable QUAD mode (CR1V bit1)
//////////////////////////////////////////
void EnableQuadModeQspiFlashS25fs512s(void)
{
	uint8_t readDataB[2];
	uint8_t configReg=0;
	uint32_t statusReg=0;

	char str[64];		//DEBUG
	
//	configReg = ReadAnyRegisterQspiFlash(0x00800002, readDataB); //CR1V
	ReadAnyRegisterQspiFlash(0x00800002, &configReg); //CR1V

//	Data2HexAscii(configReg,str,4);									//********************* DEBUG
//	PutStr("configReg(CR1V) :H' ",0);			PutStr(str,1);		//********************* DEBUG

	if(!(configReg & BIT1))
	{
		PutStr("QUAD mode set!",1);

		WriteCommandQspiFlash(0x00060000);			//WRITE ENABLE
		WriteAnyRegisterQspiFlash(0x00800002, (configReg | BIT1));	 //CR1V[1]=1 :0=Dual or Serial, 1=Quad
	
		while(1)
		{
			ReadStatusQspiFlash(&statusReg);
			if( !(statusReg & BIT0) )	break;
		}
	}
}


//////////////////////////////////////
// Qspi:Read Configuration register
//////////////////////////////////////
// rpcdrv.c �̊֐��őΉ�
// void ReadConfigRegQspiFlash(uint32_t *cnfigReg)

//////////////////////////////////////
// Qspi:Write register
//////////////////////////////////////
// rpcdrv.c �̊֐��őΉ�
// void WriteRegisterQspiFlash(uint32_t statusReg, uint32_t configReg)

	
#if 0		//S25s128s�ł́AWriteRegisterQspiFlash_Byte2()�͎g�p���Ȃ��BS25fl512s����OK�B���Ȃ��B
			//S25s128s�� 0x01 : Write (Status & Configuration) Register�R�}���h��CR1NV�ւ̏������ׁ݂̈B
#endif

//////////////////////////////////////////
// Qspi:Set SectorErase256kb mode (CR3V[1]=1   0:64kb 1:256kb)
//////////////////////////////////////////
//void SetSectorErase256kbQspiFlashS25s128s(void)



//////////////////////////////////////////
// Qspi:Sector Erase (256kB)	
//////////////////////////////////////////
//4SE DCh
//void SectorErase256kbQspiFlashS25s128s(uint32_t addr)
void SectorErase256kbQspiFlashS25s512s(uint32_t addr)
{
	uint32_t status;
	char str[64];		//DEBUG

	WriteCommandQspiFlash(0x00060000);	//WRITE ENABLE
	SectorErase4QspiFlash(addr);

	while(1){
		ReadStatusQspiFlash(&status);
//Data2HexAscii(status,str,4);				//********************* DEBUG
//PutStr("Read[RDSR1 05h]  :H' ",0);		//********************* DEBUG
//PutStr(str,1);							//********************* DEBUG
		if( (status & BIT5) ){				//Add 2015.07.23  //DEBUG===
			PutStr("Erase Error",0);		//DEBUG===
			break;							//DEBUG===
		}									//DEBUG===
		if( !(status & BIT0) )	break;
	}
}

//Add 2015.07.18
//SE D8h    
//void SectorErase256kbQspiFlashS25s128s_D8(uint32_t addr)



//////////////////////////////////////////
// Qspi:Parameter 4-kB Sector Erase  SA0�擪�i�㔼�j32KByte�p
//////////////////////////////////////////
//4P4E 21h
//void ParameterSectorErase4kbQspiFlashS25s128s(uint32_t addr)
void ParameterSectorErase4kbQspiFlashS25s512s(uint32_t addr)
{
	uint32_t status;
	char str[64];		//DEBUG

	WriteCommandQspiFlash(0x00060000);	//WRITE ENABLE
	ParameterSectorErase4QspiFlash(addr);

	while(1){
		ReadStatusQspiFlash(&status);
//Data2HexAscii(status,str,4);				//********************* DEBUG
//PutStr("Read[RDSR1 05h]  :H' ",0);		//********************* DEBUG
//PutStr(str,1);							//********************* DEBUG
		if( (status & BIT5) ){				//Add 2015.07.23
			PutStr("Erase Error",0);
			break;
		}
		if( !(status & BIT0) )	break;
	}
}





//////////////////////////////////////////
// Qspi:Bulk Erase (All)
//////////////////////////////////////////
//int32_t BulkEraseQspiFlashS25s128s(void)
int32_t BulkEraseQspiFlashS25s512s(void)
{
	uint32_t status;
	int32_t errFlag;

	errFlag = NORMAL_END;

	WriteCommandQspiFlash(0x00060000);	//WRITE ENABLE
	WriteCommandQspiFlash(0x00600000);	//Bulk Erase (BE 60h)

	while(1){
		ReadStatusQspiFlash(&status);
		if( (status & BIT5) ){				//Add 2015.07.23  //DEBUG===
//			PutStr("Erase Error",0);		//DEBUG===
			errFlag=ERROR_END;
			break;							//DEBUG===
		}									//DEBUG===
		if( !(status & BIT0) )	break;		//BIT0  1:Device Busy  0:Ready Device is in Standby
	}
	return(errFlag);
}




//////////////////////////////////////////
// Qspi:Page Program (4PP:12h)  (S25FL512S�Ɠ���)
//////////////////////////////////////////
// wrCount:Max256
//void PageProgramQspiFlashS25s128s(uint32_t addr,uint32_t writeData)
//CS�A�T�[�g�ێ� (256Byte�A���A�N�Z�X �f�t�H���g)
//void PageProgramQspiFlashS25s128s_CsCont(uint32_t addr, uint32_t *writeData,uint32_t byteCount)




//���C�g�o�b�t�@���g�p�����t���b�V���ւ̏����� (256�o�C�g�P��)
//add          = SpiFlash Address
//source_addr  = �������ރf�[�^����������Ă���擪�A�h���X�i��������256�o�C�g���̃f�[�^�������݁j
//4PP
//void PageProgramWithBuffeQspiFlashS25s128s(uint32_t addr, uint32_t source_addr)
void PageProgramWithBuffeQspiFlashS25s512s(uint32_t addr, uint32_t source_addr)
{
	uint32_t status;

	WriteCommandQspiFlash(0x00060000);	//WRITE ENABLE
	WriteData4ppWithBufferQspiFlash(addr,source_addr);			//4PP
//	WriteDataPpWithBufferQspiFlash(addr,source_addr);			//PP

//Add
	while(1){
		ReadStatusQspiFlash(&status);
		if( !(status & BIT0) )	break;
	}

}








//////////////////////////////////////////
// Qspi:Quad Page Program 
//////////////////////////////////////////
//S25s128s QuadProgram�Ȃ�






//��spiflash1drv_1.c
//////////////////////////////////////////
// Qspi:Page Program (4PP:12h) S25fl512s�Ɠ���
//////////////////////////////////////////
//void SaveDataQspiFlashS25s128s(uintptr_t srcAdd,uint32_t svFlashAdd,uint32_t svSize)

//void SaveDataQspiFlashS25s128s_CsCont_Byte(uintptr_t srcAdd,uint32_t svFlashAdd,uint32_t svSize)

//void SaveDataQspiFlashS25s128s_CsCont(uintptr_t srcAdd,uint32_t svFlashAdd,uint32_t svSize)



void SaveDataWithBuffeQspiFlashS25s512s(uint32_t srcAdd,uint32_t svFlashAdd,uint32_t svSize)
{
	uint32_t flashAdd;
	uint32_t writeDataAdd;

	WriteCommandQspiFlash(0x00060000);	//WRITE ENABLE

	writeDataAdd = srcAdd;
	for(flashAdd=svFlashAdd;flashAdd<(svFlashAdd+svSize);flashAdd+=256){	//256byte:RPC Write Buffer size
		PageProgramWithBuffeQspiFlashS25s512s(flashAdd, writeDataAdd);
		writeDataAdd = writeDataAdd + 256;
	}
}

//////////////////////////////////////////
// Qspi:Quad Page Program 
//////////////////////////////////////////
//QSPI Program�Ȃ�




void SectorEraseQspiFlashS25s512s(uint32_t EraseStatAdd,uint32_t EraseEndAdd)
{
//�Z�N�^�����ł͂Ȃ��A�A�h���X�����ō쐬
//�Z�N�^�P�ʂ� H'40000 (256Kbyte)��

	uint32_t	sectorAd;
	uint32_t	SectorStatTopAdd,SectorEndTopAdd;

	SectorStatTopAdd = EraseStatAdd & 0xFFFC0000;		//0x40000�P�ʂɃ}�X�N
	SectorEndTopAdd  = EraseEndAdd  & 0xFFFC0000;		//0x40000�P�ʂɃ}�X�N

//S25s512s�͕s�v 256KB�̂�
//	if(gSelectQspiFlash ==ONBOARD_QSPI){
//		SetSectorErase256kbQspiFlashS25s128s();
//	}

	for(sectorAd =SectorStatTopAdd;sectorAd<=SectorEndTopAdd;sectorAd=sectorAd+0x40000 ){
		SectorErase256kbQspiFlashS25s512s(sectorAd);
		PutStr(".",0);
	}
	PutStr("Erase Completed ",1);
}


void ParameterSectorEraseQspiFlashS25s512s(uint32_t EraseStatAdd,uint32_t EraseEndAdd)
{
//�Z�N�^�����ł͂Ȃ��A�A�h���X�����ō쐬
//�Z�N�^�P�ʂ� H'1000 (4Kbyte)��

	uint32_t	sectorAd;
	uint32_t	SectorStatTopAdd,SectorEndTopAdd;

	char str[64];		//DEBUG

	SectorStatTopAdd = EraseStatAdd & 0xFFFFF000;		//0x1000�P�ʂɃ}�X�N
	SectorEndTopAdd  = EraseEndAdd  & 0xFFFFF000;		//0x1000�P�ʂɃ}�X�N


	for(sectorAd =SectorStatTopAdd;sectorAd<=SectorEndTopAdd;sectorAd=sectorAd+0x1000 ){
		ParameterSectorErase4kbQspiFlashS25s512s(sectorAd);
		PutStr(".",0);
	}
	PutStr("Erase Completed ",1);
}

void SectorRdQspiFlashS25s512s(uint32_t spiStatAdd,uint32_t distRamAdd)
{
//1�Z�N�^���[�h�֐�
//�Z�N�^�����ł͂Ȃ��A�A�h���X�����ō쐬

	uint32_t	SectorStatTopAdd,readSize;
	unsigned char	*bufPtr;

	SectorStatTopAdd = spiStatAdd & 0xFFFC0000;		//0x40000�P�ʂɃ}�X�N
	readSize  = 0x40000;							//S25FL512:1�Z�N�^�T�C�Y 0x40000

	FastRdQspiFlashS25s512s(SectorStatTopAdd,distRamAdd,readSize);
}

#endif
