// PMIC Product Code
#define PMIC_BD9571		0x60
#define PMIC_BD9576		0x76
#define PMIC_BD9574		0x74

// PMIC Revision
#define PMIC_REV00		0x00
#define PMIC_REV01		0x01
#define PMIC_REV02		0x02
#define PMIC_REV03		0x03
#define PMIC_REV04		0x04

#define NORMAL_VOLTAGE	0
#define LOW_VOLTAGE		1

uint32_t SetPmicEepromData(void);
uint32_t GetPmicEepromFwRev(void);
uint32_t PutGetPmicEepromData(void);
uint32_t SetPmicEepromDataBD9571(void);
uint32_t SetPmicEepromDataBD9576(void);
uint32_t SetPmicEepromDataBD9574(void);
uint32_t SetPmicEepromDataFF(void);
void MessEepromInitError(uint32_t i,uint32_t rdData,uint32_t setData);
uint32_t SetPmicEepromFwRev(void);
uint32_t GetPmicRev(void);
void InitPmicI2c(void);
uint32_t RandomAddressReadPmic(uint32_t slAdd, uint32_t accessAdd, uint32_t *rdBuf, uint32_t rdCount);
uint32_t PageWritePmic(uint32_t slAdd,uint32_t accessAdd,uint32_t *wrBuf,uint32_t wrCount);
