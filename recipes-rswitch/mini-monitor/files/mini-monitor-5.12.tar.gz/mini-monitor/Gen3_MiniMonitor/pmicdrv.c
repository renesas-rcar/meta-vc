#include "common.h"
#include "i2cdrv.h"
#include "pmicdrv.h"
#include "reg_rcargen3.h"
#include "cpudrv.h"
#include "boardid.h"
#include "init_board.h"


#ifdef COM_IIC_ON		//ifdef COM_IIC_ON �i�{�h���C�o�t�@�C���S�āj

extern uint32_t gPmicRev;
extern uint32_t gPmicVdd;
extern uint32_t gPmicProduct;

//==========================================
// SET_PMIC : EEPROM Board Version
//--- PMIC_OLD -----------------------------
// Salvator(10S)      : V0F
// Salvator(11S)      : V0E
// Salvator(12S)      : V10
// Kriek              : V0F
// StarterKit         : V0E
//--- PMIC_NEW -----------------------------
// Condor             : V81
// Ebisu              : VA1
// Other(Sal,Krek,SK) : V11
//==========================================


//==========================================
//== Spesial Version LOW_VOLTAGE ===========
//==========================================
// SET_PMIC_M3N : EEPROM Board Version 
//--- PMIC_OLD -----------------------------
// Salvator(00S)      : V13
// Salvator(11S),SK   : V12
// Salvator(12S)      : V14
//--- PMIC_NEW -----------------------------
// Sal,Krek,SK        : V15
//==========================================


//SK(�ߓd���ی��H�ǉ�Ver):NEW PMIC
//EEPROM V17
const uint8_t TblPmicSettingV17[0x36] = {
		0x8E,	//	00h	Connection Check Code
		0x17,	//	01h	EEPROM FW Revision
		0x52,	//	02h	POW Trigger DVFS
		0x5D,	//	03h	POW Trigger VD09
		0xE6,	//	04h	POW Trigger DDR0
		0xE6,	//	05h	POW Trigger DDR1
		0xB1,	//	06h	POW Trigger VD18
		0x35,	//	07h	POW Trigger VD33
		0xE4,	//	08h	POW Trigger SD0
		0xE4,	//	09h	POW Trigger SD1
		0xE4,	//	0Ah	POW Trigger SD2
		0xE4,	//	0Bh	POW Trigger SD3
		0x35,	//	0Ch	POW Trigger VD25
		0x20,	//	0Dh	POW Trigger DDR0C
		0x20,	//	0Eh	POW Trigger DDR1C
		0x0A,	//	0Fh	POW Trigger PRESETB
		0xF4,	//	10h	POW Wait DVFS
		0xF4,	//	11h	POW Wait VD09
		0x44,	//	12h	POW Wait DDR0
		0x44,	//	13h	POW Wait DDR1
		0xF4,	//	14h	POW Wait VD18
		0xF4,	//	15h	POW Wait VD33
		0x44,	//	16h	POW Wait SD0
		0x44,	//	17h	POW Wait SD1
		0x44,	//	18h	POW Wait SD2
		0x44,	//	19h	POW Wait SD3
		0xF4,	//	1Ah	POW Wait VD25
		0xF4,	//	1Bh	POW Wait DDR0C
		0xF4,	//	1Ch	POW Wait DDR1C
		0x4F,	//	1Dh	PON Wait PRESETB
		0x01,	//	1Eh	AVS Start Tim Cnt
		0x52,	//	1Fh	AVS VD09 VID 0
		0x52,	//	20h	AVS VD09 VID 1
		0x52,	//	21h	AVS VD09 VID 2
		0x52,	//	22h	AVS VD09 VID 3
		0x53,	//	23h	AVS DVFS VID 0
		0x51,	//	24h	AVS DVFS VID 1
		0x4F,	//	25h	AVS DVFS VID 2
		0x4D,	//	26h	AVS DVFS VID 3
		0x01,	//	27h	AVS EN
		0x52,	//	28h	VD09 Vinit
		0x53,	//	29h	DVFS Vinit
		0x60,	//	2Ah	DVFS SetVmax
		0x00,	//	2Bh	reserved
		0x00,	//	2Ch	POW SoftStart 1
		0x00,	//	2Dh	POW SoftStart 2
		0x00,	//	2Eh	POW SoftStart 3
		0x00,	//	2Fh	POW SoftStart 4
		0x00,	//	30h	POW SoftStart 5
		0x00,	//	31h	POW SoftStart 6
		0x11,	//	32h	DCDC Freq
		0x00,	//	33h	SSCG Cnt
		0x01,	//	34h	POFFB / MRB
		0x2D,	//	35h	CRC Check Code
};

//Ebisu PMIC�p
//EEPROM VA1
const uint8_t TblPmicSettingVA1[0x36] = {
		0x8E,	//	00h	Connection Check Code
		0xA1,	//	01h	EEPROM FW Revision
		0x73,	//	02h	POW Trigger DVFS
		0xFF,	//	03h	POW Trigger VD09
		0x1B,	//	04h	POW Trigger DDR0
		0xFF,	//	05h	POW Trigger DDR1
		0x60,	//	06h	POW Trigger VD18
		0xB5,	//	07h	POW Trigger VD33
		0xE1,	//	08h	POW Trigger SD0
		0xE1,	//	09h	POW Trigger SD1
		0xE1,	//	0Ah	POW Trigger SD2
		0xFF,	//	0Bh	POW Trigger SD3
		0x36,	//	0Ch	POW Trigger VD25
		0xFF,	//	0Dh	POW Trigger DDR0C
		0xFF,	//	0Eh	POW Trigger DDR1C
		0x07,	//	0Fh	POW Trigger PRESETB
		0xF4,	//	10h	POW Wait DVFS
		0xF4,	//	11h	POW Wait VD09
		0xF4,	//	12h	POW Wait DDR0
		0xF4,	//	13h	POW Wait DDR1
		0xF4,	//	14h	POW Wait VD18
		0xF4,	//	15h	POW Wait VD33
		0x44,	//	16h	POW Wait SD0
		0x44,	//	17h	POW Wait SD1
		0x44,	//	18h	POW Wait SD2
		0x44,	//	19h	POW Wait SD3
		0xF4,	//	1Ah	POW Wait VD25
		0xF4,	//	1Bh	POW Wait DDR0C
		0xF4,	//	1Ch	POW Wait DDR1C
		0x4F,	//	1Dh	PON Wait PRESETB
		0x01,	//	1Eh	AVS Start Tim Cnt
		0x52,	//	1Fh	AVS VD09 VID 0
		0x52,	//	20h	AVS VD09 VID 1
		0x52,	//	21h	AVS VD09 VID 2
		0x52,	//	22h	AVS VD09 VID 3
		0x5D,	//	23h	AVS DVFS VID 0
		0x5D,	//	24h	AVS DVFS VID 1
		0x5D,	//	25h	AVS DVFS VID 2
		0x5D,	//	26h	AVS DVFS VID 3
		0x00,	//	27h	AVS EN
		0x52,	//	28h	VD09 Vinit
		0x5D,	//	29h	DVFS Vinit
		0x60,	//	2Ah	DVFS SetVmax
		0x00,	//	2Bh	reserved
		0x00,	//	2Ch	POW SoftStart 1
		0x00,	//	2Dh	POW SoftStart 2
		0x00,	//	2Eh	POW SoftStart 3
		0x00,	//	2Fh	POW SoftStart 4
		0x00,	//	30h	POW SoftStart 5
		0x00,	//	31h	POW SoftStart 6
		0x11,	//	32h	DCDC Freq
		0x00,	//	33h	SSCG Cnt
		0x01,	//	34h	POFFB / MRB
		0x69,	//	35h	CRC Check Code
};


//Condor:NEW PMIC�p�̃o�[�W����
//EEPROM V81
const uint8_t TblPmicSettingV81[0x36] = {
		0x8E,	//	00h	Connection Check Code
		0x81,	//	01h	EEPROM FW Revision
		0x35,	//	02h	POW Trigger DVFS
		0xFF,	//	03h	POW Trigger VD09
		0xE1,	//	04h	POW Trigger DDR0
		0xFF,	//	05h	POW Trigger DDR1
		0x1B,	//	06h	POW Trigger VD18
		0x5C,	//	07h	POW Trigger VD33
		0xFF,	//	08h	POW Trigger SD0
		0xFF,	//	09h	POW Trigger SD1
		0xFF,	//	0Ah	POW Trigger SD2
		0xFF,	//	0Bh	POW Trigger SD3
		0x5C,	//	0Ch	POW Trigger VD25
		0x60,	//	0Dh	POW Trigger DDR0C
		0xFF,	//	0Eh	POW Trigger DDR1C
		0x03,	//	0Fh	POW Trigger PRESETB
		0xF6,	//	10h	POW Wait DVFS
		0xF4,	//	11h	POW Wait VD09
		0x44,	//	12h	POW Wait DDR0
		0x44,	//	13h	POW Wait DDR1
		0xF4,	//	14h	POW Wait VD18
		0xF4,	//	15h	POW Wait VD33
		0x44,	//	16h	POW Wait SD0
		0x44,	//	17h	POW Wait SD1
		0x44,	//	18h	POW Wait SD2
		0x44,	//	19h	POW Wait SD3
		0xF4,	//	1Ah	POW Wait VD25
		0xF4,	//	1Bh	POW Wait DDR0C
		0xF4,	//	1Ch	POW Wait DDR1C
		0x4F,	//	1Dh	PON Wait PRESETB
		0x01,	//	1Eh	AVS Start Tim Cnt
		0x52,	//	1Fh	AVS VD09 VID 0
		0x52,	//	20h	AVS VD09 VID 1
		0x52,	//	21h	AVS VD09 VID 2
		0x52,	//	22h	AVS VD09 VID 3
		0x53,	//	23h	AVS DVFS VID 0
		0x51,	//	24h	AVS DVFS VID 1
		0x4F,	//	25h	AVS DVFS VID 2
		0x4D,	//	26h	AVS DVFS VID 3
		0x01,	//	27h	AVS EN
		0x52,	//	28h	VD09 Vinit
		0x53,	//	29h	DVFS Vinit
		0x60,	//	2Ah	DVFS SetVmax
		0x00,	//	2Bh	reserved
		0x00,	//	2Ch	POW SoftStart 1
		0x00,	//	2Dh	POW SoftStart 2
		0x00,	//	2Eh	POW SoftStart 3
		0x00,	//	2Fh	POW SoftStart 4
		0x00,	//	30h	POW SoftStart 5
		0x00,	//	31h	POW SoftStart 6
		0x11,	//	32h	DCDC Freq
		0x00,	//	33h	SSCG Cnt
		0x01,	//	34h	POFFB / MRB
		0x7C,	//	35h	CRC Check Code
};

//Salvator-XS(12)/Kriek3:NEW PMIC�p�̃o�[�W����
//EEPROM V11
const uint8_t TblPmicSettingV11[0x36] = {
		0x8E,	//	00h	Connection Check Code
		0x11,	//	01h	EEPROM FW Revision
		0x62,	//	02h	POW Trigger DVFS
		0x6D,	//	03h	POW Trigger VD09
		0xE5,	//	04h	POW Trigger DDR0
		0xE5,	//	05h	POW Trigger DDR1
		0x36,	//	06h	POW Trigger VD18
		0xB1,	//	07h	POW Trigger VD33
		0xE4,	//	08h	POW Trigger SD0
		0xE4,	//	09h	POW Trigger SD1
		0xE4,	//	0Ah	POW Trigger SD2
		0xE4,	//	0Bh	POW Trigger SD3
		0x36,	//	0Ch	POW Trigger VD25
		0x20,	//	0Dh	POW Trigger DDR0C
		0x20,	//	0Eh	POW Trigger DDR1C
		0x0A,	//	0Fh	POW Trigger PRESETB
		0xF4,	//	10h	POW Wait DVFS
		0xF4,	//	11h	POW Wait VD09
		0x44,	//	12h	POW Wait DDR0
		0x44,	//	13h	POW Wait DDR1
		0xF4,	//	14h	POW Wait VD18
		0xF4,	//	15h	POW Wait VD33
		0x44,	//	16h	POW Wait SD0
		0x44,	//	17h	POW Wait SD1
		0x44,	//	18h	POW Wait SD2
		0x44,	//	19h	POW Wait SD3
		0xF4,	//	1Ah	POW Wait VD25
		0xF4,	//	1Bh	POW Wait DDR0C
		0xF4,	//	1Ch	POW Wait DDR1C
		0x4F,	//	1Dh	PON Wait PRESETB
		0x01,	//	1Eh	AVS Start Tim Cnt
		0x52,	//	1Fh	AVS VD09 VID 0
		0x52,	//	20h	AVS VD09 VID 1
		0x52,	//	21h	AVS VD09 VID 2
		0x52,	//	22h	AVS VD09 VID 3
		0x53,	//	23h	AVS DVFS VID 0
		0x51,	//	24h	AVS DVFS VID 1
		0x4F,	//	25h	AVS DVFS VID 2
		0x4D,	//	26h	AVS DVFS VID 3
		0x01,	//	27h	AVS EN
		0x52,	//	28h	VD09 Vinit
		0x53,	//	29h	DVFS Vinit
		0x60,	//	2Ah	DVFS SetVmax
		0x00,	//	2Bh	reserved
		0x00,	//	2Ch	POW SoftStart 1
		0x00,	//	2Dh	POW SoftStart 2
		0x00,	//	2Eh	POW SoftStart 3
		0x00,	//	2Fh	POW SoftStart 4
		0x00,	//	30h	POW SoftStart 5
		0x00,	//	31h	POW SoftStart 6
		0x11,	//	32h	DCDC Freq
		0x00,	//	33h	SSCG Cnt
		0x01,	//	34h	POFFB / MRB
		0x88,	//	35h	CRC Check Code
};
//V15_for_salvatorXS_12S_5th_M3N
const uint8_t TblPmicSettingV15[0x36] = {
		0x8E,	//	00h	Connection Check Code
		0x15,	//	01h	EEPROM FW Revision
		0x62,	//	02h	POW Trigger DVFS
		0x6D,	//	03h	POW Trigger VD09
		0xE5,	//	04h	POW Trigger DDR0
		0xE5,	//	05h	POW Trigger DDR1
		0x36,	//	06h	POW Trigger VD18
		0xB1,	//	07h	POW Trigger VD33
		0xE4,	//	08h	POW Trigger SD0
		0xE4,	//	09h	POW Trigger SD1
		0xE4,	//	0Ah	POW Trigger SD2
		0xE4,	//	0Bh	POW Trigger SD3
		0x36,	//	0Ch	POW Trigger VD25
		0x20,	//	0Dh	POW Trigger DDR0C
		0x20,	//	0Eh	POW Trigger DDR1C
		0x0A,	//	0Fh	POW Trigger PRESETB
		0xF4,	//	10h	POW Wait DVFS
		0xF4,	//	11h	POW Wait VD09
		0x44,	//	12h	POW Wait DDR0
		0x44,	//	13h	POW Wait DDR1
		0xF4,	//	14h	POW Wait VD18
		0xF4,	//	15h	POW Wait VD33
		0x44,	//	16h	POW Wait SD0
		0x44,	//	17h	POW Wait SD1
		0x44,	//	18h	POW Wait SD2
		0x44,	//	19h	POW Wait SD3
		0xF4,	//	1Ah	POW Wait VD25
		0xF4,	//	1Bh	POW Wait DDR0C
		0xF4,	//	1Ch	POW Wait DDR1C
		0x4F,	//	1Dh	PON Wait PRESETB
		0x01,	//	1Eh	AVS Start Tim Cnt
		0x4B,	//	1Fh	AVS VD09 VID 0
		0x4B,	//	20h	AVS VD09 VID 1
		0x4B,	//	21h	AVS VD09 VID 2
		0x4B,	//	22h	AVS VD09 VID 3
		0x53,	//	23h	AVS DVFS VID 0
		0x51,	//	24h	AVS DVFS VID 1
		0x4F,	//	25h	AVS DVFS VID 2
		0x4D,	//	26h	AVS DVFS VID 3
		0x11,	//	27h	AVS EN
		0x52,	//	28h	VD09 Vinit
		0x53,	//	29h	DVFS Vinit
		0x60,	//	2Ah	DVFS SetVmax
		0x00,	//	2Bh	reserved
		0x00,	//	2Ch	POW SoftStart 1
		0x00,	//	2Dh	POW SoftStart 2
		0x00,	//	2Eh	POW SoftStart 3
		0x00,	//	2Fh	POW SoftStart 4
		0x00,	//	30h	POW SoftStart 5
		0x00,	//	31h	POW SoftStart 6
		0x11,	//	32h	DCDC Freq
		0x00,	//	33h	SSCG Cnt
		0x01,	//	34h	POFFB / MRB
		0x2B,	//	35h	CRC Check Code
};



//Salvator-XS_PMIC_2nd �o�[�W���� (20S)
//EEPROM V10
const uint8_t TblPmicSettingV10[0x2D] = {
		0x8E,	//	00h	Connection Check Code
		0x10,	//	01h	EEPROM FW Revision
		0x62,	//	02h	POW Trigger DVFS
		0x6D,	//	03h	POW Trigger VD09
		0xE5,	//	04h	POW Trigger DDR0
		0xE5,	//	05h	POW Trigger DDR1
		0x36,	//	06h	POW Trigger VD18
		0x51,	//	07h	POW Trigger VD33
		0xE4,	//	08h	POW Trigger SD0
		0xE4,	//	09h	POW Trigger SD1
		0xE4,	//	0Ah	POW Trigger SD2
		0xE4,	//	0Bh	POW Trigger SD3
		0x36,	//	0Ch	POW Trigger VD25
		0x20,	//	0Dh	POW Trigger DDR0C
		0x20,	//	0Eh	POW Trigger DDR1C
		0x0A,	//	0Fh	POW Trigger PRESETB
		0xF4,	//	10h	POW Wait DVFS
		0xF4,	//	11h	POW Wait VD09
		0x44,	//	12h	POW Wait DDR0
		0x44,	//	13h	POW Wait DDR1
		0xF4,	//	14h	POW Wait VD18
		0xF4,	//	15h	POW Wait VD33
		0x44,	//	16h	POW Wait SD0
		0x44,	//	17h	POW Wait SD1
		0x44,	//	18h	POW Wait SD2
		0x44,	//	19h	POW Wait SD3
		0xF4,	//	1Ah	POW Wait VD25
		0xF4,	//	1Bh	POW Wait DDR0C
		0xF4,	//	1Ch	POW Wait DDR1C
		0x4F,	//	1Dh	PON Wait PRESETB
		0x0E,	//	1Eh	AVS Start Tim Cnt
		0x52,	//	1Fh	AVS VD09 VID 0
		0x52,	//	20h	AVS VD09 VID 1
		0x52,	//	21h	AVS VD09 VID 2
		0x52,	//	22h	AVS VD09 VID 3
		0x53,	//	23h	AVS DVFS VID 0
		0x53,	//	24h	AVS DVFS VID 1
		0x53,	//	25h	AVS DVFS VID 2
		0x53,	//	26h	AVS DVFS VID 3
		0x53,	//	27h	DVFS Vinit
		0x6F,	//	28h	DVFS SetVmax
		0x07,	//	29h	VD18 VID
		0x07,	//	2Ah	VD25 VID
		0x05,	//	2Bh	VD33 VID
		0x3E,	//	2Ch	CRC Check Code
};
	
//V14_for_salvatorXS_12S_M3N	
const uint8_t TblPmicSettingV14[0x2D] = {
		0x8E,	//	00h	Connection Check Code
		0x14,	//	01h	EEPROM FW Revision
		0x62,	//	02h	POW Trigger DVFS
		0x6D,	//	03h	POW Trigger VD09
		0xE5,	//	04h	POW Trigger DDR0
		0xE5,	//	05h	POW Trigger DDR1
		0x36,	//	06h	POW Trigger VD18
		0x51,	//	07h	POW Trigger VD33
		0xE4,	//	08h	POW Trigger SD0
		0xE4,	//	09h	POW Trigger SD1
		0xE4,	//	0Ah	POW Trigger SD2
		0xE4,	//	0Bh	POW Trigger SD3
		0x36,	//	0Ch	POW Trigger VD25
		0x20,	//	0Dh	POW Trigger DDR0C
		0x20,	//	0Eh	POW Trigger DDR1C
		0x0A,	//	0Fh	POW Trigger PRESETB
		0xF4,	//	10h	POW Wait DVFS
		0xF4,	//	11h	POW Wait VD09
		0x44,	//	12h	POW Wait DDR0
		0x44,	//	13h	POW Wait DDR1
		0xF4,	//	14h	POW Wait VD18
		0xF4,	//	15h	POW Wait VD33
		0x44,	//	16h	POW Wait SD0
		0x44,	//	17h	POW Wait SD1
		0x44,	//	18h	POW Wait SD2
		0x44,	//	19h	POW Wait SD3
		0xF4,	//	1Ah	POW Wait VD25
		0xF4,	//	1Bh	POW Wait DDR0C
		0xF4,	//	1Ch	POW Wait DDR1C
		0x4F,	//	1Dh	PON Wait PRESETB
		0x0E,	//	1Eh	AVS Start Tim Cnt
		0x4B,	//	1Fh	AVS VD09 VID 0
		0x4B,	//	20h	AVS VD09 VID 1
		0x4B,	//	21h	AVS VD09 VID 2
		0x4B,	//	22h	AVS VD09 VID 3
		0x53,	//	23h	AVS DVFS VID 0
		0x53,	//	24h	AVS DVFS VID 1
		0x53,	//	25h	AVS DVFS VID 2
		0x53,	//	26h	AVS DVFS VID 3
		0x53,	//	27h	DVFS Vinit
		0x6F,	//	28h	DVFS SetVmax
		0x07,	//	29h	VD18 VID
		0x07,	//	2Ah	VD25 VID
		0x05,	//	2Bh	VD33 VID
		0x3C,	//	2Ch	CRC Check Code
};

//�ʏ�o�[�W����
//EEPROM V0E
const uint8_t TblPmicSettingV0E[0x2D] = {
		0x8E,	//	00h	Connection Check Code
		0x0E,	//	01h	EEPROM FW Revision
		0x52,	//	02h	POW Trigger DVFS
		0x5D,	//	03h	POW Trigger VD09
		0xE6,	//	04h	POW Trigger DDR0
		0xE6,	//	05h	POW Trigger DDR1
		0xB1,	//	06h	POW Trigger VD18
		0x35,	//	07h	POW Trigger VD33
		0xE4,	//	08h	POW Trigger SD0
		0xE4,	//	09h	POW Trigger SD1
		0xE4,	//	0Ah	POW Trigger SD2
		0xE4,	//	0Bh	POW Trigger SD3
		0x35,	//	0Ch	POW Trigger VD25
		0x20,	//	0Dh	POW Trigger DDR0C
		0x20,	//	0Eh	POW Trigger DDR1C
		0x0A,	//	0Fh	POW Trigger PRESETB
		0xF4,	//	10h	POW Wait DVFS
		0xF4,	//	11h	POW Wait VD09
		0x44,	//	12h	POW Wait DDR0
		0x44,	//	13h	POW Wait DDR1
		0xF4,	//	14h	POW Wait VD18
		0xF4,	//	15h	POW Wait VD33
		0x44,	//	16h	POW Wait SD0
		0x44,	//	17h	POW Wait SD1
		0x44,	//	18h	POW Wait SD2
		0x44,	//	19h	POW Wait SD3
		0xF4,	//	1Ah	POW Wait VD25
		0xF4,	//	1Bh	POW Wait DDR0C
		0xF4,	//	1Ch	POW Wait DDR1C
		0x4F,	//	1Dh	PON Wait PRESETB
		0x07,	//	1Eh	AVS Start Tim Cnt
		0x52,	//	1Fh	AVS VD09 VID 0
		0x52,	//	20h	AVS VD09 VID 1
		0x52,	//	21h	AVS VD09 VID 2
		0x52,	//	22h	AVS VD09 VID 3
		0x53,	//	23h	AVS DVFS VID 0
		0x53,	//	24h	AVS DVFS VID 1
		0x53,	//	25h	AVS DVFS VID 2
		0x53,	//	26h	AVS DVFS VID 3
		0x53,	//	27h	DVFS Vinit
		0x6F,	//	28h	DVFS SetVmax
		0x07,	//	29h	VD18 VID
		0x07,	//	2Ah	VD25 VID
		0x05,	//	2Bh	VD33 VID
		0x66,	//	2Ch	CRC Check Code
};
//V12_for_salvatorX_11S_M3N
const uint8_t TblPmicSettingV12[0x2D] = {
		0x8E,	//	00h	Connection Check Code
		0x12,	//	01h	EEPROM FW Revision
		0x52,	//	02h	POW Trigger DVFS
		0x5D,	//	03h	POW Trigger VD09
		0xE6,	//	04h	POW Trigger DDR0
		0xE6,	//	05h	POW Trigger DDR1
		0xB1,	//	06h	POW Trigger VD18
		0x35,	//	07h	POW Trigger VD33
		0xE4,	//	08h	POW Trigger SD0
		0xE4,	//	09h	POW Trigger SD1
		0xE4,	//	0Ah	POW Trigger SD2
		0xE4,	//	0Bh	POW Trigger SD3
		0x35,	//	0Ch	POW Trigger VD25
		0x20,	//	0Dh	POW Trigger DDR0C
		0x20,	//	0Eh	POW Trigger DDR1C
		0x0A,	//	0Fh	POW Trigger PRESETB
		0xF4,	//	10h	POW Wait DVFS
		0xF4,	//	11h	POW Wait VD09
		0x44,	//	12h	POW Wait DDR0
		0x44,	//	13h	POW Wait DDR1
		0xF4,	//	14h	POW Wait VD18
		0xF4,	//	15h	POW Wait VD33
		0x44,	//	16h	POW Wait SD0
		0x44,	//	17h	POW Wait SD1
		0x44,	//	18h	POW Wait SD2
		0x44,	//	19h	POW Wait SD3
		0xF4,	//	1Ah	POW Wait VD25
		0xF4,	//	1Bh	POW Wait DDR0C
		0xF4,	//	1Ch	POW Wait DDR1C
		0x4F,	//	1Dh	PON Wait PRESETB
		0x07,	//	1Eh	AVS Start Tim Cnt
		0x4B,	//	1Fh	AVS VD09 VID 0
		0x4B,	//	20h	AVS VD09 VID 1
		0x4B,	//	21h	AVS VD09 VID 2
		0x4B,	//	22h	AVS VD09 VID 3
		0x53,	//	23h	AVS DVFS VID 0
		0x53,	//	24h	AVS DVFS VID 1
		0x53,	//	25h	AVS DVFS VID 2
		0x53,	//	26h	AVS DVFS VID 3
		0x53,	//	27h	DVFS Vinit
		0x6F,	//	28h	DVFS SetVmax
		0x07,	//	29h	VD18 VID
		0x07,	//	2Ah	VD25 VID
		0x05,	//	2Bh	VD33 VID
		0xA8,	//	2Ch	CRC Check Code
};

//���ʃo�[�W����
//EEPROM V0F
const uint8_t TblPmicSettingV0F[0x2D] = {
		0x8E,	//	00h	Connection Check Code
		0x0F,	//	01h	EEPROM FW Revision
		0x52,	//	02h	POW Trigger DVFS
		0x5D,	//	03h	POW Trigger VD09
		0xE6,	//	04h	POW Trigger DDR0
		0xE6,	//	05h	POW Trigger DDR1
		0xB1,	//	06h	POW Trigger VD18
		0x3A,	//	07h	POW Trigger VD33
		0xB1,	//	08h	POW Trigger SD0
		0xB1,	//	09h	POW Trigger SD1
		0xB1,	//	0Ah	POW Trigger SD2
		0xB1,	//	0Bh	POW Trigger SD3
		0x3A,	//	0Ch	POW Trigger VD25
		0x20,	//	0Dh	POW Trigger DDR0C
		0x20,	//	0Eh	POW Trigger DDR1C
		0x04,	//	0Fh	POW Trigger PRESETB
		0xF4,	//	10h	POW Wait DVFS
		0xF4,	//	11h	POW Wait VD09
		0x44,	//	12h	POW Wait DDR0
		0x44,	//	13h	POW Wait DDR1
		0xF4,	//	14h	POW Wait VD18
		0xF4,	//	15h	POW Wait VD33
		0xF4,	//	16h	POW Wait SD0
		0xF4,	//	17h	POW Wait SD1
		0xF4,	//	18h	POW Wait SD2
		0xF4,	//	19h	POW Wait SD3
		0xF4,	//	1Ah	POW Wait VD25
		0xF4,	//	1Bh	POW Wait DDR0C
		0xF4,	//	1Ch	POW Wait DDR1C
		0x4F,	//	1Dh	PON Wait PRESETB
		0x07,	//	1Eh	AVS Start Tim Cnt
		0x52,	//	1Fh	AVS VD09 VID 0
		0x52,	//	20h	AVS VD09 VID 1
		0x52,	//	21h	AVS VD09 VID 2
		0x52,	//	22h	AVS VD09 VID 3
		0x53,	//	23h	AVS DVFS VID 0
		0x53,	//	24h	AVS DVFS VID 1
		0x53,	//	25h	AVS DVFS VID 2
		0x53,	//	26h	AVS DVFS VID 3
		0x53,	//	27h	DVFS Vinit
		0x6F,	//	28h	DVFS SetVmax
		0x07,	//	29h	VD18 VID
		0x07,	//	2Ah	VD25 VID
		0x05,	//	2Bh	VD33 VID
		0x39,	//	2Ch	CRC Check Code
};
//V13_for_salvatorX_10S_M3N
const uint8_t TblPmicSettingV13[0x2D] = {
		0x8E,	//	00h	Connection Check Code
		0x13,	//	01h	EEPROM FW Revision
		0x52,	//	02h	POW Trigger DVFS
		0x5D,	//	03h	POW Trigger VD09
		0xE6,	//	04h	POW Trigger DDR0
		0xE6,	//	05h	POW Trigger DDR1
		0xB1,	//	06h	POW Trigger VD18
		0x3A,	//	07h	POW Trigger VD33
		0xB1,	//	08h	POW Trigger SD0
		0xB1,	//	09h	POW Trigger SD1
		0xB1,	//	0Ah	POW Trigger SD2
		0xB1,	//	0Bh	POW Trigger SD3
		0x3A,	//	0Ch	POW Trigger VD25
		0x20,	//	0Dh	POW Trigger DDR0C
		0x20,	//	0Eh	POW Trigger DDR1C
		0x04,	//	0Fh	POW Trigger PRESETB
		0xF4,	//	10h	POW Wait DVFS
		0xF4,	//	11h	POW Wait VD09
		0x44,	//	12h	POW Wait DDR0
		0x44,	//	13h	POW Wait DDR1
		0xF4,	//	14h	POW Wait VD18
		0xF4,	//	15h	POW Wait VD33
		0xF4,	//	16h	POW Wait SD0
		0xF4,	//	17h	POW Wait SD1
		0xF4,	//	18h	POW Wait SD2
		0xF4,	//	19h	POW Wait SD3
		0xF4,	//	1Ah	POW Wait VD25
		0xF4,	//	1Bh	POW Wait DDR0C
		0xF4,	//	1Ch	POW Wait DDR1C
		0x4F,	//	1Dh	PON Wait PRESETB
		0x07,	//	1Eh	AVS Start Tim Cnt
		0x4B,	//	1Fh	AVS VD09 VID 0
		0x4B,	//	20h	AVS VD09 VID 1
		0x4B,	//	21h	AVS VD09 VID 2
		0x4B,	//	22h	AVS VD09 VID 3
		0x53,	//	23h	AVS DVFS VID 0
		0x53,	//	24h	AVS DVFS VID 1
		0x53,	//	25h	AVS DVFS VID 2
		0x53,	//	26h	AVS DVFS VID 3
		0x53,	//	27h	DVFS Vinit
		0x6F,	//	28h	DVFS SetVmax
		0x07,	//	29h	VD18 VID
		0x07,	//	2Ah	VD25 VID
		0x05,	//	2Bh	VD33 VID
		0xF7,	//	2Ch	CRC Check Code
};


const uint8_t TblPmic9576SettingV01[0x29] = {
		0x8E,	//	00h	Connection Check Code
		0x03,	//	01h	SHDN Cnt
		0x00,	//	02h	SSCG Cnt
		0x20,	//	03h	Watch Dog Timer setting
		0x3F,	//	04h	PGD Setting
		0x20,	//	05h	System Status Mask
		0x00,	//	06h	INT IntMask
		0x20,	//	07h	POW Trigger VOUT1
		0x61,	//	08h	POW Trigger VOUT2
		0x45,	//	09h	POW Trigger VOUT3
		0x73,	//	0Ah	POW Trigger VOUT4
		0x36,	//	0Bh	POW Trigger VOUTL1
		0x52,	//	0Ch	POW Trigger VOUTS1
		0x04,	//	0Dh	POW Trigger PRESETB
		0x01,	//	0Eh	POW Wait VOUT1
		0xA7,	//	0Fh	POW Wait VOUT2
		0x43,	//	10h	POW Wait VOUT3
		0x74,	//	11h	POW Wait VOUT4
		0x33,	//	12h	POW Wait VOUTL1
		0x3A,	//	13h	POW Wait VOUTS1
		0x37,	//	14h	POW Wait PRESETB
		0x00,	//	15h	VOUT1 TUNE
		0x43,	//	16h	VOUT1 OVD
		0x43,	//	17h	VOUT1 UVD
		0x00,	//	18h	VOUT2 TUNE
		0x37,	//	19h	VOUT2 OVD
		0x37,	//	1Ah	VOUT2 UVD
		0x00,	//	1Bh	VOUT3 TUNE
		0x3E,	//	1Ch	VOUT3 OVD
		0x23,	//	1Dh	VOUT3 UVD
		0x00,	//	1Eh	VOUT4 TUNE
		0x19,	//	1Fh	VOUT4 OVD
		0x19,	//	20h	VOUT4 UVD
		0x00,	//	21h	VOUTL1 TUNE
		0x40,	//	22h	VOUTL1_OVD
		0x40,	//	23h	VOUTL1 UVD
		0x0C,	//	24h	VOUTS1 OCW
		0x12,	//	25h	VOUTS1 OCP
		0x33,	//	26h	Deglitch Time
		0xE7,	//	27h	CRC Check Code
		0x01,	//	28h	Version
};

// BD9574_CRC_for_Ebisu_V00(2).xlsx
const uint8_t TblPmic9574SettingV00[0x36] = {
		0x8E,	//	00h	Connection Check Code
		0x00,	//	01h	EEPROM FW Revision
		0x73,	//	02h	POW Trigger DVFS
		0xFF,	//	03h	POW Trigger VD09
		0x1B,	//	04h	POW Trigger DDR0
		0xFF,	//	05h	POW Trigger DDR1
		0x60,	//	06h	POW Trigger VD18
		0xB5,	//	07h	POW Trigger VD33
		0xE1,	//	08h	POW Trigger SD0
		0xE1,	//	09h	POW Trigger SD1
		0xE1,	//	0Ah	POW Trigger SD2
		0xFF,	//	0Bh	POW Trigger SD3
		0x36,	//	0Ch	POW Trigger VD25
		0xFF,	//	0Dh	POW Trigger DDR0C
		0xFF,	//	0Eh	POW Trigger DDR1C
		0x07,	//	0Fh	POW Trigger PRESETB
		0xF4,	//	10h	POW Wait DVFS
		0xF4,	//	11h	POW Wait VD09
		0xF4,	//	12h	POW Wait DDR0
		0xF4,	//	13h	POW Wait DDR1
		0xF4,	//	14h	POW Wait VD18
		0xF4,	//	15h	POW Wait VD33
		0x44,	//	16h	POW Wait SD0
		0x44,	//	17h	POW Wait SD1
		0x44,	//	18h	POW Wait SD2
		0x44,	//	19h	POW Wait SD3
		0xF4,	//	1Ah	POW Wait VD25
		0xF4,	//	1Bh	POW Wait DDR0C
		0xF4,	//	1Ch	POW Wait DDR1C
		0x4F,	//	1Dh	PON Wait PRESETB
		0x01,	//	1Eh	AVS Start Tim Cnt
		0x52,	//	1Fh	AVS VD09 VID 0
		0x52,	//	20h	AVS VD09 VID 1
		0x52,	//	21h	AVS VD09 VID 2
		0x52,	//	22h	AVS VD09 VID 3
		0x67,	//	23h	AVS DVFS VID 0
		0x67,	//	24h	AVS DVFS VID 1
		0x67,	//	25h	AVS DVFS VID 2
		0x67,	//	26h	AVS DVFS VID 3
		0x00,	//	27h	AVS EN
		0x52,	//	28h	VD09 Vinit
		0x67,	//	29h	DVFS Vinit
		0x6C,	//	2Ah	DVFS SetVmax
		0x00,	//	2Bh	reserved
		0x00,	//	2Ch	POW SoftStart 1
		0x00,	//	2Dh	POW SoftStart 2
		0x00,	//	2Eh	POW SoftStart 3
		0x00,	//	2Fh	POW SoftStart 4
		0x00,	//	30h	POW SoftStart 5
		0x00,	//	31h	POW SoftStart 6
		0x11,	//	32h	DCDC Freq
		0x00,	//	33h	SSCG Cnt
		0x01,	//	34h	POFFB / MRB
		0xDA,	//	35h	CRC Check Code
};


uint32_t SetPmicEepromData(void)
{
	if(gPmicProduct==PMIC_BD9571){
		return(SetPmicEepromDataBD9571());
	}else if(gPmicProduct==PMIC_BD9576){		   // Eagle-R
		return(SetPmicEepromDataBD9576());
	}else if(gPmicProduct==PMIC_BD9574){		   // Ebisu_BD9574
		return(SetPmicEepromDataBD9574());
	}
}


uint32_t SetPmicEepromDataBD9571(void)
{
	char str[64];

	uint32_t i;
	uint32_t setData,rdData;

	InitPmicI2c();		        // IIC/I2C Initialize

	if(gPmicRev<=PMIC_REV01)	{	//OLD_PMIC
		if(CHK_SALVATOR){
			for(i=0;i<0x2D;i++){
				if(gPcbVer == RC7795SIPB0010S){
					if(gPmicVdd == LOW_VOLTAGE)		setData = (uint32_t)TblPmicSettingV13[i];
					else							setData = (uint32_t)TblPmicSettingV0F[i];
				}else if(gPcbVer == RC7795SIPB0011S){
					if(gPmicVdd == LOW_VOLTAGE)		setData = (uint32_t)TblPmicSettingV12[i];
					else							setData = (uint32_t)TblPmicSettingV0E[i];
				}else if(gPcbVer == RC7795SIPB0012S){
					if(gPmicVdd == LOW_VOLTAGE)		setData = (uint32_t)TblPmicSettingV14[i];
					else							setData = (uint32_t)TblPmicSettingV10[i];
				}
				PageWritePmic(EEPROM_I2C_SLA,i,&setData,1);		// �f�[�^������
				StartTMU0(1);									// �����������݃T�C�N������(max 5ms) - wait 10ms
			}
			for(i=0;i<0x2D;i++){
				if(gPcbVer == RC7795SIPB0010S){
					if(gPmicVdd == LOW_VOLTAGE)		setData = (uint32_t)TblPmicSettingV13[i];
					else							setData = (uint32_t)TblPmicSettingV0F[i];
				}else if(gPcbVer == RC7795SIPB0011S){
					if(gPmicVdd == LOW_VOLTAGE)		setData = (uint32_t)TblPmicSettingV12[i];
					else							setData = (uint32_t)TblPmicSettingV0E[i];
				}else if(gPcbVer == RC7795SIPB0012S){
					if(gPmicVdd == LOW_VOLTAGE)		setData = (uint32_t)TblPmicSettingV14[i];
					else							setData = (uint32_t)TblPmicSettingV10[i];
				}
				RandomAddressReadPmic(EEPROM_I2C_SLA,i,&rdData,1);// �f�[�^�ǂݏo��
				if(rdData != setData){
					MessEepromInitError(i,rdData,setData);
					return(1);
				}
			}
			return(0);
		}else if(CHK_KRIEK){
			for(i=0;i<0x2D;i++){
//				if(gPmicVdd == LOW_VOLTAGE)			setData = (uint32_t)TblPmicSettingV13[i];
//				else								setData = (uint32_t)TblPmicSettingV0F[i];
													setData = (uint32_t)TblPmicSettingV0F[i];
				PageWritePmic(EEPROM_I2C_SLA,i,&setData,1);		// �f�[�^������
				StartTMU0(1);									// �����������݃T�C�N������(max 5ms) - wait 10ms
			}
			for(i=0;i<0x2D;i++){
//				if(gPmicVdd == LOW_VOLTAGE)			setData = (uint32_t)TblPmicSettingV13[i];
//				else								setData = (uint32_t)TblPmicSettingV0F[i];
													setData = (uint32_t)TblPmicSettingV0F[i];
				RandomAddressReadPmic(EEPROM_I2C_SLA,i,&rdData,1);// �f�[�^�ǂݏo��
				if(rdData != setData){
					MessEepromInitError(i,rdData,setData);
					return(1);
				}
			}
			return(0);
		}else if(CHK_STARTERKIT){
			for(i=0;i<0x2D;i++){
				if(gPmicVdd == LOW_VOLTAGE)			setData = (uint32_t)TblPmicSettingV12[i];
				else								setData = (uint32_t)TblPmicSettingV0E[i];
				PageWritePmic(EEPROM_I2C_SLA,i,&setData,1);		// �f�[�^������
				StartTMU0(1);									// �����������݃T�C�N������(max 5ms) - wait 10ms
			}
			for(i=0;i<0x2D;i++){
				if(gPmicVdd == LOW_VOLTAGE)			setData = (uint32_t)TblPmicSettingV12[i];
				else								setData = (uint32_t)TblPmicSettingV0E[i];
				RandomAddressReadPmic(EEPROM_I2C_SLA,i,&rdData,1);// �f�[�^�ǂݏo��
				if(rdData != setData){
					MessEepromInitError(i,rdData,setData);
					return(1);
				}
			}
			return(0);
		}
	}
	else{	//NEW_PMIC
		if(CHK_V3H){
			for(i=0;i<0x36;i++){		//NEW_PMIC
				setData = (uint32_t)TblPmicSettingV81[i];
				PageWritePmic(EEPROM_I2C_SLA,i,&setData,1);		// �f�[�^������
				StartTMU0(1);									// �����������݃T�C�N������(max 5ms) - wait 10ms
			}
			for(i=0;i<0x36;i++){		//NEW_PMIC
				setData = (uint32_t)TblPmicSettingV81[i];
				RandomAddressReadPmic(EEPROM_I2C_SLA,i,&rdData,1);// �f�[�^�ǂݏo��
				if(rdData != setData){
					MessEepromInitError(i,rdData,setData);
					return(1);
				}
			}
			return(0);
		}else if(CHK_E3){
			for(i=0;i<0x36;i++){		//NEW_PMIC
				setData = (uint32_t)TblPmicSettingVA1[i];
				PageWritePmic(EEPROM_I2C_SLA,i,&setData,1);		// �f�[�^������
				StartTMU0(1);									// �����������݃T�C�N������(max 5ms) - wait 10ms
			}
			for(i=0;i<0x36;i++){		//NEW_PMIC
				setData = (uint32_t)TblPmicSettingVA1[i];
				RandomAddressReadPmic(EEPROM_I2C_SLA,i,&rdData,1);// �f�[�^�ǂݏo��
				if(rdData != setData){
					MessEepromInitError(i,rdData,setData);
					return(1);
				}
			}
			return(0);
		}else if(CHK_STARTERKIT){
			for(i=0;i<0x36;i++){		//NEW_PMIC
				setData = (uint32_t)TblPmicSettingV17[i];
				PageWritePmic(EEPROM_I2C_SLA,i,&setData,1);		// �f�[�^������
				StartTMU0(1);									// �����������݃T�C�N������(max 5ms) - wait 10ms
			}
			for(i=0;i<0x36;i++){		//NEW_PMIC
				setData = (uint32_t)TblPmicSettingV17[i];
				RandomAddressReadPmic(EEPROM_I2C_SLA,i,&rdData,1);// �f�[�^�ǂݏo��
				if(rdData != setData){
					MessEepromInitError(i,rdData,setData);
					return(1);
				}
			}
			return(0);
		}else{							//Salvator/Kriek
			for(i=0;i<0x36;i++){		//NEW_PMIC
				if(gPmicVdd == LOW_VOLTAGE)				setData = (uint32_t)TblPmicSettingV15[i];
				else									setData = (uint32_t)TblPmicSettingV11[i];
				PageWritePmic(EEPROM_I2C_SLA,i,&setData,1);		// �f�[�^������
				StartTMU0(1);									// �����������݃T�C�N������(max 5ms) - wait 10ms
			}
			for(i=0;i<0x36;i++){		//NEW_PMIC
				if(gPmicVdd == LOW_VOLTAGE)				setData = (uint32_t)TblPmicSettingV15[i];
				else									setData = (uint32_t)TblPmicSettingV11[i];
				RandomAddressReadPmic(EEPROM_I2C_SLA,i,&rdData,1);// �f�[�^�ǂݏo��
				if(rdData != setData){
					MessEepromInitError(i,rdData,setData);
					return(1);
				}
			}
			return(0);
		}
	}
}




uint32_t SetPmicEepromDataBD9576(void)
{
	char str[64];

	uint32_t i;
	uint32_t setData,rdData;

	InitPmicI2c();		        // IIC/I2C Initialize

	if(CHK_V3M){
		for(i=0;i<0x29;i++){
			setData = (uint32_t)TblPmic9576SettingV01[i];
			PageWritePmic(EEPROM_I2C_SLA,i,&setData,1);		// �f�[�^������
			StartTMU0(1);									// �����������݃T�C�N������(max 5ms) - wait 10ms
		}
		for(i=0;i<0x29;i++){
			setData = (uint32_t)TblPmic9576SettingV01[i];
			RandomAddressReadPmic(EEPROM_I2C_SLA,i,&rdData,1);// �f�[�^�ǂݏo��
			if(rdData != setData){
					MessEepromInitError(i,rdData,setData);
				return(1);
			}
		}
		return(0);
	}
}


uint32_t SetPmicEepromDataBD9574(void)
{
	char str[64];

	uint32_t i;
	uint32_t setData,rdData;

	InitPmicI2c();		        // IIC/I2C Initialize

	for(i=0;i<0x36;i++){
		setData = (uint32_t)TblPmic9574SettingV00[i];
		PageWritePmic(EEPROM_I2C_SLA,i,&setData,1);		// �f�[�^������
		StartTMU0(1);									// �����������݃T�C�N������(max 5ms) - wait 10ms
	}
	for(i=0;i<0x36;i++){
		setData = (uint32_t)TblPmic9574SettingV00[i];
		RandomAddressReadPmic(EEPROM_I2C_SLA,i,&rdData,1);// �f�[�^�ǂݏo��
		if(rdData != setData){
			MessEepromInitError(i,rdData,setData);
			return(1);
		}
	}
	return(0);
}

uint32_t SetPmicEepromDataFF(void)
{
	char str[64];

	uint32_t i,size;
	uint32_t setData,rdData;

	InitPmicI2c();		        // IIC/I2C Initialize
	setData = 0xFF;
	size    = 0x36;				// PMIC MAX SIZE

	for(i=0;i<size;i++){
		PageWritePmic(EEPROM_I2C_SLA,i,&setData,1);		// �f�[�^������
		StartTMU0(1);									// �����������݃T�C�N������(max 5ms) - wait 10ms
	}
	for(i=0;i<size;i++){
		RandomAddressReadPmic(EEPROM_I2C_SLA,i,&rdData,1);// �f�[�^�ǂݏo��
		if(rdData != setData){
			MessEepromInitError(i,rdData,setData);
			return(1);
		}
	}
	return(0);
}


void MessEepromInitError(uint32_t i,uint32_t rdData,uint32_t setData)
{
	char str[64];

	PutStr("EEPROM Initilize Error",1);
	PutStr(" EEPROM error address  : H'",0);	Data2HexAscii(i,str,4);			PutStr(str,1);
	PutStr(" EEPROM error data     : H'",0);	Data2HexAscii(rdData,str,4);	PutStr(str,1);
	PutStr(" EEPROM set data       : H'",0);	Data2HexAscii(setData,str,4);	PutStr(str,1);
}


uint32_t GetPmicEepromFwRev(void)
{
	uint32_t rdData;

	InitPmicI2c();			// IIC/I2C Initialize
	
	if( (gPmicProduct==PMIC_BD9571)||(gPmicProduct==PMIC_BD9574) ){
//		PutStr("(for BD9571/BD9574)",1);
		RandomAddressReadPmic(EEPROM_I2C_SLA,0x01,&rdData,1);            // �f�[�^�ǂݏo��
	}else if(gPmicProduct==PMIC_BD9576){
//		PutStr("(for BD9576)",1);
		RandomAddressReadPmic(EEPROM_I2C_SLA,0x28,&rdData,1);            // �f�[�^�ǂݏo��
	}
	return rdData;
}

uint32_t SetPmicEepromFwRev(void)
{
	uint32_t rdData;

	if(gPmicProduct==PMIC_BD9571){
		if(gPmicRev<=PMIC_REV01){				//OLD_PMIC
			if(CHK_SALVATOR){
				if(gPcbVer == RC7795SIPB0010S){
					if(gPmicVdd == LOW_VOLTAGE)		rdData= TblPmicSettingV13[1];
					else							rdData= TblPmicSettingV0F[1];
				}
				else if(gPcbVer == RC7795SIPB0011S){
					if(gPmicVdd == LOW_VOLTAGE)		rdData= TblPmicSettingV12[1];
					else							rdData= TblPmicSettingV0E[1];
				}
				else if(gPcbVer == RC7795SIPB0012S){
					if(gPmicVdd == LOW_VOLTAGE)		rdData= TblPmicSettingV14[1];
					else							rdData= TblPmicSettingV10[1];
				}
			}else if(CHK_KRIEK){
	//			if(gPmicVdd == LOW_VOLTAGE)			rdData= TblPmicSettingV13[1];
	//			else								rdData= TblPmicSettingV0F[1];
													rdData= TblPmicSettingV0F[1];
			}else if(CHK_STARTERKIT){
				if(gPmicVdd == LOW_VOLTAGE)			rdData= TblPmicSettingV12[1];
				else								rdData= TblPmicSettingV0E[1];
			}
		}else{									//NEW_PMIC
			if(CHK_V3H){							rdData= TblPmicSettingV81[1];	//Condor
			}else if(CHK_E3){						rdData= TblPmicSettingVA1[1];	//Ebisu_BBD9571
			}else if(CHK_STARTERKIT){				rdData= TblPmicSettingV17[1];	//SK
			}else{																	//Salvator/Kriek
				if(gPmicVdd == LOW_VOLTAGE)			rdData= TblPmicSettingV15[1];
				else								rdData= TblPmicSettingV11[1];
			}
		}
	}else if(gPmicProduct==PMIC_BD9576){											//Eagle-R
		rdData= TblPmic9576SettingV01[0x28];
	}else if(gPmicProduct==PMIC_BD9574){											//Ebisu_BD9574
		rdData= TblPmic9574SettingV00[1];
	}
	return rdData;
}


const char *const pmicmsg[0x36] = {	
		"  ( 00h  Connection Check Code / Connection Check Code)",
		"  ( 01h  EEPROM FW Revision    / EEPROM FW Revision)",
		"  ( 02h  POW Trigger DVFS      / POW Trigger DVFS)",
		"  ( 03h  POW Trigger VD09      / POW Trigger VD09)",
		"  ( 04h  POW Trigger DDR0      / POW Trigger DDR0)",
		"  ( 05h  POW Trigger DDR1      / POW Trigger DDR1)",
		"  ( 06h  POW Trigger VD18      / POW Trigger VD18)",
		"  ( 07h  POW Trigger VD33      / POW Trigger VD33)",
		"  ( 08h  POW Trigger SD0       / POW Trigger SD0)",
		"  ( 09h  POW Trigger SD1       / POW Trigger SD1)",
		"  ( 0Ah  POW Trigger SD2       / POW Trigger SD2)",
		"  ( 0Bh  POW Trigger SD3       / POW Trigger SD3)",
		"  ( 0Ch  POW Trigger VD25      / POW Trigger VD25)",
		"  ( 0Dh  POW Trigger DDR0C     / POW Trigger DDR0C)",
		"  ( 0Eh  POW Trigger DDR1C     / POW Trigger DDR1C)",
		"  ( 0Fh  POW Trigger PRESETB   / POW Trigger PRESETB)",
		"  ( 10h  POW Wait DVFS         / POW Wait DVFS)",
		"  ( 11h  POW Wait VD09         / POW Wait VD09)",
		"  ( 12h  POW Wait DDR0         / POW Wait DDR0)",
		"  ( 13h  POW Wait DDR1         / POW Wait DDR1)",
		"  ( 14h  POW Wait VD18         / POW Wait VD18)",
		"  ( 15h  POW Wait VD33         / POW Wait VD33)",
		"  ( 16h  POW Wait SD0          / POW Wait SD0)",
		"  ( 17h  POW Wait SD1          / POW Wait SD1)",
		"  ( 18h  POW Wait SD2          / POW Wait SD2)",
		"  ( 19h  POW Wait SD3          / POW Wait SD3)",
		"  ( 1Ah  POW Wait VD25         / POW Wait VD25)",
		"  ( 1Bh  POW Wait DDR0C        / POW Wait DDR0C)",
		"  ( 1Ch  POW Wait DDR1C        / POW Wait DDR1C)",
		"  ( 1Dh  PON Wait PRESETB      / PON Wait PRESETB)",
		"  ( 1Eh  AVS Start Tim Cnt     / AVS Start Tim Cnt)",
		"  ( 1Fh  AVS VD09 VID 0        / AVS VD09 VID 0)",
		"  ( 20h  AVS VD09 VID 1        / AVS VD09 VID 1)",
		"  ( 21h  AVS VD09 VID 2        / AVS VD09 VID 2)",
		"  ( 22h  AVS VD09 VID 3        / AVS VD09 VID 3)",
		"  ( 23h  AVS DVFS VID 0        / AVS DVFS VID 0)",
		"  ( 24h  AVS DVFS VID 1        / AVS DVFS VID 1)",
		"  ( 25h  AVS DVFS VID 2        / AVS DVFS VID 2)",
		"  ( 26h  AVS DVFS VID 3        / AVS DVFS VID 3)",
		"  ( 27h  DVFS Vinit            / AVS EN)",
		"  ( 28h  DVFS SetVmax          / VD09 Vinit)",
		"  ( 29h  VD18 VID              / DVFS Vinit)",
		"  ( 2Ah  VD25 VID              / DVFS SetVmax)",
		"  ( 2Bh  VD33 VID              / reserved)",
		"  ( 2Ch  CRC Check Code        / POW SoftStart 1)",
		"  ( 2Dh  -                     / POW SoftStart 2)",
		"  ( 2Eh  -                     / POW SoftStart 3)",
		"  ( 2Fh  -                     / POW SoftStart 4)",
		"  ( 30h  -                     / POW SoftStart 5)",
		"  ( 31h  -                     / POW SoftStart 6)",
		"  ( 32h  -                     / DCDC Freq)",
		"  ( 33h  -                     / SSCG Cnt)",
		"  ( 34h  -                     / POFFB / MRB)",
		"  ( 35h  -                     / CRC Check Code)",
};

const char *const pmic9576msg[0x29] = {	
		"  ( 00h  Connection Check Code   )",
		"  ( 01h  SHDN Cnt                )",
		"  ( 02h  SSCG Cnt                )",
		"  ( 03h  Watch Dog Timer setting )",
		"  ( 04h  PGD Setting             )",
		"  ( 05h  System Status Mask      )",
		"  ( 06h  INT IntMask             )",
		"  ( 07h  POW Trigger VOUT1       )",
		"  ( 08h  POW Trigger VOUT2       )",
		"  ( 09h  POW Trigger VOUT3       )",
		"  ( 0Ah  POW Trigger VOUT4       )",
		"  ( 0Bh  POW Trigger VOUTL1      )",
		"  ( 0Ch  POW Trigger VOUTS1      )",
		"  ( 0Dh  POW Trigger PRESETB     )",
		"  ( 0Eh  POW Wait VOUT1          )",
		"  ( 0Fh  POW Wait VOUT2          )",
		"  ( 10h  POW Wait VOUT3          )",
		"  ( 11h  POW Wait VOUT4          )",
		"  ( 12h  POW Wait VOUTL1         )",
		"  ( 13h  POW Wait VOUTS1         )",
		"  ( 14h  POW Wait PRESETB        )",
		"  ( 15h  VOUT1 TUNE              )",
		"  ( 16h  VOUT1 OVD               )",
		"  ( 17h  VOUT1 UVD               )",
		"  ( 18h  VOUT2 TUNE              )",
		"  ( 19h  VOUT2 OVD               )",
		"  ( 1Ah  VOUT2 UVD               )",
		"  ( 1Bh  VOUT3 TUNE              )",
		"  ( 1Ch  VOUT3 OVD               )",
		"  ( 1Dh  VOUT3 UVD               )",
		"  ( 1Eh  VOUT4 TUNE              )",
		"  ( 1Fh  VOUT4 OVD               )",
		"  ( 20h  VOUT4 UVD               )",
		"  ( 21h  VOUTL1 TUNE             )",
		"  ( 22h  VOUTL1_OVD              )",
		"  ( 23h  VOUTL1 UVD              )",
		"  ( 24h  VOUTS1 OCW              )",
		"  ( 25h  VOUTS1 OCP              )",
		"  ( 26h  Deglitch Time           )",
		"  ( 27h  CRC Check Code          )",
		"  ( 28h  Version                 )",
};

const char *const pmic9574msg[0x36] = {	
		"  ( 00h  Connection Check Code)",
		"  ( 01h  EEPROM FW Revision)",
		"  ( 02h  POW Trigger DVFS)",
		"  ( 03h  POW Trigger VD09)",
		"  ( 04h  POW Trigger DDR0)",
		"  ( 05h  POW Trigger DDR1)",
		"  ( 06h  POW Trigger VD18)",
		"  ( 07h  POW Trigger VD33)",
		"  ( 08h  POW Trigger SD0)",
		"  ( 09h  POW Trigger SD1)",
		"  ( 0Ah  POW Trigger SD2)",
		"  ( 0Bh  POW Trigger SD3)",
		"  ( 0Ch  POW Trigger VD25)",
		"  ( 0Dh  POW Trigger DDR0C)",
		"  ( 0Eh  POW Trigger DDR1C)",
		"  ( 0Fh  POW Trigger PRESETB)",
		"  ( 10h  POW Wait DVFS)",
		"  ( 11h  POW Wait VD09)",
		"  ( 12h  POW Wait DDR0)",
		"  ( 13h  POW Wait DDR1)",
		"  ( 14h  POW Wait VD18)",
		"  ( 15h  POW Wait VD33)",
		"  ( 16h  POW Wait SD0)",
		"  ( 17h  POW Wait SD1)",
		"  ( 18h  POW Wait SD2)",
		"  ( 19h  POW Wait SD3)",
		"  ( 1Ah  POW Wait VD25)",
		"  ( 1Bh  POW Wait DDR0C)",
		"  ( 1Ch  POW Wait DDR1C)",
		"  ( 1Dh  PON Wait PRESETB)",
		"  ( 1Eh  AVS Start Tim Cnt)",
		"  ( 1Fh  AVS VD09 VID 0)",
		"  ( 20h  AVS VD09 VID 1)",
		"  ( 21h  AVS VD09 VID 2)",
		"  ( 22h  AVS VD09 VID 3)",
		"  ( 23h  AVS DVFS VID 0)",
		"  ( 24h  AVS DVFS VID 1)",
		"  ( 25h  AVS DVFS VID 2)",
		"  ( 26h  AVS DVFS VID 3)",
		"  ( 27h  AVS EN)",
		"  ( 28h  VD09 Vinit)",
		"  ( 29h  DVFS Vinit)",
		"  ( 2Ah  DVFS SetVmax)",
		"  ( 2Bh  reserved)",
		"  ( 2Ch  reserved)",
		"  ( 2Dh  reserved)",
		"  ( 2Eh  reserved)",
		"  ( 2Fh  reserved)",
		"  ( 30h  reserved)",
		"  ( 31h  reserved)",
		"  ( 32h  DCDC Freq)",
		"  ( 33h  SSCG Cnt)",
		"  ( 34h  POFFB / MRB)",
		"  ( 35h  CRC Check Code)",
};

uint32_t PutGetPmicEepromData(void)
{
	char str[64];
	uint32_t i;
	uint32_t rdData;

	InitPmicI2c();			// IIC/I2C Initialize

	if(gPmicProduct==PMIC_BD9571){
		PutStr("",1);
		PutStr(" ===== Read PmicEepromData =====",1);
		PutStr("                     PMIC(OLD)        /      PMIC(NEW)",1);
		for(i=0;i<0x36;i++){
			RandomAddressReadPmic(EEPROM_I2C_SLA,i,&rdData,1);// �f�[�^�ǂݏo��
			PutStr("   H'",0);	Data2HexAscii(rdData,str,1);	PutStr(str,0);
			PutStr(pmicmsg[i],1);
		}
	}else if(gPmicProduct==PMIC_BD9576){
		PutStr("",1);
		PutStr(" ===== Read PmicEepromData =====",1);
		for(i=0;i<0x29;i++){
			RandomAddressReadPmic(EEPROM_I2C_SLA,i,&rdData,1);// �f�[�^�ǂݏo��
			PutStr("   H'",0);	Data2HexAscii(rdData,str,1);	PutStr(str,0);
			PutStr(pmic9576msg[i],1);
		}
	}else if(gPmicProduct==PMIC_BD9574 ){
		PutStr("",1);
		PutStr(" ===== Read PmicEepromData =====",1);
		for(i=0;i<0x36;i++){
			RandomAddressReadPmic(EEPROM_I2C_SLA,i,&rdData,1);// �f�[�^�ǂݏo��
			PutStr("   H'",0);	Data2HexAscii(rdData,str,1);	PutStr(str,0);
			PutStr(pmic9574msg[i],1);
		}
	}	
}



uint32_t GetPmicRev(void)
{
	uint32_t rdData;

	InitPmicI2c();			// IIC/I2C Initialize
	RandomAddressReadPmic(PMIC_IIC_SLA,PMIC_PRODUCT_REV,&rdData,1);  // �f�[�^�ǂݏo��

	return rdData;
}

uint32_t GetPmicPrdct(void)
{
	uint32_t rdData;

	InitPmicI2c();			// IIC/I2C Initialize
	RandomAddressReadPmic(PMIC_IIC_SLA,PMIC_PRODUCT_CODE,&rdData,1);  // �f�[�^�ǂݏo��  BD9571=H'60  BD9576=H'76

	return rdData;
}


void InitPmicI2c(void)
{
	if(CHK_H3||CHK_M3||CHK_M3N||CHK_E3){
		InitIic(IIC_CH0);
	}else if(CHK_V3H||CHK_V3M){
		InitI2c(I2C_CH0);
	}
}

uint32_t RandomAddressReadPmic(uint32_t slAdd, uint32_t accessAdd, uint32_t *rdBuf, uint32_t rdCount)
{
	if(CHK_H3||CHK_M3||CHK_M3N||CHK_E3){
		return RandomAddressReadIic(IIC_CH0, slAdd, accessAdd, rdBuf, rdCount);
	}else if(CHK_V3H||CHK_V3M){
		return RandomAddressReadI2C(I2C_CH0, slAdd, accessAdd, rdBuf, rdCount);
	}
}

uint32_t PageWritePmic(uint32_t slAdd,uint32_t accessAdd,uint32_t *wrBuf,uint32_t wrCount)
{
	if(CHK_H3||CHK_M3||CHK_M3N||CHK_E3){
		return PageWriteIic(IIC_CH0, slAdd, accessAdd, wrBuf, wrCount);
	}else if(CHK_V3H||CHK_V3M){
		return PageWriteI2C(I2C_CH0, slAdd, accessAdd, wrBuf, wrCount);
	}
}

#endif
