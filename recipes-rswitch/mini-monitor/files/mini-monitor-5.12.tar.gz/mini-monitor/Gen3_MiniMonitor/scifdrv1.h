int32_t PutCharSCIF1(char outChar);
int32_t GetCharSCIF1(char *inChar);
void PowerOnScif1(void);
void WaitPutScif1SendEnd(void);
void InitScif1_SCIFCLK(void);
void SetScif1_DL(uint16_t setData);
