int32_t PutCharSCIF0(char outChar);
int32_t GetCharSCIF0(char *inChar);
void PowerOnScif0(void);
void WaitPutScif0SendEnd(void);
void InitScif0_SCIFCLK(void);
void SetScif0_DL(uint16_t setData);
