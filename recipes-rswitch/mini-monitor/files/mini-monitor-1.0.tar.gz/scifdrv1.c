// ���̃\�[�X�t�@�C�����œK��
#pragma GCC optimize ("Og")


#include "common.h"
#include "scifdrv1.h"
#include "bit.h"
#include "reg_rcargen3.h"


//////////////////////////////////////////////////////////////////////////////////
//                                                                              //
//	Debug Seirial(SCIF1)														//
//																				//
//////////////////////////////////////////////////////////////////////////////////
int32_t PutCharSCIF1(char outChar)
{
	while(!(0x60 & *((volatile uint16_t*)SCIF1_SCFSR) ));
	*((volatile uint8_t*)SCIF1_SCFTDR) = outChar;
	*((volatile uint16_t*)SCIF1_SCFSR) &= ~0x60;	/* TEND,TDFE clear */
	return(0);
}

int32_t GetCharSCIF1(char *inChar)
{
	do{
		if(0x91 & *((volatile uint16_t *)SCIF1_SCFSR))
			*((volatile uint16_t *)SCIF1_SCFSR) &= ~0x91;
		if(0x01 & *((volatile uint16_t *)SCIF1_SCLSR))		//ORER check & clear
		{
			PutStr("ORER",1);								//ORER
			*((volatile uint16_t *)SCIF1_SCLSR) &= ~0x01;
		}
	}while( !(0x02 & *((volatile uint16_t *)SCIF1_SCFSR)) );
		*inChar = *((volatile uint8_t*)SCIF1_SCFRDR);
		*((volatile uint16_t*)SCIF1_SCFSR) &= ~0x02;
	return(0);
}

void PowerOnScif1(void)
{
	uint32_t dataL;

	dataL = *((volatile uint32_t*)CPG_MSTPSR2);
	if(dataL & BIT6){	// case SCIF1
		dataL &= ~BIT6;
		*((volatile uint32_t*)CPG_CPGWPR)    = ~dataL;
		*((volatile uint32_t*)CPG_SMSTPCR2)  =  dataL;
		while( BIT6 & *((volatile uint32_t*)CPG_MSTPSR2) );  // wait bit=0
	}
}

void WaitPutScif1SendEnd(void)
{
	uint16_t dataW;
    uint32_t loop;

	loop=1;
    while(loop){
		dataW = *((volatile uint16_t*)SCIF1_SCFSR);
		if(dataW & BIT6)	loop = 0;
	}
}

void InitScif1_SCIFCLK(void)
{
	uint16_t dataW;

	PowerOnScif1();

	dataW = *((volatile uint16_t*)SCIF1_SCLSR);	/* dummy read     		*/
	*((volatile uint16_t*)SCIF1_SCLSR) = 0x0000;	/* clear ORER bit 		*/
	*((volatile uint16_t*)SCIF1_SCFSR) = 0x0000;	/* clear all error bit	*/

	*((volatile uint16_t*)SCIF1_SCSCR) = 0x0000;	/* clear SCR.TE & SCR.RE*/
	*((volatile uint16_t*)SCIF1_SCFCR) = 0x0006;	/* reset tx-fifo, reset rx-fifo. */

	*((volatile uint16_t*)SCIF1_SCSCR) = 0x0002;	/* external clock, SC_CLK pin used for input pin */
	*((volatile uint16_t*)SCIF1_SCSMR) = 0x0000;	/* 8bit data, no-parity, 1 stop, Po/1 */
	SoftDelay(100);
//	*((volatile uint16_t*)SCIF1_DL)    = 0x0018;	/* 14.7456MHz/ ( 38400*16) = 24 */
	*((volatile uint16_t*)SCIF1_DL)    = 0x0008;	/* 14.7456MHz/ (115200*16) =  8 */
	*((volatile uint16_t*)SCIF1_CKS)   = 0x0000;	/*  select scif_clk	 */
	SoftDelay(100);
	*((volatile uint16_t*)SCIF1_SCFCR) = 0x0000;	/* reset-off tx-fifo, rx-fifo. */
	*((volatile uint16_t*)SCIF1_SCSCR) = 0x0032;	/* enable TE, RE; SC_CLK=input */
	SoftDelay(100);
}

void SetScif1_DL(uint16_t setData)
{
	//							setData
	// 14.7456MHz/ ( 38400*16) =  24  �����ݒ�l Gen2
	// 14.7456MHz/ (115200*16) =   8  �����ݒ�l Salvator-X 
	// 14.7456MHz/ (921600*16) =   1

	*((volatile uint16_t*)SCIF1_DL)    = setData;
}
