	.ALIGN	4
		.global		GO_COM

GO_COM:
    MOV    X1, X0

;#---------------------------------------------
;# Disable the instruction cache, stack pointer
;# and data access alignment checks
;# ---------------------------------------------
;#	mov x1, #(SCTLR_I_BIT | SCTLR_A_BIT | SCTLR_SA_BIT)
	mrs x0, sctlr_el3
	bic x0, x0, #(0x1 << 12)
	msr sctlr_el3, x0
	isb

CleaningAndInvalidateICache:
	IC IALLUIS
	ISB SY

	BR	   X1

	.END

