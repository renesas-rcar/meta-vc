;####################################################################################################
;#//
;#//  Copyright(C) Renesas Electronics Corp. All rights reserved.
;#//
;#//  HARDWARE        : Salvator   ( R-Car H3_SiP /  R-Car M3_SiP )
;#//                  : Kriek      ( R-Car M3  )
;#//                  : StarterKit ( R-Car H3_SiP /  R-Car M3_SiP )
;#//                  : Eagle      ( R-Car V3M )
;#//                  : Condor     ( R-Car V3H )
;#//  FUNCTIONS       : MiniMonitor
;#//  AUTHOR          : Renesas Electronics Corp.
;#//  NOTES           :
;#//
;####################################################################################################

;# W0-W30 : 32bit Register (W30=Link Register)
;# X0-X30 : 64bit Register (X30=Link Register)
;# WZR    : 32bit Zero Register
;# XZR    : 64bit Zero Register
;# WSP    : 32bit Stack Pointer
;# SP     : 64bit Stack Pointer

	.INCLUDE		"boot_mon.h"
	.ALIGN	4


	.extern		SP_ADDR

    .global     P_START
	.type		P_START, %function

;#---CACHE_SET--------------------------------------------------------------------------------------
.equ 	CACHE_MODE,ENABLE			;# ENABLE
;#.equ 	CACHE_MODE,DISABLE			;# DISABLE
;#--------------------------------------------------------------------------------------------------

P_START:
;# Initialize registers
    mov x0,  #0
    mov x1,  #0
    mov x2,  #0
    mov x3,  #0
    mov x4,  #0
    mov x5,  #0
    mov x6,  #0
    mov x7,  #0
    mov x8,  #0
    mov x9,  #0
    mov x10, #0
    mov x11, #0
    mov x12, #0
    mov x13, #0
    mov x14, #0
    mov x15, #0
    mov x16, #0
    mov x17, #0
    mov x18, #0
    mov x19, #0
    mov x20, #0
    mov x21, #0
    MOV x22,x0
    MOV x23,x0
    MOV x24,x0
    MOV x25,x0
    MOV x26,x0
    MOV x27,x0
    MOV x28,x0
    MOV x29,x0
    MOV x30,x0

Set_EnableRAM:
	LDR		X0,	=0xE67F0018
	LDR		W1, =0x00000001			;#Resource Alloc On
	STR		W1, [X0]

#    LDR x0, =0xE6330000
#    LDR x0, =0xE6320000
    LDR x0, =SP_ADDR
    MSR SP_EL0,x0
    MSR SP_EL1,x0
    MSR SP_EL2,x0
    MOV sp,x0
    MSR ELR_EL1,x0
    MSR ELR_EL2,x0
    MSR ELR_EL3,x0
    MSR SPSR_EL1,x0
    MSR SPSR_EL2,x0
    MSR SPSR_EL3,x0


;# RWDT and Secure WDT Disable setting.
.ifdef Area0Boot
Init_set_WDT:
	LDR		W0,	=RWDT_RWTCSRA
	LDR		W1, =0xA5A5A500			;#Timer disabled
	STR		W1, [X0]

Init_set_SYSWDT:
	LDR		W0,	=SYSWDT_WTCSRA
	LDR		W1, =0xA5A5A500			;#Timer  disabled (Enable -> disabled)
	STR		W1, [X0]
.endif


.ifdef Scif0Boot
Init_set_WDT:
	LDR		W0,	=RWDT_RWTCSRA
	LDR		W1, =0xA5A5A500			;#Timer disabled
	STR		W1, [X0]

Init_set_SYSWDT:
	LDR		W0,	=SYSWDT_WTCSRA
	LDR		W1, =0xA5A5A500			;#Timer  disabled (Enable -> disabled)
	STR		W1, [X0]
.endif


.IF CACHE_MODE == ENABLE
;#---------------------------------------------
;# Enable the instruction cache, stack pointer
;# and data access alignment checks
;# ---------------------------------------------
;#	mov x1, #(SCTLR_I_BIT | SCTLR_A_BIT | SCTLR_SA_BIT)
	mrs x0, sctlr_el3
	orr x0, x0, #(0x1 << 12)
	orr x0, x0, #(0x1 <<  1)
	orr x0, x0, #(0x1 <<  3)
	msr sctlr_el3, x0
	isb
.ENDIF


;# Check Soc and Board
	BL	CheckSoCBoard
	BL	CheckBoardId_DataFF
;#	BL	RcarM3wEs1xWa

;# Board Initialize
	BL	SetScifFlagDefault

.ifdef Area0Boot
	BL Init_PFC_GPIO
	BL InitEtherPhyReset
	BL InitLBSC
	BL InitScif
	BL InitDramBoard
.endif

.ifdef Writer
	BL Init_PFC_GPIO
	BL InitEtherPhyReset
	BL InitLBSC
	BL InitScif
	BL InitDramBoard
.endif

.ifdef ScifBoot
	BL Init_PFC_GPIO
	BL InitEtherPhyReset
	BL InitScif
	BL InitDramBoard
.endif

Jmp_MAIN_C:
	BL	Main

	.END

