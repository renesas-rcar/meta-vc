void	InitSysMon( void );
