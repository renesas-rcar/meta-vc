/**********************************************************/
/* Sample program : GPIO initialization                   */
/* File Name      : boot_init_gpio.c                      */
/* Copyright (C) Renesas Electronics Corp. 2016.          */
/**********************************************************/

//=========================================================
//===== Setting for R-CarV3M ==============================
//=========================================================

#include "common.h"
#include "reg_rcargen3.h"
#include "boot_init_gpio_V3M.h"
#include "boardid.h"


void InitGPIO_V3M(void)
{
	InitPOSNEG();
	InitIOINTSEL();
	InitOUTDT();
	InitINOUTSEL();
}


static void InitPOSNEG(void)
{
	*((volatile uint32_t*)GPIO_POSNEG0)=0x00000000;
	*((volatile uint32_t*)GPIO_POSNEG1)=0x00000000;
	*((volatile uint32_t*)GPIO_POSNEG2)=0x00000000;
	*((volatile uint32_t*)GPIO_POSNEG3)=0x00000000;
	*((volatile uint32_t*)GPIO_POSNEG4)=0x00000000;
	*((volatile uint32_t*)GPIO_POSNEG5)=0x00000000;
}

static void InitIOINTSEL(void)
{
	*((volatile uint32_t*)GPIO_IOINTSEL0)=0x00000000;
	*((volatile uint32_t*)GPIO_IOINTSEL1)=0x00000000;
	*((volatile uint32_t*)GPIO_IOINTSEL2)=0x00000000;
	*((volatile uint32_t*)GPIO_IOINTSEL3)=0x00000000;
	*((volatile uint32_t*)GPIO_IOINTSEL4)=0x00000000;
	*((volatile uint32_t*)GPIO_IOINTSEL5)=0x00000000;
}

static void InitOUTDT(void)
{
//	*((volatile uint32_t*)GPIO_OUTDT0)=0x00000000;
	*((volatile uint32_t*)GPIO_OUTDT1)=0x00010000;
//	*((volatile uint32_t*)GPIO_OUTDT2)=0x00000000;
//	*((volatile uint32_t*)GPIO_OUTDT3)=0x00000000;
//	*((volatile uint32_t*)GPIO_OUTDT4)=0x00000000;
	*((volatile uint32_t*)GPIO_OUTDT5)=0x00007000;
}

static void InitINOUTSEL(void)
{
	*((volatile uint32_t*)GPIO_INOUTSEL0)=0x00000000;
	*((volatile uint32_t*)GPIO_INOUTSEL1)=0x00010000;
	*((volatile uint32_t*)GPIO_INOUTSEL2)=0x00000000;
	*((volatile uint32_t*)GPIO_INOUTSEL3)=0x00000000;
	*((volatile uint32_t*)GPIO_INOUTSEL4)=0x00000000;
	*((volatile uint32_t*)GPIO_INOUTSEL5)=0x00007000;
}
