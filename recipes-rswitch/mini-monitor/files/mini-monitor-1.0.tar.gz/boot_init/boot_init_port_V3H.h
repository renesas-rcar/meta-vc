void InitPORT_V3H(void);
void InitIPSR_Area0_V3H(void);
void InitIPSR_SPI_V3H(void);
void InitGPSR_Area0_V3H(void);
void InitGPSR_SPI_V3H(void);

static void InitMODSEL(void);
static void InitIPSR(void);
static void InitGPSR(void);
static void InitIOCTRL(void);
static void InitPUD(void);
static void InitPUEN(void);
