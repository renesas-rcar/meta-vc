.INCLUDE "SET_PARAMETER_D3E3.h"


.section .PARAMETER1,"a"
.long   AUTH_SELECT

.section .PARAMETER2,"a"
.long   WRITER_TYPE

.section .PARAMETER3,"a"
.long   WRITER_ADD

.section .PARAMETER4,"a"
.long   WRITER_SIZE

.section .PARAMETER5,"a"
.long   WRITER_ADD

.section .PARAMETER6,"a"
.long   WRITER_SIZE

.END
