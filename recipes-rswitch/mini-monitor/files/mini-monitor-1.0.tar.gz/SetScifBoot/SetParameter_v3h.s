.INCLUDE "SET_PARAMETER_V3H.h"


.section .PARAMETER1,"a"
.long   AUTH_SELECT

.section .PARAMETER2,"a"
.long   WRITER_TYPE

.section .PARAMETER3,"a"
.long   WRITER_ADD

.section .PARAMETER4,"a"
.long   WRITER_SIZE

.section .PARAMETER5,"a"
.long   WRITER_KYE_SIZE

.END
