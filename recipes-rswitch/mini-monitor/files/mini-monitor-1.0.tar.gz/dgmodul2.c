#include "common.h"
#include "dgtable.h"
#include "dgmodul1.h"
#include "dgmodul2.h"
#include "devdrv.h"

extern const com_menu MonCom[COMMAND_UNIT];
extern int32_t  gComNo;
extern uintptr_t gUMem[3];


void DisplayDump(uintptr_t stAdd,uintptr_t dumpSize,uint32_t  width)
{
#ifdef	COM_D_ON

	char buf[32],asciiBuf[20];
	uintptr_t readAdd,readData;
	uint32_t  blankCnt,byte_count;

	byte_count=0x0;

	/********* Dump Data 1Line All Display *********************/
	if(!((dumpSize&0x0000000F)==0x0000000F)){
		dumpSize=dumpSize|0x0000000F;
	}
	for(readAdd=stAdd;readAdd<=(stAdd+dumpSize);readAdd+=width){
		/********* Dump Address Display ************************/
		if((!(byte_count&0x0000000F))||(byte_count==0)){
			Data2HexAscii_64(readAdd,buf,CPU_BYTE_SIZE);
			PutStr(buf,0);
			PutStr("  ",0);
		}
		Get1ByteMem(readAdd,&readData,width);
		Data2HexAscii_64(readData,buf,(char)width);
		ChgDumpAsciiCode(readData,asciiBuf,(char)(byte_count&0xF),(char)width);
		/********* Dump Data Display blank ********************/
		if(!(byte_count&0x8)){
			PutStr(buf,0);
			for(blankCnt=0;blankCnt<width;blankCnt++) PutStr(" ",0);
		}
		else{
			for(blankCnt=0;blankCnt<width;blankCnt++) PutStr(" ",0);
			PutStr(buf,0);
		}
		if( ((width==SIZE_8BIT )&&((byte_count&0xF)==0xF))||
			((width==SIZE_16BIT)&&((byte_count&0xF)==0xE))||
			((width==SIZE_32BIT)&&((byte_count&0xF)==0xC))||
			((width==SIZE_64BIT)&&((byte_count&0xF)==0x8))  ){
				ChgDumpAsciiStr(asciiBuf);
				PutStr("  ",0);
				PutStr(asciiBuf,1);
		}
		byte_count+=width;
	}

#endif
}

void ChgDumpAsciiCode(uintptr_t chCode,char *buf,char chPtr,uint32_t width)
{
	unsigned char tmpBCode,i;
	uintptr_t tmpLCode;

	switch(width){
	case SIZE_8BIT:
		tmpLCode = 0xFF & chCode;
		tmpBCode = (unsigned char)tmpLCode;
		if((0x20<=tmpBCode)&&(tmpBCode<=0x7E)){
			*((unsigned char *)(buf+chPtr)) = tmpBCode;
		}
		else{
			*((unsigned char *)(buf+chPtr)) = '.';
		}
		break;
	case SIZE_16BIT:
		for(i=0;i<width;i++){
			tmpLCode = chCode;
			tmpLCode = 0xFF & (tmpLCode>>(8-(i*8)));
			tmpBCode = (unsigned char)tmpLCode;
			if((0x20<=tmpBCode)&&(tmpBCode<=0x7E)){
				*((unsigned char *)(buf+i+chPtr)) = tmpBCode;
			}
			else{
				*((unsigned char *)(buf+i+chPtr)) = '.';
			}
		}
		break;
	case SIZE_32BIT:
		for(i=0;i<width;i++){
			tmpLCode = chCode;
			tmpLCode = 0xFF & (tmpLCode>>(24-(i*8)));
			tmpBCode = (unsigned char)tmpLCode;
			if((0x20<=tmpBCode)&&(tmpBCode<=0x7E)){
				*((unsigned char *)(buf+i+chPtr)) = tmpBCode;
			}
			else{
				*((unsigned char *)(buf+i+chPtr)) = '.';
			}
		}
		break;
	case SIZE_64BIT:
		for(i=0;i<width;i++){
			tmpLCode = chCode;
			tmpLCode = 0xFF & (tmpLCode>>(56-(i*8)));
			tmpBCode = (unsigned char)tmpLCode;
			if((0x20<=tmpBCode)&&(tmpBCode<=0x7E)){
				*((unsigned char *)(buf+i+chPtr)) = tmpBCode;
			}
			else{
				*((unsigned char *)(buf+i+chPtr)) = '.';
			}
		}
		break;
	}
}
void ChgDumpAsciiStr(char *buf)
{
	unsigned char i;
	buf[18]=0; buf[17]=0x22;
	for(i=16;i>0;i--){
		buf[i]=buf[i-1];
	}
	buf[0] = 0x22;
}

void Get1ByteMem(uintptr_t readAdd,uintptr_t *readData,uint32_t  width)
{
	unsigned char tmpB;
	uint16_t tmpW;
	uint32_t tmpL;
	uint64_t tmpX;
	
	switch(width){
		case SIZE_8BIT:
			tmpB = *((volatile uint8_t *)readAdd);
			*readData = (uintptr_t)tmpB;
			break;
		case SIZE_16BIT:
			tmpW = *((volatile uint16_t *)readAdd);
			*readData = (uintptr_t)tmpW;
			break;
		case SIZE_32BIT:
			tmpL = *((volatile uint32_t *)readAdd);
			*readData = (uintptr_t)tmpL;
			break;
		case SIZE_64BIT:
			tmpX = *((volatile uint64_t *)readAdd);
			*readData = (uintptr_t)tmpX;
			break;
	}
}
void Put1ByteMem(uintptr_t writeAdd,uintptr_t writeData,uint32_t width)
{
	uint8_t tmpB;
	uint16_t tmpW;
	uint32_t tmpL;

	switch(width){
		case SIZE_8BIT:
			tmpB = (uint8_t)writeData;
			*((volatile uint8_t *)writeAdd) = tmpB;
			break;
		case SIZE_16BIT:
			tmpW = (uint16_t)writeData;
			*((volatile uint16_t *)writeAdd) = tmpW;
			break;
		case SIZE_32BIT:
			tmpL = (uint32_t)writeData;
			*((volatile uint32_t *)writeAdd) = tmpL;
			break;
		case SIZE_64BIT:
			*((uint64_t *)writeAdd) = writeData;
			break;
	}
}

void DisplayMemEd(uintptr_t mem1st,uint32_t width,uint32_t verifyFlg)
{
#ifdef COM_M_ON

	uintptr_t readData,wrData;
	char mEnd,buf[32],key[32],chCnt,chPtr;

	mEnd = 0;
		while(!mEnd){
			Data2HexAscii_64(mem1st,buf,CPU_BYTE_SIZE);
			PutStr(buf,0); PutStr(" ",0);
			Get1ByteMem(mem1st,&readData,width);
			Data2HexAscii_64(readData,buf,(char)width);
			PutStr(buf,0); PutStr(" ? ",0);
			GetStr_MemEd(key,&chCnt);
			chPtr=0;
			if(!GetStrBlk(key,buf,&chPtr,0)){
				if(chPtr==1){								/* Case Return */
					mem1st += width;
				}else if((buf[0]=='.')){					/* Case End */
					mEnd = 1;
				}else if((buf[0]=='^')){					/* Case ^ */
					mem1st -= width;
				}else if(chPtr > (char)((width<<1)+1) ){	/* Case Data Size Over */
					PutStr("Syntax Error",1);
				}else{
					if(HexAscii2Data_64((unsigned char*)buf,&wrData)){
						PutStr("Syntax Error",1);
					}else{									/* Case Mem Edit  */
						Put1ByteMem(mem1st,wrData,width);
						
						if(verifyFlg == VERIFY_ON){
							Get1ByteMem(mem1st,&readData,width);
							if(wrData!=readData)	PutStr("Verify Error",1);
						}
						mem1st += width;
					}
				}
			}else{
				PutStr("Syntax Error",1);
			}
		}
	gUMem[0] = mem1st;

#endif
}
