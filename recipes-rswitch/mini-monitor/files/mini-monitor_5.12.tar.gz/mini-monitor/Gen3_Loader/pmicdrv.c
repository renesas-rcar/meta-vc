#include "common.h"
#include "i2cdrv.h"
#include "pmicdrv.h"
#include "reg_rcargen3.h"
#include "cpudrv.h"
#include "boardid.h"
#include "init_board.h"
#include "iicdrv.h"


//#ifdef COM_IIC_ON		//ifdef COM_IIC_ON �i�{�h���C�o�t�@�C���S�āj

extern uint32_t gPmicRev;
#if 0
uint32_t GetPmicEepromFwRev(void)
{
	uint32_t rdData;

	InitIic(EEPROM_IIC);		// IIC������
	RandomAddressReadIic(EEPROM_IIC,EEPROM_I2C_SLA,0x01,&rdData,1);  // �f�[�^�ǂݏo��

	return rdData;
}
#endif

uint32_t GetPmicRev(void)
{
	uint32_t rdData;

	InitIic(PMIC_IIC);		// IIC������
	RandomAddressReadIic(PMIC_IIC,PMIC_IIC_SLA,PMIC_PRODUCT_REV,&rdData,1);  // �f�[�^�ǂݏo��

	return rdData;
}



static void SetPmicVoltage(uint32_t addr, uint32_t volt)
{
//AVS VD09 VID0 (0x32)�̂�
	PageWriteIic(PMIC_IIC,PMIC_IIC_SLA,addr,&volt,1);  // Data Write
//	if(addr==PMIC_AVS_VD09_VID0){
//		PageWriteIic(PMIC_IIC,PMIC_IIC_SLA,addr+1,&volt,1);  // Data Write AVS VD09 VID1
//		PageWriteIic(PMIC_IIC,PMIC_IIC_SLA,addr+2,&volt,1);  // Data Write AVS VD09 VID2
//		PageWriteIic(PMIC_IIC,PMIC_IIC_SLA,addr+3,&volt,1);  // Data Write AVS VD09 VID3
//	}
}


static void UnlockPmic(void)
{
	uint32_t addr, data;

//	if( CHK_PMIC_OLD ) return;

	// VD18, VD25, VD33, DVFS, VDD
	addr = PMIC_ACCESS_KEY;
	data = 0x8E;
	PageWriteIic(PMIC_IIC,PMIC_IIC_SLA,addr,&data,1);

	addr = PMIC_WRITE_PROTECT;
	data = 0x9D;
	PageWriteIic(PMIC_IIC,PMIC_IIC_SLA,addr,&data,1);

	// DVFS
//	addr = PMIC_DVFS_SET_VMAX;
//	data = 0x7F;
//	PageWriteIic(PMIC_I2C,PMIC_IIC_SLA,addr,&data,1);

	// VDD
	addr = PMIC_AVS_SET_MONI;
	RandomAddressReadIic(PMIC_IIC,PMIC_IIC_SLA,addr,&data,1);
	data |= 0x20;		// BIT5 = AVS_VD09_EN
	PageWriteIic(PMIC_IIC,PMIC_IIC_SLA,addr,&data,1);
}


uint32_t gPmicRev;

void RcarM3nWa(void)
{
	if(CHK_M3N_ES10){
		ChangePmicVdd();
	}
}

void ChangePmicVdd(void)
{
	char str[64];
	uint32_t fwRev;
	uint32_t volt,addr;


	gPmicRev = GetPmicRev();
	PutStr("",1);
	PutStr(" PMIC-Product Revision : ",0);
	Data2HexAscii(gPmicRev,str,1);		
	PutStr(str,1);

	if(!(gPmicRev<=PMIC_REV01))	{	//NEW_PMIC
		PutStr(" UnlockPMIC",1);
		UnlockPmic();
	}
	PutStr(" Change VDD=0.82V (AVS VD09 VID0=0x52) ",1);
	addr = PMIC_AVS_VD09_VID0;
	volt = 0x52;		//0.82V
	SetPmicVoltage(addr, volt);

	StartTMU0usec(3);		// Wait 30us  (�d���J�ڎ��Ԃ�10mV/us = 0.82-0.75=0.07  ��7us�ȏ�m�ۗv)

}

//#endif
