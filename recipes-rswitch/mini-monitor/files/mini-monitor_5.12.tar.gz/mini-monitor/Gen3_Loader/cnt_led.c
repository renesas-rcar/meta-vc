#include "common.h"
#include "reg_rcargen3.h"
#include "cnt_led.h"
#include "bit.h"
#include "boardid.h"


const void* const PFC_GPSR[8]={
	(void*)PFC_GPSR0,
	(void*)PFC_GPSR1,
	(void*)PFC_GPSR2,
	(void*)PFC_GPSR3,
	(void*)PFC_GPSR4,
	(void*)PFC_GPSR5,
	(void*)PFC_GPSR6,
	(void*)PFC_GPSR7,
};

const void* const GPIO_INOUTSEL[8]={
	(void*)GPIO_INOUTSEL0,
	(void*)GPIO_INOUTSEL1,
	(void*)GPIO_INOUTSEL2,
	(void*)GPIO_INOUTSEL3,
	(void*)GPIO_INOUTSEL4,
	(void*)GPIO_INOUTSEL5,
	(void*)GPIO_INOUTSEL6,
	(void*)GPIO_INOUTSEL7,
};


const void* const GPIO_OUTDT[8]={
	(void*)GPIO_OUTDT0,
	(void*)GPIO_OUTDT1,
	(void*)GPIO_OUTDT2,
	(void*)GPIO_OUTDT3,
	(void*)GPIO_OUTDT4,
	(void*)GPIO_OUTDT5,
	(void*)GPIO_OUTDT6,
	(void*)GPIO_OUTDT7,
};


uint32_t CntLedNR(void)
{

	int32_t i,cnt,n;

//	InitSoftLedGpioOutputPinFunction();

	for(i=0;i<LED_COUNT;i++){
		CtrlLed(i,0);		// �SLED��OFF
	}

	while(1){
		cnt=1;
		for(n=1;n<=2;n++){
			for(i=0;i<LED_COUNT;i++){
				CtrlLed(i,cnt);
				SoftTimer(0x800000);
			}
			cnt=0;
		}
		cnt=1;
		for(n=1;n<=2;n++){
			for(i=2;i>=0;i--){
				CtrlLed(i,cnt);
				SoftTimer(0x800000);
			}
			cnt=0;
		}
	__asm__ __volatile__ ("WFI");
	}
}


void SetGpioOutputLevel( uint32_t gp, uint32_t bit, uint32_t lvl )
{
	if(lvl)	*((volatile uint32_t*)GPIO_OUTDT[gp]) |=  (1<<bit);
	else	*((volatile uint32_t*)GPIO_OUTDT[gp]) &= ~(1<<bit);
}

// ledSel: 0����n�܂�A�ԁALED�̖��O(LED1,LED6��)�̓w�b�_��define�Őݒ�
// onFlag: 0=OFF/1=ON
void CtrlLed( uint32_t ledSel, uint32_t onFlag )
{
	if(CHK_SALVATOR){
		switch(ledSel){
			case 0:
				if( onFlag ) SetGpioOutputLevel(6,11,1);
				else		 SetGpioOutputLevel(6,11,0);	break;
			case 1:
				if( onFlag ) SetGpioOutputLevel(6,12,1);
				else		 SetGpioOutputLevel(6,12,0);	break;
			case 2:
				if( onFlag ) SetGpioOutputLevel(6,13,1);
				else		 SetGpioOutputLevel(6,13,0);	break;
		}
	}else if (CHK_CONDOR){
		switch(ledSel){
			case 0:
				if( onFlag ) SetGpioOutputLevel(5,12,1);
				else		 SetGpioOutputLevel(5,12,0);	break;
			case 1:
				if( onFlag ) SetGpioOutputLevel(5,13,1);
				else		 SetGpioOutputLevel(5,13,0);	break;
			case 2:
				if( onFlag ) SetGpioOutputLevel(5,14,1);
				else		 SetGpioOutputLevel(5,14,0);	break;
		}
	}
}


void SoftTimer(uint32_t loop)
{
	uint32_t i;
	
	for(i = 0; i < loop; i=i+40);
}