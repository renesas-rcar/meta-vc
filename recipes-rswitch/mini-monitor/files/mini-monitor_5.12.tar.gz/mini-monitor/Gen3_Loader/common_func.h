/**********************************************************/
/* Sample program : R-CarH3 Common Header                 */
/* File Name      : common.h                              */
/* Copyright (C) Renesas Electronics Corp. 2015.          */
/**********************************************************/
#ifndef	__COMMON_FUNC_
#define	__COMMON_FUNC_

#define		DIS_RTN			0			/* Disable Return		*/
#define		ENB_RTN			1			/* Enable Return		*/

#define		INT_CODE		0x25		/* "%"					*/
#define		BS_CODE			0x08		/* "BS"					*/
#define		CR_CODE			0x0d		/* "CR"					*/
#define		SP_CODE			0x20		/* "LF"					*/
#define		LF_CODE			0x0a		/* "LF"					*/

#define		SIZE_8BIT		1			// Old name : BYTE_SIZE
#define		SIZE_16BIT		2			// Old name : WORD_SIZE
#define		SIZE_32BIT		4			// Old name : LONG_SIZE
#define		SIZE_64BIT		8			// New

int32_t PutMess(const char *const mess[]);
int32_t PutStr(const char *str,char rtn);
void DelStr(int32_t delCnt);
char Data2HexAscii(uint32_t data,char *buf,char size);
void SoftDelay(uint32_t loop);
char *memcpy(char *s1,char *s2,unsigned long n);
uint64_t __aeabi_llsl(uint64_t val, uint32_t shift);
uint64_t __aeabi_llsr(uint64_t val, uint32_t shift);

#endif /* __COMMON_FUNC_ */