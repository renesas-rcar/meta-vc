/*
 * Copyright (c) 2015-2018, Renesas Electronics Corporation. All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <mmio.h>
#include <debug.h>
#include "ddr_regdef.h"
#include "init_dram_tbl_m3.h"
#include "init_dram_tbl_m3n.h"
#include "boot_init_dram_regdef.h"
#include "boot_init_dram.h"
#include "dram_sub_func.h"
#include "micro_wait.h"

//#define DDR_BACKUPMODE
//#define ddr_qos_init_setting	// only for non qos_init

  #define FATAL_MSG(x) NOTICE(x)
/*******************************************************************************
 *	variables
 ******************************************************************************/
#ifndef RCAR_AUTO
  #define RCAR_AUTO	99
  #define RCAR_H3	0
  #define RCAR_M3	1
  #define RCAR_M3N	2
  #define RCAR_E3	3	// NON
  #define RCAR_H3N	4

  #define RCAR_CUT_10	0
  #define RCAR_CUT_11	1
  #define RCAR_CUT_20	10
  #define RCAR_CUT_30	20
#endif
#ifndef RCAR_LSI
  #define RCAR_LSI	RCAR_AUTO
#endif
#if(RCAR_LSI==RCAR_AUTO)
	static uint32_t Prr_Product;
	static uint32_t Prr_Cut;
#else
  #if(RCAR_LSI==RCAR_M3)
	static const uint32_t Prr_Product	= PRR_PRODUCT_M3;
  #elif(RCAR_LSI==RCAR_M3N)
	static const uint32_t Prr_Product	= PRR_PRODUCT_M3N;
  #endif//RCAR_LSI

  #ifndef RCAR_LSI_CUT
	static uint32_t Prr_Cut;
  #else//RCAR_LSI_CUT
    #if(RCAR_LSI_CUT==RCAR_CUT_10)
	static const uint32_t Prr_Cut		= PRR_PRODUCT_10;
    #elif(RCAR_LSI_CUT==RCAR_CUT_11)
	static const uint32_t Prr_Cut		= PRR_PRODUCT_11;
    #elif(RCAR_LSI_CUT==RCAR_CUT_20)
	static const uint32_t Prr_Cut		= PRR_PRODUCT_20;
    #elif(RCAR_LSI_CUT==RCAR_CUT_30)
	static const uint32_t Prr_Cut		= PRR_PRODUCT_30;
    #endif//RCAR_LSI_CUT
  #endif//RCAR_LSI_CUT
#endif//RCAR_AUTO_NON

char *pRCAR_DDR_VERSION;
uint32_t _cnf_BOARDTYPE;
static uint32_t *pDDR_REGDEF_TBL;
static uint32_t brd_clk;
static uint32_t brd_clkdiv;
static uint32_t brd_clkdiva;
static uint32_t ddr_mbps;
static uint32_t ddr_mbpsdiv;
static uint32_t ddr_tccd;
static struct _boardcnf *Boardcnf;
uint32_t ddr_phyvalid;
uint32_t ddr_density[DRAM_CH_CNT][CS_CNT];
static uint32_t ch_have_this_cs[CS_CNT];
static uint32_t max_density;
static uint32_t max_cs;
static uint32_t ddr_mul;
static uint32_t ddr_mbps;
static uint8_t  ddr_3lmode;
static uint8_t  use_speed_bins;
static uint32_t	DDR_PHY_SLICE_REGSET_OFS;
static uint32_t DDR_PHY_ADR_V_REGSET_OFS;
static uint32_t DDR_PHY_ADR_I_REGSET_OFS;
static uint32_t DDR_PHY_ADR_G_REGSET_OFS;
static uint32_t DDR_PI_REGSET_OFS;
static uint32_t DDR_PHY_SLICE_REGSET_SIZE;
static uint32_t DDR_PHY_ADR_V_REGSET_SIZE;
static uint32_t DDR_PHY_ADR_I_REGSET_SIZE;
static uint32_t DDR_PHY_ADR_G_REGSET_SIZE;
static uint32_t DDR_PI_REGSET_SIZE;
static uint32_t DDR_PHY_SLICE_REGSET_NUM;
static uint32_t DDR_PHY_ADR_V_REGSET_NUM;
static uint32_t DDR_PHY_ADR_I_REGSET_NUM;
static uint32_t DDR_PHY_ADR_G_REGSET_NUM;
static uint32_t DDR_PI_REGSET_NUM;
static uint32_t	DDR_PHY_ADR_I_NUM;
#define DDR_PHY_REGSET_MAX 128
#define DDR_PI_REGSET_MAX 320
static uint32_t _cnf_DDR_PHY_SLICE_REGSET[DDR_PHY_REGSET_MAX];
static uint32_t _cnf_DDR_PHY_ADR_V_REGSET[DDR_PHY_REGSET_MAX];
static uint32_t _cnf_DDR_PHY_ADR_I_REGSET[DDR_PHY_REGSET_MAX];
static uint32_t _cnf_DDR_PHY_ADR_G_REGSET[DDR_PHY_REGSET_MAX];
static uint32_t _cnf_DDR_PI_REGSET[DDR_PI_REGSET_MAX];

#define DDR_PHY_LOOP_MAX 4

#ifdef DDR_BACKUPMODE
uint32_t ddrBackup;
#endif

#ifdef ddr_qos_init_setting // only for non qos_init
#define OPERATING_FREQ			(400U)		//Mhz
#define BASE_SUB_SLOT_NUM		(0x6U)
#define SUB_SLOT_CYCLE			(0x7EU)		//126
#define QOSWT_WTSET0_CYCLE		((SUB_SLOT_CYCLE * BASE_SUB_SLOT_NUM * 1000U)/OPERATING_FREQ)	//unit:ns

uint32_t get_refperiod(void)
{
	return QOSWT_WTSET0_CYCLE;
}
#else// ddr_qos_init_setting // only for non qos_init
extern uint32_t get_refperiod(void);
#endif//ddr_qos_init_setting // only for non qos_init

#define _reg_PHY_RX_CAL_X_NUM 11
static const uint32_t _reg_PHY_RX_CAL_X[_reg_PHY_RX_CAL_X_NUM] = {
	_reg_PHY_RX_CAL_DQ0,
	_reg_PHY_RX_CAL_DQ1,
	_reg_PHY_RX_CAL_DQ2,
	_reg_PHY_RX_CAL_DQ3,
	_reg_PHY_RX_CAL_DQ4,
	_reg_PHY_RX_CAL_DQ5,
	_reg_PHY_RX_CAL_DQ6,
	_reg_PHY_RX_CAL_DQ7,
	_reg_PHY_RX_CAL_DM,
	_reg_PHY_RX_CAL_DQS,
	_reg_PHY_RX_CAL_FDBK
};

#define _reg_PHY_CLK_WRX_SLAVE_DELAY_NUM 10
static const uint32_t _reg_PHY_CLK_WRX_SLAVE_DELAY[_reg_PHY_CLK_WRX_SLAVE_DELAY_NUM] = {
	_reg_PHY_CLK_WRDQ0_SLAVE_DELAY,
	_reg_PHY_CLK_WRDQ1_SLAVE_DELAY,
	_reg_PHY_CLK_WRDQ2_SLAVE_DELAY,
	_reg_PHY_CLK_WRDQ3_SLAVE_DELAY,
	_reg_PHY_CLK_WRDQ4_SLAVE_DELAY,
	_reg_PHY_CLK_WRDQ5_SLAVE_DELAY,
	_reg_PHY_CLK_WRDQ6_SLAVE_DELAY,
	_reg_PHY_CLK_WRDQ7_SLAVE_DELAY,
	_reg_PHY_CLK_WRDM_SLAVE_DELAY,
	_reg_PHY_CLK_WRDQS_SLAVE_DELAY
};

#define _reg_PHY_RDDQS_X_FALL_SLAVE_DELAY_NUM 9
static const uint32_t _reg_PHY_RDDQS_X_FALL_SLAVE_DELAY[_reg_PHY_RDDQS_X_FALL_SLAVE_DELAY_NUM] = {
	_reg_PHY_RDDQS_DQ0_FALL_SLAVE_DELAY,
	_reg_PHY_RDDQS_DQ1_FALL_SLAVE_DELAY,
	_reg_PHY_RDDQS_DQ2_FALL_SLAVE_DELAY,
	_reg_PHY_RDDQS_DQ3_FALL_SLAVE_DELAY,
	_reg_PHY_RDDQS_DQ4_FALL_SLAVE_DELAY,
	_reg_PHY_RDDQS_DQ5_FALL_SLAVE_DELAY,
	_reg_PHY_RDDQS_DQ6_FALL_SLAVE_DELAY,
	_reg_PHY_RDDQS_DQ7_FALL_SLAVE_DELAY,
	_reg_PHY_RDDQS_DM_FALL_SLAVE_DELAY
};

#define _reg_PHY_RDDQS_X_RISE_SLAVE_DELAY_NUM 9
static const uint32_t _reg_PHY_RDDQS_X_RISE_SLAVE_DELAY[_reg_PHY_RDDQS_X_RISE_SLAVE_DELAY_NUM] = {
	_reg_PHY_RDDQS_DQ0_RISE_SLAVE_DELAY,
	_reg_PHY_RDDQS_DQ1_RISE_SLAVE_DELAY,
	_reg_PHY_RDDQS_DQ2_RISE_SLAVE_DELAY,
	_reg_PHY_RDDQS_DQ3_RISE_SLAVE_DELAY,
	_reg_PHY_RDDQS_DQ4_RISE_SLAVE_DELAY,
	_reg_PHY_RDDQS_DQ5_RISE_SLAVE_DELAY,
	_reg_PHY_RDDQS_DQ6_RISE_SLAVE_DELAY,
	_reg_PHY_RDDQS_DQ7_RISE_SLAVE_DELAY,
	_reg_PHY_RDDQS_DM_RISE_SLAVE_DELAY
};

#define _reg_PHY_PAD_TERM_X_NUM 9
static const uint32_t _reg_PHY_PAD_TERM_X[_reg_PHY_PAD_TERM_X_NUM] = {
	_reg_PHY_PAD_FDBK_TERM,
	_reg_PHY_PAD_DATA_TERM,
	_reg_PHY_PAD_DQS_TERM,
	_reg_PHY_PAD_ADDR_TERM,
	_reg_PHY_PAD_CLK_TERM,
	_reg_PHY_PAD_CKE_TERM,
	_reg_PHY_PAD_RST_TERM,
	_reg_PHY_PAD_CS_TERM,
	_reg_PHY_PAD_ODT_TERM
};

#define _reg_PHY_CLK_CACS_SLAVE_DELAY_X_NUM 10
static const uint32_t _reg_PHY_CLK_CACS_SLAVE_DELAY_X[_reg_PHY_CLK_CACS_SLAVE_DELAY_X_NUM] = {
	_reg_PHY_ADR0_CLK_WR_SLAVE_DELAY,
	_reg_PHY_ADR1_CLK_WR_SLAVE_DELAY,
	_reg_PHY_ADR2_CLK_WR_SLAVE_DELAY,
	_reg_PHY_ADR3_CLK_WR_SLAVE_DELAY,
	_reg_PHY_ADR4_CLK_WR_SLAVE_DELAY,
	_reg_PHY_ADR5_CLK_WR_SLAVE_DELAY,

	_reg_PHY_GRP_SLAVE_DELAY_0,
	_reg_PHY_GRP_SLAVE_DELAY_1,
	_reg_PHY_GRP_SLAVE_DELAY_2,
	_reg_PHY_GRP_SLAVE_DELAY_3
};

/*******************************************************************************
 *	Prototypes
 ******************************************************************************/
static inline int32_t vch_nxt(int32_t pos);
static void cpg_write_32(uint32_t a, uint32_t v);
static void pll3_control(void);
static inline void dsb_sev(void);
static void wait_dbcmd(void);
static void send_dbcmd(uint32_t cmd);
static uint32_t reg_ddrphy_read(uint32_t phyno, uint32_t regadd);
static void reg_ddrphy_write(uint32_t phyno, uint32_t regadd, uint32_t regdata);
static void reg_ddrphy_write_a(uint32_t regadd, uint32_t regdata);
static inline uint32_t ddr_regdef(uint32_t _regdef );
static inline uint32_t ddr_regdef_adr(uint32_t _regdef );
static inline uint32_t ddr_regdef_lsb(uint32_t _regdef );
static void ddr_setval_s(uint32_t ch, uint32_t slice, uint32_t _regdef, uint32_t val);
static uint32_t ddr_getval_s(uint32_t ch, uint32_t slice, uint32_t _regdef);
static void ddr_setval(uint32_t ch, uint32_t regdef, uint32_t val);
static void ddr_setval_ach_s(uint32_t slice, uint32_t regdef, uint32_t val);
static void ddr_setval_ach(uint32_t regdef, uint32_t val);
static void ddr_setval_ach_as(uint32_t regdef, uint32_t val);
static uint32_t ddr_getval(uint32_t ch, uint32_t regdef);
static uint32_t ddr_getval_ach(uint32_t regdef, uint32_t *p);
static uint32_t ddr_getval_ach_as(uint32_t regdef, uint32_t *p);
static void _tblcopy(uint32_t *to, const uint32_t *from, uint32_t size);
static void ddrtbl_setval(uint32_t *tbl, uint32_t _regdef, uint32_t val);
static uint32_t ddrtbl_getval(uint32_t *tbl, uint32_t _regdef);
static uint32_t ddrphy_regif_chk(void);
static inline void ddrphy_regif_idle();
static uint16_t _f_scale(uint32_t ddr_mbps, uint32_t ddr_mbpsdiv, uint32_t ps, uint16_t cyc);
static void _f_scale_js2(uint32_t ddr_mbps, uint32_t ddr_mbpsdiv, uint16_t *js2);
static int16_t _f_scale_adj(int16_t ps);
static void ddrtbl_load(void);
static void ddr_config_sub(void);
static void ddr_config(void);
static void dbsc_regset(void);
static void dbsc_regset_post(void);
static uint32_t dfi_init_start(void);
static uint32_t set_term_code(void) ;
static inline void set_dfifrequency(uint32_t freq);
static void update_dly(void);
static uint32_t pi_training_go(void);
static uint32_t init_ddr(void);

static int32_t _find_change(uint64_t val, uint32_t dir);
static uint32_t _rx_offset_cal_updn(uint32_t code);
static uint32_t rx_offset_cal(void);
static uint32_t rx_offset_cal_hw(void);

struct DdrtData {
	int32_t  init_temp;	// Initial Temperature (do)
	uint32_t init_cal[4];	// Initial io-code (4 is for H3)
	uint32_t tcomp_cal[4];	// Temperature compensated io-code (4 is for H3)
};
struct DdrtData tcal;

static void ddr_padcal_tcompensate_getinit(uint32_t override);

/*******************************************************************************
 *	load board configuration
 ******************************************************************************/
#include "boot_init_dram_config.c"

/*******************************************************************************
 *	macro for channel selection loop
 ******************************************************************************/
static inline int32_t vch_nxt(int32_t pos)
{
	int32_t posn;
	for(posn=pos;posn<DRAM_CH_CNT; posn++){
		if(ddr_phyvalid & (1U<<posn))break;
	}
	return posn;
}
#define foreach_vch(ch) \
for(ch=vch_nxt(0);ch<DRAM_CH_CNT;ch=vch_nxt(ch+1))

#define foreach_ech(ch) \
for(ch=0;ch<DRAM_CH_CNT;ch++)

/*******************************************************************************
 *	Printing functions
 ******************************************************************************/
#define MSG_LF(...)

/*******************************************************************************
 *	clock settings, reset control
 ******************************************************************************/
static void cpg_write_32(uint32_t a, uint32_t v)
{
	mmio_write_32(CPG_CPGWPR, ~v);
	mmio_write_32(a, v);
}

static void pll3_control(void)
{
	uint32_t dataL,dataDIV,dataMUL,tmpDIV;
	uint32_t pll3DIV,pll3MUL;

	tmpDIV  = (1000*ddr_mbpsdiv*brd_clkdiv*(brd_clkdiva+1))/(ddr_mul*brd_clk*ddr_mbpsdiv+1);
	dataMUL = ((ddr_mul * (tmpDIV +1)-1) << 24)|(brd_clkdiva << 7);

	if(tmpDIV){
		dataDIV = tmpDIV +1;
		dataDIV = (dataDIV <<16) | dataDIV;
	} else {
		dataDIV = 0;
	}

	pll3MUL = mmio_read_32(CPG_PLL3CR);
	pll3DIV = mmio_read_32(CPG_FRQCRD);

	if((dataDIV!=pll3DIV)||(dataMUL!=pll3MUL)) {
		/* PLL3 disable */
		dataL = (~CPG_PLLECR_PLL3E_BIT) & mmio_read_32(CPG_PLLECR);
		cpg_write_32(CPG_PLLECR, dataL);
		dsb_sev();
		if((Prr_Product==PRR_PRODUCT_M3)){
			/* PLL3 DIV resetting(Lowest value:3) */
			dataL= (0xFF80FF80 & mmio_read_32(CPG_FRQCRD));
			cpg_write_32(CPG_FRQCRD, 0x00030003|dataL);
			dsb_sev();

			/* zb3 clk stop */
			dataL = CPG_ZB3CKCR_ZB3ST_BIT | mmio_read_32(CPG_ZB3CKCR);
			cpg_write_32(CPG_ZB3CKCR, dataL);
			dsb_sev();

			/* PLL3 enable */
			dataL = CPG_PLLECR_PLL3E_BIT | mmio_read_32(CPG_PLLECR);
			cpg_write_32(CPG_PLLECR, dataL);
			dsb_sev();

			do {
				dataL = mmio_read_32(CPG_PLLECR);
			} while((dataL&CPG_PLLECR_PLL3ST_BIT)==0);
			dsb_sev();

			/* PLL3 DIV resetting (Highest value:0) */
			cpg_write_32(CPG_FRQCRD, pll3DIV);
			dsb_sev();

			/* DIV SET KICK */
			dataL = CPG_FRQCRB_KICK_BIT | mmio_read_32(CPG_FRQCRB);
			cpg_write_32(CPG_FRQCRB, dataL);
			dsb_sev();

			/* PLL3 multiplie set */
			cpg_write_32(CPG_PLL3CR, dataMUL);
			dsb_sev();

			do {
				dataL = mmio_read_32(CPG_PLLECR);
			} while((dataL&CPG_PLLECR_PLL3ST_BIT)==0);
			dsb_sev();

			/* PLL3 DIV resetting(Target value) */
			cpg_write_32(CPG_FRQCRD, dataDIV | pll3DIV);
			dsb_sev();

			/* DIV SET KICK */
			dataL = CPG_FRQCRB_KICK_BIT | mmio_read_32(CPG_FRQCRB);
			cpg_write_32(CPG_FRQCRB, dataL);
			dsb_sev();

			do {
				dataL = mmio_read_32(CPG_PLLECR);
			} while((dataL&CPG_PLLECR_PLL3ST_BIT)==0);
			dsb_sev();

			/* zb3 clk start */
			dataL= (~CPG_ZB3CKCR_ZB3ST_BIT) & mmio_read_32(CPG_ZB3CKCR);
			cpg_write_32(CPG_ZB3CKCR, dataL);
			dsb_sev();

		} else {
			/* PLL3 multiplie set */
			cpg_write_32(CPG_PLL3CR, dataMUL);
			dsb_sev();

			/* PLL3 DIV resetting */
			cpg_write_32(CPG_FRQCRD, dataDIV | pll3DIV);
			dsb_sev();

			/* DIV SET KICK */
			dataL = CPG_FRQCRB_KICK_BIT | mmio_read_32(CPG_FRQCRB);
			cpg_write_32(CPG_FRQCRB, dataL);
			dsb_sev();

			/* PLL3 enable */
			dataL = CPG_PLLECR_PLL3E_BIT | mmio_read_32(CPG_PLLECR);
			cpg_write_32(CPG_PLLECR, dataL);
			dsb_sev();

			do {
				dataL = mmio_read_32(CPG_PLLECR);
			} while((dataL&CPG_PLLECR_PLL3ST_BIT)==0);
			dsb_sev();
		}
	}
	return;
}

/*******************************************************************************
 *	barrier
 ******************************************************************************/
static inline void dsb_sev(void)
{
	__asm__ __volatile__ ("dsb sy");
}

/*******************************************************************************
 *	DDR memory register access
 ******************************************************************************/
static void wait_dbcmd(void)
{
	uint32_t dataL;

	/* dummy read */
	dataL = mmio_read_32(DBSC_DBCMD);
	dsb_sev();

	while(1)
	{
		/* wait DBCMD 1=busy, 0=ready */
		dataL = mmio_read_32(DBSC_DBWAIT);
		dsb_sev();
		if((dataL & 0x00000001) == 0x00) break;
	}
}

static void send_dbcmd(uint32_t cmd)
{
	/* dummy read */
	wait_dbcmd();
	mmio_write_32(DBSC_DBCMD, cmd);
	dsb_sev();
}

/*******************************************************************************
 *	DDRPHY register access (raw)
 ******************************************************************************/
static uint32_t reg_ddrphy_read(uint32_t phyno, uint32_t regadd)
{
	uint32_t val;
	uint32_t loop;

	if(Prr_Product==PRR_PRODUCT_M3){
		mmio_write_32(DBSC_DBPDRGA(phyno), regadd);
		dsb_sev();
		while(mmio_read_32(DBSC_DBPDRGA(phyno))!=regadd){dsb_sev();};
		val = mmio_read_32(DBSC_DBPDRGA(phyno));
		dsb_sev();

		for(loop=0;loop<DDR_PHY_LOOP_MAX;loop++){
			val = mmio_read_32(DBSC_DBPDRGD(phyno));
			dsb_sev();
		}
		(void)val;
	} else {
		mmio_write_32(DBSC_DBPDRGA(phyno), regadd|0x00004000);
		dsb_sev();
		while(mmio_read_32(DBSC_DBPDRGA(phyno))!=(regadd|0x0000C000)){dsb_sev();};
		val = mmio_read_32(DBSC_DBPDRGA(phyno));

		mmio_write_32(DBSC_DBPDRGA(phyno), regadd|0x00008000);
		while(mmio_read_32(DBSC_DBPDRGA(phyno))!=regadd){dsb_sev();};
		dsb_sev();

		mmio_write_32(DBSC_DBPDRGA(phyno), regadd|0x00008000);
		while(mmio_read_32(DBSC_DBPDRGA(phyno))!=regadd){dsb_sev();};
		dsb_sev();

		val = mmio_read_32(DBSC_DBPDRGD(phyno));
		dsb_sev();
		(void)val;
	}
	return val ;
}

static void reg_ddrphy_write(uint32_t phyno, uint32_t regadd, uint32_t regdata)
{
	uint32_t val;
	uint32_t loop;

	if(Prr_Product==PRR_PRODUCT_M3){
		mmio_write_32(DBSC_DBPDRGA(phyno), regadd);
		dsb_sev();
		while(mmio_read_32(DBSC_DBPDRGA(phyno))!=regadd){dsb_sev();};
		for(loop=0;loop<DDR_PHY_LOOP_MAX;loop++){
			val = mmio_read_32(DBSC_DBPDRGD(phyno));
			dsb_sev();
		}
		mmio_write_32(DBSC_DBPDRGD(phyno),regdata);
		dsb_sev();
		for(loop=0;loop<DDR_PHY_LOOP_MAX;loop++){
			val = mmio_read_32(DBSC_DBPDRGD(phyno));
			dsb_sev();
		}
	} else {
		mmio_write_32(DBSC_DBPDRGA(phyno), regadd);
		dsb_sev();

		while(mmio_read_32(DBSC_DBPDRGA(phyno))!=regadd){dsb_sev();};
		dsb_sev();

		mmio_write_32(DBSC_DBPDRGD(phyno), regdata);
		dsb_sev();

		while(mmio_read_32(DBSC_DBPDRGA(phyno))!=(regadd|0x00008000)){dsb_sev();};
		mmio_write_32(DBSC_DBPDRGA(phyno), regadd|0x00008000);

		while(mmio_read_32(DBSC_DBPDRGA(phyno))!=regadd){dsb_sev();};
		dsb_sev();

		mmio_write_32(DBSC_DBPDRGA(phyno), regadd);
	}
	(void)val;
}

static void reg_ddrphy_write_a(uint32_t regadd, uint32_t regdata)
{
	uint32_t ch;
	uint32_t val;
	uint32_t loop;

	if(Prr_Product==PRR_PRODUCT_M3){
		foreach_vch(ch){
			mmio_write_32(DBSC_DBPDRGA(ch), regadd);
			dsb_sev();
		}

		foreach_vch(ch){
			mmio_write_32(DBSC_DBPDRGD(ch), regdata);
			dsb_sev();
		}

		for(loop=0;loop<DDR_PHY_LOOP_MAX;loop++){
			val = mmio_read_32(DBSC_DBPDRGD(0));
			dsb_sev();
		}
		(void)val;
	} else {
		foreach_vch(ch){
			reg_ddrphy_write(ch, regadd, regdata);
			dsb_sev();
		}
	}
}

static inline void ddrphy_regif_idle()
{
	uint32_t val;
	val = reg_ddrphy_read(0, ddr_regdef_adr(_reg_PI_INT_STATUS));
	dsb_sev();
	(void)val;
}

/*******************************************************************************
 *	DDRPHY register access (field modify)
 ******************************************************************************/
static inline uint32_t ddr_regdef(uint32_t _regdef )
{
	return pDDR_REGDEF_TBL[_regdef];
}

static inline uint32_t ddr_regdef_adr(uint32_t _regdef )
{
	return DDR_REGDEF_ADR(pDDR_REGDEF_TBL[_regdef]);
}

static inline uint32_t ddr_regdef_lsb(uint32_t _regdef )
{
	return DDR_REGDEF_LSB(pDDR_REGDEF_TBL[_regdef]);
}

static void ddr_setval_s(uint32_t ch, uint32_t slice, uint32_t _regdef, uint32_t val)
{
	uint32_t adr;
	uint32_t lsb;
	uint32_t len;
	uint32_t msk;
	uint32_t tmp;
	uint32_t regdef;

	regdef = ddr_regdef(_regdef);
	adr = DDR_REGDEF_ADR(regdef)+0x80*slice;
	len = DDR_REGDEF_LEN(regdef);
	lsb = DDR_REGDEF_LSB(regdef);
	if(len==0x20)
		msk = 0xffffffff;
	else
		msk = ((1U<<len)-1)<<lsb;

	tmp = reg_ddrphy_read(ch, adr);
	tmp = (tmp & (~msk)) | ((val<<lsb) & msk);
	reg_ddrphy_write(ch, adr, tmp);
}

static uint32_t ddr_getval_s(uint32_t ch, uint32_t slice, uint32_t _regdef)
{
	uint32_t adr;
	uint32_t lsb;
	uint32_t len;
	uint32_t msk;
	uint32_t tmp;
	uint32_t regdef;

	regdef = ddr_regdef(_regdef);
	adr = DDR_REGDEF_ADR(regdef)+0x80*slice;
	len = DDR_REGDEF_LEN(regdef);
	lsb = DDR_REGDEF_LSB(regdef);
	if(len==0x20)
		msk = 0xffffffff;
	else
		msk = ((1U<<len)-1);

	tmp = reg_ddrphy_read(ch, adr);
	tmp = (tmp >> lsb) & msk;

	return tmp;
}

static void ddr_setval(uint32_t ch, uint32_t regdef, uint32_t val)
{
	ddr_setval_s(ch, 0, regdef, val);
}

static void ddr_setval_ach_s(uint32_t slice, uint32_t regdef, uint32_t val)
{
	uint32_t ch;

	foreach_vch(ch)
		ddr_setval_s(ch, slice, regdef, val);
}

static void ddr_setval_ach(uint32_t regdef, uint32_t val)
{
	ddr_setval_ach_s(0, regdef, val);
}

static void ddr_setval_ach_as(uint32_t regdef, uint32_t val)
{
	uint32_t slice;

	for(slice=0;slice<SLICE_CNT;slice++)
		ddr_setval_ach_s(slice, regdef, val);
}

static uint32_t ddr_getval(uint32_t ch, uint32_t regdef)
{
	return ddr_getval_s(ch, 0, regdef);
}

static uint32_t ddr_getval_ach(uint32_t regdef, uint32_t *p)
{
	uint32_t ch;

	foreach_vch(ch)
		p[ch] = ddr_getval_s(ch, 0, regdef);

	return p[0];
}

static uint32_t ddr_getval_ach_as(uint32_t regdef, uint32_t *p)
{
	uint32_t ch, slice;
	uint32_t *pp;

	pp = p;
	foreach_vch(ch)
		for(slice=0; slice<SLICE_CNT; slice++)
			*pp++ = ddr_getval_s(ch, slice, regdef);

	return p[0];
}

/*******************************************************************************
 *	handling functions for setteing ddrphy value table
 ******************************************************************************/
static void _tblcopy(uint32_t *to, const uint32_t *from, uint32_t size)
{
	uint32_t i;

	for(i=0;i<size;i++){
		to[i] = from[i];
	}
}

static void ddrtbl_setval(uint32_t *tbl, uint32_t _regdef, uint32_t val)
{
	uint32_t adr;
	uint32_t lsb;
	uint32_t len;
	uint32_t msk;
	uint32_t tmp;
	uint32_t adrmsk;
	uint32_t regdef;

	regdef = ddr_regdef(_regdef);
	adr = DDR_REGDEF_ADR(regdef);
	len = DDR_REGDEF_LEN(regdef);
	lsb = DDR_REGDEF_LSB(regdef);
	if(len==0x20)
		msk = 0xffffffff;
	else
		msk = ((1U<<len)-1)<<lsb;

	if(adr<0x400){
		adrmsk = 0xff;
	} else {
		adrmsk = 0x7f;
	}

	tmp = tbl[adr & adrmsk];
	tmp = (tmp & (~msk)) | ((val<<lsb) & msk);
	tbl[adr & adrmsk] = tmp;
}

static uint32_t ddrtbl_getval(uint32_t *tbl, uint32_t _regdef)
{
	uint32_t adr;
	uint32_t lsb;
	uint32_t len;
	uint32_t msk;
	uint32_t tmp;
	uint32_t adrmsk;
	uint32_t regdef;

	regdef = ddr_regdef(_regdef);
	adr = DDR_REGDEF_ADR(regdef);
	len = DDR_REGDEF_LEN(regdef);
	lsb = DDR_REGDEF_LSB(regdef);
	if(len==0x20)
		msk = 0xffffffff;
	else
		msk = ((1U<<len)-1);

	if(adr<0x400){
		adrmsk = 0xff;
	} else {
		adrmsk = 0x7f;
	}

	tmp = tbl[adr & adrmsk];
	tmp = (tmp >> lsb) & msk;

	return tmp;
}

/*******************************************************************************
 *	DDRPHY register access handling
 ******************************************************************************/
static uint32_t ddrphy_regif_chk(void)
{
	uint32_t tmp_ach[DRAM_CH_CNT];
	uint32_t ch;
	uint32_t err;
	uint32_t PI_VERSION_CODE;

	if(Prr_Product==PRR_PRODUCT_M3){
		PI_VERSION_CODE = 0x2041;
	} else {
		PI_VERSION_CODE = 0x2040;
	}

	ddr_getval_ach(_reg_PI_VERSION, (uint32_t *)tmp_ach);
	err = 0;
	foreach_vch(ch){
		if(PI_VERSION_CODE!=tmp_ach[ch])
			err = 1;
	}
	return err;
}

/*******************************************************************************
 *	functions and parameters for timing setting
 ******************************************************************************/
struct _jedec_spec2 {
	uint16_t ps;
	uint16_t cyc;
};

#define JS2_tRTP	0
#define JS2_tWTR	(JS2_tRTP	+1)
#define JS2_tWR		(JS2_tWTR	+1)
#define JS2_tMRD	(JS2_tWR	+1)
#define JS2_tMOD	(JS2_tMRD	+1)
#define JS2_tXS		(JS2_tMOD	+1)
#define JS2_tXSDLL	(JS2_tXS	+1)
#define JS2_tXPDLL	(JS2_tXSDLL	+1)
#define JS2_tIEdly	(JS2_tXPDLL	+1)
#define JS2_tZQoper	(JS2_tIEdly	+1)
#define JS2_tZQCS	(JS2_tZQoper	+1)
#define JS2_TBLCNT	(JS2_tZQCS	+1)

#define JS2_tRFC	(JS2_TBLCNT)
#define JS2_CNT		(JS2_TBLCNT	+1)

const struct _jedec_spec2 jedec_spec2[JS2_TBLCNT] = {
/*tRTP  */	{  7500 , 4 },
/*tWTR  */	{  7500 , 4 },
/*tWR   */	{ 15000 , 0 },
/*tMRD  */	{     0 , 4 },
/*tMOD  */	{ 15000 ,12 },
/*tXS   */	{ 10000 , 5 },	// =tRFC+10us,5
/*tXSDLL*/	{     0 ,512},
/*tXPDLL*/	{ 24000 ,10 },
/*tIEdly*/	{ 10000 , 0 },
/*tZQoper*/	{   320 ,256},
/*tZQCS */	{    80 ,64 }
};

const uint16_t jedec_spec2_tRFC[4] = {
/*	2Gb, 4Gb, 8Gb, TBD	*/
	160, 260, 350, 350
};

const uint8_t jedec_spec3_WR[2][17] = {
//	 0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15,16 [WR(cycle)]
	{5, 5, 5, 5, 5, 5, 6, 7, 8,10,10,12,12,14,14,16,16},
	{1, 1, 1, 1, 1, 1, 2, 3, 4, 5, 5, 6, 6, 7, 7, 0, 0}
};

static uint32_t js1_ind;
static uint16_t js2[JS2_CNT];
static uint8_t RL;
static uint8_t WL;

static uint16_t _f_scale(uint32_t ddr_mbps, uint32_t ddr_mbpsdiv, uint32_t ps, uint16_t cyc)
{
	uint32_t tmp;
	uint32_t div;

	tmp = ps * ddr_mbps;
	div = tmp / (2000000 * ddr_mbpsdiv);
	if(tmp != (div*2000000*ddr_mbpsdiv))
		div = div + 1;

	if(div>cyc)
		return (uint16_t)div;
	return cyc;
}

static void _f_scale_js2(uint32_t ddr_mbps, uint32_t ddr_mbpsdiv, uint16_t *js2)
{
	int i;

	for(i=0;i<JS2_TBLCNT-2;i++){
		js2[i] = _f_scale(ddr_mbps, ddr_mbpsdiv,
			1UL*jedec_spec2[i].ps,
			jedec_spec2[i].cyc);
	}
	for(i=JS2_TBLCNT-2;i<JS2_TBLCNT;i++){
		js2[i] = _f_scale(ddr_mbps, ddr_mbpsdiv,
			1000UL*jedec_spec2[i].ps,
			jedec_spec2[i].cyc);
	}

	if(js2[JS2_tIEdly]>=0x0e) js2[JS2_tIEdly] = 0x0e;
	if(js2[JS2_tWR]>=0x10) js2[JS2_tWR] = 0x10;
}

/* scaler for DELAY value */
static int16_t _f_scale_adj(int16_t ps)
{
	int32_t tmp;

	/*
	tmp = (int32_t)512 * ps * ddr_mbps /2 / ddr_mbpsdiv / 1000 / 1000;
            = ps * ddr_mbps /2 / ddr_mbpsdiv *512 / 8 / 8 / 125 / 125
            = ps * ddr_mbps / ddr_mbpsdiv *4 / 125 / 125
	*/
	tmp = (int32_t)4 * (int32_t)ps * (int32_t)ddr_mbps / (int32_t)ddr_mbpsdiv;
	tmp = (int32_t)tmp / (int32_t)15625;

	return (int16_t)tmp;
}

static uint32_t _reg_PI_MR0_DATA_Fx_CSx;

const uint32_t _reg_PI_MR1_DATA_Fx_CSx[2][CSAB_CNT] = {
	{
		_reg_PI_MR1_DATA_F0_0,
		_reg_PI_MR1_DATA_F0_1,
		_reg_PI_MR1_DATA_F0_2,
		_reg_PI_MR1_DATA_F0_3
	},
	{
		_reg_PI_MR1_DATA_F1_0,
		_reg_PI_MR1_DATA_F1_1,
		_reg_PI_MR1_DATA_F1_2,
		_reg_PI_MR1_DATA_F1_3
	}
};

const uint32_t _reg_PI_MR2_DATA_Fx_CSx[2][CSAB_CNT] = {
	{
		_reg_PI_MR2_DATA_F0_0,
		_reg_PI_MR2_DATA_F0_1,
		_reg_PI_MR2_DATA_F0_2,
		_reg_PI_MR2_DATA_F0_3
	},
	{
		_reg_PI_MR2_DATA_F1_0,
		_reg_PI_MR2_DATA_F1_1,
		_reg_PI_MR2_DATA_F1_2,
		_reg_PI_MR2_DATA_F1_3
	}
};

/*******************************************************************************
 * regif pll w/a   ( REGIF_H3WS2_WA )
 *******************************************************************************/
static void regif_pll_wa(void)
{
	uint32_t ch;

	reg_ddrphy_write_a(ddr_regdef_adr(_reg_PHY_PLL_WAIT), (0x5064U<<ddr_regdef_lsb(_reg_PHY_PLL_WAIT)));

	reg_ddrphy_write_a(ddr_regdef_adr(_reg_PHY_PLL_CTRL),
		(ddrtbl_getval(_cnf_DDR_PHY_ADR_G_REGSET, _reg_PHY_PLL_CTRL_TOP)<<16)|
		 ddrtbl_getval(_cnf_DDR_PHY_ADR_G_REGSET, _reg_PHY_PLL_CTRL));
	reg_ddrphy_write_a(ddr_regdef_adr(_reg_PHY_PLL_CTRL_CA),
		ddrtbl_getval(_cnf_DDR_PHY_ADR_G_REGSET, _reg_PHY_PLL_CTRL_CA));

	reg_ddrphy_write_a(ddr_regdef_adr(_reg_PHY_LP4_BOOT_PLL_CTRL),
		(ddrtbl_getval(_cnf_DDR_PHY_ADR_G_REGSET, _reg_PHY_LP4_BOOT_PLL_CTRL_CA)<<16)|
		 ddrtbl_getval(_cnf_DDR_PHY_ADR_G_REGSET, _reg_PHY_LP4_BOOT_PLL_CTRL));
	reg_ddrphy_write_a(ddr_regdef_adr(_reg_PHY_LP4_BOOT_TOP_PLL_CTRL),
		ddrtbl_getval(_cnf_DDR_PHY_ADR_G_REGSET, _reg_PHY_LP4_BOOT_TOP_PLL_CTRL));

	/* protect register interface */
	ddrphy_regif_idle();

	reg_ddrphy_write_a(ddr_regdef_adr(_reg_PHY_DLL_RST_EN), (0x1U<<ddr_regdef_lsb(_reg_PHY_DLL_RST_EN)));
	ddrphy_regif_idle();

	/***********************************************************************
	init start
	***********************************************************************/
	/* dbdficnt0:
	 * dfi_dram_clk_disable=1
	 * dfi_frequency = 0
	 * freq_ratio = 01 (2:1)
	 * init_start =0
	 */
	foreach_vch(ch)
		mmio_write_32(DBSC_DBDFICNT(ch), 0x00000F10);
	dsb_sev();

	/* dbdficnt0:
	 * dfi_dram_clk_disable=1
	 * dfi_frequency = 0
	 * freq_ratio = 01 (2:1)
	 * init_start =1
	 */
	foreach_vch(ch)
		mmio_write_32(DBSC_DBDFICNT(ch), 0x00000F11);
	dsb_sev();

	foreach_vch(ch)
		while((mmio_read_32(DBSC_PLL_LOCK(ch))&0x1f)!=0x1f);
	dsb_sev();

}

/*******************************************************************************
 *	load table data into DDR registers
 ******************************************************************************/
static void ddrtbl_load(void)
{
	int i;
	uint32_t slice;
	uint32_t csab;
	uint32_t adr;
	uint32_t dataL;
	uint16_t dataS;

	/***********************************************************************
	TIMING REGISTERS
	***********************************************************************/
	/* search jedec_spec1 index */
	for(i=0;i<JS1_FREQ_TBL_NUM-1;i++){
		if(js1[use_speed_bins][i].fx3 * 2 * ddr_mbpsdiv >= ddr_mbps*3)
			break;
	}
	if((JS1_FREQ_TBL_NUM-1)<i)
		js1_ind = JS1_FREQ_TBL_NUM-1;
	else
		js1_ind = i;

	RL = js1[use_speed_bins][js1_ind].RL;
	WL = js1[use_speed_bins][js1_ind].WL;

	/* calculate jedec_spec2 */
	_f_scale_js2(ddr_mbps, ddr_mbpsdiv, js2);

	/***********************************************************************
	PREPARE TBL
	***********************************************************************/
	if(Prr_Product==PRR_PRODUCT_M3N){
		_tblcopy(_cnf_DDR_PHY_SLICE_REGSET,
			DDR_PHY_SLICE_REGSET_M3N, DDR_PHY_SLICE_REGSET_NUM_M3N);
		_tblcopy(_cnf_DDR_PHY_ADR_V_REGSET,
			DDR_PHY_ADR_V_REGSET_M3N, DDR_PHY_ADR_V_REGSET_NUM_M3N);
		_tblcopy(_cnf_DDR_PHY_ADR_I_REGSET,
			DDR_PHY_ADR_I_REGSET_M3N, DDR_PHY_ADR_I_REGSET_NUM_M3N);
		_tblcopy(_cnf_DDR_PHY_ADR_G_REGSET,
			DDR_PHY_ADR_G_REGSET_M3N, DDR_PHY_ADR_G_REGSET_NUM_M3N);
		_tblcopy(_cnf_DDR_PI_REGSET,
			DDR_PI_REGSET_M3N, DDR_PI_REGSET_NUM_M3N);

		DDR_PHY_SLICE_REGSET_OFS = DDR_PHY_SLICE_REGSET_OFS_M3N;
		DDR_PHY_ADR_V_REGSET_OFS = DDR_PHY_ADR_V_REGSET_OFS_M3N;
		DDR_PHY_ADR_I_REGSET_OFS = DDR_PHY_ADR_I_REGSET_OFS_M3N;
		DDR_PHY_ADR_G_REGSET_OFS = DDR_PHY_ADR_G_REGSET_OFS_M3N;
		DDR_PI_REGSET_OFS = DDR_PI_REGSET_OFS_M3N;
		DDR_PHY_SLICE_REGSET_SIZE = DDR_PHY_SLICE_REGSET_SIZE_M3N;
		DDR_PHY_ADR_V_REGSET_SIZE = DDR_PHY_ADR_V_REGSET_SIZE_M3N;
		DDR_PHY_ADR_I_REGSET_SIZE = DDR_PHY_ADR_I_REGSET_SIZE_M3N;
		DDR_PHY_ADR_G_REGSET_SIZE = DDR_PHY_ADR_G_REGSET_SIZE_M3N;
		DDR_PI_REGSET_SIZE = DDR_PI_REGSET_SIZE_M3N;
		DDR_PHY_SLICE_REGSET_NUM = DDR_PHY_SLICE_REGSET_NUM_M3N;
		DDR_PHY_ADR_V_REGSET_NUM = DDR_PHY_ADR_V_REGSET_NUM_M3N;
		DDR_PHY_ADR_I_REGSET_NUM = DDR_PHY_ADR_I_REGSET_NUM_M3N;
		DDR_PHY_ADR_G_REGSET_NUM = DDR_PHY_ADR_G_REGSET_NUM_M3N;
		DDR_PI_REGSET_NUM = DDR_PI_REGSET_NUM_M3N;

		DDR_PHY_ADR_I_NUM = 2;
	} else {

		_tblcopy(_cnf_DDR_PHY_SLICE_REGSET,
			DDR_PHY_SLICE_REGSET_M3, DDR_PHY_SLICE_REGSET_NUM_M3);
		_tblcopy(_cnf_DDR_PHY_ADR_V_REGSET,
			DDR_PHY_ADR_V_REGSET_M3, DDR_PHY_ADR_V_REGSET_NUM_M3);
		_tblcopy(_cnf_DDR_PHY_ADR_I_REGSET,
			DDR_PHY_ADR_I_REGSET_M3, DDR_PHY_ADR_I_REGSET_NUM_M3);
		_tblcopy(_cnf_DDR_PHY_ADR_G_REGSET,
			DDR_PHY_ADR_G_REGSET_M3, DDR_PHY_ADR_G_REGSET_NUM_M3);
		_tblcopy(_cnf_DDR_PI_REGSET,
			DDR_PI_REGSET_M3, DDR_PI_REGSET_NUM_M3);

		DDR_PHY_SLICE_REGSET_OFS = DDR_PHY_SLICE_REGSET_OFS_M3;
		DDR_PHY_ADR_V_REGSET_OFS = DDR_PHY_ADR_V_REGSET_OFS_M3;
		DDR_PHY_ADR_I_REGSET_OFS = DDR_PHY_ADR_I_REGSET_OFS_M3;
		DDR_PHY_ADR_G_REGSET_OFS = DDR_PHY_ADR_G_REGSET_OFS_M3;
		DDR_PI_REGSET_OFS = DDR_PI_REGSET_OFS_M3;
		DDR_PHY_SLICE_REGSET_SIZE = DDR_PHY_SLICE_REGSET_SIZE_M3;
		DDR_PHY_ADR_V_REGSET_SIZE = DDR_PHY_ADR_V_REGSET_SIZE_M3;
		DDR_PHY_ADR_I_REGSET_SIZE = DDR_PHY_ADR_I_REGSET_SIZE_M3;
		DDR_PHY_ADR_G_REGSET_SIZE = DDR_PHY_ADR_G_REGSET_SIZE_M3;
		DDR_PI_REGSET_SIZE = DDR_PI_REGSET_SIZE_M3;
		DDR_PHY_SLICE_REGSET_NUM = DDR_PHY_SLICE_REGSET_NUM_M3;
		DDR_PHY_ADR_V_REGSET_NUM = DDR_PHY_ADR_V_REGSET_NUM_M3;
		DDR_PHY_ADR_I_REGSET_NUM = DDR_PHY_ADR_I_REGSET_NUM_M3;
		DDR_PHY_ADR_G_REGSET_NUM = DDR_PHY_ADR_G_REGSET_NUM_M3;
		DDR_PI_REGSET_NUM = DDR_PI_REGSET_NUM_M3;

		DDR_PHY_ADR_I_NUM = 2;
	}

	/***********************************************************************
	DDR3/DD3L setting
	***********************************************************************/
	if(ddr_3lmode){
		ddrtbl_setval(_cnf_DDR_PHY_ADR_G_REGSET, _reg_PHY_CAL_MODE_0,
			ddrtbl_getval(_cnf_DDR_PHY_ADR_G_REGSET, _reg_PHY_CAL_MODE_0)|0x210);
		ddrtbl_setval(_cnf_DDR_PHY_ADR_G_REGSET, _reg_PHY_PAD_VREF_CTRL_DQ_0,
			ddrtbl_getval(_cnf_DDR_PHY_ADR_G_REGSET, _reg_PHY_PAD_VREF_CTRL_DQ_0)|0x200);
		ddrtbl_setval(_cnf_DDR_PHY_ADR_G_REGSET, _reg_PHY_PAD_VREF_CTRL_DQ_1,
			ddrtbl_getval(_cnf_DDR_PHY_ADR_G_REGSET, _reg_PHY_PAD_VREF_CTRL_DQ_1)|0x200);
		ddrtbl_setval(_cnf_DDR_PHY_ADR_G_REGSET, _reg_PHY_PAD_VREF_CTRL_DQ_2,
			ddrtbl_getval(_cnf_DDR_PHY_ADR_G_REGSET, _reg_PHY_PAD_VREF_CTRL_DQ_2)|0x200);
		ddrtbl_setval(_cnf_DDR_PHY_ADR_G_REGSET, _reg_PHY_PAD_VREF_CTRL_DQ_3,
			ddrtbl_getval(_cnf_DDR_PHY_ADR_G_REGSET, _reg_PHY_PAD_VREF_CTRL_DQ_3)|0x200);
		ddrtbl_setval(_cnf_DDR_PHY_ADR_G_REGSET, _reg_PHY_PAD_VREF_CTRL_AC,
			ddrtbl_getval(_cnf_DDR_PHY_ADR_G_REGSET, _reg_PHY_PAD_VREF_CTRL_AC)|0x200);
	}

	/***********************************************************************
	on fly gate adjust
	***********************************************************************/
	if((Prr_Product==PRR_PRODUCT_M3)&&(Prr_Cut==PRR_PRODUCT_10)){
		ddrtbl_setval(_cnf_DDR_PHY_SLICE_REGSET, _reg_ON_FLY_GATE_ADJUST_EN, 0x00);
	}

	/***********************************************************************
	Adjust PI paramters
	***********************************************************************/
	dataS = js2[JS2_tIEdly];
	if(dataS+2 >RL) dataS = RL-2;

	ddrtbl_setval(_cnf_DDR_PHY_SLICE_REGSET, _reg_PHY_RDDATA_EN_DLY, dataS);
	ddrtbl_setval(_cnf_DDR_PHY_SLICE_REGSET, _reg_PHY_RDDATA_EN_TSEL_DLY, (dataS-2));
	ddrtbl_setval(_cnf_DDR_PI_REGSET, _reg_PI_RDLAT_ADJ_F1, RL-dataS);
	ddrtbl_setval(_cnf_DDR_PI_REGSET, _reg_PI_RDLAT_ADJ_F0, RL-dataS);

	if(ddrtbl_getval(_cnf_DDR_PHY_SLICE_REGSET, _reg_PHY_WRITE_PATH_LAT_ADD)){
		dataL = WL - 1;
	} else {
		dataL = WL;
	}

	ddrtbl_setval(_cnf_DDR_PI_REGSET, _reg_PI_WRLAT_ADJ_F2, dataL-2);
	ddrtbl_setval(_cnf_DDR_PI_REGSET, _reg_PI_WRLAT_ADJ_F1, dataL-2);
	ddrtbl_setval(_cnf_DDR_PI_REGSET, _reg_PI_WRLAT_ADJ_F0, dataL-2);
	ddrtbl_setval(_cnf_DDR_PI_REGSET, _reg_PI_WRLAT_F2, dataL-1);
	ddrtbl_setval(_cnf_DDR_PI_REGSET, _reg_PI_WRLAT_F1, dataL-1);
	ddrtbl_setval(_cnf_DDR_PI_REGSET, _reg_PI_WRLAT_F0, dataL-1);

	_reg_PI_MR0_DATA_Fx_CSx = js1[use_speed_bins][js1_ind].MR0;

	for(i=0;i<2;i++){
		for(csab=0;csab<CSAB_CNT;csab++){
			ddrtbl_setval(_cnf_DDR_PI_REGSET,
				_reg_PI_MR2_DATA_Fx_CSx[i][csab], js1[use_speed_bins][js1_ind].MR2);
		}
	}

	/***********************************************************************
	 DDRPHY INT START
	***********************************************************************/
	regif_pll_wa();

	/***********************************************************************
	FREQ_SEL_MULTICAST & PER_CS_TRAINING_MULTICAST SET (for safety)
	***********************************************************************/
	ddr_setval_ach(_reg_PHY_FREQ_SEL_MULTICAST_EN, 0x01);
	ddr_setval_ach_as(_reg_PHY_PER_CS_TRAINING_MULTICAST_EN, 0x01);

	/***********************************************************************
	Set external signal MxRESET_n
	***********************************************************************/
#ifdef DDR_BACKUPMODE
	if(ddrBackup==DRAM_BOOT_STATUS_COLD){
		/* RSX */
		send_dbcmd(0x01840001);
	}
#else//DDR_BACKUPMODE
	/* RSX */
	send_dbcmd(0x01840001);
#endif//DDR_BACKUPMODE

	/***********************************************************************
	SET DATA SLICE TABLE
	***********************************************************************/
	for(slice=0; slice<SLICE_CNT; slice++){
		adr = DDR_PHY_SLICE_REGSET_OFS + DDR_PHY_SLICE_REGSET_SIZE * slice;
		for(i=0; i<DDR_PHY_SLICE_REGSET_NUM; i++){
			reg_ddrphy_write_a(adr+i, _cnf_DDR_PHY_SLICE_REGSET[i]);
		}
	}

	/***********************************************************************
	SET ADR SLICE TABLE
	***********************************************************************/
	adr = DDR_PHY_ADR_V_REGSET_OFS;
	for(i=0; i<DDR_PHY_ADR_V_REGSET_NUM; i++ ){
		reg_ddrphy_write_a(adr+i, _cnf_DDR_PHY_ADR_V_REGSET[i]);
	}
	for(slice=0; slice<DDR_PHY_ADR_I_NUM; slice++){
		adr = DDR_PHY_ADR_I_REGSET_OFS + DDR_PHY_ADR_I_REGSET_SIZE * slice;
		for(i=0; i<DDR_PHY_ADR_I_REGSET_NUM; i++ ){
			reg_ddrphy_write_a(adr+i, _cnf_DDR_PHY_ADR_V_REGSET[i]);
		}
	}

	/***********************************************************************
	SET ADRCTRL SLICE TABLE
	***********************************************************************/
	adr = DDR_PHY_ADR_G_REGSET_OFS;
	for(i=0; i<DDR_PHY_ADR_G_REGSET_NUM; i++){
		reg_ddrphy_write_a(adr+i, _cnf_DDR_PHY_ADR_G_REGSET[i]);
	}

	/***********************************************************************
	SET PI REGISTERS
	***********************************************************************/
	adr = DDR_PI_REGSET_OFS;
	for(i=0; i<DDR_PI_REGSET_NUM; i++)
	{
		reg_ddrphy_write_a(adr+i, _cnf_DDR_PI_REGSET[i]);
	}
}

/*******************************************************************************
 *	CONFIGURE DDR REGISTERS
 ******************************************************************************/
static void ddr_config_sub(void)
{
	int32_t i;
	uint32_t ch, slice;
	uint32_t dataL;
	uint32_t tmp;
	uint8_t high_byte[SLICE_CNT];
	uint8_t m3n_caswap;

	const uint8_t addr_swap[2][16] = {
		{0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0A,0x0B,0x0C,0x0D,0x0E,0x0F},
		{0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0E,0x0F,0x0A,0x0B,0x0C,0x0D}};

	foreach_vch(ch){
	/***********************************************************************
	BOARD SETTINGS (DQ,DM,VREF_DRIVING)
	***********************************************************************/
		for(slice=0;slice<SLICE_CNT;slice++){
			high_byte[slice] = (Boardcnf->ch[ch].dqs_swap >> (4*slice))%2;
			ddr_setval_s(ch, slice, _reg_PHY_DQ_DM_SWIZZLE0, Boardcnf->ch[ch].dq_swap[slice]);
			ddr_setval_s(ch, slice, _reg_PHY_DQ_DM_SWIZZLE1, Boardcnf->ch[ch].dm_swap[slice]);
			if(high_byte[slice] ){
				/* HIGHER 16 BYTE */
				ddr_setval_s(ch, slice, _reg_PHY_CALVL_VREF_DRIVING_SLICE, 0x00);
			} else {
				/* LOWER 16 BYTE */
				ddr_setval_s(ch, slice, _reg_PHY_CALVL_VREF_DRIVING_SLICE, 0x01);
			}
		}

	/***********************************************************************
	BOARD SETTINGS (CA,ADDR_SEL)
	***********************************************************************/
		/* ----------- adr slice0 swap ----------- */
		if(Prr_Product==PRR_PRODUCT_M3N){
			m3n_caswap = 1;
		} else {
			m3n_caswap = 0;
		}
		tmp   = (0x00ffffff & (uint32_t)(Boardcnf->ch[ch].ca_swap));


		/* --- ADR_ADDR_SEL --- */
		dataL = 0;
		for(i=0;i<6;i++){
			dataL |= (((uint32_t)(addr_swap[m3n_caswap][tmp&0xf]))<<(i*5));
			tmp = tmp>>4;
		}
		ddr_setval_s(ch, 0, _reg_PHY_ADR_ADDR_SEL, dataL);

		/* ----------- adr slice1 swap ----------- */
		tmp = (uint32_t)((Boardcnf->ch[ch].ca_swap) >> 24);

		/* --- ADR_ADDR_SEL --- */
		dataL = 0;
		for(i=0;i<6;i++){
			dataL |= (((uint32_t)(addr_swap[m3n_caswap][tmp&0xf]))<<(i*5));
			tmp=tmp>>4;
		}
		ddr_setval_s(ch, 1, _reg_PHY_ADR_ADDR_SEL, dataL);

		/* ----------- adr slice2 swap ----------- */
		tmp = (uint32_t)((Boardcnf->ch[ch].ca_swap) >> 40);

		/* --- ADR_ADDR_SEL --- */
		dataL = 0;
		for(i=0;i<6;i++){
			dataL |= (((uint32_t)(addr_swap[m3n_caswap][tmp&0xf]))<<(i*5));
			tmp = tmp>>4;
		}
		ddr_setval_s(ch, 2, _reg_PHY_ADR_ADDR_SEL, dataL);

	/***********************************************************************
	BOARD SETTINGS (BYTE_ORDER_SEL)
	***********************************************************************/
		dataL = 0;
		tmp = Boardcnf->ch[ch].dqs_swap;
		if(Prr_Product==PRR_PRODUCT_M3N){
			dataL = tmp;
			ddr_setval(ch, _reg_PI_DATA_BYTE_SWAP_EN, 0x01);
			ddr_setval(ch, _reg_PI_DATA_BYTE_SWAP_SLICE0, (dataL       ) & 0x0f );
			ddr_setval(ch, _reg_PI_DATA_BYTE_SWAP_SLICE1, (dataL >> 4*1) & 0x0f );
			ddr_setval(ch, _reg_PI_DATA_BYTE_SWAP_SLICE2, (dataL >> 4*2) & 0x0f );
			ddr_setval(ch, _reg_PI_DATA_BYTE_SWAP_SLICE3, (dataL >> 4*3) & 0x0f );

			ddr_setval(ch, _reg_PHY_DATA_BYTE_ORDER_SEL_HIGH, 0x00);
		} else {
			for(i=0;i<4;i++){
				dataL |= ((tmp&0x3)<<(i*2));
				tmp = tmp>>4;
			}
		}
		ddr_setval(ch, _reg_PHY_DATA_BYTE_ORDER_SEL, dataL);
	}
}

static void ddr_config(void)
{
	int32_t i;
	uint32_t ch, slice;
	uint32_t dataL;
	uint32_t tmp;

	ddr_config_sub();

	/***********************************************************************
	WDQ_USER_PATT
	***********************************************************************/
	foreach_vch(ch){
		union {
			uint32_t ui32[4];
			uint8_t ui8[16];
		} patt;
		uint16_t patm;

		for(slice=0;slice<SLICE_CNT;slice++){
			patm = 0;
			for(i=0;i<16;i++){
				tmp = Boardcnf->ch[ch].wdqlvl_patt[i];
				patt.ui8[i] = tmp & 0xff;
				if(tmp&0x100)
					patm |= (1U<<i);
			}
			ddr_setval_s(ch, slice, _reg_PHY_USER_PATT0, patt.ui32[0]);
			ddr_setval_s(ch, slice, _reg_PHY_USER_PATT1, patt.ui32[1]);
			ddr_setval_s(ch, slice, _reg_PHY_USER_PATT2, patt.ui32[2]);
			ddr_setval_s(ch, slice, _reg_PHY_USER_PATT3, patt.ui32[3]);
			ddr_setval_s(ch, slice, _reg_PHY_USER_PATT4, patm);
		}
	}

	/***********************************************************************
	CACS DLY
	***********************************************************************/
	dataL = Boardcnf->cacs_dly + _f_scale_adj(Boardcnf->cacs_dly_adj);
	foreach_vch(ch){
		int16_t adj;
		for(i=0;i<(_reg_PHY_CLK_CACS_SLAVE_DELAY_X_NUM-4);i++){
			adj = _f_scale_adj(Boardcnf->ch[ch].cacs_adj[i]);
			ddr_setval_s(ch, 0, _reg_PHY_CLK_CACS_SLAVE_DELAY_X[i],
				dataL + adj
			);
		}

		for(i=(_reg_PHY_CLK_CACS_SLAVE_DELAY_X_NUM-4);i<_reg_PHY_CLK_CACS_SLAVE_DELAY_X_NUM;i++){
			adj = _f_scale_adj(Boardcnf->ch[ch].cacs_adj[i]);
			ddr_setval(ch, _reg_PHY_CLK_CACS_SLAVE_DELAY_X[i],
				dataL + adj
			);
		}

		for(i=0;i<4;i++){
			adj = _f_scale_adj(Boardcnf->ch[ch].cacs_adj[10+i]);
			ddr_setval_s(ch, 1, _reg_PHY_CLK_CACS_SLAVE_DELAY_X[i],
				dataL + adj
			);
		}

		for(i=0;i<(_reg_PHY_CLK_CACS_SLAVE_DELAY_X_NUM-4);i++){
			adj = _f_scale_adj(Boardcnf->ch[ch].cacs_adj[14+i]);
			ddr_setval_s(ch, 2, _reg_PHY_CLK_CACS_SLAVE_DELAY_X[i],
				dataL + adj
			);
		}
	}

	/***********************************************************************
	WDQDM DLY
	***********************************************************************/
	dataL = Boardcnf->dqdm_dly_w;
	foreach_vch(ch){
		int8_t _adj;
		int16_t adj;
		uint32_t dq;
		for(slice=0;slice<SLICE_CNT;slice++){
			for(i=0;i<=8;i++){
				dq = slice*8+i;
				if(i==8)
					_adj = Boardcnf->ch[ch].dm_adj_w[slice];
				else
					_adj = Boardcnf->ch[ch].dq_adj_w[dq];
				adj = _f_scale_adj(_adj);
				ddr_setval_s(ch, slice,
					_reg_PHY_CLK_WRX_SLAVE_DELAY[i],
					dataL + adj
				);
			}
		}
	}

	/***********************************************************************
	RDQDM DLY
	***********************************************************************/
	dataL = Boardcnf->dqdm_dly_r;
	foreach_vch(ch){
		int8_t _adj;
		int16_t adj;
		uint32_t dq;

		for(slice=0;slice<SLICE_CNT;slice++){
			for(i=0;i<=8;i++){
				dq = slice*8+i;
				if(i==8)
					_adj = Boardcnf->ch[ch].dm_adj_r[slice];
				else
					_adj = Boardcnf->ch[ch].dq_adj_r[dq];
				adj = _f_scale_adj(_adj);
				ddr_setval_s(ch, slice,
					_reg_PHY_RDDQS_X_FALL_SLAVE_DELAY[i],
					dataL + adj
				);
				ddr_setval_s(ch, slice,
					_reg_PHY_RDDQS_X_RISE_SLAVE_DELAY[i],
					dataL + adj
				);
			}
		}
	}
}

/*******************************************************************************
 *	DBSC register setting functions
 ******************************************************************************/
static void dbsc_regset_pre(void)
{
	uint32_t ch, csab;
	uint32_t dataL;

	/***********************************************************************
	PRIMARY SETTINGS
	***********************************************************************/
	/* DDR3   , BL= 8 */
	mmio_write_32(DBSC_DBKIND, 0x00000007);
	mmio_write_32(DBSC_DBBL, 0x00000000);

	/* DDR3 : ODT assert/negate timing (BL/2+2 & sametime) */
	mmio_write_32(DBSC_DBTR(18), 0x00000200);

	/* DDR3 : ODT select */
	foreach_vch(ch)
		mmio_write_32(DBSC_DBODT(ch), 0x00000001);
	mmio_write_32(DBSC_DBPHYCONF0, 0x00000001);

	/* FREQRATIO=2 */
	mmio_write_32(DBSC_DBSYSCONF1, 0x00000002);

	/* DRAM SIZE REGISTER:
	 * set all ranks as density=0(4Gb) for PHY initialization
	 */
	foreach_vch(ch)
		for(csab=0;csab<4;csab++)
			mmio_write_32(DBSC_DBMEMCONF(ch, csab), DBMEMCONF_REGD(0));

	if(Prr_Product==PRR_PRODUCT_M3){
		dataL = 0xe4e4e4e4;
		foreach_ech(ch){
			if((Boardcnf->phyvalid & (1U<<ch)))
				dataL = (dataL &(~(0x000000FF << (ch*8))))
					|((	  (Boardcnf->ch[ch].dqs_swap & 0x0003)
						|((Boardcnf->ch[ch].dqs_swap & 0x0030) >> 2)
						|((Boardcnf->ch[ch].dqs_swap & 0x0300) >> 4)
						|((Boardcnf->ch[ch].dqs_swap & 0x3000) >> 6)	) << (ch*8));
		}
		mmio_write_32(DBSC_DBBSWAP, dataL);
	}

	/* Internal DFI signal setting: External signal does not change */
#ifdef DDR_BACKUPMODE
	if(ddrBackup==DRAM_BOOT_STATUS_COLD){
		/* RSE */
		send_dbcmd(0x01840000);
		/* PDE */
		send_dbcmd(0x08840000);
	}
#else//DDR_BACKUPMODE
	/* RSE */
	send_dbcmd(0x01840000);
	/* PDE */
	send_dbcmd(0x08840000);
#endif//DDR_BACKUPMODE
}

static void dbsc_regset(void)
{
	uint32_t ch;
	uint32_t dataL;
	uint32_t tmp[4];

	/* RFC */
	js2[JS2_tRFC] = _f_scale(ddr_mbps, ddr_mbpsdiv,
		1UL*jedec_spec2_tRFC[max_density/2] * 1000, 0);

	/* DBTR0.CL  : RL */
	mmio_write_32(DBSC_DBTR(0), RL);

	/* DBTR1.CWL : WL */
	mmio_write_32(DBSC_DBTR(1), WL);

	/* DBTR2.AL  : 0 */
	mmio_write_32(DBSC_DBTR(2), 0x00);

	/* DBTR3.TRCD: tRCD */
	dataL = _f_scale(ddr_mbps, ddr_mbpsdiv, js1[use_speed_bins][js1_ind].tRCD, 0);
	mmio_write_32(DBSC_DBTR(3), dataL);

	/* DBTR4.TRPA,TRP: tRPab,tRPpb */
	mmio_write_32(DBSC_DBTR(4), (dataL<<16) | dataL);

	/* DBTR5.TRC : use tRCpb */
	mmio_write_32(DBSC_DBTR(5), _f_scale(ddr_mbps, ddr_mbpsdiv, js1[use_speed_bins][js1_ind].tRC, 0));

	/* DBTR6.TRAS : tRAS */
	mmio_write_32(DBSC_DBTR(6), _f_scale(ddr_mbps, ddr_mbpsdiv, js1[use_speed_bins][js1_ind].tRAS, 0));

	/* DBTR7.TRRD : tRRD */
	dataL = _f_scale(ddr_mbps, ddr_mbpsdiv, js1[use_speed_bins][js1_ind].tRRD, 4);
	mmio_write_32(DBSC_DBTR(7), (dataL<<16) | dataL);

	/* DBTR8.TFAW : tFAW */
	mmio_write_32(DBSC_DBTR(8), _f_scale(ddr_mbps, ddr_mbpsdiv, js1[use_speed_bins][js1_ind].tFAW, 0));

	/* DBTR9.TRDPR : tRTP */
	mmio_write_32(DBSC_DBTR(9), js2[JS2_tRTP]);

	/* DBTR10.TWR : tWR */
	mmio_write_32(DBSC_DBTR(10), jedec_spec3_WR[0][js2[JS2_tWR]]);

	/* DBTR11.TRDWR : RL + tDQSCK + BL/2 + Rounddown(tRPST) - WL + tWPRE  */
	mmio_write_32(DBSC_DBTR(11), RL + 1 + (8/2) + 1 - WL + 2);

	/* DBTR12.TWRRD : WL + 1 + BL/2 + tWTR */
	dataL = WL + 1 + (8/2) + js2[JS2_tWTR];
	mmio_write_32(DBSC_DBTR(12), (dataL<<16) | dataL);

	/* DBTR13.TRFCAB : tRFC */
	mmio_write_32(DBSC_DBTR(13), js2[JS2_tRFC]);

	/* DBTR14.TCKEHDLL,tCKEH : tXPDLL,tXP */
	dataL = _f_scale(ddr_mbps, ddr_mbpsdiv, js1[use_speed_bins][js1_ind].tXP, 3);
	mmio_write_32(DBSC_DBTR(14), (js2[JS2_tXPDLL]<<16) | dataL);

	/* DBTR15.TCKESR,TCKEL : tCKESR,tCKE */
	dataL = _f_scale(ddr_mbps, ddr_mbpsdiv, js1[use_speed_bins][js1_ind].tCKE, 3);
	mmio_write_32(DBSC_DBTR(15), ((dataL+1)<<16) | dataL);

	/* DBTR16 & DBTR24*/
	/* WDQL : tphy_wrlat + tphy_wrdata */
	tmp[0] = ddrtbl_getval(_cnf_DDR_PI_REGSET, _reg_PI_WRLAT_F1);
	/* DQENLTNCY : tphy_wrlat  = WL-2 */
	tmp[1] = ddrtbl_getval(_cnf_DDR_PI_REGSET, _reg_PI_WRLAT_ADJ_F1);
	/* DQL : tphy_rdlat + trdata_en */
	/* it is not important for dbsc */
	tmp[2] = RL + 16;
	/* DQIENLTNCY : trdata_en */
	tmp[3] = ddrtbl_getval(_cnf_DDR_PI_REGSET, _reg_PI_RDLAT_ADJ_F1) - 1;
	mmio_write_32(DBSC_DBTR(16),
		(tmp[3]<<24) | (tmp[2]<<16) | (tmp[1]<<8) | tmp[0]);

	/* WRCSLAT = WRLAT -5*/
	if(tmp[0] > 5){
		tmp[0] -= 5;
	}else {
		tmp[0] = 0;
	}
	/* WRCSGAP = 5 */
	tmp[1] = 5;
	/* RDCSLAT = RDLAT_ADJ +2*/
	tmp[2] = tmp[3];
	/* RDCSGAP = 6 */
	tmp[3] = 6;
	mmio_write_32(DBSC_DBTR(24),
		(tmp[3]<<24) | (tmp[2]<<16) | (tmp[1]<<8) | tmp[0]);

	/* DBTR17.TMOD: tMOD */
	mmio_write_32(DBSC_DBTR(17), (js2[JS2_tMOD]<<24)|(js2[JS2_tMOD]<<16));

	/* DBTR18.RODTL, RODTA, WODTL, WODTA */
	/* DDR3 : ODT assert/negate timing (WODTL = BL/2+2 , WODTA = sametime) */
	mmio_write_32(DBSC_DBTR(18), 0x00000200);
	/* DBTR19.TZQCL, TZQCS :  tZQoper, tZQCS */
	mmio_write_32(DBSC_DBTR(19), (js2[JS2_tZQoper])<<16 | js2[JS2_tZQCS]);

	/* move to dbsc_regset_pre */
	/* DBTR20.TXSDLL, TXS */
	dataL = (js2[JS2_tXSDLL])<<16 | (js2[JS2_tXS]+js2[JS2_tRFC]);
	mmio_write_32(DBSC_DBTR(20), dataL);

	/* DBTR21.TCCD */
	if(ddr_tccd<=4){
		dataL=4;
	} else {
		dataL = ddr_tccd;
	}
	mmio_write_32(DBSC_DBTR(21), (dataL<<16) | dataL);

	/* DBTR22.ZQLAT : do not use in DDR3/3L */
	mmio_write_32(DBSC_DBTR(22), 0x00);

	/* DBTR23.TCCD */
	mmio_write_32(DBSC_DBTR(23), 0x00000001);

	/* DBTR25 : TWDQLVLDIS, TWDQLVLEN   WriteDQ leveling setting*/
	mmio_write_32(DBSC_DBTR(25), 0x007f007f);
	/* ODT select */
	foreach_vch(ch)
		mmio_write_32(DBSC_DBODT(ch), 0x00000001);

	/* DDR3 : CAMODE = 2T mode */
	mmio_write_32(DBSC_DBADJ0, 0x00000001);

	/***********************************************************************
	timing registers for Scheduler
	***********************************************************************/
	/* SCFCTST0 */
	dataL = _f_scale(ddr_mbps, ddr_mbpsdiv, js1[use_speed_bins][js1_ind].tRCD, 0);
	/* SCFCTST0 ACT-ACT*/
	tmp[3] = 1UL * _f_scale(ddr_mbps, ddr_mbpsdiv, js1[use_speed_bins][js1_ind].tRC, 0) * 800 * ddr_mbpsdiv /ddr_mbps;
	/* SCFCTST0 RDA-ACT : tRTP + tRP*/
	tmp[2] = 1UL * ((16/2) + js2[JS2_tRTP] -8 + dataL) * 800 * ddr_mbpsdiv /ddr_mbps;
	/* SCFCTST0 WRA-ACT : CWL +4 + tWR + tRP */
	tmp[1] = 1UL * (WL + 4 + jedec_spec3_WR[0][js2[JS2_tWR]] + dataL) * 800 * ddr_mbpsdiv /ddr_mbps;
	/* SCFCTST0 PRE-ACT : tRP*/
	tmp[0] = 1UL * dataL * 800 * ddr_mbpsdiv /ddr_mbps;
	mmio_write_32(DBSC_SCFCTST0, (tmp[3]<<24) | (tmp[2]<<16) | (tmp[1]<<8) | tmp[0]);

	/* SCFCTST1 */
	/* SCFCTST1 RD-WR*/
	tmp[3] =  1UL * (mmio_read_32(DBSC_DBTR(11)) & 0xff) * 800 * ddr_mbpsdiv /ddr_mbps;
	/* SCFCTST1 WR-RD*/
	tmp[2] =  1UL * (mmio_read_32(DBSC_DBTR(12)) & 0xff) * 800 * ddr_mbpsdiv /ddr_mbps;
	/* SCFCTST1 ACT-RD/WR*/
	tmp[1] =  1UL * dataL * 800 * ddr_mbpsdiv /ddr_mbps;
	/* SCFCTST1 ASYNCOFS*/
	tmp[0] =  12;
	mmio_write_32(DBSC_SCFCTST1, (tmp[3]<<24) | (tmp[2]<<16) | (tmp[1]<<8) | tmp[0]);

	/* DBSCHRW1 */
	/* DBSCHRW1 SCTRFCAB*/
	tmp[0] = 1UL * js2[JS2_tRFC] * 800 * ddr_mbpsdiv /ddr_mbps;
	mmio_write_32(DBSC_DBSCHRW1, tmp[0]);

	/***********************************************************************
	QOS and CAM
	***********************************************************************/
#ifdef ddr_qos_init_setting // only for non qos_init
	mmio_write_32(QOSCTRL_RAEN, 0x00000000U);

	/*wbkwait(0004), wbkmdhi(4, 2), wbkmdlo(1, 8) */
	mmio_write_32(DBSC_DBCAM0CNF1, 0x00043218);
	/*0(fillunit), 8(dirtymax), 4(dirtymin)*/
	mmio_write_32(DBSC_DBCAM0CNF2, 0x000000F4);
	/*stop_tolerance*/
	mmio_write_32(DBSC_DBSCHRW0, 0x22421111);
	/*rd-wr/wr-rd toggle priority*/
	mmio_write_32(DBSC_SCFCTST2, 0x012F1123);
	mmio_write_32(DBSC_DBSCHSZ0, 0x00000001);
	mmio_write_32(DBSC_DBSCHCNT0, 0x000F0037);

	/* QoS Settings */
	mmio_write_32(DBSC_DBSCHQOS00,  0x00000F00U);
	mmio_write_32(DBSC_DBSCHQOS01,  0x00000B00U);
	mmio_write_32(DBSC_DBSCHQOS02,  0x00000000U);
	mmio_write_32(DBSC_DBSCHQOS03,  0x00000000U);
	mmio_write_32(DBSC_DBSCHQOS40,  0x00000300U);
	mmio_write_32(DBSC_DBSCHQOS41,  0x000002F0U);
	mmio_write_32(DBSC_DBSCHQOS42,  0x00000200U);
	mmio_write_32(DBSC_DBSCHQOS43,  0x00000100U);
	mmio_write_32(DBSC_DBSCHQOS90,  0x00000100U);
	mmio_write_32(DBSC_DBSCHQOS91,  0x000000F0U);
	mmio_write_32(DBSC_DBSCHQOS92,  0x000000A0U);
	mmio_write_32(DBSC_DBSCHQOS93,  0x00000040U);
	mmio_write_32(DBSC_DBSCHQOS120, 0x00000040U);
	mmio_write_32(DBSC_DBSCHQOS121, 0x00000030U);
	mmio_write_32(DBSC_DBSCHQOS122, 0x00000020U);
	mmio_write_32(DBSC_DBSCHQOS123, 0x00000010U);
	mmio_write_32(DBSC_DBSCHQOS130, 0x00000100U);
	mmio_write_32(DBSC_DBSCHQOS131, 0x000000F0U);
	mmio_write_32(DBSC_DBSCHQOS132, 0x000000A0U);
	mmio_write_32(DBSC_DBSCHQOS133, 0x00000040U);
	mmio_write_32(DBSC_DBSCHQOS140, 0x000000C0U);
	mmio_write_32(DBSC_DBSCHQOS141, 0x000000B0U);
	mmio_write_32(DBSC_DBSCHQOS142, 0x00000080U);
	mmio_write_32(DBSC_DBSCHQOS143, 0x00000040U);
	mmio_write_32(DBSC_DBSCHQOS150, 0x00000040U);
	mmio_write_32(DBSC_DBSCHQOS151, 0x00000030U);
	mmio_write_32(DBSC_DBSCHQOS152, 0x00000020U);
	mmio_write_32(DBSC_DBSCHQOS153, 0x00000010U);

	mmio_write_32(QOSCTRL_RAEN,  0x00000001U);
#endif//ddr_qos_init_setting

	/* resrdis	M3/M3N	*/
	mmio_write_32(DBSC_DBBCAMDIS, 0x00000001);

}

static void dbsc_regset_post(void)
{
	uint32_t ch, cs;
	uint32_t dataL;
	uint32_t slice, rdlat_max;

	rdlat_max = 0 ;
	foreach_vch(ch){
		for(slice=0;slice<SLICE_CNT;slice++){
			dataL = ddr_getval_s(ch, slice,	_reg_PHY_RDDQS_LATENCY_ADJUST);
			if(dataL>rdlat_max) rdlat_max = dataL ;
		}
	}
	mmio_write_32(DBSC_DBTR(24),
		((rdlat_max +2)<<16) + mmio_read_32(DBSC_DBTR(24)));

	/* set ddr density information */
	foreach_vch(ch){
		for(cs=0;cs<CS_CNT;cs++){
			if(ddr_density[ch][cs]==0xff){
				mmio_write_32(DBSC_DBMEMCONF(ch, cs), 0x00);
			} else {
				mmio_write_32(DBSC_DBMEMCONF(ch, cs), DBMEMCONF_REGD(ddr_density[ch][cs]));
			}
		}
		mmio_write_32(DBSC_DBMEMCONF(ch, 2), 0x00000000);
		mmio_write_32(DBSC_DBMEMCONF(ch, 3), 0x00000000);
	}
	mmio_write_32(DBSC_DBBUS0CNF1, 0x00000010);

	/*set REFCYCLE */
	dataL = (get_refperiod())*ddr_mbps/2000/ddr_mbpsdiv ;
	mmio_write_32(DBSC_DBRFCNF1, 0x00080000|(dataL&0xffff));
	mmio_write_32(DBSC_DBRFCNF2, 0x00010000|DBSC_REFINTS);
	if(Prr_Product==PRR_PRODUCT_M3N){
		mmio_write_32(DBSC_DBDFICUPDCNF ,0x28240001);
	}

	/* Periodec ZQCS */
	mmio_write_32(DBSC_DBCALCNF, 0x01000010);

	MSG_LF("dbsc_regset_post(done)");
}

/*******************************************************************************
 *	DFI_INIT_START
 ******************************************************************************/
static uint32_t dfi_init_start(void)
{
	uint32_t ch;
	uint32_t phytrainingok;
	uint32_t retry;
	uint32_t dataL;
	const uint32_t RETRY_MAX = 0x10000;

	/***********************************************************************
	DLL setting
	***********************************************************************/
	ddr_setval_ach_as(_reg_PHY_DLL_RST_EN, 0x02);
	dsb_sev();
	ddrphy_regif_idle();

	/* dll_rst negate */
	foreach_vch(ch)
		mmio_write_32(DBSC_DBPDCNT3(ch), 0x0000CF01);
	dsb_sev();

	/***********************************************************************
	wait init_complete
	***********************************************************************/
	phytrainingok = 0;
	retry = 0;
	while(retry++<RETRY_MAX){
		foreach_vch(ch){
			dataL = mmio_read_32(DBSC_INITCOMP(ch));
			if(dataL & 0x00000001)
				phytrainingok |= (1U<<ch);
		}
		dsb_sev();
		if(phytrainingok == ddr_phyvalid)
			break;
		if(retry%256==0)
			ddr_setval_ach_as(_reg_SC_PHY_RX_CAL_START, 0x01);
	}

	/***********************************************************************
	all ch ok?
	***********************************************************************/
	if((phytrainingok & ddr_phyvalid) != ddr_phyvalid){
		return (0xff);
	}
	/* dbdficnt0:
	 * dfi_dram_clk_disable = 0
	 * dfi_frequency = 0
	 * freq_ratio = 01 (2:1)
	 * init_start = 0
	 */
	foreach_vch(ch)
		mmio_write_32(DBSC_DBDFICNT(ch), 0x00000010);
	dsb_sev();

	return 0;
}

/*******************************************************************************
 *	drivablity setting
 ******************************************************************************/
static uint32_t set_term_code(void)
{
	uint32_t ch, index;
	uint32_t dataL;

	if((Prr_Product==PRR_PRODUCT_M3)&&(Prr_Cut==PRR_PRODUCT_10)){
		// non
	} else {
		ddr_setval_ach(_reg_PHY_PAD_TERM_X[0],
			(ddrtbl_getval(_cnf_DDR_PHY_ADR_G_REGSET, _reg_PHY_PAD_TERM_X[0]) & 0xFFFE0000));
		ddr_setval_ach(_reg_PHY_CAL_CLEAR_0, 0x01);
		ddr_setval_ach(_reg_PHY_CAL_START_0, 0x01);
		foreach_vch(ch){
			do {
				dataL = ddr_getval(ch, _reg_PHY_CAL_RESULT2_OBS_0);
			} while(!(dataL&0x00800000));
		}

		foreach_vch(ch){
			if(Prr_Product==PRR_PRODUCT_M3){
				for(index=0;index<(_reg_PHY_PAD_TERM_X_NUM-1);index++){
					dataL = ddr_getval(ch, _reg_PHY_PAD_TERM_X[index]);
					ddr_setval(ch, _reg_PHY_PAD_TERM_X[index], (dataL & 0xFFFE0FFF) | 0x00015000);
				}
			} else {
				for(index=0;index<_reg_PHY_PAD_TERM_X_NUM;index++){
					dataL = ddr_getval(ch, _reg_PHY_PAD_TERM_X[index]);
					ddr_setval(ch, _reg_PHY_PAD_TERM_X[index], (dataL & 0xFFFE0FFF) | 0x00015000);
				}
			}
		}
	}

	ddr_padcal_tcompensate_getinit(0);

	return 0;
}

/*******************************************************************************
 *	Training handshake functions
 ******************************************************************************/
static inline void set_dfifrequency(uint32_t freq)
{
	uint32_t ch;

	foreach_vch(ch)
		mmio_clrsetbits_32(DBSC_DBDFICNT(ch), 0x1fU<<24, (freq << 24));
	dsb_sev();
}


/*******************************************************************************
 *	update dly
 ******************************************************************************/
static void update_dly(void)
{
	ddr_setval_ach(_reg_SC_PHY_MANUAL_UPDATE, 0x01);
	ddr_setval_ach(_reg_PHY_ADRCTL_MANUAL_UPDATE, 0x01);
}

/*******************************************************************************
 *	training by pi
 ******************************************************************************/
static uint32_t pi_training_go(void)
{
	uint32_t dataL;
	uint32_t retry;
	const uint32_t RETRY_MAX = 4096*16;
	uint32_t ch;

	uint32_t complete;
	/***********************************************************************
	pi_start
	***********************************************************************/
	ddr_setval_ach(_reg_PI_START, 0x01);
	foreach_vch(ch)
		dataL = reg_ddrphy_read(ch, ddr_regdef_adr(_reg_PI_INT_STATUS));

	/* set dfi_phymstr_ack = 1 */
	mmio_write_32(DBSC_DBDFIPMSTRCNF, 0x00000001);
	dsb_sev();

	/***********************************************************************
	wait pi_int_status[0]
	***********************************************************************/
	complete = 0;
	retry = RETRY_MAX;

	set_dfifrequency(1);

	do {
		foreach_vch(ch){
			if(complete & (1U<<ch))continue;
			dataL = ddr_getval(ch, _reg_PI_INT_STATUS);

			if(dataL & 0x01){
				complete |= (1U<<ch);
			}
		}
		if(complete==ddr_phyvalid)break;
	} while(--retry);
	foreach_vch(ch){
		/* dummy read */
		dataL = ddr_getval_s(ch, 0, _reg_PHY_CAL_RESULT2_OBS_0);
		dataL = ddr_getval(ch, _reg_PI_INT_STATUS);
		ddr_setval(ch, _reg_PI_INT_ACK, dataL);
	}
	if(ddrphy_regif_chk()){
		return(0xfd);
	}
	return complete;
}

/*******************************************************************************
 *	Initialize ddr
 ******************************************************************************/
static uint32_t init_ddr(void)
{
	uint32_t dataL;
	uint32_t phytrainingok;
	uint32_t ch;
	uint32_t err;

	MSG_LF("init_ddr:0\n");

#ifdef DDR_BACKUPMODE
	uint32_t i;
	dram_get_boot_status(&ddrBackup);
#endif//DDR_BACKUPMODE

	/***********************************************************************
	unlock phy
	***********************************************************************/
	/* Unlock DDRPHY register */
	foreach_vch(ch)
		mmio_write_32(DBSC_DBPDLK(ch), 0x0000A55A);
	dsb_sev();

	if(Prr_Product==PRR_PRODUCT_M3)
		reg_ddrphy_write_a(0x1010, 0x00010001);

	/* dbsc register pre set */
	dbsc_regset_pre();

	/***********************************************************************
	load ddrphy registers
	***********************************************************************/
	ddrtbl_load();

	/***********************************************************************
	config ddrphy registers
	***********************************************************************/
	ddr_config();

	/***********************************************************************
	dfi_reset assert
	***********************************************************************/
	foreach_vch(ch)
		mmio_write_32(DBSC_DBPDCNT0(ch), 0x01);
	dsb_sev();

	/***********************************************************************
	dbsc register set
	***********************************************************************/
	dbsc_regset();
	MSG_LF("init_ddr:1\n");

	/***********************************************************************
	dfi_reset negate
	***********************************************************************/
	foreach_vch(ch)
		mmio_write_32(DBSC_DBPDCNT0(ch), 0x00);
	dsb_sev();

	/***********************************************************************
	dfi_init_start (start ddrphy)
	***********************************************************************/
	err = dfi_init_start();
	if(err){
		return INITDRAM_ERR_I;
	}
	MSG_LF("init_ddr:2\n");

	/***********************************************************************
	ddr backupmode end
	***********************************************************************/
#ifdef DDR_BACKUPMODE
	if(ddrBackup){
		NOTICE("[WARM_BOOT]");
	} else {
		NOTICE("[COLD_BOOT]");
	}
	err=dram_update_boot_status(ddrBackup);
	if(err){
		NOTICE("[BOOT_STATUS_UPDATE_ERROR]");
		return INITDRAM_ERR_I;
	}
#endif//DDR_BACKUPMODE
	MSG_LF("init_ddr:3\n");

	/***********************************************************************
	override term code after dfi_init_complete
	***********************************************************************/
	err = set_term_code();
	if(err){
		return INITDRAM_ERR_I;
	}
	MSG_LF("init_ddr:4\n");

	/***********************************************************************
	rx offset calibration
	***********************************************************************/
	if((Prr_Product==PRR_PRODUCT_M3)&&(Prr_Cut==PRR_PRODUCT_10)){
		err = rx_offset_cal();
	} else {
		err = rx_offset_cal_hw();
	}
	if(err){
		return(INITDRAM_ERR_O);
	}
	MSG_LF("init_ddr:5\n");

	/***********************************************************************
	check register i/f is alive
	***********************************************************************/
	err = ddrphy_regif_chk();
	if(err){
		return(INITDRAM_ERR_O);
	}
	MSG_LF("init_ddr:6\n");

	/***********************************************************************
	phy initialize end
	***********************************************************************/

	/***********************************************************************
	Thermal sensor setting
	***********************************************************************/
	/* THCTR Bit6: PONM=0 , Bit0: THSST=1	*/
	dataL = ((mmio_read_32(THS1_THCTR)) & 0xFFFFFFBF) | 0x00000001;
	mmio_write_32(THS1_THCTR, dataL);

	/***********************************************************************
	setup DDR mode registers
	***********************************************************************/
#ifdef DDR_BACKUPMODE
	if(ddrBackup==DRAM_BOOT_STATUS_WARM){
		/* PDX */
		send_dbcmd(0x08840001);
		wait_dbcmd();
		/* SRX */
		send_dbcmd(0x0A840001);
		wait_dbcmd();

		/* PREA/REF */
		send_dbcmd(0x04840010);		// PREA
		wait_dbcmd();
		for(i=0;8>i;i++) {
			send_dbcmd(0x05840010);	// REF
		}
		wait_dbcmd();
	} else {
		/* PDX */
		send_dbcmd(0x08840001);
		wait_dbcmd();
		micro_wait(1);

		// MRS2
		dataL = ddrtbl_getval(_cnf_DDR_PI_REGSET, _reg_PI_MR2_DATA_Fx_CSx[0][0]);
		send_dbcmd(0x0c844000|dataL);
		wait_dbcmd();

		// MRS3
		send_dbcmd(0x0c846000);
		wait_dbcmd();

		// MRS1
		dataL = ddrtbl_getval(_cnf_DDR_PI_REGSET, _reg_PI_MR1_DATA_Fx_CSx[0][0]);
		send_dbcmd(0x0c842000|dataL);
		wait_dbcmd();

		// MRS0
		send_dbcmd(0x0c840000|_reg_PI_MR0_DATA_Fx_CSx);
		wait_dbcmd();
		micro_wait(1);	// tMOD: max(12nCK,15ns)

		// ZQCL
		send_dbcmd(0x06840001);
	}
#else//DDR_BACKUPMODE
	/* PDX */
	send_dbcmd(0x08840001);
	wait_dbcmd();
	micro_wait(1);

	// MRS2
	dataL = ddrtbl_getval(_cnf_DDR_PI_REGSET, _reg_PI_MR2_DATA_Fx_CSx[0][0]);
	send_dbcmd(0x0c844000|dataL);
	wait_dbcmd();

	// MRS3
	send_dbcmd(0x0c846000);
	wait_dbcmd();

	// MRS1
	dataL = ddrtbl_getval(_cnf_DDR_PI_REGSET, _reg_PI_MR1_DATA_Fx_CSx[0][0]);
	send_dbcmd(0x0c842000|dataL);

	// MRS0
	send_dbcmd(0x0c840000|_reg_PI_MR0_DATA_Fx_CSx);
	wait_dbcmd();

	// ZQCL
	send_dbcmd(0x06840001);
#endif//DDR_BACKUPMODE

	MSG_LF("init_ddr:7\n");

	/***********************************************************************
	exec pi_training
	***********************************************************************/

	phytrainingok = pi_training_go();

	MSG_LF("init_ddr:8\n");

	/***********************************************************************
	update delay line
	***********************************************************************/
	update_dly();

	/***********************************************************************
	training complete, setup dbsc
	***********************************************************************/
	dbsc_regset_post();
	MSG_LF("init_ddr:12\n");

	return phytrainingok;
}


/*******************************************************************************
 *	rx offset calibration
 ******************************************************************************/
static int32_t _find_change(uint64_t val, uint32_t dir)
{
	int32_t i;
	uint32_t startval;
	uint32_t curval;
	const uint32_t VAL_END = 0x3f;

	if(dir==0){
		startval = (val&0x01);
		for(i=1;i<=VAL_END;i++){
			curval = (val>>i) & 0x01;
			if(curval!=startval)
				return(i);
		}
		return(VAL_END);
	} else {
		startval = (val>>dir)&0x01;
		for(i=dir-1;i>=0;i--){
			curval = (val>>i) & 0x01;
			if(curval!=startval)
				return(i);
		}
		return(0);
	}
}

static uint32_t _rx_offset_cal_updn(uint32_t code)
{
	const uint32_t CODE_MAX = 0x40;
	uint32_t tmp;

	if(code==0){
		tmp = (1U<<6) | (CODE_MAX-1);
	} else {
		tmp = (code<<6) | (CODE_MAX-code);
	}

	return tmp;
}

static uint32_t rx_offset_cal(void)
{
	uint32_t index;
	uint32_t code;
	const uint32_t CODE_MAX = 0x40;
	const uint32_t CODE_STEP = 2;
	uint32_t ch, slice;
	uint32_t tmp;
	uint32_t tmp_ach_as[DRAM_CH_CNT][SLICE_CNT];
	uint64_t val[DRAM_CH_CNT][SLICE_CNT][_reg_PHY_RX_CAL_X_NUM];
	ddr_setval_ach_as(_reg_PHY_RX_CAL_OVERRIDE, 0x01);
	foreach_vch(ch){
		for(slice=0; slice<SLICE_CNT; slice++){
			for(index=0;index<_reg_PHY_RX_CAL_X_NUM;index++){
				val[ch][slice][index] = 0;
			}
		}
	}

	for(code=0;code<CODE_MAX/CODE_STEP;code++){
		tmp = _rx_offset_cal_updn(code*CODE_STEP);
		for(index=0;index<_reg_PHY_RX_CAL_X_NUM;index++){
			ddr_setval_ach_as(_reg_PHY_RX_CAL_X[index], tmp);
		}
		dsb_sev();
		ddr_getval_ach_as(_reg_PHY_RX_CAL_OBS, (uint32_t *)tmp_ach_as);

		foreach_vch(ch){
			for(slice=0; slice<SLICE_CNT; slice++){
				tmp = tmp_ach_as[ch][slice];
				for(index=0;index<_reg_PHY_RX_CAL_X_NUM;index++){
					if(tmp & (1U<<index)){
						val[ch][slice][index] |= (1ULL<<code);
					} else {
						val[ch][slice][index] &= ~(1ULL<<code);
					}
				}
			}
		}
	}

	foreach_vch(ch){
		for(slice=0; slice<SLICE_CNT; slice++){
			for(index=0;index<_reg_PHY_RX_CAL_X_NUM;index++){
				uint64_t tmpval;
				int32_t lsb, msb;
				tmpval = val[ch][slice][index];
				lsb = _find_change(tmpval, 0x00);
				msb = _find_change(tmpval, (CODE_MAX/CODE_STEP)-1);
				tmp = (lsb+msb)>>1;

				tmp = _rx_offset_cal_updn(tmp*CODE_STEP);
				ddr_setval_s(ch, slice, _reg_PHY_RX_CAL_X[index], tmp);
			}
		}
	}
	ddr_setval_ach_as(_reg_PHY_RX_CAL_OVERRIDE, 0x00);
	return 0;
}

static uint32_t rx_offset_cal_hw(void){
	uint32_t ch, slice;
	uint32_t retry;
	uint32_t complete;
	uint32_t tmp;
	uint32_t tmp_ach_as[DRAM_CH_CNT][SLICE_CNT];

	ddr_setval_ach_as(_reg_PHY_RX_CAL_X[9], 0x00);
	ddr_setval_ach_as(_reg_PHY_RX_CAL_OVERRIDE, 0x00);
	ddr_setval_ach_as(_reg_PHY_RX_CAL_SAMPLE_WAIT, 0x0f);

	retry = 0;
	while(retry<4096){
		if((retry & 0xff) == 0){
			ddr_setval_ach_as(_reg_SC_PHY_RX_CAL_START, 0x01);
		}
		ddr_getval_ach_as(_reg_PHY_RX_CAL_X[9], (uint32_t *)tmp_ach_as);
		complete = 1;
		foreach_vch(ch){
			for(slice=0;slice<SLICE_CNT;slice++){
				tmp = tmp_ach_as[ch][slice];
				tmp = (tmp&0x3f) + ((tmp>>6)&0x3f);
				if(Prr_Product==PRR_PRODUCT_M3N){
					if(tmp!=0x3E) complete = 0;
				} else {
					if(tmp!=0x40) complete = 0;
				}
			}
		}
		if(complete) break;

		retry++;
	}
	return (complete==0);
}

/*******************************************************************************
 *	Write DQ traning for DDR3/3L
 ******************************************************************************/
static inline void _set_dbsysctrl(uint32_t wdata)
{
	*((volatile uint32_t*)DBSC_DBSYSCTRL0) = wdata;
	dsb_sev();
	*((volatile uint32_t*)DBSC_DBSYSCTRL0) = 0;
	dsb_sev();
}

static void set_dbsysctrl()
{
	uint32_t i;

	/* --- DBSC Soft reset!! --- */
	__asm__ volatile(".balign 64");
	__asm__ __volatile__("dmb sy");
	__asm__ __volatile__("isb sy");
	for(i=0;5>i;i+=1){
		_set_dbsysctrl((i==4));
		dsb_sev();
	}
}

int32_t init_ddr3_wdqlvl()
{
	uint32_t ch, slice, dataL, i;
	uint32_t dbtr11_bkup;

	dbtr11_bkup = mmio_read_32(DBSC_DBTR(11));
	mmio_write_32(DBSC_DBTR(11),
		RL + 1 + ( 8/2) + 1 - WL + 2 +16);
	dsb_sev();

	send_dbcmd(0x04840010);		// PREA
	wait_dbcmd();
	for(i=0;8>i;i++) {
		send_dbcmd(0x05840010);	// REF
	}
	wait_dbcmd();

	/* ----- DDR3 WriteDQ Traning by DBSC ---------- */
	send_dbcmd(0x03840000);

	foreach_vch(ch){
		for(slice=0;slice<SLICE_CNT;slice++){
			dataL = 0;
			while(dataL==0){
				dataL = (ddr_getval_s(ch, slice,_reg_PHY_WDQLVL_STATUS_OBS));
				dsb_sev();
				dataL = dataL & 0x40000000;
			}
		}
	}

	if(Prr_Product==PRR_PRODUCT_M3){
		/* --- DBSC Return to normal mode!! --- */
		set_dbsysctrl();
	}

	/* --- Resetting DBSC REG --- */
	mmio_write_32(DBSC_DBTR(11), dbtr11_bkup);

	send_dbcmd(0x0A840001);
	wait_dbcmd();

	mmio_write_32(DBSC_DBRFEN, 0x00000001);
	mmio_write_32(DBSC_DBACEN, 0x00000001);

	return 0;
}

/*******************************************************************************
 *	DDR Initialize entry
 ******************************************************************************/
int32_t InitDram(void)
{
	uint32_t ch, cs;
	uint32_t dataL;
	uint32_t failcount;

	/***********************************************************************
	Thermal sensor setting
	***********************************************************************/
	dataL = mmio_read_32(CPG_MSTPSR5);
	if(dataL & (1<<22)){	// case THS/TSC Standby
		dataL &= ~(1<<22);
		mmio_write_32(CPG_CPGWPR, (~dataL));
		mmio_write_32(CPG_SMSTPCR5, dataL);
		while((1<<22) &  mmio_read_32(CPG_MSTPSR5));  // wait bit=0
	}

	/* THCTR Bit6: PONM=0 , Bit0: THSST=0	*/
	dataL = mmio_read_32(THS1_THCTR) & 0xFFFFFFBE;
	mmio_write_32(THS1_THCTR, dataL);

	/***********************************************************************
	Judge product and cut
	***********************************************************************/
#if(RCAR_LSI==RCAR_AUTO)
	Prr_Product = mmio_read_32(PRR) & PRR_PRODUCT_MASK;
	Prr_Cut = mmio_read_32(PRR) & PRR_CUT_MASK;
#else//RCAR_LSI
#ifndef RCAR_LSI_CUT
	Prr_Cut = mmio_read_32(PRR) & PRR_CUT_MASK;
#endif//RCAR_LSI_CUT
#endif//RCAR_LSI

	if(Prr_Product == PRR_PRODUCT_M3N){
		pDDR_REGDEF_TBL = (uint32_t *)&DDR_REGDEF_TBL[0][0];
		mmio_write_32(DBSC_DBSYSCNT0, 0x00001234);
	} else if(Prr_Product == PRR_PRODUCT_M3){
		pDDR_REGDEF_TBL = (uint32_t *)&DDR_REGDEF_TBL[1][0];
	} else {
		FATAL_MSG("DDR:Unknown Product");
		return 0xff;
	}

	/***********************************************************************
	Judge board type
	***********************************************************************/
	_cnf_BOARDTYPE = boardcnf_get_brd_type();
	if(_cnf_BOARDTYPE>=BOARDNUM){
		FATAL_MSG("DDR:Unknown Board");
		return 0xff;
	}
	Boardcnf = (struct _boardcnf *)&boardcnfs[_cnf_BOARDTYPE];

	ddr_phyvalid = Boardcnf->phyvalid;
	max_density = 0;
	max_cs = 0;
	for(cs=0;cs<CS_CNT;cs++){
		ch_have_this_cs[cs] = 0;
	}
	foreach_vch(ch){
		for(cs=0;cs<CS_CNT;cs++){
			dataL = Boardcnf->ch[ch].ddr_density[cs];
			ddr_density[ch][cs] = dataL;

			if(dataL==0xff)continue;
			if(dataL>max_density)
				max_density = dataL;
			if(cs==1)
				max_cs = 1;
			ch_have_this_cs[cs] |= (1U<<ch);
		}
	}
	ddr_3lmode = (Boardcnf->ddr_mode) & 0x01;
	use_speed_bins = (Boardcnf->ddr_speed_bins);

	/***********************************************************************
	Judge board clock frequency (in MHz)
	***********************************************************************/
	boardcnf_get_brd_clk(_cnf_BOARDTYPE, &brd_clk, &brd_clkdiv);
	if((brd_clk/brd_clkdiv) > 25){
		brd_clkdiva = 1;
	} else {
		brd_clkdiva = 0;
	}

	/***********************************************************************
	Judge ddr operating frequency clock(in Mbps)
	***********************************************************************/
	boardcnf_get_ddr_mbps(_cnf_BOARDTYPE, &ddr_mbps, &ddr_mbpsdiv);

	ddr_mul = CLK_DIV(ddr_mbps, ddr_mbpsdiv*2, brd_clk, brd_clkdiv*(brd_clkdiva+1));

	/***********************************************************************
	Adjust tccd
	***********************************************************************/
	uint32_t bus_mbps, bus_mbpsdiv;
	uint32_t tmp_tccd;

	dataL = (0x00006000 & mmio_read_32(RST_MODEMR)) >> 13;
	switch(dataL){
		case 0:	bus_mbps = brd_clk * 0x60 * 2; bus_mbpsdiv = brd_clkdiv * 1;	break;
		case 1:	bus_mbps = brd_clk * 0x50 * 2; bus_mbpsdiv = brd_clkdiv * 1;	break;
		case 2:	bus_mbps = brd_clk * 0x40 * 2; bus_mbpsdiv = brd_clkdiv * 1;	break;
		case 3:	bus_mbps = brd_clk * 0x60 * 2; bus_mbpsdiv = brd_clkdiv * 2;	break;
		default:bus_mbps = brd_clk * 0x60 * 2; bus_mbpsdiv = brd_clkdiv * 2;	break;
	}

	tmp_tccd = CLK_DIV(ddr_mbps*4, ddr_mbpsdiv, bus_mbps, bus_mbpsdiv);
	if(4*ddr_mbps*bus_mbpsdiv != tmp_tccd * bus_mbps * ddr_mbpsdiv)
		tmp_tccd = tmp_tccd + 1;

	if(tmp_tccd<4)
		ddr_tccd = 4;
	else
		ddr_tccd = tmp_tccd;

	NOTICE("BL2: DDR%d(%s)", ddr_mbps/ddr_mbpsdiv, RCAR_DDR_VERSION);

	MSG_LF("Start\n");

	/***********************************************************************
	initialize DDRPHY
	***********************************************************************/
	pll3_control();

	dataL = init_ddr();
	if(dataL==ddr_phyvalid){
		failcount = 0;
	}
	else {
		failcount = 1;
	}

	if(failcount==0)
		failcount = init_ddr3_wdqlvl();

	/***********************************************************************
	initialize DDRPHY
	***********************************************************************/
	NOTICE("..%d\n", failcount);

	foreach_vch(ch)
		mmio_write_32(DBSC_DBPDLK(ch), 0x00000000);
	if(Prr_Product==PRR_PRODUCT_M3N){
		mmio_write_32(DBSC_DBSYSCNT0, 0x00000000);
	}
	if(failcount==0){
		return INITDRAM_OK;
	} else {
		return INITDRAM_NG;
	}
}

void ddr_padcal_tcompensate_getinit(uint32_t override)
{
	uint32_t ch;
	uint32_t dataL;
	uint32_t pvtp, pvtn;

	tcal.init_temp = 0;
	for(ch=0;ch<4;ch++){
		tcal.init_cal[ch]  = 0;
		tcal.tcomp_cal[ch] = 0;
	}

	foreach_vch(ch){
		tcal.init_cal[ch]  = ddr_getval(ch, _reg_PHY_PAD_TERM_X[1]);
		tcal.tcomp_cal[ch] = ddr_getval(ch, _reg_PHY_PAD_TERM_X[1]);
	}

	if(!override){
		dataL = mmio_read_32(THS1_TEMP);
		if(dataL < 2800){	tcal.init_temp = (143 * (int32_t)dataL - 359000)/1000;}
			else	{	tcal.init_temp = (121 * (int32_t)dataL - 296300)/1000;}

		foreach_vch(ch){
			if(ddr_3lmode){
				pvtp = (tcal.init_cal[ch] >> 0) & 0x000003F;
				pvtn = (tcal.init_cal[ch] >> 6) & 0x000003F;
				if((int32_t)pvtp > ((tcal.init_temp * 27 -3145)/1000))
					pvtp = (int32_t)pvtp +((3145 - tcal.init_temp * 27 )/1000);
				else
					pvtp = 0;

				if((int32_t)pvtn > ((tcal.init_temp * 49 -6582)/1000))
					pvtn = (int32_t)pvtn +((6582 - tcal.init_temp * 49)/1000);
				else
					pvtn = 0;
			} else {
				pvtp = (tcal.init_cal[ch] >> 0) & 0x000003F;
				pvtn = (tcal.init_cal[ch] >> 6) & 0x000003F;
				if((int32_t)pvtp > ((tcal.init_temp * 26 -3201)/1000))
					pvtp = (int32_t)pvtp +((3201 - tcal.init_temp * 26 )/1000);
				else
					pvtp = 0;

				if((int32_t)pvtn > ((tcal.init_temp * 44 -5834)/1000))
					pvtn = (int32_t)pvtn +((5834 - tcal.init_temp * 44)/1000);
				else
					pvtn = 0;
			}

			tcal.init_cal[ch] = (tcal.init_cal[ch] & 0xfffff000) | (pvtn << 6) |(pvtp);

		}
		tcal.init_temp = 125;
	}

	foreach_vch(ch){
		ddr_setval(ch, _reg_PHY_PAD_FDBK_TERM, tcal.init_cal[ch]);
		ddr_setval(ch, _reg_PHY_PAD_DATA_TERM, tcal.init_cal[ch]);
		ddr_setval(ch, _reg_PHY_PAD_DQS_TERM, tcal.init_cal[ch]);
		ddr_setval(ch, _reg_PHY_PAD_ADDR_TERM, tcal.init_cal[ch]);
		ddr_setval(ch, _reg_PHY_PAD_CS_TERM, tcal.init_cal[ch]);
		if(Prr_Product==PRR_PRODUCT_M3N){
			ddr_setval(ch, _reg_PHY_PAD_ODT_TERM, tcal.init_cal[ch]);
		}
	}

}

#ifndef ddr_qos_init_setting
// for QoS init
uint8_t get_boardcnf_phyvalid(void)
{
	return ddr_phyvalid;
}
#endif//ddr_qos_init_setting

/*******************************************************************************
 *	END
 ******************************************************************************/
