/**********************************************************/
/* Sample program : Dummy Header                          */
/* File Name      : debug.h                               */
/* Copyright (C) Renesas Electronics Corp. 2018.          */
/**********************************************************/

#pragma once

#include "boot_init_dram_ext.h"

#define BIT22 (1<<22)

// Message ON
//#define NOTICE      mprintf
//#define tf_printf   mprintf
//#define INFO        mprintf
//#define ERROR       mprintf

// Message OFF
#define NOTICE      noprintf
#define tf_printf   noprintf
#define INFO        noprintf
#define ERROR       noprintf

static inline void noprintf(const char *format,...){}


