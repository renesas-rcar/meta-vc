
#include "common.h"
#include "bit.h"
#include "reg_rcargen3.h"
#include "cpudrv.h"
#include "boardid.h"
#include "dmaspi.h"





const void* const GPIO_INDT[8]={
	(void*)GPIO_INDT0,
	(void*)GPIO_INDT1,
	(void*)GPIO_INDT2,
	(void*)GPIO_INDT3,
	(void*)GPIO_INDT4,
	(void*)GPIO_INDT5,
	(void*)GPIO_INDT6,
	(void*)GPIO_INDT7,
};


uint32_t GetGpioInputLevel( uint32_t gp, uint32_t bit )
{
	uint32_t dataL;
	dataL = *((volatile uint32_t*)GPIO_INDT[gp]);
	if(dataL & (1<<bit))	return 1;
	else					return 0;
}


void PowerOnTmu0(void)
{
	uint32_t dataL;

	dataL = *((volatile uint32_t*)CPG_MSTPSR1);
	if(dataL & BIT25){
		dataL &= ~BIT25;
		*((volatile uint32_t*)CPG_CPGWPR)   = ~dataL;
		*((volatile uint32_t*)CPG_SMSTPCR1) =  dataL;
		while( (BIT25) & *((volatile uint32_t*)CPG_MSTPSR1) );  // wait bit=0
	}
}

// TMU ch0-2   : CP-Clock
// TMU ch3-11  : S3D2_PERE-Clock
// TMU ch12-14 : S3D2_RT-Clock
/************************************************************************/
/*	TMU0���g�p���A�^����ꂽ�����̎��Ԃ����ҋ@���郂�W���[��(10us�P��)	*/
/************************************************************************/
// 10us�P�ʂőҋ@����֐�
void StartTMU0usec(uint32_t tenuSec)
{
	uint16_t dataW;
	uint32_t cnt,dataL;

	PowerOnTmu0();

	*((volatile uint16_t*)TMU_TCR0)  = 0x0000;	// TCNT_count_clock=(Input-Clock)/4    Input-Clock=CP(for channel 0/1/2)

	if(CHK_H3||CHK_M3||CHK_M3N||CHK_V3M||CHK_V3H){
		*((volatile uint32_t*)TMU_TCNT0) = 21;	// [Gen3](8.3333MHz/4)*21=10.08004us (+0.8004s/100s)
		*((volatile uint32_t*)TMU_TCOR0) = 21;	// Input-Clock=CP-Clock=16.6666/2=8.3333MHz                 [ 8.3333MHz = 16.6666MHz(EXTAL) * 1/2 ]
	}else if(CHK_D3||CHK_E3){
		*((volatile uint32_t*)TMU_TCNT0) = 60;	// [Gen3](24.000MHz/4)*60=10.000000us (+-0.000000s/100s)
		*((volatile uint32_t*)TMU_TCOR0) = 60;	// Input-Clock=CP-Clock=24.0000MHz(Fixed)
	}

	*((volatile uint8_t*)TMU_TSTR0) |= BIT0;	// TMU0 Start
	for(cnt=0;cnt<tenuSec;cnt++){
		while(1){
			dataW = *((volatile uint16_t*)TMU_TCR0);
			if(dataW & BIT8){	// UNF(under-flow-flag) clear
				*((volatile uint16_t*)TMU_TCR0) &= ~BIT8;
				break;
			}
		}
	}
	*((volatile uint8_t*)TMU_TSTR0) &= ~BIT0;		// TMU0 Stop
}




/************************************************************************/
/*	TMU0���g�p���A�^����ꂽ�����̎��Ԃ����ҋ@���郂�W���[��(10ms�P��)	*/
/************************************************************************/
void StartTMU0(uint32_t tenmSec)
{
	uint16_t dataW;
	uint32_t cnt,dataL;

	PowerOnTmu0();

	*((volatile uint16_t*)TMU_TCR0)  = 0x0000;	// TCNT_count_clock=(Input-Clock)/4    Input-Clock=CP(for channel 0/1/2)

	if(CHK_H3||CHK_M3||CHK_M3N||CHK_V3M||CHK_V3H){
		*((volatile uint32_t*)TMU_TCNT0) = 20833;	// [Gen3](8.3333MHz/4)*20833=9.999880ms (-0.000012s/100s)
		*((volatile uint32_t*)TMU_TCOR0) = 20833;	// Input-Clock=CP-Clock=16.6666/2=8.3333MHz                 [ 8.3333MHz = 16.6666MHz(EXTAL) * 1/2 ]
	}else if(CHK_D3||CHK_E3){
		*((volatile uint32_t*)TMU_TCNT0) = 60000;	// [Gen3](24.000MHz/4)*60000=10.000000ms (+-0.000000s/100s)
		*((volatile uint32_t*)TMU_TCOR0) = 60000;	// Input-Clock=CP-Clock=24.0000MHz(Fixed)
	}


	*((volatile uint8_t*)TMU_TSTR0) |= BIT0;	// TMU0 Start
	for(cnt=0;cnt<tenmSec;cnt++){
		while(1){
			dataW = *((volatile uint16_t*)TMU_TCR0);
			if(dataW & BIT8){	// UNF(under-flow-flag) clear
				*((volatile uint16_t*)TMU_TCR0) &= ~BIT8;
				break;
			}
		}
	}
	*((volatile uint8_t*)TMU_TSTR0) &= ~BIT0;		// TMU0 Stop
}

