uint32_t SSI_WS6_OpenCheck(void);
uint32_t USB0_OVC_OpenCheck(void);
