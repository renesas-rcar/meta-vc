/**********************
* COMMAND_UNITE       *
***********************/
#define		NORMAL_END			0
#define		ERROR_END			1
