/**********************************************************/
/* Sample program : R-CarH3 RPC Driver Header             */
/* File Name      : rpcdrv.h                              */
/* Copyright (C) Renesas Electronics Corp. 2015.          */
/**********************************************************/
#ifndef	__RPCDRV_
#define	__RPCDRV_

#include <stdint.h>		//for uint32_t


#include "rpcdrv.h"
#include "bit.h"
#include "reg_rcargen3.h"

#define RPC_CLK_160M	160		//160MHz
#define RPC_CLK_133M	133		//133MHz V3M
#define RPC_CLK_80M		 80		// 80MHz
#define RPC_CLK_40M		 40		// 40MHz


#define HYPER_FLASH     0x0
#define QSPI_FLASH      0x1
#define QSPI_FLASH_2CH  0x2


extern void InitRPC_ExtMode(uint32_t mode);
extern uint32_t ReadHyperFlashData8Byte(uint32_t addr, uint32_t *readData);
extern uint32_t SingleReadQspiFlashData4Byte(uint32_t addr, uint32_t *readData);
extern uint32_t QuadReadQspiFlashData4Byte(uint32_t addr, uint32_t *readData);
extern uint32_t ReadQspiFlashData8Byte(uint32_t addr, uint32_t *readData);
extern uint32_t ReadHyperFlashID(uint32_t *readData);
extern void EntryHyperFlashID(void);
extern void ResetHyperFlash(void);
extern void WriteCommandHyperFlash(uint32_t addr, uint32_t writeData);
extern uint32_t ReadQspiFlashID(uint32_t *readData);
extern uint32_t ReadQspiFlashID64(uint32_t *readData1,uint32_t *readData2);
extern void WaitRpcTxEnd(void);

#endif /* __RPCDRV_ */
