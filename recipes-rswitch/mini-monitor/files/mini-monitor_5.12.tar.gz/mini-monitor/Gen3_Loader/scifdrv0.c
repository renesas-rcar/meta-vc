/**********************************************************/
/* Sample program : R-CarH3 SCIF Driver                   */
/* File Name      : scifdrv0.c                             */
/* Copyright (C) Renesas Electronics Corp. 2015.          */
/**********************************************************/

#include "common.h"
#include "scifdrv0.h"
#include "bit.h"
#include "reg_rcargen3.h"


//////////////////////////////////////////////////////////////////////////////////
//                                                                              //
//	Debug Seirial(SCIF0)														//
//																				//
//////////////////////////////////////////////////////////////////////////////////
int32_t PutCharSCIF0(char outChar)
{
	while(!(0x60 & *((volatile uint16_t*)SCIF0_SCFSR) ));
	*((volatile uint8_t*)SCIF0_SCFTDR) = outChar;
	*((volatile uint16_t*)SCIF0_SCFSR) &= ~0x60;	/* TEND,TDFE clear */
	return(0);
}

int32_t GetCharSCIF0(char *inChar)
{
	do{
		if(0x91 & *((volatile uint16_t *)SCIF0_SCFSR))
			*((volatile uint16_t *)SCIF0_SCFSR) &= ~0x91;
		if(0x01 & *((volatile uint16_t *)SCIF0_SCLSR))		//ORER check & clear
			*((volatile uint16_t *)SCIF0_SCLSR) &= ~0x01;
	}while( !(0x02 & *((volatile uint16_t *)SCIF0_SCFSR)) );
		*inChar = *((volatile uint8_t*)SCIF0_SCFRDR);
		*((volatile uint16_t*)SCIF0_SCFSR) &= ~0x02;
	return(0);
}

void PowerOnScif0(void)
{
	uint32_t dataL;

	dataL = *((volatile uint32_t*)CPG_MSTPSR2);
	if(dataL & BIT7){	// case SCIF0
		dataL &= ~BIT7;
		*((volatile uint32_t*)CPG_CPGWPR)    = ~dataL;
		*((volatile uint32_t*)CPG_SMSTPCR2)  =  dataL;
		while( BIT7 & *((volatile uint32_t*)CPG_MSTPSR2) );  // wait bit=0
	}
}

void WaitPutScif0SendEnd(void)
{
	uint16_t dataW;
    uint32_t loop;

	loop=1;
    while(loop){
		dataW = *((volatile uint16_t*)SCIF0_SCFSR);
		if(dataW & BIT6)	loop = 0;
	}
}

void InitScif0_SCIFCLK(void)
{
	uint16_t dataW;

	PowerOnScif0();

	dataW = *((volatile uint16_t*)SCIF0_SCLSR);	/* dummy read     		*/
	*((volatile uint16_t*)SCIF0_SCLSR) = 0x0000;	/* clear ORER bit 		*/
	*((volatile uint16_t*)SCIF0_SCFSR) = 0x0000;	/* clear all error bit	*/

	*((volatile uint16_t*)SCIF0_SCSCR) = 0x0000;	/* clear SCR.TE & SCR.RE*/
	*((volatile uint16_t*)SCIF0_SCFCR) = 0x0006;	/* reset tx-fifo, reset rx-fifo. */

	*((volatile uint16_t*)SCIF0_SCSCR) = 0x0002;	/* external clock, SC_CLK pin used for input pin */
	*((volatile uint16_t*)SCIF0_SCSMR) = 0x0000;	/* 8bit data, no-parity, 1 stop, Po/1 */
	SoftDelay(100);
//	*((volatile uint16_t*)SCIF0_DL)    = 0x0018;	/* 14.7456MHz/ ( 38400*16) = 24 */
	*((volatile uint16_t*)SCIF0_DL)    = 0x0008;	/* 14.7456MHz/ (115200*16) =  8 */
	*((volatile uint16_t*)SCIF0_CKS)   = 0x0000;	/*  select scif_clk	 */
	SoftDelay(100);
	*((volatile uint16_t*)SCIF0_SCFCR) = 0x0000;	/* reset-off tx-fifo, rx-fifo. */
	*((volatile uint16_t*)SCIF0_SCSCR) = 0x0032;	/* enable TE, RE; SC_CLK=input */
	SoftDelay(100);
}

