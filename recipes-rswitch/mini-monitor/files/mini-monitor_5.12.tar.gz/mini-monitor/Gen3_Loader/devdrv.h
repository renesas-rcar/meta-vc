/**********************************************************/
/* Sample program : R-CarH3 Device Driver Header          */
/* File Name      : devdrv.h                              */
/* Copyright (C) Renesas Electronics Corp. 2015.          */
/**********************************************************/
#ifndef	__DEVDRV_
#define	__DEVDRV_

#include <stdint.h>		//for uint32_t

int32_t PutChar(char outChar);
int32_t GetChar(char *inChar);
void WaitPutCharSendEnd(void);

#endif /* __DEVDRV_ */
