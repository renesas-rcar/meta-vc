/**********************************************************/
/* Sample program : R-CarH3 SCIF Driver Header            */
/* File Name      : scifdrv2.h                              */
/* Copyright (C) Renesas Electronics Corp. 2015.          */
/**********************************************************/
#ifndef	__SCIFDRV2_
#define	__SCIFDRV2_

#include <stdint.h>		//for uint32_t

int32_t PutCharSCIF2(char outChar);
int32_t GetCharSCIF2(char *inChar);
void PowerOnScif2(void);
void WaitPutScif2SendEnd(void);
void InitScif2_SCIFCLK(void);
void InitScif2_INTERNAL_S3D1(void);
//void InitScif2_INTERNAL(void);


#endif /* __SCIFDRV2_ */
