/**********************************************************/
/* Sample program : IIC Driver Header                     */
/* File Name      : iicdrv.h                              */
/* Copyright (C) Renesas Electronics Corp. 2015.          */
/**********************************************************/

#ifndef __IICDRV_H_
#define __IICDRV_H_

///////////////////////////////////////////////////////
// IIC Error Define
///////////////////////////////////////////////////////
#define IIC_NORMAL_END			0
#define IIC_ERROR				1
#define IIC_NACK_ERROR			2
#define IIC_TIMEOUT_ERROR		3
#define IIC_AL_ERROR			4


void InitIic(uint32_t chNo);
uint32_t RandomAddressReadIic(uint32_t chNo,uint32_t slAdd,uint32_t accessAdd,uint32_t *rdBuf,uint32_t rdCount);

uint32_t PageWriteIic(uint32_t chNo,uint32_t slAdd,uint32_t accessAdd,uint32_t *wrBuf,uint32_t wrCount);

void InitIic0(void);

void InitIic0PinFunction(void);

void InitIic0Freq(void);

void PowerOnIic0(void);

void ResetIic0Bus(void);

uint32_t RandomAddressReadIic0(uint32_t slAdd,uint32_t accessAdd,uint32_t *rdBuf,uint32_t rdCount);

uint32_t PageWriteIic0(uint32_t slAdd,uint32_t accessAdd,uint32_t *wrBuf,uint32_t wrCount);

#endif
