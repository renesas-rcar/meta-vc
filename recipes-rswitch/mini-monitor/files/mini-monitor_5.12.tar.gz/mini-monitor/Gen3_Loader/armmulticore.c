/**********************************************************/
/* Sample program : ARM Multi Core                        */
/* File Name      : armmulticore.c                        */
/* Copyright (C) Renesas Electronics Corp. 2017.          */
/**********************************************************/

#include "common.h"
#include "armmulticore.h"
#include "reg_rcargen3.h"
#include "bit.h"



///////////////////////////////////////////////////////////////////////////////////////////////////
// Function : SetBootAddress                                                                     //
// Parameter: wupCore  = [CA57/CA53]_CPU[0/1/2/3] (ex. CA57_CPU0)                                //
//          : bootAddr = Boot Address (ex. 0x40000000)                                           //
// Return   : none                                                                               //
// Outline  : Set Boot Address                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////
void SetBootAddress(uint32_t wupCore, uint64_t bootAddr)
{
	uint32_t dataL, bit;
	uint32_t bar, barh, barl, md15;

	// Set Boot Address --------------------------------------------------------

	bar  = ((bootAddr&BIT39_18)>>8 );	// BIT[31:10]=SBAR[39:18]
	barh = ((bootAddr&BIT39_32)>>32);	// BIT[07:00]=Boot Address[39:32]
	barl = ((bootAddr&BIT31_2 )>>0 );	// BIT[31:00]=Boot Address[31:2]

	if(wupCore&(CA53_CPU0|CA53_CPU1|CA53_CPU2|CA53_CPU3)){
		// for AArch32
		*((volatile uint32_t*)RST_CA53BAR) = bar;
		*((volatile uint32_t*)RST_CA53BAR) |= BIT4;		// BIT4=1=SBAR is valid. (2 steps writing)
		*((volatile uint32_t*)RST_CA53BAR2) &= ~BIT0;	// BIT0=0=the address set to SBAR. (Not use SBAR2)
		// for AArch64
		if(wupCore&CA53_CPU0){
			md15 = *((volatile uint32_t*)RST_CA53CPU0BARH) & BIT31;
			*((volatile uint32_t*)RST_CA53CPU0BARH) = barh|md15;
			*((volatile uint32_t*)RST_CA53CPU0BARL) = barl;
		}else if(wupCore&CA53_CPU1){
			md15 = *((volatile uint32_t*)RST_CA53CPU1BARH) & BIT31;
			*((volatile uint32_t*)RST_CA53CPU1BARH) = barh|md15;
			*((volatile uint32_t*)RST_CA53CPU1BARL) = barl;
		}else if(wupCore&CA53_CPU2){
			md15 = *((volatile uint32_t*)RST_CA53CPU2BARH) & BIT31;
			*((volatile uint32_t*)RST_CA53CPU2BARH) = barh|md15;
			*((volatile uint32_t*)RST_CA53CPU2BARL) = barl;
		}else if(wupCore&CA53_CPU3){
			md15 = *((volatile uint32_t*)RST_CA53CPU3BARH) & BIT31;
			*((volatile uint32_t*)RST_CA53CPU3BARH) = barh|md15;
			*((volatile uint32_t*)RST_CA53CPU3BARL) = barl;
		}
	}else if(wupCore&(CA57_CPU0|CA57_CPU1|CA57_CPU2|CA57_CPU3)){
		// for AArch32
		*((volatile uint32_t*)RST_CA57BAR) = bar;
		*((volatile uint32_t*)RST_CA57BAR) |= BIT4;		// BIT4=1=SBAR is valid. (2 steps writing)
		*((volatile uint32_t*)RST_CA57BAR2) &= ~BIT0;	// BIT0=0=the address set to SBAR. (Not use SBAR2)
		// for AArch64
		if(wupCore&CA57_CPU0){
			md15 = *((volatile uint32_t*)RST_CA57CPU0BARH) & BIT31;
			*((volatile uint32_t*)RST_CA57CPU0BARH) = barh|md15;
			*((volatile uint32_t*)RST_CA57CPU0BARL) = barl;
		}else if(wupCore&CA57_CPU1){
			md15 = *((volatile uint32_t*)RST_CA57CPU1BARH) & BIT31;
			*((volatile uint32_t*)RST_CA57CPU1BARH) = barh|md15;
			*((volatile uint32_t*)RST_CA57CPU1BARL) = barl;
		}else if(wupCore&CA57_CPU2){
			md15 = *((volatile uint32_t*)RST_CA57CPU2BARH) & BIT31;
			*((volatile uint32_t*)RST_CA57CPU2BARH) = barh|md15;
			*((volatile uint32_t*)RST_CA57CPU2BARL) = barl;
		}else if(wupCore&CA57_CPU3){
			md15 = *((volatile uint32_t*)RST_CA57CPU3BARH) & BIT31;
			*((volatile uint32_t*)RST_CA57CPU3BARH) = barh|md15;
			*((volatile uint32_t*)RST_CA57CPU3BARL) = barl;
		}
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Function : WakeupArmCore                                                                      //
// Parameter: wupCore  = [CA57/CA53]_CPU[0/1/2/3] (ex. CA57_CPU0)                                //
// Return   : none                                                                               //
// Outline  : Wake up ARM core                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////
void WakeupArmCore(uint32_t wupCore)
{
	uint32_t dataL, bit;
	void *ca53wupcr_p, *ca57wupcr_p;
	uint32_t prr;

	// ARM SCU Power Control ---------------------------------------------------
	if(wupCore&(CA53_CPU0|CA53_CPU1|CA53_CPU2|CA53_CPU3)){
		CtrlNonArmCpuPowerBySYSC(SYSC_CA53_SCU,POWER_RESUME);	// CA53-SCU
	}else if(wupCore&(CA57_CPU0|CA57_CPU1|CA57_CPU2|CA57_CPU3)){
		CtrlNonArmCpuPowerBySYSC(SYSC_CA57_SCU,POWER_RESUME);	// CA57-SCU
	}else if(wupCore&(CR7_CPU0)){
		CtrlNonArmCpuPowerBySYSC(SYSC_CR7     ,POWER_RESUME);	// CR7
	}

	// ARM Core Power Control --------------------------------------------------
	// Need set CPGWPR(CPG Write Protect Register)

	if(CHK_CA57){
		ca53wupcr_p = (void*)APMU_CA53WUPCR;
		ca57wupcr_p = (void*)APMU_CA57WUPCR_SELF;
	}else if(CHK_CA53){
		ca53wupcr_p = (void*)APMU_CA53WUPCR_SELF;
		ca57wupcr_p = (void*)APMU_CA57WUPCR;
	}else if(CHK_CR7){
		ca53wupcr_p = (void*)APMU_CA53WUPCR;
		ca57wupcr_p = (void*)APMU_CA57WUPCR;
	}

	if(wupCore&CA53_CPU0)     { bit=WUPCR_CPU0; }
	else if(wupCore&CA53_CPU1){ bit=WUPCR_CPU1; }
	else if(wupCore&CA53_CPU2){ bit=WUPCR_CPU2; }
	else if(wupCore&CA53_CPU3){ bit=WUPCR_CPU3; }
	else if(wupCore&CA57_CPU0){ bit=WUPCR_CPU0; }
	else if(wupCore&CA57_CPU1){ bit=WUPCR_CPU1; }
	else if(wupCore&CA57_CPU2){ bit=WUPCR_CPU2; }
	else if(wupCore&CA57_CPU3){ bit=WUPCR_CPU3; }

	if(wupCore&(CA53_CPU0|CA53_CPU1|CA53_CPU2|CA53_CPU3)){
		dataL = *((volatile uint32_t*)(ca53wupcr_p));
		dataL |= bit;
		*((volatile uint32_t*)CPG_CPGWPR)    = ~dataL;
		*((volatile uint32_t*)(ca53wupcr_p)) =  dataL;
		while( *((volatile uint32_t*)(ca53wupcr_p)) & bit );		// wait wake up sequence is completed
	}else if(wupCore&(CA57_CPU0|CA57_CPU1|CA57_CPU2|CA57_CPU3)){
		dataL = *((volatile uint32_t*)(ca57wupcr_p));
		dataL |= bit;
		*((volatile uint32_t*)CPG_CPGWPR)    = ~dataL;
		*((volatile uint32_t*)(ca57wupcr_p)) =  dataL;
		while( *((volatile uint32_t*)(ca57wupcr_p)) & bit );		// wait wake up sequence is completed
	}

	// Reset Control -----------------------------------------------------------

	if(wupCore&CA53_CPU0)     { bit=RESCNT_CPU0; }
	else if(wupCore&CA53_CPU1){ bit=RESCNT_CPU1; }
	else if(wupCore&CA53_CPU2){ bit=RESCNT_CPU2; }
	else if(wupCore&CA53_CPU3){ bit=RESCNT_CPU3; }
	else if(wupCore&CA57_CPU0){ bit=RESCNT_CPU0; }
	else if(wupCore&CA57_CPU1){ bit=RESCNT_CPU1; }
	else if(wupCore&CA57_CPU2){ bit=RESCNT_CPU2; }
	else if(wupCore&CA57_CPU3){ bit=RESCNT_CPU3; }

	if(wupCore&(CA53_CPU0|CA53_CPU1|CA53_CPU2|CA53_CPU3)){
		dataL = *((volatile uint32_t*)(RST_CA53RESCNT));
		dataL &= BIT3_0;
		dataL |= 0x5A5A0000;
		dataL &= ~bit;			// Deassert the reset
		*((volatile uint32_t*)(RST_CA53RESCNT)) = dataL;
	}else if(wupCore&(CA57_CPU0|CA57_CPU1|CA57_CPU2|CA57_CPU3)){
		dataL = *((volatile uint32_t*)(RST_CA57RESCNT));
		dataL &= BIT3_0;
		dataL |= 0xA5A50000;
		dataL &= ~bit;			// Deassert the reset
		*((volatile uint32_t*)(RST_CA57RESCNT)) = dataL;
	}
}


///////////////////////////////////////////////////////////////////////////////////////////////////
// Function : CtrlNonArmCpuPowerBySYSC                                                           //
// Parameter: n      = SYSCISR_[CA53_SCU/IMP_X5/CA57_SCU/CR7/A3VP/A3VC] (ex. SYSCISR_CA53_SCU)   //
//          : resume = POWER_RESUME/POWER_SHUTOFF                                                //
// Return   : none                                                                               //
// Outline  : Power Control for non-ARM-CPU domain by SYSC Registers                             //
///////////////////////////////////////////////////////////////////////////////////////////////////
void CtrlNonArmCpuPowerBySYSC(uint32_t n, uint32_t resume)
{
	uint32_t syscisr;
	uint32_t prr;
	void *SYSC_PWRSRn, *SYSC_PWRONCRn, *SYSC_PWROFFCRn, *SYSC_PWRERn;

	// Initialize variables
	switch(n){
	case SYSC_CA53_SCU : syscisr=SYSCISR_CA53_SCU; SYSC_PWRSRn=(void*)SYSC_PWRSR3 ; SYSC_PWRONCRn=(void*)SYSC_PWRONCR3 ; SYSC_PWROFFCRn=(void*)SYSC_PWROFFCR3 ; SYSC_PWRERn=(void*)SYSC_PWRER3 ; break;	// n=3
	case SYSC_IMP_X5   : syscisr=SYSCISR_IMP_X5  ; SYSC_PWRSRn=(void*)SYSC_PWRSR4 ; SYSC_PWRONCRn=(void*)SYSC_PWRONCR4 ; SYSC_PWROFFCRn=(void*)SYSC_PWROFFCR4 ; SYSC_PWRERn=(void*)SYSC_PWRER4 ; break;	// n=4
	case SYSC_CA57_SCU : syscisr=SYSCISR_CA57_SCU; SYSC_PWRSRn=(void*)SYSC_PWRSR5 ; SYSC_PWRONCRn=(void*)SYSC_PWRONCR5 ; SYSC_PWROFFCRn=(void*)SYSC_PWROFFCR5 ; SYSC_PWRERn=(void*)SYSC_PWRER5 ; break;	// n=5
	case SYSC_CR7      : syscisr=SYSCISR_CR7     ; SYSC_PWRSRn=(void*)SYSC_PWRSR7 ; SYSC_PWRONCRn=(void*)SYSC_PWRONCR7 ; SYSC_PWROFFCRn=(void*)SYSC_PWROFFCR7 ; SYSC_PWRERn=(void*)SYSC_PWRER7 ; break;	// n=7
	case SYSC_A3VP     : syscisr=SYSCISR_A3VP    ; SYSC_PWRSRn=(void*)SYSC_PWRSR8 ; SYSC_PWRONCRn=(void*)SYSC_PWRONCR8 ; SYSC_PWROFFCRn=(void*)SYSC_PWROFFCR8 ; SYSC_PWRERn=(void*)SYSC_PWRER8 ; break;	// n=8
	case SYSC_A3VC     : syscisr=SYSCISR_A3VC    ; SYSC_PWRSRn=(void*)SYSC_PWRSR9 ; SYSC_PWRONCRn=(void*)SYSC_PWRONCR9 ; SYSC_PWROFFCRn=(void*)SYSC_PWROFFCR9 ; SYSC_PWRERn=(void*)SYSC_PWRER9 ; break;	// n=9
//	case SYSC_A3VIP    : syscisr=SYSCISR_A3VIP   ; SYSC_PWRSRn=(void*)SYSC_PWRSR12; SYSC_PWRONCRn=(void*)SYSC_PWRONCR12; SYSC_PWROFFCRn=(void*)SYSC_PWROFFCR12; SYSC_PWRERn=(void*)SYSC_PWRER12; break;	// n=12 for R-CarV3H
//	case SYSC_A3VIP1   : syscisr=SYSCISR_A3VIP1  ; SYSC_PWRSRn=(void*)SYSC_PWRSR13; SYSC_PWRONCRn=(void*)SYSC_PWRONCR13; SYSC_PWROFFCRn=(void*)SYSC_PWROFFCR13; SYSC_PWRERn=(void*)SYSC_PWRER13; break;	// n=13 for R-CarV3H
//	case SYSC_A3VIP2   : syscisr=SYSCISR_A3VIP2  ; SYSC_PWRSRn=(void*)SYSC_PWRSR14; SYSC_PWRONCRn=(void*)SYSC_PWRONCR14; SYSC_PWROFFCRn=(void*)SYSC_PWROFFCR14; SYSC_PWRERn=(void*)SYSC_PWRER14; break;	// n=14 for R-CarV3H
	}
	prr = *((volatile uint32_t*)PRR);

	// Check already resume
	if( BIT4 & *((volatile uint32_t*)SYSC_PWRSRn) ) return;  // BIT4=1: The module is in the power non-shutoff state.

	// Figure 9.3 Power Resume/Shutoff Flowchart for non-ARM-CPU domain by SYSC Registers
	// [Start of power resume/power shutoff]
	// Set SYSCIER and SYSCIMR.
	*((volatile uint32_t*)SYSC_SYSCIER) = 0x002031EF;
	*((volatile uint32_t*)SYSC_SYSCIMR) = 0xFFFFFFFF;

	while(1){
		// SYSCSR[0](power shutoff) or SYSCSR[1](power resume) = 1?
		if(resume) while( !(*((volatile uint32_t*)SYSC_SYSCSR) & BIT1) );	// wait BIT=1
		else       while( !(*((volatile uint32_t*)SYSC_SYSCSR) & BIT0) );	// wait BIT=1

		// Set bit in SYSCEXTMASK to 1 (for V3M only)
		if((prr&0xFF00)==0x5400){	// V3M?
			*((volatile uint32_t*)SYSC_SYSCEXTMASK_V3M) = 1;
		}

		// Set bit in PWRONCRn or PWROFFCRn to 1.
		if(resume) *((volatile uint32_t*)SYSC_PWRONCRn)  = 1;
		else       *((volatile uint32_t*)SYSC_PWROFFCRn) = 1;

		// Pertinent bit in PWRERn = 0? (Check whether the request have been accepted.)
		if( *((volatile uint32_t*)SYSC_PWRERn) == 0 ) break;
	}

	// Bit in SYSCISR = 1? (Wait fo the completion of power sequence, by interrupt or register polling.)
	while( !(*((volatile uint32_t*)SYSC_SYSCISR) & syscisr) );	// wait 1=Power shutoff or power resume processing is completed.

	// Clear bit in SYSCISR.
	*((volatile uint32_t*)SYSC_SYSCISCR) = syscisr;	// Writing 1 to this bit clears

	// Clear bit SYSCEXTMASK (for V3M only)
	if((prr&0xFF00)==0x5400){	// V3M?
		*((volatile uint32_t*)SYSC_SYSCEXTMASK_V3M) = 0;
	}
	// [Completion of power resume/power shutoff]
}

#ifndef PRE_BOOT

///////////////////////////////////////////////////////////////////////////////////////////////////
// Function : ResetAndStandbyPreBootCpu                                                          //
// Parameter: none                                                                               //
// Return   : none                                                                               //
// Outline  : Compare myself with the Master Boot Processor(Mode pins) and                       //
//            if the two CPUs are different, reset and standby the Master Boot Processor.        //
///////////////////////////////////////////////////////////////////////////////////////////////////
void ResetAndStandbyPreBootCpu(void)
{
	uint32_t mbp, cpu;

	mbp = GetMasterBootProcessor();
	cpu = GetArmCpuName();

	if(mbp!=cpu){
//		mprintf("Master Boot Processor(0x%08x) != ARM CPU(0x%08x)\n", mbp, cpu);	// for Debug
		ResetArmCpu(mbp);
		StandbyArmCpu(mbp);
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Function : ResetArmCpu                                                                        //
// Parameter: cpuName  = [CA57/CA53]_CPU[0/1/2/3] (ex. CA57_CPU0)                                //
// Return   : none                                                                               //
// Outline  : Reset the ARM CPU                                                                  //
///////////////////////////////////////////////////////////////////////////////////////////////////
void ResetArmCpu(uint32_t cpuName)
{
	uint32_t dataL, bit;

	// Reset Control -----------------------------------------------------------

	if(cpuName&CA53_CPU0)     { bit=RESCNT_CPU0; }
	else if(cpuName&CA53_CPU1){ bit=RESCNT_CPU1; }
	else if(cpuName&CA53_CPU2){ bit=RESCNT_CPU2; }
	else if(cpuName&CA53_CPU3){ bit=RESCNT_CPU3; }
	else if(cpuName&CA57_CPU0){ bit=RESCNT_CPU0; }
	else if(cpuName&CA57_CPU1){ bit=RESCNT_CPU1; }
	else if(cpuName&CA57_CPU2){ bit=RESCNT_CPU2; }
	else if(cpuName&CA57_CPU3){ bit=RESCNT_CPU3; }

	if(cpuName&(CA53_CPU0|CA53_CPU1|CA53_CPU2|CA53_CPU3)){
		dataL = *((volatile uint32_t*)(RST_CA53RESCNT));
		dataL &= BIT3_0;
		dataL |= 0x5A5A0000;
		dataL |= bit;			// Assert the reset
		*((volatile uint32_t*)(RST_CA53RESCNT)) = dataL;
	}else if(cpuName&(CA57_CPU0|CA57_CPU1|CA57_CPU2|CA57_CPU3)){
		dataL = *((volatile uint32_t*)(RST_CA57RESCNT));
		dataL &= BIT3_0;
		dataL |= 0xA5A50000;
		dataL |= bit;			// Assert the reset
		*((volatile uint32_t*)(RST_CA57RESCNT)) = dataL;
	}else if(cpuName&(CR7_CPU0)){
		dataL = *((volatile uint32_t*)CPG_SRCR2);
		dataL |= BIT22;  // ARM Realtime Core
		*((volatile uint32_t*)CPG_CPGWPR) = ~dataL;
		*((volatile uint32_t*)CPG_SRCR2)  =  dataL;
		while( !( BIT22 & *((volatile uint32_t*)CPG_SRCR2) ) );  // wait BIT22==1
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Function : StandbyArmCpu                                                                      //
// Parameter: cpuName  = [CA57/CA53]_CPU[0/1/2/3] (ex. CA57_CPU0)                                //
// Return   : none                                                                               //
// Outline  : Standby the ARM CPU                                                                //
///////////////////////////////////////////////////////////////////////////////////////////////////
void StandbyArmCpu(uint32_t cpuName)
{
	if(cpuName&(CA53_CPU0|CA53_CPU1|CA53_CPU2|CA53_CPU3)){
		CtrlNonArmCpuPowerBySYSC(SYSC_CA53_SCU,POWER_SHUTOFF);	// CA53-SCU
	}else if(cpuName&(CA57_CPU0|CA57_CPU1|CA57_CPU2|CA57_CPU3)){
		CtrlNonArmCpuPowerBySYSC(SYSC_CA57_SCU,POWER_SHUTOFF);	// CA57-SCU
	}else if(cpuName&(CR7_CPU0)){
		CtrlNonArmCpuPowerBySYSC(SYSC_CR7     ,POWER_SHUTOFF);	// CR7
	}
}


///////////////////////////////////////////////////////////////////////////////////////////////////
// Function : GetMasterBootProcessor                                                             //
// Parameter: none                                                                               //
// Return   : CA57_CPU0, CA53_CPU0, CR7_CPU0, ICUMXA_CPU0                                        //
// Outline  : Check the Mode pin(MD7-6) and return Master Boot Processor                         //
///////////////////////////////////////////////////////////////////////////////////////////////////
uint32_t GetMasterBootProcessor(void)
{
	uint32_t md, cpu;

	//------------------------------------------------------
	// Master boot processor
	//------------------------------------------------------
	// MD7  MD6  Booted Processor
	//  0    0    Cortex-A57 CPU0
	//  0    1    Cortex-A53 CPU0
	//  1    0    ICUMXA CPU0 (V3H only)
	//  1    0    Reserved    (not V3H)
	//  1    1    Cortex-R7 CPU0
	md = *((volatile uint32_t*)RST_MODEMR);
	switch( md & (BIT7|BIT6) ){
		case (0        ) : cpu=CA57_CPU0;	break;
		case (BIT6     ) : cpu=CA53_CPU0;	break;
		case (BIT7     ) : cpu=ICUMXA_CPU0;	break;
		case (BIT7|BIT6) : cpu=CR7_CPU0;	break;
	}

	return cpu;
}


///////////////////////////////////////////////////////////////////////////////////////////////////
// Function : GetArmCpuName                                                                      //
// Parameter: none                                                                               //
// Return   : [CA57/CA53/CR7]_CPU[0/1/2/3]                                                       //
// Outline  : Check the ARM internal register and return ARM CPU name                            //
///////////////////////////////////////////////////////////////////////////////////////////////////
uint32_t GetArmCpuName(void)
{
	uint32_t cpu;

	if(CHK_CA57){
		if(CHK_CPU0) cpu=CA57_CPU0;
		if(CHK_CPU1) cpu=CA57_CPU1;
		if(CHK_CPU2) cpu=CA57_CPU2;
		if(CHK_CPU3) cpu=CA57_CPU3;
	}else if(CHK_CA53){
		if(CHK_CPU0) cpu=CA53_CPU0;
		if(CHK_CPU1) cpu=CA53_CPU1;
		if(CHK_CPU2) cpu=CA53_CPU2;
		if(CHK_CPU3) cpu=CA53_CPU3;
	}else if(CHK_CR7){
		if(CHK_CPU0) cpu=CR7_CPU0;
	}

	return cpu;
}

#endif	/* #ifndef PRE_BOOT */
