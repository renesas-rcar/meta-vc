#define LED_COUNT	3		// LED�̌�

uint32_t CntLed(void);
uint32_t CntLedNR(void);
void InitSoftLedGpioOutputPinFunction(void);
void InitGpioOutputPinFunction( uint32_t gp, uint32_t bit );
void SetGpioOutputLevel( uint32_t gp, uint32_t bit, uint32_t lvl );
void CtrlLed( uint32_t ledSel, uint32_t onFlag );
void SoftTimer(uint32_t loop);
