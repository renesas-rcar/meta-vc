void Init_PFC_GPIO(void);
void InitEtherPhyReset(void);
void EtherPhyReset();
void SetEtherPhyRes(uint32_t lvl);
