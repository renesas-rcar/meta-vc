/**********************************************************/
/* Sample program : R-CarH3 DMA Driver Header             */
/* File Name      : dmaspi.h                              */
/* Copyright (C) Renesas Electronics Corp. 2015.          */
/**********************************************************/
#ifndef	__DMASPI_
#define	__DMASPI_

#include <stdint.h>		//for uint32_t

extern void InitDma01_Data(uint32_t prgStartAd, uint32_t sector_Ad, uint32_t accessCount);
extern void StartDma01(void);
extern uint32_t WaitDma01(void);
extern void DisableDma01(void);
extern void ClearDmaCh01(void);

extern void InitRtDmaCh0(uint32_t prgStartAd, uint32_t sector_Ad, uint32_t accessCount);
extern void DisableRtDmaCh0(void);
extern void ClearRtDmaCh0(void);
extern void StartRtDmaCh0_15(void);
extern uint32_t WaitRtDmaCh0(void);

extern void StartRtDma0_Descriptor(void);

#endif /* __DMASPI_ */
