/**********************************************************/
/* Sample program : I2C Driver                            */
/* File Name      : i2cdrv.c                              */
/* Copyright (C) Renesas Electronics Corp. 2016.          */
/**********************************************************/

#include "common.h"
#include "i2cdrv.h"
#include "reg_rcargen3.h"
#include "bit.h"
#include "dgtable.h"
#include "boardid.h"
#include "cpudrv.h"

#define I2C_TIMEOUT		1000	// 100us * 1000 = 100ms

static uint32_t gI2cMainChNo;

// I2C register list
typedef struct i2cRegList{
	uint32_t *ICSCR;			// +0x00 Slave control register
	uint32_t *ICMCR;			// +0x04 Master control register
	uint32_t *ICSSR;			// +0x08 Slave status register
	uint32_t *ICMSR;			// +0x0C Master status register
	uint32_t *ICSIER;			// +0x10 Slave interrupt enable register
	uint32_t *ICMIER;			// +0x14 Master interrupt enable register
	uint32_t *ICCCR;			// +0x18 Clock control register
	uint32_t *ICSAR;			// +0x1C Slave address register
	uint32_t *ICMAR;			// +0x20 Master address register
	uint32_t *ICRXD;			// +0x24 Receive data register
	uint32_t *ICTXD;			// +0x24 Transmit data register
	uint32_t *ICCCR2;			// +0x28 Clock control register 2
	uint32_t *ICMPR;			// +0x2C SCL mask control register
	uint32_t *ICHPR;			// +0x30 SCL high control register
	uint32_t *ICLPR;			// +0x34 SCL low control register
	uint32_t *ICDMAER;			// +0x3C DMA enable register
	uint32_t *ICFBSCR;			// +0x38 First bit setup cycle register
}i2cRegList;

static const i2cRegList I2C_REG_LIST[]={
		{
			(uint32_t *)I2C0_ICSCR	,
			(uint32_t *)I2C0_ICMCR	,
			(uint32_t *)I2C0_ICSSR	,
			(uint32_t *)I2C0_ICMSR	,
			(uint32_t *)I2C0_ICSIER	,
			(uint32_t *)I2C0_ICMIER	,
			(uint32_t *)I2C0_ICCCR	,
			(uint32_t *)I2C0_ICSAR	,
			(uint32_t *)I2C0_ICMAR	,
			(uint32_t *)I2C0_ICRXD	,
			(uint32_t *)I2C0_ICTXD	,
			(uint32_t *)I2C0_ICCCR2	,
			(uint32_t *)I2C0_ICMPR	,
			(uint32_t *)I2C0_ICHPR	,
			(uint32_t *)I2C0_ICLPR	,
			(uint32_t *)I2C0_ICDMAER,
			(uint32_t *)I2C0_ICFBSCR,
		}
#if 0
		{
			(uint32_t *)I2C1_ICSCR	,
			(uint32_t *)I2C1_ICMCR	,
			(uint32_t *)I2C1_ICSSR	,
			(uint32_t *)I2C1_ICMSR	,
			(uint32_t *)I2C1_ICSIER	,
			(uint32_t *)I2C1_ICMIER	,
			(uint32_t *)I2C1_ICCCR	,
			(uint32_t *)I2C1_ICSAR	,
			(uint32_t *)I2C1_ICMAR	,
			(uint32_t *)I2C1_ICRXD	,
			(uint32_t *)I2C1_ICTXD	,
			(uint32_t *)I2C1_ICCCR2	,
			(uint32_t *)I2C1_ICMPR	,
			(uint32_t *)I2C1_ICHPR	,
			(uint32_t *)I2C1_ICLPR	,
			(uint32_t *)I2C1_ICDMAER,
			(uint32_t *)I2C1_ICFBSCR,
		},
		{
			(uint32_t *)I2C2_ICSCR	,
			(uint32_t *)I2C2_ICMCR	,
			(uint32_t *)I2C2_ICSSR	,
			(uint32_t *)I2C2_ICMSR	,
			(uint32_t *)I2C2_ICSIER	,
			(uint32_t *)I2C2_ICMIER	,
			(uint32_t *)I2C2_ICCCR	,
			(uint32_t *)I2C2_ICSAR	,
			(uint32_t *)I2C2_ICMAR	,
			(uint32_t *)I2C2_ICRXD	,
			(uint32_t *)I2C2_ICTXD	,
			(uint32_t *)I2C2_ICCCR2	,
			(uint32_t *)I2C2_ICMPR	,
			(uint32_t *)I2C2_ICHPR	,
			(uint32_t *)I2C2_ICLPR	,
			(uint32_t *)I2C2_ICDMAER,
			(uint32_t *)I2C2_ICFBSCR,
		},
		{
			(uint32_t *)I2C3_ICSCR	,
			(uint32_t *)I2C3_ICMCR	,
			(uint32_t *)I2C3_ICSSR	,
			(uint32_t *)I2C3_ICMSR	,
			(uint32_t *)I2C3_ICSIER	,
			(uint32_t *)I2C3_ICMIER	,
			(uint32_t *)I2C3_ICCCR	,
			(uint32_t *)I2C3_ICSAR	,
			(uint32_t *)I2C3_ICMAR	,
			(uint32_t *)I2C3_ICRXD	,
			(uint32_t *)I2C3_ICTXD	,
			(uint32_t *)I2C3_ICCCR2	,
			(uint32_t *)I2C3_ICMPR	,
			(uint32_t *)I2C3_ICHPR	,
			(uint32_t *)I2C3_ICLPR	,
			(uint32_t *)I2C3_ICDMAER,
			(uint32_t *)I2C3_ICFBSCR,
		},
		{
			(uint32_t *)I2C4_ICSCR	,
			(uint32_t *)I2C4_ICMCR	,
			(uint32_t *)I2C4_ICSSR	,
			(uint32_t *)I2C4_ICMSR	,
			(uint32_t *)I2C4_ICSIER	,
			(uint32_t *)I2C4_ICMIER	,
			(uint32_t *)I2C4_ICCCR	,
			(uint32_t *)I2C4_ICSAR	,
			(uint32_t *)I2C4_ICMAR	,
			(uint32_t *)I2C4_ICRXD	,
			(uint32_t *)I2C4_ICTXD	,
			(uint32_t *)I2C4_ICCCR2	,
			(uint32_t *)I2C4_ICMPR	,
			(uint32_t *)I2C4_ICHPR	,
			(uint32_t *)I2C4_ICLPR	,
			(uint32_t *)I2C4_ICDMAER,
			(uint32_t *)I2C4_ICFBSCR,
		},
#endif
};

////////////////////////////////////////////////////////////////////////////////
// INTERNAL FUNCTION PROTOTYPE
////////////////////////////////////////////////////////////////////////////////
static void InitI2c0PinFunction(void);
static void PowerOnI2c0(void);
static void InitI2c1PinFunction(void);
static void PowerOnI2c1(void);
static void InitI2c2PinFunction(void);
static void PowerOnI2c2(void);
static void InitI2c3PinFunction(void);
static void PowerOnI2c3(void);
static void InitI2c4PinFunction(void);
static void PowerOnI2c4(void);


//////////////////////////////////////////////////////////////////////////////////
//                                                                              //
//  I2C Main Channel Control                                                    //
//                                                                              //
//////////////////////////////////////////////////////////////////////////////////
// I2C0 or I2C4
void SetI2cFlagDefault(void)
{
	gI2cMainChNo = I2C_CH0;
}

void SetI2cFlagRouting(void)
{
	gI2cMainChNo = I2C_CH4;
}

uint32_t GetI2cFlag(void)
{
	return gI2cMainChNo;
}


////////////////////////////////////////////////////////////////////////////////
// FUNCTION : InitI2c                                                         //
// ARGUMENT : chNo = I2C��ch�w�� (0~6)                                        //
// RETURN   : none                                                            //
// OUTLINE  : �w��ch��I2C module������������                                  //
////////////////////////////////////////////////////////////////////////////////
void InitI2c(uint32_t chNo)
{
	// Power On & Initialize Pin-Function
	PowerOnI2c(chNo);
	InitI2cPinFunction(chNo);

	*((volatile uint32_t*)I2C_REG_LIST[chNo].ICCCR2) = 0x00000000;	// CDFD=0,HLSE=0,SME=0

    *((volatile uint32_t*)I2C_REG_LIST[chNo].ICCCR) = ((3<<3) | 7);		// SCGD=3,CDF=7
	//																	// MOD_CLK=S3D2-clk=133.33MHz
	//																	// I2Cck=MOD_CLK/(1+CDF)=16.66625MHz
	//																	// SCL-Freq=16.66625/(20+8*SCGD+alpha)=378.78kHz
	*((volatile uint32_t*)I2C_REG_LIST[chNo].ICSCR)  = 0x00000000;
	*((volatile uint32_t*)I2C_REG_LIST[chNo].ICSSR)  = 0x00000000;
	*((volatile uint32_t*)I2C_REG_LIST[chNo].ICSIER) = 0x00000000;
	*((volatile uint32_t*)I2C_REG_LIST[chNo].ICSAR)  = 0x00000000;
	*((volatile uint32_t*)I2C_REG_LIST[chNo].ICMCR)  = 0x00000088;
	*((volatile uint32_t*)I2C_REG_LIST[chNo].ICMSR)  = 0x00000000;
	*((volatile uint32_t*)I2C_REG_LIST[chNo].ICMIER) = 0x00000000;
	*((volatile uint32_t*)I2C_REG_LIST[chNo].ICMAR)  = 0x00000000;
//	*((volatile uint32_t*)I2C_REG_LIST[chNo].ICFBSCR)= 0x0000000F;		// DMA�����ł�0x0F�ɐݒ肵�Ă���B�����l0x04
}


////////////////////////////////////////////////////////////////////////////////
// FUNCTION : RandomAddressReadI2C                                            //
// ARGUMENT : chNo      = I2C��ch�w�� (0~6)                                   //
//          : slAdd     = �X���[�u�A�h���X�w�� (BIT0��0�Œ��8bit��)          //
//          : accessAdd = �A�N�Z�X�A�h���X�w�� (0x01~0xFF)                    //
//          : *rdBuf    = ���[�h�f�[�^�i�[�|�C���^ (1�ϐ��ɂ�1�f�[�^�i�[)   //
//          : rdCount   = ���[�h�񐔂̎w�� (0x01~)                            //
// RETURN   : ���펞 = NORMAL_END = 0                                         //
//          : �ُ펞 = ERROR_END = 1 (������)                                 //
// OUTLINE  : �w��ch��I2C�Ŏw��A�h���X���烊�[�h����                         //
////////////////////////////////////////////////////////////////////////////////
uint32_t RandomAddressReadI2C(uint32_t chNo, uint32_t slAdd, uint32_t accessAdd, uint32_t *rdBuf, uint32_t rdCount)
{
	uint32_t dataL,i;
	uint32_t timeout;

	// �]���񐔂�1�ȏ�K�v
	if( 1>rdCount ) return ERROR_END;

	/* �o�X�̋󂫏�Ԃ��`�F�b�N	*/
	while(1){
		dataL = *((volatile uint32_t*)I2C_REG_LIST[chNo].ICMCR);
		dataL &= 0x60;
		if(dataL == 0x40) break;
	}

	// Clear the Master Status register (ICMSR) = H�f00 (all 0 clear)
	*((volatile uint32_t*)I2C_REG_LIST[chNo].ICMSR) = 0x00000000;

	*((volatile uint32_t*)I2C_REG_LIST[chNo].ICMCR) = 0x00000088;		/* Ͻ����۰�ڼ޽������ݒ�			*/
	dataL = slAdd & 0x000000FF;											/* �X���[�u�A�h���X����				*/
	dataL  &= ~BIT0;													/* STM1 = 0:���C�g					*/
	*((volatile uint32_t*)I2C_REG_LIST[chNo].ICMAR) = dataL;			/* Ͻ���ڽڼ޽��ݒ�					*/
	dataL = accessAdd;
	dataL &= 0x000000FF;												/* �������ڽ����					*/
	*((volatile uint32_t*)I2C_REG_LIST[chNo].ICTXD) = dataL;			/* ��ꑗ�M�ް��ݒ�(EEPROM�̱��ڽ)	*/

	/* �o�X�̋󂫏�Ԃ��`�F�b�N	*/
	while(1){
		dataL = *((volatile uint32_t*)I2C_REG_LIST[chNo].ICMCR);
		dataL &= 0x60;
		if(dataL == 0x40) break;
	}
	*((volatile uint32_t*)I2C_REG_LIST[chNo].ICMCR) = 0x00000089;	/* Ͻ����۰�ڼ޽�					*/
																	/* MDBS=1 :�ݸ���ޯ̧Ӱ��			*/
																	/* MIE=1  :Ͻ����̪���L��			*/
																	/* ESG=1  :�Ȱ��ٽ��Đ���			*/

	/* ��1�o�C�g(I2C_Address)���M�I���҂�	*/
	timeout = 0;
	while(1){
		dataL = *((volatile uint32_t*)I2C_REG_LIST[chNo].ICMSR);
		if( dataL & BIT3 )										/* MDE=1:Ͻ��ް�����è				*/
			if( dataL & BIT0 )									/* MAT=1:Ͻ����ڽ���M				*/
				break;
		if( dataL & BIT6 ) return I2C_NACK_ERROR;				// MNR=1:Master NACK Received
		if( timeout++ > I2C_TIMEOUT ) return I2C_TIMEOUT_ERROR;	// timeout = 1000 * 100us = 100ms
		StartTMU0usec(10);										// Wait 100us
	}

	*((volatile uint32_t*)I2C_REG_LIST[chNo].ICMCR)  = 0x00000088;
																// STOP���s���s��Ȃ��悤�ɕύX
	*((volatile uint32_t*)I2C_REG_LIST[chNo].ICMSR) &= 0x000000F6;	/* MDE,MAT�ر ������1st data���M�J�n*/

	timeout = 0;
	while(1){
		dataL = *((volatile uint32_t*)I2C_REG_LIST[chNo].ICMSR);
		if( dataL & BIT3 )										// MDE=1:Master Data Empty
			  break;
		if( dataL & BIT6 ) return I2C_NACK_ERROR;				// MNR=1:Master NACK Received
		if( timeout++ > I2C_TIMEOUT ) return I2C_TIMEOUT_ERROR;	// timeout = 1000 * 100us = 100ms
		StartTMU0usec(10);										// Wait 100us
	}

	/* RESTART,��3�o�C�g�]������ */
	dataL = *((volatile uint32_t*)I2C_REG_LIST[chNo].ICMAR);
	dataL &= 0x000000FF;
	dataL |= BIT0;
	*((volatile uint32_t*)I2C_REG_LIST[chNo].ICMAR) = dataL;         /* Ͻ���ڽڼ޽��ݒ�,STM=1:ذ��		*/
	*((volatile uint32_t*)I2C_REG_LIST[chNo].ICMCR) = 0x00000089;	/* Ͻ����۰�ڼ޽�:START��������(2byte�ړ]���I����)*/

	*((volatile uint32_t*)I2C_REG_LIST[chNo].ICMSR) = 0x00000000;	// Move Status Clear Timing

	/* ��3�o�C�g(I2C_Address,RESTART)���M�I���҂�	*/
	timeout = 0;
	while(1){
		dataL = *((volatile uint32_t*)I2C_REG_LIST[chNo].ICMSR);
		if( dataL & BIT1 )										/* MDR=1:Ͻ��ް���M				*/
		  if( dataL & BIT0 )									/* MAT=1:Ͻ����ڽ���M				*/
			  break;
		if( dataL & BIT6 ) return I2C_NACK_ERROR;				// MNR=1:Master NACK Received
		if( timeout++ > I2C_TIMEOUT ) return I2C_TIMEOUT_ERROR;	// timeout = 1000 * 100us = 100ms
		StartTMU0usec(10);										// Wait 100us
	}

	*((volatile uint32_t*)I2C_REG_LIST[chNo].ICMCR) = 0x00000088;

	if(rdCount==1)
		*((volatile uint32_t*)I2C_REG_LIST[chNo].ICMCR) = 0x0000008A;/* Ͻ����۰�ڼ޽�:STOP��������		*/

	*((volatile uint32_t*)I2C_REG_LIST[chNo].ICMSR) &= 0x000000FC;	/* MDR,MAT�ر */

	/* ��4�o�C�g�`��N�o�C�g(EEPROM�̃f�[�^)��M�I���҂�	*/
	for(i=0;i<rdCount;i++){
		// rdCount��1�ȊO�ŁA���̑��M�f�[�^���Ō�̃f�[�^�̏ꍇ0x8A�𔭍s
		// rcCount��1�̏ꍇ�͎��O�ɔ��s�ς�
		if((rdCount!=1)&&(i==rdCount-1)){
			*((volatile uint32_t*)I2C_REG_LIST[chNo].ICMCR) = 0x0000008A;/* Ͻ����۰�ڼ޽�:STOP��������		*/
		}

		timeout = 0;
		while(1){
			dataL = *((volatile uint32_t*)I2C_REG_LIST[chNo].ICMSR);
			if( dataL & BIT1 )									/* MDR=1:Ͻ��ް���M				*/
				break;
			if( dataL & BIT6 ) return I2C_NACK_ERROR;				// MNR=1:Master NACK Received
			if( timeout++ > I2C_TIMEOUT ) return I2C_TIMEOUT_ERROR;	// timeout = 1000 * 100us = 100ms
			StartTMU0usec(10);										// Wait 100us
		}

		*rdBuf = ( *((volatile uint32_t*)I2C_REG_LIST[chNo].ICRXD) & 0x0FF);
		rdBuf++;

		*((volatile uint32_t*)I2C_REG_LIST[chNo].ICMSR) = 0x00000000;	/* MDR,MAT�ر */

	}

	while(1){
		dataL = *((volatile uint32_t*)I2C_REG_LIST[chNo].ICMSR);
		if( dataL & BIT4 )											/* MST=1:Ͻ��į�ߑ��M				*/
			break;
	}

	*((volatile uint32_t*)I2C_REG_LIST[chNo].ICMSR) = 0x00000000;		/* MST�ر						*/
	*((volatile uint32_t*)I2C_REG_LIST[chNo].ICMCR) = 0x00000088;

	return NORMAL_END;
}


////////////////////////////////////////////////////////////////////////////////
// FUNCTION : PageWriteI2C                                                    //
// ARGUMENT : chNo      = I2C��ch�w�� (0~6)                                   //
//          : slAdd     = �X���[�u�A�h���X�w�� (BIT0��0�Œ��8bit��)          //
//          : accessAdd = �A�N�Z�X�A�h���X�w�� (0x01~0xFF)                    //
//          : *wrBuf    = ���C�g�f�[�^�i�[�|�C���^ (1�ϐ��ɂ�1�f�[�^�i�[)   //
//          : wrCount   = ���C�g�񐔂̎w�� (0x01~)                            //
// RETURN   : ���펞 = NORMAL_END = 0                                         //
//          : �ُ펞 = ERROR_END = 1 (������)                                 //
// OUTLINE  : �w��ch��I2C�Ŏw��A�h���X���烊�[�h����                         //
////////////////////////////////////////////////////////////////////////////////
uint32_t PageWriteI2C(uint32_t chNo,uint32_t slAdd,uint32_t accessAdd,uint32_t *wrBuf,uint32_t wrCount)
{
	uint32_t dataL,i;
	uint32_t timeout;

	// �]���񐔂�1�ȏ�K�v
	if( 1>wrCount ) return ERROR_END;

	/* �o�X�̋󂫏�Ԃ��`�F�b�N	*/
	while(1){
		dataL = *((volatile uint32_t*)I2C_REG_LIST[chNo].ICMCR);
		dataL &= 0x60;
		if(dataL == 0x40) break;
	}

	*((volatile uint32_t*)I2C_REG_LIST[chNo].ICMCR) = 0x00000088;	/* Ͻ����۰�ڼ޽������ݒ�			*/
	dataL = slAdd & 0x000000FF;										/* �X���[�u�A�h���X����				*/
	dataL  &= ~BIT0;												/* STM1 = 0:���C�g					*/
	*((volatile uint32_t*)I2C_REG_LIST[chNo].ICMAR) = dataL;		/* Ͻ���ڽڼ޽��ݒ�					*/
	dataL = accessAdd;
	dataL &= 0x000000FF;											/* EEPROM�������ڽ����				*/
	*((volatile uint32_t*)I2C_REG_LIST[chNo].ICTXD) = dataL;		/* ��ꑗ�M�ް��ݒ�(EEPROM�̱��ڽ)	*/

	/* �o�X�̋󂫏�Ԃ��`�F�b�N	*/
	while(1){
		dataL = *((volatile uint32_t*)I2C_REG_LIST[chNo].ICMCR);
		dataL &= 0x60;
		if(dataL == 0x40) break;
	}
	*((volatile uint32_t*)I2C_REG_LIST[chNo].ICMCR) = 0x00000089;	/* Ͻ����۰�ڼ޽�(�Ȱ��ٽ���)		*/
																	/* MDBS=1 :�ݸ���ޯ̧Ӱ��			*/
																	/* MIE=1  :Ͻ����̪���L��			*/
																	/* ESG=1  :�Ȱ��ٽ��Đ���			*/
	/* ��1�o�C�g(I2C_Address)���M�I���҂�	*/
	timeout = 0;
	while(1){
		dataL = *((volatile uint32_t*)I2C_REG_LIST[chNo].ICMSR);
		if( dataL & BIT3 )											/* MDE=1:Ͻ��ް�����è				*/
		  if( dataL & BIT0 )										/* MAT=1:Ͻ����ڽ���M				*/
			break;
		if( dataL & BIT6 ) return I2C_NACK_ERROR;				// MNR=1:Master NACK Received
		if( timeout++ > I2C_TIMEOUT ) return I2C_TIMEOUT_ERROR;	// timeout = 1000 * 100us = 100ms
		StartTMU0usec(10);										// Wait 100us
	}

	*((volatile uint32_t*)I2C_REG_LIST[chNo].ICMCR) = 0x00000088;	/* Ͻ����۰�ڼ޽�(���Đ����Ȃ�)		*/
	*((volatile uint32_t*)I2C_REG_LIST[chNo].ICMSR) &= 0x000000F6;	/* MDE,MAT�ر 						*/

	// ��Q�o�C�g���M�I���҂�
	timeout = 0;
	while(1){
		dataL = *((volatile uint32_t*)I2C_REG_LIST[chNo].ICMSR);
		if( dataL & BIT3 )											// MDE=1:Master Data Empty
		  if(dataL & BIT2)
			break;
		if( dataL & BIT6 ) return I2C_NACK_ERROR;				// MNR=1:Master NACK Received
		if( timeout++ > I2C_TIMEOUT ) return I2C_TIMEOUT_ERROR;	// timeout = 1000 * 100us = 100ms
		StartTMU0usec(10);										// Wait 100us
	}

	/* ��3�o�C�g�`��N�o�C�g(EEPROM�̃f�[�^)���M�I���҂�	*/
	for(i=0;i<wrCount;i++){
		*((volatile uint32_t*)I2C_REG_LIST[chNo].ICTXD) = *wrBuf;
		wrBuf++;

		dataL = *((volatile uint32_t*)I2C_REG_LIST[chNo].ICMSR);
		dataL &= ~(BIT3|BIT2);
		dataL &= 0x000000FF;
		*((volatile uint32_t*)I2C_REG_LIST[chNo].ICMSR) = dataL;

		timeout = 0;
		while(1){
			dataL = *((volatile uint32_t*)I2C_REG_LIST[chNo].ICMSR);
			if( dataL & BIT3 )										/* MDE=1:Ͻ��ް�����è				*/
				if(dataL & BIT2)									// TDE=1�m�F�ǉ�
					break;
			if( dataL & BIT6 ) return I2C_NACK_ERROR;				// MNR=1:Master NACK Received
			if( timeout++ > I2C_TIMEOUT ) return I2C_TIMEOUT_ERROR;	// timeout = 1000 * 100us = 100ms
			StartTMU0usec(10);										// Wait 100us
		}

	}

	*((volatile uint32_t*)I2C_REG_LIST[chNo].ICMCR) = 0x0000008A;	/* Ͻ����۰�ڼ޽�:STOP��������		*/
	*((volatile uint32_t*)I2C_REG_LIST[chNo].ICMSR) = 0x00000000;	/* MST�ر							*/

	while(1){
		dataL = *((volatile uint32_t*)I2C_REG_LIST[chNo].ICMSR);
		if( dataL & BIT4 )											/* MST=1:Ͻ��į�ߑ��M				*/
			break;
	}

	*((volatile uint32_t*)I2C_REG_LIST[chNo].ICMSR) = 0x00000000;	/* MST�ر							*/
	*((volatile uint32_t*)I2C_REG_LIST[chNo].ICMCR) = 0x00000088;

	return NORMAL_END;

}


////////////////////////////////////////////////////////////////////////////////
// FUNCTION : InitI2c0PinFunction                                             //
// ARGUMENT : chNo = I2C��ch�w�� (0~6)                                        //
// RETURN   : none                                                            //
// OUTLINE  : I2C�s���t�@���N�V�����ݒ�                                       //
////////////////////////////////////////////////////////////////////////////////
void InitI2cPinFunction(uint32_t chNo)
{
	switch(chNo){
		case I2C_CH0: InitI2c0PinFunction(); break;
		case I2C_CH1: InitI2c1PinFunction(); break;
		case I2C_CH2: InitI2c2PinFunction(); break;
		case I2C_CH3: InitI2c3PinFunction(); break;
		case I2C_CH4: InitI2c4PinFunction(); break;
	}
	return;
}


////////////////////////////////////////////////////////////////////////////////
// FUNCTION : PowerOnI2c                                                      //
// ARGUMENT : chNo = I2C��ch�w�� (0~4)                                        //
// RETURN   : none                                                            //
// OUTLINE  : I2C���W���[���X�g�b�v���W�X�^����                               //
//          : SMSTPCR9[31]=I2C0                                               //
//          : SMSTPCR9[30]=I2C1                                               //
//          : SMSTPCR9[29]=I2C2                                               //
//          : SMSTPCR9[28]=I2C3                                               //
//          : SMSTPCR9[27]=I2C4                                               //
////////////////////////////////////////////////////////////////////////////////
void PowerOnI2c(uint32_t chNo)
{
	switch(chNo){
		case I2C_CH0: PowerOnI2c0(); break;
		case I2C_CH1: PowerOnI2c1(); break;
		case I2C_CH2: PowerOnI2c2(); break;
		case I2C_CH3: PowerOnI2c3(); break;
		case I2C_CH4: PowerOnI2c4(); break;
	}
	return;
}


////////////////////////////////////////////////////////////////////////////////
// FUNCTION : PowerOnI2c0                                                     //
// FUNCTION : InitI2c0PinFunction                                             //
// ARGUMENT : none                                                            //
// RETURN   : none                                                            //
// OUTLINE  : I2C0���W���[���X�g�b�v���W�X�^�����A�s���t�@���N�V�����ݒ�      //
////////////////////////////////////////////////////////////////////////////////
static void InitI2c0PinFunction(void)
{
	uint32_t dataL;

	if(CHK_V3M||CHK_V3H){
		// SCL0 = GP4_00 = IPSR7[7:4]  = PUEN2[1] = PUD2[1]
		// SDA0 = GP4_01 = IPSR7[11:8] = PUEN2[2] = PUD2[2]

		// IPSR7[11:8][7:4] -> all 0 -> SDA0, SCL0
		dataL = *((volatile uint32_t*)PFC_IPSR7);
		dataL &= ~(BIT11_8|BIT7_4);
		*((volatile uint32_t*)PFC_PMMR)  = ~dataL;
		*((volatile uint32_t*)PFC_IPSR7) =  dataL;

		// GPSR4[1][0] -> Peripheral Function
		dataL = *((volatile uint32_t*)PFC_GPSR4);
		dataL |= (BIT1|BIT0);
		*((volatile uint32_t*)PFC_PMMR)  = ~dataL;
		*((volatile uint32_t*)PFC_GPSR4) =  dataL;

		if(CHK_V3M){
			// PUEN2[2][1] = all 0 -> Pull-up/down function is disabled.
			dataL = *((volatile uint32_t*)PFC_PUEN2);
			dataL &= ~(BIT2|BIT1);
			*((volatile uint32_t*)PFC_PMMR)  = ~dataL;
			*((volatile uint32_t*)PFC_PUEN2) =  dataL;
		}
		else if(CHK_V3H){
			// PUEN2[11][10] = all 0 -> Pull-up/down function is disabled.
			dataL = *((volatile uint32_t*)PFC_PUEN2);
			dataL &= ~(BIT11|BIT10);
			*((volatile uint32_t*)PFC_PMMR)  = ~dataL;
			*((volatile uint32_t*)PFC_PUEN2) =  dataL;
		}
	}else if(CHK_D3){
		// SCL0 = GP4_08 = No IPSR = PUEN3[23]
		// SDA0 = GP4_09 = No IPSR = PUEN3[22]

		// GPSR4[9][8] -> Peripheral Function
		dataL = *((volatile uint32_t*)PFC_GPSR4);
		dataL |= (BIT9|BIT8);
		*((volatile uint32_t*)PFC_PMMR)  = ~dataL;
		*((volatile uint32_t*)PFC_GPSR4) =  dataL;

		// PUEN3[23][22] = all 0 -> Pull-up/down function is disabled.
		dataL = *((volatile uint32_t*)PFC_PUEN3);
		dataL &= ~(BIT23|BIT22);
		*((volatile uint32_t*)PFC_PMMR)  = ~dataL;
		*((volatile uint32_t*)PFC_PUEN3) =  dataL;
	}else if(CHK_E3){
		// SCL0,SDA0:��ppin
	}
}

static void PowerOnI2c0(void)
{
	uint32_t dataL;
	dataL = *((volatile uint32_t*)CPG_MSTPSR9);
	if(dataL & BIT31){
		dataL &= ~BIT31;
		*((volatile uint32_t*)CPG_CPGWPR)   = ~dataL;
		*((volatile uint32_t*)CPG_SMSTPCR9) =  dataL;
		while( BIT31 & *((volatile uint32_t*)CPG_MSTPSR9) );  // wait bit=0
	}
}


////////////////////////////////////////////////////////////////////////////////
// FUNCTION : PowerOnI2c1                                                     //
// FUNCTION : InitI2c1PinFunction                                             //
// ARGUMENT : none                                                            //
// RETURN   : none                                                            //
// OUTLINE  : I2C1���W���[���X�g�b�v���W�X�^�����A�s���t�@���N�V�����ݒ�      //
////////////////////////////////////////////////////////////////////////////////
static void InitI2c1PinFunction(void)
{
}

static void PowerOnI2c1(void)
{
}


////////////////////////////////////////////////////////////////////////////////
// FUNCTION : PowerOnI2c2                                                     //
// FUNCTION : InitI2c2PinFunction                                             //
// ARGUMENT : none                                                            //
// RETURN   : none                                                            //
// OUTLINE  : I2C2���W���[���X�g�b�v���W�X�^�����A�s���t�@���N�V�����ݒ�      //
////////////////////////////////////////////////////////////////////////////////
static void InitI2c2PinFunction(void)
{
}

static void PowerOnI2c2(void)
{
}


////////////////////////////////////////////////////////////////////////////////
// FUNCTION : PowerOnI2c3                                                     //
// FUNCTION : InitI2c3PinFunction                                             //
// ARGUMENT : none                                                            //
// RETURN   : none                                                            //
// OUTLINE  : I2C3���W���[���X�g�b�v���W�X�^�����A�s���t�@���N�V�����ݒ�      //
////////////////////////////////////////////////////////////////////////////////
static void InitI2c3PinFunction(void)
{
}

static void PowerOnI2c3(void)
{
}


////////////////////////////////////////////////////////////////////////////////
// FUNCTION : PowerOnI2c4                                                     //
// FUNCTION : InitI2c4PinFunction                                             //
// ARGUMENT : none                                                            //
// RETURN   : none                                                            //
// OUTLINE  : I2C4���W���[���X�g�b�v���W�X�^�����A�s���t�@���N�V�����ݒ�      //
////////////////////////////////////////////////////////////////////////////////
static void InitI2c4PinFunction(void)
{
}

static void PowerOnI2c4(void)
{
}


