/**********************************************************/
/* Sample program : R-CarH3 DMA Driver                    */
/* File Name      : dmaspi.c                              */
/* Copyright (C) Renesas Electronics Corp. 2015.          */
/**********************************************************/

#include "dmaspi.h"
#include "reg_rcargen3.h"
#include "bit.h"


void InitDma01_Data(uint32_t prgStartAd, uint32_t sector_Ad, uint32_t accessCount);
void StartDma01(void);
uint32_t WaitDma01(void);
void DisableDma01(void);
void ClearDmaCh01(void);

void InitRtDmaCh0(uint32_t prgStartAd, uint32_t sector_Ad, uint32_t accessCount);
void DisableRtDmaCh0(void);
void ClearRtDmaCh0(void);
void StartRtDmaCh0_15(void);
uint32_t WaitRtDmaCh0(void);

void StartRtDma0_Descriptor(void);

void InitDma01_Data(uint32_t prgStartAd, uint32_t sector_Ad, uint32_t accessCount)
{
	//DMA Setting
	*((volatile uint32_t*)SYSDMAC_DMASAR_0)    =  sector_Ad;		//	RPC area
	*((volatile uint32_t*)SYSDMAC_DMADAR_0)    =  prgStartAd;		//	
	*((volatile uint32_t*)SYSDMAC_DMATCR_0)    =  accessCount;		//
	*((volatile uint32_t*)SYSDMAC_DMACHCR_0)   =  0x00105409;		//64Byte/AutoRequest mode
}

void DisableDma01(void)
{
	*((volatile uint32_t*)SYSDMAC_DMACHCR_0)   &=  0x00105410;		//64Byte/AutoRequest mode
}

void ClearDmaCh01(void)
{
	*((volatile uint32_t*)SYSDMAC_DMACHCLR_0) |= BIT0;
}

void StartDma01(void)
{
	*((volatile uint16_t*)SYSDMAC_DMAOR_0)  =  0x0001;				//Start DMA	  ( Priority Mode:Fixed )
}

uint32_t WaitDma01(void)
{
	uint32_t dataL=0;

	////////////////////////////////
	// DMA transfer complite check
	////////////////////////////////
	while(1){
		dataL = *((volatile uint32_t*)SYSDMAC_DMACHCR_0);
		if(dataL & BIT1){
			*((volatile uint32_t*)SYSDMAC_DMACHCR_0) &= ~BIT1;		// TE Clear
			break;
		}
		if(dataL & BIT31){
			*((volatile uint32_t*)SYSDMAC_DMACHCR_0) &= ~BIT31;	// CAE Clear
			return(1);
		}
	}
	*((volatile uint16_t*)SYSDMAC_DMAOR_0) = 0x0000;				//0: Disables DMA transfers on all channels
	return(0);
}

//===  RT-DAMC ===============================================
void InitRtDmaCh0(uint32_t prgStartAd, uint32_t sector_Ad, uint32_t accessCount)
{
	//DMA Setting
	*((volatile uint32_t*)RTDMAC_RDMSAR_0)    =  sector_Ad;		//	RPC area
	*((volatile uint32_t*)RTDMAC_RDMDAR_0)    =  prgStartAd;	//	
	*((volatile uint32_t*)RTDMAC_RDMTCR_0)    =  accessCount;	//
	*((volatile uint32_t*)RTDMAC_RDMCHCR_0)   =  0x00105409;	//64Byte/AutoRequest mode
}

void DisableRtDmaCh0(void)
{
	*((volatile uint32_t*)RTDMAC_RDMCHCR_0)    &=  0x00105408;		//64Byte/AutoRequest mode
}

void ClearRtDmaCh0(void)
{
	*((volatile uint32_t*)RTDMAC_RDMCHCLR) |= BIT0;
}

void StartRtDmaCh0_15(void)
{
	*((volatile uint16_t*)RTDMAC_RDMOR)  =  0x0001;				//Start DMA	  ( Priority Mode:Fixed )
}

uint32_t WaitRtDmaCh0(void)
{
	uint32_t dataL=0;

	////////////////////////////////
	// DMA transfer complite check
	////////////////////////////////
	while(1){
		dataL = *((volatile uint32_t*)RTDMAC_RDMCHCR_0);
		if(dataL & BIT1){
			*((volatile uint32_t*)RTDMAC_RDMCHCR_0) &= ~BIT1;	// TE Clear
			break;
		}
		if(dataL & BIT31){
			*((volatile uint32_t*)RTDMAC_RDMCHCR_0) &= ~BIT31;	// CAE Clear
			return(1);
		}
	}
	*((volatile uint16_t*)RTDMAC_RDMOR) = 0x0000;				//0: Disables DMA transfers on all channels
	return(0);
}







void StartRtDma0_Descriptor(void)
{
	//Initialize ch0, Reset Descriptor
	*((volatile uint32_t*)RTDMAC_RDMCHCLR)   = 0x00000001;
	*((volatile uint32_t*)RTDMAC_RDMCHCRB_0) = 0x00008000;
	
	//Enable DMA
	*((volatile uint16_t*)RTDMAC_RDMOR)  =  0x0001;			//Start DMA (Priority Mode:Fixed)
	
	//Set first transfer
	*((volatile uint32_t*)RTDMAC_RDMSAR_0)    =  PRR;			//	source_addr
	*((volatile uint32_t*)RTDMAC_RDMDAR_0)    =  SCIF3_SCFDR;	//	destination_addr
	*((volatile uint32_t*)RTDMAC_RDMTCR_0)    =  0x00000001;	//	transfer_count
	
	//Set descriptor
	*((volatile uint32_t*)RTDMAC_DESC_RDMSAR)    =  0x00000000;
	*((volatile uint32_t*)RTDMAC_DESC_RDMDAR)    =  0x00000000;
	*((volatile uint32_t*)RTDMAC_DESC_RDMTCR)    =  0x00200000;
	*((volatile uint32_t*)RTDMAC_RDMCHCRB_0)     =  0x00000080;
	*((volatile uint32_t*)RTDMAC_RDMDPBASE_0)    = (RTDMAC_DESC_RDMSAR | 0x1);

	//Set transfer parameter, Start transfer
	*((volatile uint32_t*)RTDMAC_RDMCHCR_0)      =  0x32000409;	
	
}
