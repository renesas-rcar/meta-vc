/**********************************************************/
/* Sample program : IIC Driver                            */
/* File Name      : iicdrv.c                              */
/* Copyright (C) Renesas Electronics Corp. 2015.          */
/**********************************************************/

#include "common.h"
#include "cpudrv.h"
#include "iicdrv.h"
#include "i2cdrv.h"
#include "reg_rcargen3.h"
#include "bit.h"
#include "boardid.h"
#define IIC_TIMEOUT		50000	// 10us * 50000 = 500ms

static uint32_t Iic0InterruptWait(void);
static uint32_t Iic0InterruptDte(void);
static uint32_t Iic0StopCondition(void);


void InitIic(uint32_t chNo)
{
	switch(chNo){
		case IIC_CH0:	InitIic0();		break;
	}
}

uint32_t RandomAddressReadIic(uint32_t chNo,uint32_t slAdd,uint32_t accessAdd,uint32_t *rdBuf,uint32_t rdCount)
{
	switch(chNo){
		case IIC_CH0:
			return RandomAddressReadIic0(slAdd,accessAdd,rdBuf,rdCount);
	}
	return(0);
}

uint32_t PageWriteIic(uint32_t chNo,uint32_t slAdd,uint32_t accessAdd,uint32_t *wrBuf,uint32_t wrCount)
{
	switch(chNo){
		case IIC_CH0:
			return PageWriteIic0(slAdd,accessAdd,wrBuf,wrCount);
	}
	return(0);
}

/****************************************************************************/
/* IIC CH0																	*/
/****************************************************************************/

void InitIic0(void)
{
	uint32_t dataL;

	PowerOnIic0();
	InitIic0PinFunction();

}

void InitIic0PinFunction(void)
{
	// IIC function is fixed
}

void InitIic0Freq(void)
{
	if(CHK_H3||CHK_M3||CHK_M3N){
		// Calculation value of ICCL and ICCH
		// "ICIC[7],ICCL" = ((Module clock/Freq)*(L/(L+H))-1)/2
		//                = (( 8.3333MHz/400kHz )*(5/(5+4))-1)/2 = (20.83325*0.55555...-1)/2 = 5.28701 = 0x006
		// "ICIC[6],ICCH" = ((Module clock/Freq)*(H/(L+H))-5)/2
		//                = (( 8.3333MHz/400kHz )*(4/(5+4))-5)/2 = (20.83325*0.44444...-5)/2 = 2.12961 = 0x003

		// IIC transfer rate
		// Freq = Module clock/(ICCL*2+ICCH*2+1+5) = 8.3333MHz/(12+6+1+5) = 8.3333MHz/18 = 347.22kHz

		*((volatile uint8_t*)IICDVFS_ICCL)  = 0x06;		// Low level	ICIC[7] + ICCL = H'006 (Fast-mode=347.22kHz)
		*((volatile uint8_t*)IICDVFS_ICCH)  = 0x03;		// High level	ICIC[6] + ICCH = H'003 (Fast-mode=347.22kHz)
		*((volatile uint8_t*)IICDVFS_ICIC) &= ~(BIT7|BIT6);
	}else if(CHK_E3){
		// Calculation value of ICCL and ICCH
		// "ICIC[7],ICCL" = ((Module clock/Freq)*(L/(L+H))-1)/2
		//                = (( 24.000MHz/400kHz )*(5/(5+4))-1)/2 = (60.000*0.55555...-1)/2 = 16.16666... = 0x011
		// "ICIC[6],ICCH" = ((Module clock/Freq)*(H/(L+H))-5)/2
		//                = (( 24.000MHz/400kHz )*(4/(5+4))-5)/2 = (60.000*0.44444...-5)/2 = 10.83333... = 0x00B

		// IIC transfer rate
		// Freq = Module clock/(ICCL*2+ICCH*2+1+5) = 24.000MHz/(17*2+11*2+1+5) = 24.000MHz/62 = 387.10kHz

		*((volatile uint8_t*)IICDVFS_ICCL)  = 0x11;		// Low level	ICIC[7] + ICCL = H'011 (Fast-mode=387.10kHz)
		*((volatile uint8_t*)IICDVFS_ICCH)  = 0x0B;		// High level	ICIC[6] + ICCH = H'00B (Fast-mode=387.10kHz)
		*((volatile uint8_t*)IICDVFS_ICIC) &= ~(BIT7|BIT6);
	}
}

// Default:Idle
void PowerOnIic0(void)
{
	uint32_t dataL;

	dataL = *((volatile uint32_t*)CPG_MSTPSR9);
	if(dataL & BIT26){	// case IIC0 Standby
		dataL &= ~BIT26;
		*((volatile uint32_t*)CPG_CPGWPR)   = ~dataL;
		*((volatile uint32_t*)CPG_SMSTPCR9) =  dataL;
	}
}

void ResetIic0Bus(void)
{
	*((volatile uint8_t*)IICDVFS_ICIC) = 0x00;
	*((volatile uint8_t*)IICDVFS_ICSR) = 0x00;
	*((volatile uint8_t*)IICDVFS_ICCR) = 0x00;
}

/****************************************************************************/
/*	IIC Read from I2C device												*/
/*		 = slAdd     : Slave Address (8bit length, BIT0 is fixed 0)			*/
/*		 = accessAdd : Register address (0x00~0xFF)							*/
/*		 = *rdBuf    : Pointer to store read data (32bit length variable)	*/
/*		 = rdCount   : Number of transfers (not use)						*/
/****************************************************************************/
uint32_t RandomAddressReadIic0(uint32_t slAdd,uint32_t accessAdd,uint32_t *rdBuf,uint32_t rdCount)
{
	uint8_t dataB;
	uint32_t err;

	// ICCR : Clear
	*((volatile uint8_t*)IICDVFS_ICCR) = 0x00;

	// ICCR : IIC bus interface module is enabled.
	*((volatile uint8_t*)IICDVFS_ICCR) |= 0x80;

	// Calculation value of ICCL and ICCH
	InitIic0Freq();

	////////////////////////////////////////
	// Generate START condition
	////////////////////////////////////////
	*((volatile uint8_t*)IICDVFS_ICIC) |= 0x0F;

	*((volatile uint8_t*)IICDVFS_ICCR)  = 0x94;			// ICCR : START condition

	// DTE bit
	err = Iic0InterruptDte();
	if(err) return err;

	*((volatile uint8_t*)IICDVFS_ICIC) &= ~BIT0;

	////////////////////////////////////////
	// Send Slave Address (Transmission Mode)
	////////////////////////////////////////
	dataB = (uint8_t)((slAdd&~BIT0) & 0xff);
	*((volatile uint8_t*)IICDVFS_ICDR) = dataB;			// ICDR : Slave Address (BIT0=0:Write)

	// WAIT bit
	err = Iic0InterruptWait();
	if(err) return err;

	////////////////////////////////////////
	// Send Register Address (Transmission Mode)
	////////////////////////////////////////
	dataB = (uint8_t)(0x000000ff & accessAdd);
	*((volatile uint8_t*)IICDVFS_ICDR) = dataB;	// ICDR : Register Address

	*((volatile uint8_t*)IICDVFS_ICCR) = 0x94;	// ICCR : Repeated START condition (Transmission Mode)

	*((volatile uint8_t*)IICDVFS_ICIC) |= BIT0;

	*((volatile uint8_t*)IICDVFS_ICSR) &= ~BIT1;// WAIT clear

	// WAIT bit
	err = Iic0InterruptWait();
	if(err) return err;

	*((volatile uint8_t*)IICDVFS_ICSR) &= ~BIT1;	// WAIT clear

	// DTE bit
	err = Iic0InterruptDte();
	if(err) return err;

	// *****************************************************************
	// Master receive mode for 1 byte
	// *****************************************************************

	*((volatile uint8_t*)IICDVFS_ICIC) |=  BIT1;
	*((volatile uint8_t*)IICDVFS_ICIC) &= ~BIT0;

	////////////////////////////////////////
	// Send Slave Address (Receive Mode)
	////////////////////////////////////////
	dataB = (uint8_t)((slAdd|BIT0) & 0xff);
	*((volatile uint8_t*)IICDVFS_ICDR) = dataB;			// ICDR : Slave Address (BIT0=1:Read)

	// WAIT bit
	err = Iic0InterruptWait();
	if(err) return err;

	*((volatile uint8_t*)IICDVFS_ICCR) = 0x81;				// ICCR : Change from transmission mode to receive mode

	*((volatile uint8_t*)IICDVFS_ICSR) &= ~BIT1;			// WAIT clear

	////////////////////////////////////////
	// Get Register Data (Receive Mode)
	////////////////////////////////////////

	// WAIT bit
	err = Iic0InterruptWait();
	if(err) return err;

	*((volatile uint8_t*)IICDVFS_ICIC) |=  BIT0;

	*((volatile uint8_t*)IICDVFS_ICCR) = 0xC0;			// ICCR : STOP condition

	*((volatile uint8_t*)IICDVFS_ICSR) &= ~BIT1;		// WAIT clear

	// DTE bit
	err = Iic0InterruptDte();
	if(err) return err;

	*((volatile uint8_t*)IICDVFS_ICIC) &= ~BIT1;

	// Get received data from the data register
	dataB = *((volatile uint8_t*)IICDVFS_ICDR);
	*rdBuf = (uint32_t)dataB;

	// STOP condition (ICSR.BUSY is cleared)
	err = Iic0StopCondition();
	if(err) return err;

	*((volatile uint8_t*)IICDVFS_ICSR) = 0x00;

	*((volatile uint8_t*)IICDVFS_ICIC) = 0x00;

	*((volatile uint8_t*)IICDVFS_ICCR) &= ~BIT7;

	return(0);

}

/****************************************************************************/
/*	IIC Write to I2C device													*/
/*		 = slAdd     : Slave Address (8bit length, BIT0 is fixed 0)			*/
/*		 = accessAdd : Register address (0x00~0xFF)							*/
/*		 = *wrBuf    : Pointer to store write data (32bit length variable)	*/
/*		 = wrCount   : Number of transfers (not use)						*/
/****************************************************************************/
uint32_t PageWriteIic0(uint32_t slAdd,uint32_t accessAdd,uint32_t *wrBuf,uint32_t wrCount)
{
	uint8_t dataB;
	uint32_t err;

	// ICCR : Clear
	*((volatile uint8_t*)IICDVFS_ICCR) = 0x00;

	// ICCR : IIC bus interface module is enabled.
	*((volatile uint8_t*)IICDVFS_ICCR) |= 0x80;

	// Calculation value of ICCL and ICCH
	InitIic0Freq();

	////////////////////////////////////////
	// Generate START condition
	////////////////////////////////////////
	*((volatile uint8_t*)IICDVFS_ICIC) |= 0x0F;


	*((volatile uint8_t*)IICDVFS_ICCR) = 0x94;			// ICCR : START condition

	// DTE bit
	err = Iic0InterruptDte();
	if(err) return err;

	////////////////////////////////////////
	// Send Slave Address (Transmission Mode)
	////////////////////////////////////////
	*((volatile uint8_t*)IICDVFS_ICIC) &= ~BIT0;

	dataB = (uint8_t)((slAdd&~BIT0) & 0xff);
	*((volatile uint8_t*)IICDVFS_ICDR) = dataB;			// ICDR : Slave Address (BIT0=0:Write)

	// WAIT bit
	err = Iic0InterruptWait();
	if(err) return err;

	////////////////////////////////////////
	// Send Register Address (Transmission Mode)
	////////////////////////////////////////
	dataB = (uint8_t)(0x000000ff & accessAdd);
	*((volatile uint8_t*)IICDVFS_ICDR) = dataB;			// ICDR : Register Address

	*((volatile uint8_t*)IICDVFS_ICSR) &= ~BIT1;		// WAIT Clear

	// WAIT bit
	err = Iic0InterruptWait();
	if(err) return err;

	// Send 1 byte only
	dataB = (uint8_t)(0x000000ff & *wrBuf);
	*((volatile uint8_t*)IICDVFS_ICDR) = dataB;			// ICDR : Set transfer data to the data register

	*((volatile uint8_t*)IICDVFS_ICCR) = 0x90;				// Stop Condition

	*((volatile uint8_t*)IICDVFS_ICSR) &= ~BIT1;			// WAIT Clear

	// WAIT bit
	err = Iic0InterruptWait();
	if(err) return err;

	*((volatile uint8_t*)IICDVFS_ICSR) &= ~BIT1;			// WAIT Clear

	// STOP condition (ICSR.BUSY is cleared)
	err = Iic0StopCondition();
	if(err) return err;

	*((volatile uint8_t*)IICDVFS_ICSR) = 0x00;

	*((volatile uint8_t*)IICDVFS_ICIC) = 0x00;

	*((volatile uint8_t*)IICDVFS_ICCR) &= ~BIT7;

	return (0);

}

static uint32_t Iic0InterruptWait(void)
{
	uint8_t dataB;
	uint32_t ToutCnt = 0;
	while(1){
		dataB = *((volatile uint8_t*)IICDVFS_ICSR);
		if(dataB & BIT1) break;						// WAIT bit : Wait State
		if(dataB & BIT2){							// TACK bit : Transmit Acknowledge Bit
			return I2C_NACK_ERROR;
		}
		if(dataB & BIT3){							// AL bit   : Arbitration Lost Interrupt
			return IIC_AL_ERROR;
		}
		if(ToutCnt++ >= IIC_TIMEOUT){
			ResetIic0Bus();
			return IIC_TIMEOUT_ERROR;
		}
		StartTMU0usec(1);							// Wait 10us
	}
	return IIC_NORMAL_END;
}

static uint32_t Iic0InterruptDte(void)
{
	uint8_t dataB;
	uint32_t ToutCnt = 0;
	while(1){
		dataB = *((volatile uint8_t*)IICDVFS_ICSR);
		if(dataB & BIT0) break;						// Waits DTE bit to generate START condition
		if(ToutCnt++ >= IIC_TIMEOUT){
			ResetIic0Bus();
			return IIC_TIMEOUT_ERROR;
		}
		StartTMU0usec(1);							// Wait 10us
	}
	return IIC_NORMAL_END;
}

static uint32_t Iic0StopCondition(void)
{
	uint8_t dataB;
	uint32_t ToutCnt = 0;
	while(1){
		dataB = *((volatile uint8_t*)IICDVFS_ICSR);
		if((dataB&BIT4)==0) break;					// Wait STOP condition on IIC bus (ICSR.BUSY is cleared)
		if(ToutCnt++ >= IIC_TIMEOUT){
//			DEBUGS("[DBG]BUSY bit timeout\n");
			PutStr("[DBG]BUSY bit timeout",1);
			ResetIic0Bus();
			return IIC_TIMEOUT_ERROR;
		}
		StartTMU0usec(1);							// Wait 10us
	}
	return IIC_NORMAL_END;
}

