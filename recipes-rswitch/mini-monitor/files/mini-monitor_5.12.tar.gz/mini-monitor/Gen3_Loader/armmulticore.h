/**********************************************************/
/* Sample program : ARM Multi Core Header                 */
/* File Name      : armmulticore.h                        */
/* Copyright (C) Renesas Electronics Corp. 2017.          */
/**********************************************************/

#pragma once

//extern const char MAIN_BOOT_ADDR[];
//extern const char CODE_BASE_ADDR[];

extern uint32_t GetMIDR(void);
extern uint64_t GetMPIDR(void);
extern uint32_t GetRMR(void);

#define CHK_CA57		((GetMIDR()&BIT15_4)==0xD070)
#define CHK_CA53		((GetMIDR()&BIT15_4)==0xD030)
#define CHK_CR7			((GetMIDR()&BIT15_4)==0xC170)

#define CHK_CPU0		((GetMPIDR()&BIT1_0)==0x0000)
#define CHK_CPU1		((GetMPIDR()&BIT1_0)==0x0001)
#define CHK_CPU2		((GetMPIDR()&BIT1_0)==0x0002)
#define CHK_CPU3		((GetMPIDR()&BIT1_0)==0x0003)

#define CHK_MAIN_CPU	(GetMasterBootProcessor()==GetArmCpuName())
#define CHK_SUB_CPU		(GetMasterBootProcessor()!=GetArmCpuName())

#define CA57_CPU0		0x0001
#define CA57_CPU1		0x0002
#define CA57_CPU2		0x0004
#define CA57_CPU3		0x0008

#define CA53_CPU0		0x0010
#define CA53_CPU1		0x0020
#define CA53_CPU2		0x0040
#define CA53_CPU3		0x0080

#define CR7_CPU0		0x0100
#define ICUMXA_CPU0		0x0200

#define RESCNT_CPU0			BIT3
#define RESCNT_CPU1			BIT2
#define RESCNT_CPU2			BIT1
#define RESCNT_CPU3			BIT0

#define WUPCR_CPU0			BIT0
#define WUPCR_CPU1			BIT1
#define WUPCR_CPU2			BIT2
#define WUPCR_CPU3			BIT3

// CtrlNonArmCpuPowerBySYSC
#define POWER_RESUME		1
#define POWER_SHUTOFF		0

// Power Control Registers for SCU of CA53, IMP-X5, SCU of CA57, CR7, A3VP, A3VIP, A3VIP1, V3IP2 and A3VC.
#define SYSC_CA53_SCU		3
#define SYSC_IMP_X5			4
#define SYSC_CA57_SCU		5
#define SYSC_CR7			7
#define SYSC_A3VP			8
#define SYSC_A3VC			9
//#define SYSC_A3VIP			12	// for R-CarV3H
//#define SYSC_A3VIP1			13	// for R-CarV3H
//#define SYSC_A3VIP2			14	// for R-CarV3H

#define SYSCISR_IMP_X5		BIT24
#define SYSCISR_CA53_SCU	BIT21
#define SYSCISR_A3VC		BIT14
#define SYSCISR_CR7			BIT13
#define SYSCISR_CA57_SCU	BIT12
#define SYSCISR_A3VP		BIT9
#define SYSCISR_CA53_CPU3	BIT8
#define SYSCISR_CA53_CPU2	BIT7
#define SYSCISR_CA53_CPU1	BIT6
#define SYSCISR_CA53_CPU0	BIT5
#define SYSCISR_CA57_CPU3	BIT3
#define SYSCISR_CA57_CPU2	BIT2
#define SYSCISR_CA57_CPU1	BIT1
#define SYSCISR_CA57_CPU0	BIT0

#define SYSCISR_A3VIP2		BIT26	// for R-CarV3H
#define SYSCISR_A3VIP1		BIT25	// for R-CarV3H
#define SYSCISR_A2IR5		BIT12	// for R-CarV3H
#define SYSCISR_A3VIP		BIT11	// for R-CarV3H

void SetBootAddress(uint32_t wupCore, uint64_t bootAddr);
void WakeupArmCore(uint32_t wupCore);
void CtrlNonArmCpuPowerBySYSC(uint32_t n, uint32_t resume);
void CopyMainBootJumpProgram(void);

void ResetAndStandbyPreBootCpu(void);
void ResetArmCpu(uint32_t cpuName);
void StandbyArmCpu(uint32_t cpuName);

uint32_t GetMasterBootProcessor(void);
uint32_t GetArmCpuName(void);

