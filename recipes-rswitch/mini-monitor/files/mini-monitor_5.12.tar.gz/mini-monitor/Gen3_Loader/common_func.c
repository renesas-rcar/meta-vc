/**********************************************************/
/* Sample program : R-CarH3 Common                        */
/* File Name      : common.c                              */
/* Copyright (C) Renesas Electronics Corp. 2015.          */
/**********************************************************/

#include	"common.h"
#include	"common_func.h"
#include	"devdrv.h"

/************************************************************************/
/*NAME		: PutMes													*/
/************************************************************************/
int32_t PutMess(const char *const mess[])
{
	int32_t i=0;
	while(mess[i]){
		PutStr(mess[i],ENB_RTN);
		i++;
	}
	return(0);
}

/************************************************************************/
/*NAME		: PutStr													*/
/************************************************************************/
int32_t	PutStr(const char *str,char rtn)
{
	while(*str){
		PutChar(*str);
		str++;
	}
	if(rtn == 1){
		PutChar(CR_CODE);
		PutChar(LF_CODE);
	}
	return(0);

}

void	DelStr(int32_t delCnt)
{
	int32_t i,j;
	for(i=0;i<delCnt;i++){	PutChar(BS_CODE);for(j=0;j<100;j++); }
	for(i=0;i<delCnt;i++){	PutChar(' ');for(j=0;j<100;j++); }
	for(i=0;i<delCnt;i++){	PutChar(BS_CODE);for(j=0;j<100;j++); }
}

char Data2HexAscii(uint32_t data,char *buf,char size)
{
	char loopCnt,i;
	uint32_t tmpData;
	switch(size){
	case SIZE_8BIT:
		data <<= (SIZE_32BIT*8-8); loopCnt=2;
		break;
	case SIZE_16BIT:
		data <<= (SIZE_32BIT*8-16); loopCnt=4;
		break;
	case SIZE_32BIT:
		data <<= (SIZE_32BIT*8-32); loopCnt=8;
		break;
	}
	for(i=0;i<loopCnt;i++,buf++){
		tmpData = (data >> (SIZE_32BIT*8-4));
		if(tmpData < 0x0a){ /* case 1 to 9 */
			*buf = (char)(tmpData + '0');
		}else{	/* case A to F */
			*buf = (char)(tmpData + 55);
		}
		data <<= 4;
	}
	*buf = 0;
	return(0);
}

/****************************************************/
/*		Soft Delay									*/
/****************************************************/
void SoftDelay(uint32_t loop)
{
	volatile uint32_t i;
	for(i=0;i<loop;i++);
}





//====================================================================
//"boot_init_dram.c  AArch32(CR7)�Ή�
//====================================================================
//--------------------------------------------------------------------
// AArch32(CR7)�Ή��BCR7�w��ŕW�����C�u�������N�G���[�B
// �W�����C�u�������g�p�����Bmemcpy�쐬�B
//--------------------------------------------------------------------
char *memcpy(char *s1,char *s2,unsigned long n)
{
	unsigned long i;

	for(i=0;i<n;i++){
		*s1 = *s2;
		s1++;	s2++;
	}
	return(s1);
}

//--------------------------------------------------------------------
//AArch32(CR7) gcc -Og �œK���Ή��B 
//("boot_init_dram.c: undefined reference to "__aeabi_llsr","__aeabi_llsl")
//--------------------------------------------------------------------
uint64_t __aeabi_llsl(uint64_t val, uint32_t shift)
{
//	shift &= 0x0000003F;		// AArch64�͂������̋���
	if(shift>=64) return 0;		// AArch32�͂������̋���

	uint32_t lo = (uint32_t)(val >> 0);
	uint32_t hi = (uint32_t)(val >> 32);

	uint32_t hi_lsb;
	if(shift==0)       hi_lsb = 0;
	else if(shift<=32) hi_lsb = (lo >> (32-shift));
	else               hi_lsb = (lo << (shift-32));

	uint32_t s_lo;
	if(shift<=31) s_lo = (lo << shift);
	else          s_lo = 0;

	uint32_t s_hi;
	if(shift<=31) s_hi = (hi << shift);
	else          s_hi = 0;

	return ((uint64_t)(s_hi|hi_lsb) << 32) | (s_lo);
}
uint64_t __aeabi_llsr(uint64_t val, uint32_t shift)
{
//	shift &= 0x0000003F;		// AArch64�͂������̋���
	if(shift>=64) return 0;		// AArch32�͂������̋���

	uint32_t lo = (uint32_t)(val >> 0);
	uint32_t hi = (uint32_t)(val >> 32);

	uint32_t lo_msb;
	if(shift==0)       lo_msb = 0;
	else if(shift<=32) lo_msb = (hi << (32-shift));
	else               lo_msb = (hi >> (shift-32));

	uint32_t s_lo;
	if(shift<=31) s_lo = (lo >> shift);
	else          s_lo = 0;

	uint32_t s_hi;
	if(shift<=31) s_hi = (hi >> shift);
	else          s_hi = 0;

	return ((uint64_t)(s_hi) << 32) | (s_lo|lo_msb);
}

