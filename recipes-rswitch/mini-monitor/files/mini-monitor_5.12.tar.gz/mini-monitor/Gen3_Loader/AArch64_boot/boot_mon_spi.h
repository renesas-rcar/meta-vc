;#RWDT
;#R-CarH3 77. RCLK Watchdog Timer
.EQU	RWDT_RWTCNT		,	0xE6020000		;#RCLK watchdog timer counter
.EQU	RWDT_RWTCSRA	,	0xE6020004		;#RCLK watchdog timer control/status register A
.EQU	RWDT_RWTCSRB	,	0xE6020008		;#RCLK watchdog timer control/status register B

;#SystemWDT
;#R-CarH3 78. System Watchdog Timer
.EQU	SYSWDT_WTCNT	,	0xE6030000		;#watchdog timer counter
.EQU	SYSWDT_WTCSRA	,	0xE6030004		;#watchdog timer control/status register A
.EQU	SYSWDT_WTCSRB	,	0xE6030008		;#watchdog timer control/status register B


