/**********************************************************/
/* Sample program : R-CarH3 Boot Loader Header            */
/* File Name      : bootloader.h                          */
/* Copyright (C) Renesas Electronics Corp. 2015.          */
/**********************************************************/
#ifndef	__BOOTLOADER_
#define	__BOOTLOADER_

#define COLD_BOOT				0
#define WARM_BOOT				1
#define WARM_BOOT_TIMEOUT		2

#include <stdint.h>		//for uint32_t

#define S26KS512_DEVICE_ID		0x007E0001	// HyperFlash on SiP
#define S25FS128_DEVICE_ID		0x4D182001	// QSPI Flash on Board
#define S25FL512_DEVICE_ID		0x4D200201	// QSPI Flash on QSPI Board
#define S25FS512_DEVICE_ID		0x4D200201	// QSPI Flash on Board (Eagle Board)

//SpiFlash Famiry ID:ID-CFI Address[05h]
#define		FS_S_FAMILY			0x00008100	//On Board SpiFlashMemory
#define		FL_S_FAMILY			0x00008000	//Ex Board SpiFlashMemory

#define ADDR_SECTOR_01_TOP		0x00040000
#define ADDR_SECTOR_02_TOP		0x00080000
#define ADDR_SECTOR_03_TOP		0x000C0000
#define ADDR_SECTOR_04_TOP		0x00100000

//#define SYSTEMRAM_WORK_ADD		0xE6330000
#define SYSTEMRAM_WORK_ADD		0xE6300000

#define NORMAL_END	0
#define ERROR		1

uint32_t BootLoaderMain(void);

#endif /* __BOOTLOADER_ */
