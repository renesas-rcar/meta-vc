void InitPORT_D3(void);
void InitIPSR_Area0_D3(void);
void InitIPSR_SPI_D3(void);
void InitGPSR_Area0_D3(void);
void InitGPSR_SPI_D3(void);

static void InitMODSEL(void);
static void InitIPSR(void);
static void InitGPSR(void);
static void InitIOCTRL(void);
static void InitPUD(void);
static void InitPUEN(void);
