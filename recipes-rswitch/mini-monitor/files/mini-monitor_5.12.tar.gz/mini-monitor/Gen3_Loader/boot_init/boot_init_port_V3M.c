/**********************************************************/
/* Sample program : PORT initialization                   */
/* File Name      : boot_init_port.c                      */
/* Copyright (C) Renesas Electronics Corp. 2016.          */
/**********************************************************/

//=========================================================
//===== Setting for R-Car V3M =============================
//=========================================================

#include "common.h"
#include "reg_rcargen3.h"
#include "boot_init_port_V3M.h"
#include "boardid.h"


#define PFC_WR(m,n)   *((volatile uint32_t*)PFC_PMMR)=~(n);*((volatile uint32_t*)(m))=(n);

void InitPORT_V3M(void)
{
#ifdef D3_V3M_E3
	InitMODSEL();
	InitIPSR();
	InitGPSR();
//	InitPOCCTRL();
//	InitDRVCTRL();
	InitIOCTRL();
	InitPUD();
	InitPUEN();
#endif
}

void InitIPSR_Area0_V3M(void)
{
	PFC_WR(PFC_IPSR0,0x33333333);
	PFC_WR(PFC_IPSR1,0x33333333);
	PFC_WR(PFC_IPSR2,0x00333333);
	PFC_WR(PFC_IPSR3,0x02200000);
	PFC_WR(PFC_IPSR4,0x33333000);
	PFC_WR(PFC_IPSR5,0x33333333);
	PFC_WR(PFC_IPSR6,0x33333333);
	PFC_WR(PFC_IPSR7,0x04433003);
	PFC_WR(PFC_IPSR8,0x00040000);
}
void InitIPSR_SPI_V3M(void)
{
	PFC_WR(PFC_IPSR0,0x00000000);
	PFC_WR(PFC_IPSR1,0x00000000);
	PFC_WR(PFC_IPSR2,0x00000000);
	PFC_WR(PFC_IPSR3,0x02200000);
	PFC_WR(PFC_IPSR4,0x00000000);
	PFC_WR(PFC_IPSR5,0x00000000);
	PFC_WR(PFC_IPSR6,0x00000000);
	PFC_WR(PFC_IPSR7,0x04400000);
	PFC_WR(PFC_IPSR8,0x00040000);
}

void InitGPSR_Area0_V3M(void)
{
	PFC_WR(PFC_GPSR0,0x003FFFFF);
	PFC_WR(PFC_GPSR1,0x0E06FFFF);
	PFC_WR(PFC_GPSR2,0x0001F0C0);
	PFC_WR(PFC_GPSR3,0x0001FFFF);
	PFC_WR(PFC_GPSR4,0x0000003F);
	PFC_WR(PFC_GPSR5,0x00000FFF);
}
void InitGPSR_SPI_V3M(void)
{
	PFC_WR(PFC_GPSR0,0x00000000);
	PFC_WR(PFC_GPSR1,0x0E06FFFF);
	PFC_WR(PFC_GPSR2,0x000000C0);
	PFC_WR(PFC_GPSR3,0x00000000);
	PFC_WR(PFC_GPSR4,0x00000033);
	PFC_WR(PFC_GPSR5,0x00000FFF);
}

#ifdef D3_V3M_E3
//===== Static function ===================================

static void InitMODSEL(void)
{
	PFC_WR(PFC_MOD_SEL0,0x00000404);
}

static void InitIPSR(void)
{
#ifdef Area0Boot
	InitIPSR_Area0_V3M();
#else
	InitIPSR_SPI_V3M();
#endif
}

static void InitGPSR(void)
{
#ifdef Area0Boot
	InitGPSR_Area0_V3M();
#else
	InitGPSR_SPI_V3M();
#endif
}

static void InitIOCTRL(void)
{
	PFC_WR(PFC_IOCTRL30,0xFFFFFFFF);
	PFC_WR(PFC_IOCTRL31,0xFFFFFFFF);
	PFC_WR(PFC_IOCTRL32,0x00000000);
	PFC_WR(PFC_IOCTRL40,0x00000000);
}

static void InitPUD(void)
{
	PFC_WR(PFC_PUD0,0x800FFFFF);
	if(CHK_EAGLE_R){
		PFC_WR(PFC_PUD1,0xFFFFF79F);		//GP2_10:Pull-Up Enable
	}else{
		PFC_WR(PFC_PUD1,0xFFFFF59F);		//GP2_10:Pull-Up Disable
	}
	PFC_WR(PFC_PUD2,0x72000019);
	PFC_WR(PFC_PUD3,0x00018000);
}

static void InitPUEN(void)
{
	PFC_WR(PFC_PUEN0,0x800FFFFF);
	if(CHK_EAGLE_R){
		PFC_WR(PFC_PUEN1,0xFFFFF79F);		//GP2_10:Pull-Up Enable
	}else{
		PFC_WR(PFC_PUEN1,0xFFFFF59F);		//GP2_10:Pull-Up Disable
	}
	PFC_WR(PFC_PUEN2,0x72000019);
	PFC_WR(PFC_PUEN3,0x00018000);
}
#endif
