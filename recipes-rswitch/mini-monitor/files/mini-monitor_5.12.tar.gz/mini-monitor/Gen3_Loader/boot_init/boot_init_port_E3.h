void InitPORT_E3(void);

static void InitIPSR_SPI_E3(void);
static void InitGPSR_SPI_E3(void);
static void InitMODSEL(void);
static void InitIPSR(void);
static void InitGPSR(void);
static void InitIOCTRL(void);
static void InitPUD(void);
static void InitPUEN(void);
