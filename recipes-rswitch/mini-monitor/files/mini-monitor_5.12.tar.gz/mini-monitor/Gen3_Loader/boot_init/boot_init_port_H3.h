void InitPORT_H3(void);
void InitIPSR_Area0_H3(void);
void InitIPSR_SPI_H3(void);
void InitGPSR_Area0_H3(void);
void InitGPSR_SPI_H3(void);

static void InitMODSEL(void);
static void InitIPSR(void);
static void InitGPSR(void);
static void InitPOCCTRL(void);
static void InitDRVCTRL(void);
static void InitPUD(void);
static void InitPUEN(void);
