// PMIC Revision
#define PMIC_REV00		0x00
#define PMIC_REV01		0x01
#define PMIC_REV02		0x02
#define PMIC_REV03		0x03
#define PMIC_REV04		0x04


//uint32_t GetPmicEepromFwRev(void);
uint32_t GetPmicRev(void);
uint8_t GetPmicRevision(void);
static void SetPmicVoltage(uint32_t addr, uint32_t volt);
static void UnlockPmic(void);
void RcarM3nWa(void);
void ChangePmicVdd(void);

