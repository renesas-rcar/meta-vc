#define		VERIFY_OFF	0
#define		VERIFY_ON	1


void	dgHelp(void);
void	dgDump(void);
void	dgDumpMode(void);
char	CheckAccessSize(char *buf,uint32_t *sizeId);
void	dgMemEdit_byte(void);
void	dgMemEdit_word(void);
void	dgMemEdit_long(void);
void	dgMemEdit_longlong(void);
void	dgMemEdit(uint32_t width);
void	dgFill_byte(void);
void	dgFill_long(void);
void	dgFill_longlong(void);
void	dgFill(uint32_t width);
void	dgMoveMemory(void);
void	dgLoadFlashGo(void);
void	LoadFlashGo(void);
void	Lf_Program_Flash(uint32_t PrgStatAdd,uint32_t PrgEndadd,uint32_t CopyAdd);
void	dgGo(void);
uint32_t dgGo_addr(void);
uint32_t setGoAddr(uint32_t goAdd);
void	dgClear_Flash(void);
void	dgClear_FlashGo(void);
void	Clear_FlashGo(void);
void	dgScifSpeedUp(void);
void	dgScifSpeedUp_115200(void);
void	dgScifSpeedUp_230400(void);
void	dgScifSpeedUp_460800(void);
void	dgScifSpeedUp_921600(void);
void	dgScifSpeedUp_Internal(void);

