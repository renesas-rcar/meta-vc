// ���̃\�[�X�t�@�C�����œK��
#pragma GCC optimize ("Og")


#include "common.h"
#include "scifdrv2.h"
#include "bit.h"
#include "reg_rcargen3.h"
#include "boardid.h"


//////////////////////////////////////////////////////////////////////////////////
//                                                                              //
//	Debug Seirial(SCIF2)														//
//																				//
//////////////////////////////////////////////////////////////////////////////////
int32_t PutCharSCIF2(char outChar)
{
	while(!(0x60 & *((volatile uint16_t*)SCIF2_SCFSR) ));
	*((volatile uint8_t*)SCIF2_SCFTDR) = outChar;
	*((volatile uint16_t*)SCIF2_SCFSR) &= ~0x60;	/* TEND,TDFE clear */
	return(0);
}

int32_t GetCharSCIF2(char *inChar)
{
	do{
		if(0x91 & *((volatile uint16_t *)SCIF2_SCFSR))
			*((volatile uint16_t *)SCIF2_SCFSR) &= ~0x91;
		if(0x01 & *((volatile uint16_t *)SCIF2_SCLSR))		//ORER check & clear
		{
			PutStr("ORER",1);								//ORER
			*((volatile uint16_t *)SCIF2_SCLSR) &= ~0x01;
		}
	}while( !(0x02 & *((volatile uint16_t *)SCIF2_SCFSR)) );
		*inChar = *((volatile uint8_t*)SCIF2_SCFRDR);
		*((volatile uint16_t*)SCIF2_SCFSR) &= ~0x02;
	return(0);
}

void PowerOnScif2(void)
{
	uint32_t dataL;

	dataL = *((volatile uint32_t*)CPG_MSTPSR3);
	if(dataL & BIT10){	// case SCIF2(IrDA) Standby
		dataL &= ~BIT10;
		*((volatile uint32_t*)CPG_CPGWPR)    = ~dataL;
		*((volatile uint32_t*)CPG_SMSTPCR3)  =  dataL;
		while( BIT10 & *((volatile uint32_t*)CPG_MSTPSR3) );  // wait bit=0
	}
}

void WaitPutScif2SendEnd(void)
{
	uint16_t dataW;
    uint32_t loop;

	loop=1;
    while(loop){
		dataW = *((volatile uint16_t*)SCIF2_SCFSR);
		if(dataW & BIT6)	loop = 0;
	}
}

void InitScif2_SCIFCLK(void)
{
	uint16_t dataW;

	PowerOnScif2();

	dataW = *((volatile uint16_t*)SCIF2_SCLSR);	/* dummy read     		*/
	*((volatile uint16_t*)SCIF2_SCLSR) = 0x0000;	/* clear ORER bit 		*/
	*((volatile uint16_t*)SCIF2_SCFSR) = 0x0000;	/* clear all error bit	*/

	*((volatile uint16_t*)SCIF2_SCSCR) = 0x0000;	/* clear SCR.TE & SCR.RE*/
	*((volatile uint16_t*)SCIF2_SCFCR) = 0x0006;	/* reset tx-fifo, reset rx-fifo. */

#ifdef SCIF_CLK_EXTERNAL
	*((volatile uint16_t*)SCIF2_SCSCR) = 0x0002;	/* external clock, SC_CLK pin used for input pin */
	*((volatile uint16_t*)SCIF2_SCSMR) = 0x0000;	/* 8bit data, no-parity, 1 stop, Po/1 */
	SoftDelay(100);
//	*((volatile uint16_t*)SCIF2_DL)    = 0x0018;	/* 14.7456MHz/ ( 38400*16) = 24 */
	*((volatile uint16_t*)SCIF2_DL)    = 0x0008;	/* 14.7456MHz/ (115200*16) =  8 */
	*((volatile uint16_t*)SCIF2_CKS)   = 0x0000;	/*  select scif_clk	 */
	SoftDelay(100);
	*((volatile uint16_t*)SCIF2_SCFCR) = 0x0000;	/* reset-off tx-fifo, rx-fifo. */
	*((volatile uint16_t*)SCIF2_SCSCR) = 0x0032;	/* enable TE, RE; SC_CLK=input */
	SoftDelay(100);

#endif /* SCIF_CLK_EXTERNAL */

#ifdef SCIF_CLK_INTERNAL
	*((volatile uint16_t*)SCIF2_SCSCR) = 0x0000;	/* internal clock, SC_CLK pin used for input pin */
	*((volatile uint16_t*)SCIF2_SCSMR) = 0x0000;	/* 8bit data, no-parity, 1 stop, Po/1 */
	SoftDelay(100);
	*((volatile uint8_t*)SCIF2_SCBRR)  = 0x11;   	/* 115200bps@66MHz */
	SoftDelay(100);
	*((volatile uint16_t*)SCIF2_SCFCR) = 0x0000;	/* reset-off tx-fifo, rx-fifo. */
	*((volatile uint16_t*)SCIF2_SCSCR) = 0x0030;	/* enable TE, RE; SC_CLK=input */
	SoftDelay(100);
#endif /* SCIF_CLK_INTERNAL */
}

void InitScif2_INTERNAL_S3D1(void)
{
	uint16_t dataW;
	uint32_t md=0;
	uint32_t sscg=0;

	PowerOnScif2();

	md = *((volatile uint32_t*)RST_MODEMR);
	sscg = (md & 0x00001000) >> 12;

	dataW = *((volatile uint16_t*)SCIF2_SCLSR);	/* dummy read     		*/
	*((volatile uint16_t*)SCIF2_SCLSR) = 0x0000;	/* clear ORER bit 		*/
	*((volatile uint16_t*)SCIF2_SCFSR) = 0x0000;	/* clear all error bit	*/

	*((volatile uint16_t*)SCIF2_SCSCR) = 0x0000;	/* clear SCR.TE & SCR.RE*/
	*((volatile uint16_t*)SCIF2_SCFCR) = 0x0006;	/* reset tx-fifo, reset rx-fifo. */

	*((volatile uint16_t*)SCIF2_SCSCR) = 0x0002;	/* external clock, SC_CLK pin used for input pin */
	*((volatile uint16_t*)SCIF2_SCSMR) = 0x0000;	/* 8bit data, no-parity, 1 stop, Po/1 */
	SoftDelay(100);
// External SCIF_CLK
//	*((volatile uint16_t*)SCIF2_DL)    = 0x0008;	/* 14.7456MHz/ (115200*16) =  8 */
//	*((volatile uint16_t*)SCIF2_CKS)   = 0x0000;	/* select scif_clk	 */
// Internal S3D1
	if(CHK_D3){
		if(sscg == 0x0){								//MD12=0 (SSCG off) �F S3D1C��=266.6MHz
			*((volatile uint16_t*)SCIF2_DL) = 0x0091;	/* 266.66MHz/ (115200*16) =  144.67   (Error Rate =-0.23%) */
		}
		else if(sscg == 0x1){							//MD12=1 (SSCG on)  �F S3D1C��=250MHz
			*((volatile uint16_t*)SCIF2_DL) = 0x0088;	/* 250.00MHz/ (115200*16) =  135.67   (Error Rate =-0.27%) */
		}
	}else if(CHK_E3){
		if(sscg == 0x0){								//MD12=0 (SSCG off) �F S3D1C��=266.6MHz
			*((volatile uint16_t*)SCIF2_DL) = 0x0091;	/* 266.66MHz/ (115200*16) =  144.67   (Error Rate =-0.23%) */
		}
		else if(sscg == 0x1){							//MD12=1 (SSCG on)  �F S3D1C��=240MHz    <----
			*((volatile uint16_t*)SCIF2_DL) = 0x0082;	/* 240.00MHz/ (115200*16) =  130.21   (Error Rate = 0.16%) */
		}
	}
	*((volatile uint16_t*)SCIF2_CKS)   = 0x4000;	/* select S3D1-Clock */
	SoftDelay(100);
	*((volatile uint16_t*)SCIF2_SCFCR) = 0x0000;	/* reset-off tx-fifo, rx-fifo. */
	*((volatile uint16_t*)SCIF2_SCSCR) = 0x0032;	/* enable TE, RE; SC_CLK=input */
	SoftDelay(100);
}

#if 0 //���g�p
void InitScif2_INTERNAL(void)	//S3D4
{
	uint16_t dataW;
	uint32_t md=0;
	uint32_t sscg=0;

	PowerOnScif2();

	md = *((volatile uint32_t*)RST_MODEMR);
	sscg = (md & 0x00001000) >> 12;

	dataW = *((volatile uint16_t*)SCIF2_SCLSR);	/* dummy read     		*/
	*((volatile uint16_t*)SCIF2_SCLSR) = 0x0000;	/* clear ORER bit 		*/
	*((volatile uint16_t*)SCIF2_SCFSR) = 0x0000;	/* clear all error bit	*/

	*((volatile uint16_t*)SCIF2_SCSCR) = 0x0000;	/* clear SCR.TE & SCR.RE*/
	*((volatile uint16_t*)SCIF2_SCFCR) = 0x0006;	/* reset tx-fifo, reset rx-fifo. */

	*((volatile uint16_t*)SCIF2_SCSCR) = 0x0002;	/* external clock, SC_CLK pin used for input pin */
	*((volatile uint16_t*)SCIF2_SCSMR) = 0x0000;	/* 8bit data, no-parity, 1 stop, S3D4/1 */
	SoftDelay(100);

// External
//	*((volatile uint16_t*)SCIF2_DL)    = 0x0008;	/* 14.7456MHz/ (115200*16) =  8 */
//	*((volatile uint16_t*)SCIF2_CKS)   = 0x0000;	/*  select scif_clk	 */

// Internal
	if(CHK_D3){
		if(sscg == 0x0){								//MD12=0 (SSCG off) �F S3D4C��=66.6MHz
			*((volatile uint8_t*)SCIF2_SCBRR)  = 0x11;	/* 115200 bit-rate */
//			*((volatile uint8_t*)SCIF2_SCBRR)  = 0x08;	/* 230400 bit-rate */

		}
		else if(sscg == 0x1){							//MD12=1 (SSCG on)  �F S3D4C��=62.5MHz
			*((volatile uint8_t*)SCIF2_SCBRR)  = 0x10;	/* 115200 bit-rate */
//			*((volatile uint8_t*)SCIF2_SCBRR)  = 0x07;	/* 230400 bit-rate */
		}
	}else(CHK_E3){
		if(sscg == 0x0){								//MD12=0 (SSCG off) �F S3D4C��=66.6MHz
			*((volatile uint8_t*)SCIF2_SCBRR)  = 0x11;	/* 115200 bit-rate */
//			*((volatile uint8_t*)SCIF2_SCBRR)  = 0x08;	/* 230400 bit-rate */
		}
		else if(sscg == 0x1){							//MD12=1 (SSCG on)  �F S3D4C��=60MHz
			*((volatile uint8_t*)SCIF2_SCBRR)  = 0x0F;	/* 115200 bit-rate */
//			*((volatile uint8_t*)SCIF2_SCBRR)  = 0x07;	/* 230400 bit-rate */
		}
	}
	SoftDelay(100);
	*((volatile uint16_t*)SCIF2_SCFCR) = 0x0000;	/* reset-off tx-fifo, rx-fifo. */
// External
//	*((volatile uint16_t*)SCIF2_SCSCR) = 0x0032;	/* enable TE, RE; SC_CLK=input */
// Internal
	*((volatile uint16_t*)SCIF2_SCSCR) = 0x0030;	/* enable TE, RE; SCK pin is not used */
	SoftDelay(100);
}
#endif

void SetScif2_DL(uint16_t setData)
{
	//							setData
	// 14.7456MHz/ ( 38400*16) =  24  �����ݒ�l Gen2
	// 14.7456MHz/ (115200*16) =   8  �����ݒ�l Salvator-X 
	// 14.7456MHz/ (921600*16) =   1

	*((volatile uint16_t*)SCIF2_DL)    = setData;
}

void SetScif2_SCBRR(uint8_t setData)
{
	*((volatile uint16_t*)SCIF2_SCSMR) = 0x0000;	/* 8bit data, no-parity, 1 stop, S3D4/1 */
	SoftDelay(100);
//	*((volatile uint8_t*)SCIF2_SCBRR)  = 17;		/* 115200 bit-rate: S3D4(66.66MHz) */
//	*((volatile uint8_t*)SCIF2_SCBRR)  = 8;			/* 230400 bit-rate: S3D4(66.66MHz) */
	*((volatile uint8_t*)SCIF2_SCBRR)  = setData;
}
