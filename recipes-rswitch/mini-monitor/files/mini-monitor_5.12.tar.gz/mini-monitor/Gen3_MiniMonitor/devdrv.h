int32_t PutChar(char outChar);
int32_t GetChar(char *inChar);
void WaitPutCharSendEnd(void);
