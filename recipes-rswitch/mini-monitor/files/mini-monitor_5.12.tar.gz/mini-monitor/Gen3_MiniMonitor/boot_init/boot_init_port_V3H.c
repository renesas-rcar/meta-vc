/**********************************************************/
/* Sample program : PORT initialization                   */
/* File Name      : boot_init_port.c                      */
/* Copyright (C) Renesas Electronics Corp. 2017.          */
/**********************************************************/

//=========================================================
//===== Setting for R-Car V3H =============================
//=========================================================

#include "common.h"
#include "reg_rcargen3.h"
#include "boot_init_port_V3H.h"
#include "boardid.h"


#define PFC_WR(m,n)   *((volatile uint32_t*)PFC_PMMR)=~(n);*((volatile uint32_t*)(m))=(n);

void InitPORT_V3H(void)
{
	InitMODSEL();
	InitIPSR();
	InitGPSR();
	InitIOCTRL();
	InitPUD();
	InitPUEN();
}

void InitIPSR_Area0_V3H(void)
{
	PFC_WR(PFC_IPSR0,0x33333333);
	PFC_WR(PFC_IPSR1,0x33333333);
	PFC_WR(PFC_IPSR2,0x00333333);
	PFC_WR(PFC_IPSR3,0x00000000);
	PFC_WR(PFC_IPSR4,0x33333000);
	PFC_WR(PFC_IPSR5,0x33333333);
	PFC_WR(PFC_IPSR6,0x33333333);
	PFC_WR(PFC_IPSR7,0x04433003);
	PFC_WR(PFC_IPSR8,0x00444000);
	PFC_WR(PFC_IPSR9,0x00000000);
	PFC_WR(PFC_IPSR10,0x00000000);
}
void InitIPSR_SPI_V3H(void)
{
	PFC_WR(PFC_IPSR0,0x00000000);
	PFC_WR(PFC_IPSR1,0x00000000);
	PFC_WR(PFC_IPSR2,0x00000000);
	PFC_WR(PFC_IPSR3,0x00000000);
	PFC_WR(PFC_IPSR4,0x00000000);
	PFC_WR(PFC_IPSR5,0x44000000);
	PFC_WR(PFC_IPSR6,0x44444444);
	PFC_WR(PFC_IPSR7,0x04400004);
	PFC_WR(PFC_IPSR8,0x00400000);
	PFC_WR(PFC_IPSR9,0x00000000);
	PFC_WR(PFC_IPSR10,0x00000000);
}

void InitGPSR_Area0_V3H(void)
{
	PFC_WR(PFC_GPSR0,0x003FFFFF);
	PFC_WR(PFC_GPSR1,0x0FE6FFFF);
	PFC_WR(PFC_GPSR2,0x0001F000);
	PFC_WR(PFC_GPSR3,0x0001FFFF);
	PFC_WR(PFC_GPSR4,0x01BFFFFC);
	PFC_WR(PFC_GPSR5,0x00000FFF);
}
void InitGPSR_SPI_V3H(void)
{
	PFC_WR(PFC_GPSR0,0x00000000);
	PFC_WR(PFC_GPSR1,0x0E66FFFF);
	PFC_WR(PFC_GPSR2,0x00000000);
	PFC_WR(PFC_GPSR3,0x0001FFC0);
	PFC_WR(PFC_GPSR4,0x01BFFFFF);
	PFC_WR(PFC_GPSR5,0x00000FFF);
}


//===== Static function ===================================

static void InitMODSEL(void)
{
#ifdef Area0Boot
	PFC_WR(PFC_MOD_SEL0,0x00000202);
#else
	PFC_WR(PFC_MOD_SEL0,0x00000200);
#endif
}

static void InitIPSR(void)
{
#ifdef Area0Boot
	InitIPSR_Area0_V3H();
#else
	InitIPSR_SPI_V3H();
#endif
}

static void InitGPSR(void)
{
#ifdef Area0Boot
	InitGPSR_Area0_V3H();
#else
	InitGPSR_SPI_V3H();
#endif
}

static void InitIOCTRL(void)
{
	PFC_WR(PFC_IOCTRL30,0xFFFFFFFF);
	PFC_WR(PFC_IOCTRL31,0xFFFFFFFF);
	PFC_WR(PFC_IOCTRL32,0x0000001F);
	PFC_WR(PFC_IOCTRL33,0x00000000);
	PFC_WR(PFC_IOCTRL40,0x00000000);
}

static void InitPUD(void)
{
	PFC_WR(PFC_PUD0,0x80000000);
#ifdef Area0Boot
	PFC_WR(PFC_PUD1,0x1B01C77C);
#else
	PFC_WR(PFC_PUD1,0x1901C77C);
#endif
	PFC_WR(PFC_PUD2,0x00000000);
	PFC_WR(PFC_PUD3,0x0F800008);
	PFC_WR(PFC_PUD4,0x03807C00);
}

static void InitPUEN(void)
{
	PFC_WR(PFC_PUEN0,0x0035F721);
#ifdef Area0Boot
	PFC_WR(PFC_PUEN1,0x7F01C700);
#else
	PFC_WR(PFC_PUEN1,0x7E01C700);
#endif
	PFC_WR(PFC_PUEN2,0x003F0000);
	PFC_WR(PFC_PUEN3,0x07000000);
	PFC_WR(PFC_PUEN4,0x0381E800);
}
