void InitLBSC_H3M3(void);

static void InitCSCTRL(void);
static void InitCSWCR(void);
static void InitCSPWCR(void);
static void InitEXWTSYNC(void);
