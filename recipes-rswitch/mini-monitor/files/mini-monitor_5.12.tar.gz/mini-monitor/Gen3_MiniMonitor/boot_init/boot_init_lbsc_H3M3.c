/**********************************************************/
/* Sample program : LBSC initialization                   */
/* File Name      : boot_init_lbsc_H3M3.c                 */
/* Copyright (C) Renesas Electronics Corp. 2015.          */
/**********************************************************/

#include "common.h"
#include "reg_rcargen3.h"
#include "boot_init_lbsc_H3M3.h"

void InitLBSC_H3M3(void)
{
	InitCSCTRL();
	InitCSWCR();
	InitCSPWCR();
	InitEXWTSYNC();
}


static void InitCSCTRL(void)
{
	*((volatile uint32_t*)LBSC_CS0CTRL)=0x00000020;
	*((volatile uint32_t*)LBSC_CS1CTRL)=0x00000020;
}

static void InitCSWCR(void)
{
//	*((volatile uint32_t*)LBSC_CSWCR0)=0xFF70FF70;			//Initial value
	*((volatile uint32_t*)LBSC_CSWCR0)=0x2A103320;
//	*((volatile uint32_t*)LBSC_CSWCR1)=0xFF70FF70;			//Initial value
	*((volatile uint32_t*)LBSC_CSWCR1)=0x2A103320;
}

static void InitCSPWCR(void)
{
	*((volatile uint32_t*)LBSC_CSPWCR0)=0x00000000;
	*((volatile uint32_t*)LBSC_CSPWCR1)=0x00000000;
}

static void InitEXWTSYNC(void)
{
	*((volatile uint32_t*)LBSC_EXWTSYNC)=0x00000000;
	*((volatile uint32_t*)LBSC_CS1GDST) =0x00000000;
//	*((volatile uint32_t*)LBSC_CS1GDST) =0x0000001F;
}
