#include	"common.h"
#include	"dgtable.h"
#include	"dgmodul4.h"
#include	"rpcqspidrv.h"
#include	"rpchyperdrv.h"
#include	"hyperflashdrv.h"
#include	"spiflash1drv.h"
#include	"reg_rcargen3.h"
#include	"dgloadmodul.h"
#include	"boardid.h"
#include	"init_board.h"
#include	"cpudrv.h"

#include	"switch.h"


uint32_t	gSpiFlashSvArea;
uint32_t	gUserPrgStartAdd;
uint32_t	gUserPrgSize;
uint32_t	gSelectQspiFlash;

uint32_t	gSpiDevId;
uint32_t	gSpiFamilyId;


extern uint32_t gDumpMode;
extern uint32_t gDumpStatus;
extern uint32_t gSPIDump[3];


extern const prg_tbl SwChgOnBoard_QSPI0[BOARD_COUNT];
extern const prg_tbl SwChgExSPI_QSPI0[BOARD_COUNT];
extern const prg_tbl SwChgHyperFlash[BOARD_COUNT];
extern const prg_tbl SwChgOnBoard_QSPI0_512M[BOARD_COUNT];


/****************************************************************
	MODULE				: dgGen3LoadSpi/Hyperflash				*
	FUNCTION			: load Program to Spi/Hyperflash memory	*
	COMMAND				: XLS									*
	INPUT PARAMETER		: XLS				 					*
*****************************************************************/
void dgGen3LoadSpiflash0(void)
{
#ifdef COM_SPI_ON

	char str[64];
	uint32_t OnBoardSpiSysSize;

	char		buf[16],key[16],chCnt,chPtr;
	uint32_t	readManuId,readDevId;
	uint32_t	loop;
	uint32_t	wrData;

	uint32_t	Load_workStartAdd,Load_workEndAdd;					//MOT�t�@�C���_�E�����[�h�G���A
	uint32_t	workAdd_Min,workAdd_Max;							//MOT�t�@�C���_�E�����[�h���(���[�N�A�h���X�j

	uint32_t	Read_workStartAdd;									//SPI�f�[�^�`�F�b�N�p�̃_�E�����[�h�A�h���X�i�Z�N�^��؂�j
	uint32_t	ClrSpiStartSecTopAdd,ClrSpiSecEndAdd;				//����SPI�A�h���X�i�Z�N�^��؂�j
	uint32_t	clearSize;											//�����T�C�Y

	uint32_t	MaskSectorSize;										//�Z�N�^��؂�}�X�N�l
	uint32_t	WriteDataStatAdd;									//�������݃��[�N�J�n�A�h���X
	uint32_t	PrgSpiStatAdd,PrgSpiEndAdd;							//��������SPI�A�h���X
	uint32_t	saveSize;											//�������ݎ��̃T�C�Y

	uint32_t	InfoPrgStatAdd;
	uint32_t	rdBufstatAdd;
	uintptr_t	prgStAdd,prgSize;

	uint32_t	WrittenSize;											//�������݃T�C�Y
	uint32_t	RemainingSize;											//�������ݎc�T�C�Y
	uint32_t	CondorLoaderFlag;

	PutStr("===== Qspi/HyperFlash writing of Gen3 Board Command ========",1);
	PutStr("Load Program to Spiflash",1);
	if(RamCheckTest1(LS_WORK_DRAM_SADD)){								//�Ȉ�R/W�`�F�b�N 4MB�̂�
		return;
	}
	SelQspiFlashSetSw();
	InitRPC_Mode();
	if(CheckQspiFlashId())
		return;						//Error abortt

	PutStr("---------------------------------------------------------------------",1);
	PutStr("Please select,Qspi/HyperFlash Save Area. ",1);
	PutStr(" ",1);
	PutStr("== Loader Program : Program to execute on SystemRAM or RT-SRAM ======",1);
	PutStr("   1 : A-Side SPI_Address = H' 004_0000-H' 007_FFFF         ",1);
	PutStr("   2 : B-Side SPI_Address = H' 008_0000-H' 00B_FFFF         ",1);
	PutStr(" ",1);
	PutStr("== User Program : Program to execute on DRAM , SystemRAM or RT-SRAM==",1);
	PutStr("   3 :        SPI_Address = H' 010_0000-H' 3FF_FFFF         ",1);
	PutStr("---------------------------------------------------------------------",1);

	loop=1;
	while(loop){
		PutStr("  Select area(1-3)>",0);
		GetStr(str,&chCnt);
		  switch(str[0]){
			case '1':				//LoaderProgram
				gSpiFlashSvArea		= 1;
				Load_workStartAdd	= LS_WORK_DRAM_SADD;
				Load_workEndAdd		= LS_WORK_DRAM_EADD_192K;
				PrgSpiStatAdd		= S25FL512_SA01_STARTAD;
				loop=0;
				break;
			case '2':				//LoaderProgram
				gSpiFlashSvArea		= 2;
				Load_workStartAdd	= LS_WORK_DRAM_SADD;
				Load_workEndAdd		= LS_WORK_DRAM_EADD_192K;
				PrgSpiStatAdd		= S25FL512_SA02_STARTAD;
				loop=0;
				break;
			case '3':				//UserProgram
				gSpiFlashSvArea		= 3;
				Load_workStartAdd	= LS_WORK_DRAM_SADD;
				Load_workEndAdd		= LS_WORK_DRAM_EADD_64M;
				PrgSpiStatAdd		= S25FL512_SA04_STARTAD;
				loop=0;
				break;
		  }
	}
	if(gSpiFlashSvArea==1 || gSpiFlashSvArea==2){
		CondorLoaderFlag = 0;
		PutStr("-- Loader Program --------------------------",1);
		PutStr("Please select.",1);
		PutStr(" 1 : Condor Board [Program Start Address:H'EB202600]",1);
		PutStr(" 2 : Other  Board [Program Start Address:H'E6302000]",1);
		loop=1;
		while(loop){
			PutStr("  Select Board(1-2)>",0);
			GetStr(str,&chCnt);
			  switch(str[0]){
				case '1':
					CondorLoaderFlag = 1;
					gUserPrgStartAdd = RTRAM_IPL_SADD;			//0xEB202600
					loop=0;
					break;
				case '2':
					gUserPrgStartAdd = SYSTEMRAM_IPL_SADD;		//0xE6302000
					loop=0;
					break;
			  }
		}
	}else if(gSpiFlashSvArea==3){
		PutStr("-- User Program ----------------------------",1);
		loop=1;
		while(loop){
			PutStr("Please Input User Program Start Address : ",0);
			GetStr(key,&chCnt);
			chPtr=0;
			if(!GetStrBlk(key,buf,&chPtr,0)){
				if(chPtr==1){									/* Case Return */

				}else if((buf[0]=='.')){						/* Case End */
					gUserPrgStartAdd = 0x40000000;				//��
					loop =0;
				}else if(chPtr > (char)((SIZE_32BIT<<1)+1) ){	/* Case Data Size Over */
					PutStr("Syntax Error",1);
				}else{
					if(HexAscii2Data((unsigned char*)buf,&wrData)){
						PutStr("Syntax Error",1);
					}else{
						if(wrData&0x00000003){
							PutStr("Memory Boundary Error",1);
						}
						else{
							gUserPrgStartAdd = wrData;
							loop =0;
						}
					}
				}
			}else{
				PutStr("Syntax Error",1);
			}
		}
	}

//=====================================================================================
//	InfoPrgStatAdd = S25FL512_SA03_STARTAD;
//	InfoPrgSizeAdd = S25FL512_SA03_STARTAD + 0x04;
//=====================================================================================

// WorkMemory CLEAR (Write H'FF)
   	if(gSpiFlashSvArea==1 || gSpiFlashSvArea==2){						//Loader Area
		PutStr("Work RAM(H'50000000-H'5002FFFF) Clear....",1);			//Change
   	}else if(gSpiFlashSvArea==3) {
		PutStr("Work RAM(H'50000000-H'53FFFFFF) Clear....",1);
    }
	FillData8Bit(Load_workStartAdd,Load_workEndAdd,0xFF);

// ������MOT�t�@�C�����[�h
	if(dgLS_Load_Offset2(&workAdd_Max ,&workAdd_Min))					//Change �v���O���� SystemRAM�Ή�
		return;															//

	PrgSpiStatAdd = PrgSpiStatAdd + (workAdd_Min - Load_workStartAdd);
	PrgSpiEndAdd  = PrgSpiStatAdd + (workAdd_Max - workAdd_Min);
	saveSize = (PrgSpiEndAdd-PrgSpiStatAdd)+1;

//���������ΏۃG���A�ŏ����̑ΏۃG���A�ɂ���

	MaskSectorSize= 0xFFFC0000;					//SA�P�ʂɃA�h���X�ύX�i0x40000�P�ʂɃ}�X�N�j

	WriteDataStatAdd     = workAdd_Min;
	ClrSpiStartSecTopAdd = PrgSpiStatAdd &   MaskSectorSize;	//�Z�N�^��؂�̐擪�A�h���X�ɕύX
	ClrSpiSecEndAdd      = PrgSpiEndAdd  | ~(MaskSectorSize);	//�Z�N�^��؂�̍ŏI�A�h���X�ɕύX

	clearSize = (ClrSpiSecEndAdd-ClrSpiStartSecTopAdd)+1;

//SPI Data(H'FF) Check Work Memory (�`�F�b�N�p��SPI���烊�[�h���Ă����f�[�^��W�J����G���A)
	Read_workStartAdd    = WORK_SPI_LOAD_AREA;

//OnBoardFlash�Ή� �ǉ�
	if(gSelectQspiFlash ==ONBOARD_QSPI){
		if( CkQspiFlash1ClearSectorSize(Read_workStartAdd,ClrSpiStartSecTopAdd,clearSize,1) )
			return;
	}else if(gSelectQspiFlash ==QSPI_BOARD){
		if( CkQspiFlash0ClearSectorSize(Read_workStartAdd,ClrSpiStartSecTopAdd,clearSize,1) )
			return;
	}else if(gSelectQspiFlash ==HYPER_FLASH){
		if( CkHyperFlashClearSectorSize(Read_workStartAdd,ClrSpiStartSecTopAdd,clearSize,1) )
			return;
	}else if(gSelectQspiFlash ==ONBOARD_QSPI_512M){
		if( CkQspiFlash2ClearSectorSize(Read_workStartAdd,ClrSpiStartSecTopAdd,clearSize,1) )
			return;
	}

// SAVE QSPI-FLASH
	PutStr("SAVE SPI-FLASH.......",0);

//OnBoardFlash�Ή� �ǉ�
	if(gSelectQspiFlash ==ONBOARD_QSPI){
		SaveDataWithBuffeQspiFlashS25s128s(WriteDataStatAdd,PrgSpiStatAdd,saveSize);			//Manual Mode Single WriteBuffe
		PutStr(" complete!",1);
	}
//RarH3_ES1�Ή�
	else if(gSelectQspiFlash ==QSPI_BOARD){														//H3_ES1.X�g�p����(4ByteAddress+WriteBuffe ��������NG)
		if(CHK_H3_ES1X){		//RarH3_ES1�Ή�
			PutStr(" ",1);
			if(PrgSpiStatAdd <0x1000000){
				if(PrgSpiEndAdd>0x1000000){
					WrittenSize   = 0x1000000-PrgSpiStatAdd;
					RemainingSize = saveSize - WrittenSize;

					Data2HexAscii(WrittenSize,str,4);	PutStr(" WrittenSize      :H' ",0);		PutStr(str,1);
					Data2HexAscii(RemainingSize,str,4);	PutStr(" RemainingSize    :H' ",0);		PutStr(str,1);

					PutStr("SpiArea : H'00000000-H'00FFFFFF",0);
					SaveDataWithBuffeQspiFlashS25fl512s(WriteDataStatAdd,PrgSpiStatAdd,WrittenSize);	//Manual Mode Single WriteBuffe
					PutStr(" complete!",1);
					PutStr("SpiArea : H'01000000-H'03FFFFFF",0);
					SaveDataQspiFlashS25fl512s_CsCont((0x50000000+WrittenSize),0x1000000,RemainingSize);	//Manual Mode Single (512)
					PutStr(" complete!",1);
				}else{
					PutStr("SpiArea : H'00000000-H'00FFFFFF",0);
					SaveDataWithBuffeQspiFlashS25fl512s(WriteDataStatAdd,PrgSpiStatAdd,saveSize);		//Manual Mode Single WriteBuffe
					PutStr(" complete!",1);
				}
			}else{
				PutStr("SpiArea : H'01000000-H'03FFFFFF",0);
				SaveDataQspiFlashS25fl512s_CsCont(WriteDataStatAdd,PrgSpiStatAdd,saveSize);			//Manual Mode Single (512)
				PutStr(" complete!",1);
			}
		}else{
			PutStr(" WriteBuffe Write ",0);														//********************* DEBUG
			SaveData4PPWithBuffeQspiFlashS25fl512s(WriteDataStatAdd,PrgSpiStatAdd,saveSize);	//Manual Mode Single WriteBuffe //4byte_add
			PutStr(" complete!",1);
		}
	}else if(gSelectQspiFlash ==HYPER_FLASH){
		SetRPC_ClockMode(RPC_CLK_40M);															//Word Program 50MHz(max)
		SaveDataWithBuffeHyperFlash(WriteDataStatAdd,PrgSpiStatAdd,saveSize);					//Manual Mode WriteBuffe
		SetRPC_ClockMode(RPC_CLK_80M);
		PutStr(" complete!",1);
	}else if(gSelectQspiFlash ==ONBOARD_QSPI_512M){
		SaveDataWithBuffeQspiFlashS25s512s(WriteDataStatAdd,PrgSpiStatAdd,saveSize);			//Manual Mode Single WriteBuffe
		PutStr(" complete!",1);
	}


//S25FL512,S128����
//���G���A�ւ̃A�h���X�A�f�[�^�T�C�Y��������
	PutStr("-- Save (Program Start Address & Size ) -----",1);		//Message change
   	if(gSpiFlashSvArea==1){				//A-Side IPL
		InfoPrgStatAdd = S25FL512_SA00_STARTAD;						//0x0000000
		if(CondorLoaderFlag){										//�t���O�ŕ���BCondor�ȊO�̃{�[�h�ł���������ꍇ����BCHK_V3H�ł�NG.
			prgStAdd   = Read_workStartAdd + V3H_SPIBOOT_A_IPL_ADD;		//Read_workStartAdd + 0x0003154
			prgSize    = Read_workStartAdd + V3H_SPIBOOT_A_IPL_SIZE;	//Read_workStartAdd + 0x0003264
		}else{
			prgStAdd   = Read_workStartAdd + SPIBOOT_A_IPL_ADD;			//Read_workStartAdd + 0x0000D54
			prgSize    = Read_workStartAdd + SPIBOOT_A_IPL_SIZE;		//Read_workStartAdd + 0x0000E64
		}
   	}else if(gSpiFlashSvArea==2){		//B-Side IPL
		InfoPrgStatAdd = S25FL512_SA00_STARTAD;						//0x0000000
		if(CondorLoaderFlag){										//�t���O�ŕ���BCondor�ȊO�̃{�[�h�ł���������ꍇ����BCHK_V3H�ł�NG.
			prgStAdd   = Read_workStartAdd + V3H_SPIBOOT_B_IPL_ADD;		//Read_workStartAdd + 0x0004154
			prgSize    = Read_workStartAdd + V3H_SPIBOOT_B_IPL_SIZE;	//Read_workStartAdd + 0x0004264
		}else{
			prgStAdd   = Read_workStartAdd + SPIBOOT_B_IPL_ADD;			//Read_workStartAdd + 0x0001154
			prgSize    = Read_workStartAdd + SPIBOOT_B_IPL_SIZE;		//Read_workStartAdd + 0x0001264
		}
   	}else if(gSpiFlashSvArea==3){		//User Program Area
		InfoPrgStatAdd = S25FL512_SA03_STARTAD;						//0x00C0000
		prgStAdd       = Read_workStartAdd + SPIBOOT_UPRG_ST_AD;		//Read_workStartAdd + 0x00C0000
		prgSize        = Read_workStartAdd + SPIBOOT_UPRG_SIZE;			//Read_workStartAdd + 0x00C0004
   	}

//�f�[�^�ޔ�
//SPI(SA0:H'0000000-H'003FFFF) -> DRAM(H'XX000000-H'6003FFFF)�Ƀ��[�h or
//SPI(SA3:H'00C0000-H'00FFFFF) -> DRAM(H'XX0C0000-H'600FFFFF)�Ƀ��[�h
	rdBufstatAdd    = Read_workStartAdd + InfoPrgStatAdd;	//0xXX000000 + 0x00C0000 = 0xXX0C0000
//	OnBoardSpiSysSize    = 0x2000;							//OnBoardSpi�̂� SA0=�p�����[�^�G���A�Ȃ̂ŏ����T�C�Y4K�i�ΏۃG���A�̂ݏ��������Ƃ���j
	OnBoardSpiSysSize    = 0x8000;							//V3H�Ή� 32KB�Ƃ���

	if(gSelectQspiFlash ==ONBOARD_QSPI){
		if(gSpiFlashSvArea==1 || gSpiFlashSvArea==2){
			FastRd3adQspiFlashS25s128s(InfoPrgStatAdd,rdBufstatAdd,OnBoardSpiSysSize);		//�V�X�e���Ŏg�p���Ă���ŏ����̂݃��[�h
		}else{
			SectorRdQspiFlashS25s128s(InfoPrgStatAdd,rdBufstatAdd);
		}
	}else if(gSelectQspiFlash ==QSPI_BOARD){
		SectorRdQspiFlashS25fl512s(InfoPrgStatAdd,rdBufstatAdd);
	}else if(gSelectQspiFlash ==HYPER_FLASH){
		SectorRdHyperFlash(InfoPrgStatAdd,rdBufstatAdd);
	}else if(gSelectQspiFlash ==ONBOARD_QSPI_512M){
		if(gSpiFlashSvArea==1 || gSpiFlashSvArea==2){
			FastRdQspiFlashS25s512s(InfoPrgStatAdd,rdBufstatAdd,OnBoardSpiSysSize);		//�V�X�e���Ŏg�p���Ă���ŏ����̂݃��[�h
		}else{
			SectorRdQspiFlashS25s512s(InfoPrgStatAdd,rdBufstatAdd);
		}
	}


//�ΏۃZ�N�^����  �FSPI_Flash����
	if(gSpiFlashSvArea==1 || gSpiFlashSvArea==2)
		PutStr("SPI Data Clear(H'FF):H'000000-03FFFF Erasing.",0);
	else
		PutStr("SPI Data Clear(H'FF):H'0C0000-0FFFFF Erasing.",0);
	if(gSelectQspiFlash ==ONBOARD_QSPI){
		if(gSpiFlashSvArea==1 || gSpiFlashSvArea==2){
			ParameterSectorEraseQspiFlashS25s128s(InfoPrgStatAdd,((OnBoardSpiSysSize)-1));
		}else{
			SectorEraseQspiFlashS25s128s(InfoPrgStatAdd,((InfoPrgStatAdd+0x8)-1));
		}
	}else if(gSelectQspiFlash ==QSPI_BOARD){
		SectorEraseQspiFlashS25fl512s(InfoPrgStatAdd,((InfoPrgStatAdd+0x8)-1));
	}else if(gSelectQspiFlash ==HYPER_FLASH){
		SectorEraseHyperFlashRange(InfoPrgStatAdd,((InfoPrgStatAdd+0x8)-1));
	}else if(gSelectQspiFlash ==ONBOARD_QSPI_512M){
		if(gSpiFlashSvArea==1 || gSpiFlashSvArea==2){
			ParameterSectorEraseQspiFlashS25s512s(InfoPrgStatAdd,((OnBoardSpiSysSize)-1));
		}else{
			SectorEraseQspiFlashS25s512s(InfoPrgStatAdd,((InfoPrgStatAdd+0x8)-1));
		}
	}

//DRAM�ɏ�����(�ΏۃA�h���X�̂�)
	*((uint32_t*)prgStAdd)     = gUserPrgStartAdd;
	saveSize = (saveSize|0x3)>>2;
	*((uint32_t*)prgSize)      = saveSize;

//�����݁FDRAM(H'600x0000-H'600xFFFF) -> SPI_Flash(SA3) H'00x0000-H'00xFFFF
	PutStr("SAVE SPI-FLASH.......",0);
	if(gSelectQspiFlash ==ONBOARD_QSPI){
		if(gSpiFlashSvArea==1 || gSpiFlashSvArea==2){
			SaveDataWithBuffeQspiFlashS25s128s(rdBufstatAdd,InfoPrgStatAdd,OnBoardSpiSysSize);		//Manual Mode Single WriteBuffe //o
		}else{
			SaveDataWithBuffeQspiFlashS25s128s(rdBufstatAdd,InfoPrgStatAdd,S25FL512_SA_SIZE);		//Manual Mode Single WriteBuffe
		}
	}else if(gSelectQspiFlash ==QSPI_BOARD){
		SaveDataQspiFlashS25fl512s_CsCont(rdBufstatAdd,InfoPrgStatAdd,S25FL512_SA_SIZE);			//Manual Mode Single (512)			//OK
	}else if(gSelectQspiFlash ==HYPER_FLASH){
		SetRPC_ClockMode(RPC_CLK_40M);															//Word Program 50MHz(max)
		SaveDataWithBuffeHyperFlash(rdBufstatAdd,InfoPrgStatAdd,S25FL512_SA_SIZE);				//Manual Mode WriteBuffe
		SetRPC_ClockMode(RPC_CLK_80M);
	}else if(gSelectQspiFlash ==ONBOARD_QSPI_512M){
		if(gSpiFlashSvArea==1 || gSpiFlashSvArea==2){
			SaveDataWithBuffeQspiFlashS25s512s(rdBufstatAdd,InfoPrgStatAdd,OnBoardSpiSysSize);		//Manual Mode Single WriteBuffe //o
		}else{
			SaveDataWithBuffeQspiFlashS25s512s(rdBufstatAdd,InfoPrgStatAdd,S25FL512_SA_SIZE);		//Manual Mode Single WriteBuffe
		}
	}

	PutStr(" complete!",1);

//�Z�[�u��񃁃b�Z�[�W�\��
	PutStr("",1);
	PutStr("==========  Qspi/HyperFlash Save Information  =================",1);
	PutStr(" Program Start Address :  H'",0);
	Data2HexAscii(gUserPrgStartAdd,str,4);
	PutStr(str,1);
	Data2HexAscii(saveSize,str,4);
	PutStr(" Program Size (Byte/4) :  H'",0);
	PutStr(str,1);
	PutStr("===============================================================",1);
	PutStr("",1);

#endif
}


#ifdef COM_SPI_ON		//ifdef COM_SPI_ON ��������


void SelQspiFlashSetSw(void)
{
	if(CHK_V3M||CHK_V3H){				// Eagle / CONDOR
		SelQspiFlashSetSw_Eagle();
	}else{								// Salvator / Kriek / StarterKit / Draak
		SelQspiFlashSetSw_Salvator();
	}
}

void SelQspiFlashSetSw_Salvator(void)
{
	char str[64];
	char		chCnt;
	uint32_t	loop;

	gSelectQspiFlash =0;

										PutStr("Please select,FlashMemory. ",1);
										PutStr("   1 : QspiFlash       (U5 : S25FS128S)",1);
	if(CHK_STARTERKIT)				{	PutStr("   2 : QspiFlash Board (CN2: S25FL512S)",1);	}
	else							{	PutStr("   2 : QspiFlash Board (CN3: S25FL512S)",1);	}
	if( (CHK_KRIEK)||(CHK_EBISU) )	{	PutStr("   3 : HyperFlash      (U86: S26KS512S)",1);	}
	else if(CHK_DRAAK)				{	PutStr("   3 : HyperFlash      (U110: S26KS512S)",1);	}
	else							{	PutStr("   3 : HyperFlash      (SiP internal)",1);		}
	loop=1;
	while(loop){
		PutStr("  Select (1-3)>",0);
		GetStr(str,&chCnt);
		  switch(str[0]){
			case '1':
		  		gSelectQspiFlash = ONBOARD_QSPI;
		  		gSpiFamilyId     = FS_S_FAMILY;
		  		gSpiDevId        = DEVID_S25FS128S;
		  		loop=0;
			  	SwChgOnBoard_QSPI0[ChkBoardCode()].program(); break;
			case '2':
		  		gSelectQspiFlash = QSPI_BOARD;
		  		gSpiFamilyId     = FL_S_FAMILY;
		  		gSpiDevId        = DEVID_S25FL512S;
		  		loop=0;
		  		SwChgExSPI_QSPI0[ChkBoardCode()].program();   break;
			case '3':
		  		gSelectQspiFlash = HYPER_FLASH;
		  		gSpiDevId        = DEVID_S26KS512S;
		  		loop=0;
		  		SwChgHyperFlash[ChkBoardCode()].program();    break;
		  }
	}
}

void SelQspiFlashSetSw_Eagle(void)
{
	char str[64];
	char		chCnt;
	uint32_t	loop;

	gSelectQspiFlash =0;

	PutStr("Please select,FlashMemory. ",1);
	PutStr("   1 : QspiFlash_128Mbit (U7  : S25FS128S)",1);
	PutStr("   2 : QspiFlash Board   (CN18: S25FL512S)",1);
	PutStr("   3 : QspiFlash_512Mbit (U6  : S25FS512S)",1);
	loop=1;
	while(loop){
		PutStr("  Select (1-3)>",0);
		GetStr(str,&chCnt);
		  switch(str[0]){
			case '1':
		  		gSelectQspiFlash = ONBOARD_QSPI;
		  		gSpiFamilyId     = FS_S_FAMILY;
		  		gSpiDevId        = DEVID_S25FS128S;
		  		loop=0;	
		  		SwChgOnBoard_QSPI0[ChkBoardCode()].program(); break;
			case '2':
		  		gSelectQspiFlash = QSPI_BOARD;
		  		gSpiFamilyId     = FL_S_FAMILY;
		  		gSpiDevId        = DEVID_S25FL512S;
		  		loop=0;
		  		SwChgExSPI_QSPI0[ChkBoardCode()].program();   break;
			case '3':	
		  		gSelectQspiFlash = ONBOARD_QSPI_512M;
		  		gSpiFamilyId     = FS_S_FAMILY;
		  		gSpiDevId        = DEVID_S25FS512S;
		  		loop=0;
		  		SwChgOnBoard_QSPI0_512M[ChkBoardCode()].program(); break;	//NEW
		  }
	}
}

void InitRPC_Mode(void)
{
	if(gSelectQspiFlash      == ONBOARD_QSPI)		{	InitRPC_QspiFlash();		}
	else if(gSelectQspiFlash == QSPI_BOARD)			{	InitRPC_QspiFlashBoard();	}
	else if(gSelectQspiFlash == HYPER_FLASH)		{	InitRPC_HyperFlash();		}
	else if(gSelectQspiFlash == ONBOARD_QSPI_512M)	{	InitRPC_QspiFlash();		}
}

uint32_t CheckQspiFlashId(void)
{
	char str[64];
	uint32_t	readDevId1;
	uint32_t	readDevId2;

	if(gSelectQspiFlash == HYPER_FLASH){
		ReadHyperFlashID(&readDevId1);
		ResetHyperFlash();			// ���[�h���[�h�ɖ߂�		Add 2015.07.21
	}else{	//QSPI
		ReadQspiFlashID64(&readDevId1,&readDevId2);
		readDevId1 = readDevId1 & 0x00FFFFFF;			//03h:�}�X�N
		readDevId2 = readDevId2 & 0x0000FF00;			//07h,06h,04h:�}�X�N
		if(readDevId2 != gSpiFamilyId){
			PutStr(" DEVICE FAMIRY ID Error. Please check switch setting ",1);
			readDevId2=readDevId2 >> 8;
			Data2HexAscii(readDevId2,str,1);	PutStr(" READ FAMIRY ID = 0x",0);	PutStr(str,0);
			if     (readDevId2==(FS_S_FAMILY>>8))	PutStr(" (FS_S_FAMILY)",1);
			else if(readDevId2==(FL_S_FAMILY>>8))	PutStr(" (FL_S_FAMILY)",1);
			else
				PutStr(" ",1);
			return(1);
		}
	}
	if(readDevId1 != gSpiDevId){
		PutStr(" DEVICE ID Error. Please check switch setting ",1);
		Data2HexAscii(readDevId1,str,4);		PutStr(" READ ID = 0x",0);			PutStr(str,1);
		if(gSelectQspiFlash != HYPER_FLASH){
			PutStr(" Note: The lower 24-bit only is valid. (Upper 8 bits it is mask.)",1);
		}
		return(1);
	}else{
		PutStr(" READ ID OK.",1);
		return(0);
	}
}



int32_t CkQspiFlash0ClearSectorSize(uint32_t rdBufAdd,uint32_t spiFlashStatAdd,uint32_t checkSize,uint32_t accessSize)
{
//	unsigned char *bufPtr;
	uint32_t flashStatus,flashEraseFlg;
	char str1Buf[10],str2Buf[10];



	char str[64];		//DEBUG

//	bufPtr = (unsigned char*)rdBufAdd;

	PutStr("SPI Data Clear(H'FF) Check :",0);
	QuadRdQspiFlashS25fl512s(spiFlashStatAdd,rdBufAdd,checkSize);

	flashEraseFlg = 0;

	if( CkSpiFlashAllF(rdBufAdd,checkSize) ){
		// SPI-FASH�Ƀf�[�^����̏ꍇ����

	    PutStr("H'",0);
		Data2HexAscii(spiFlashStatAdd,str1Buf,4);					PutStr(&str1Buf[0],0);
		PutStr("-",0);
		Data2HexAscii(((spiFlashStatAdd+checkSize)-1),str2Buf,4);	PutStr(&str2Buf[0],0);
		PutStr(",Clear OK?(y/n)",0);

		if( WaitKeyIn_YorN() ){	// Return1=N  �������Ȃ��ꍇ
		    DelStr(34);
			PutStr(" Exit ",1);
			return(1);
		}
		DelStr(34);
		flashEraseFlg = 1;
	}else{
		PutStr(" OK ",1);
	}
    if(flashEraseFlg){		// FLASH: erase
    	//PutStr("SPI-FLASH:H'xxxxxxxx-xxxxxxxx Erasing.",0);
//		PutStr("H'",0);	PutStr(&str1Buf[2],0);	PutStr("-",0);
		PutStr("H'",0);	PutStr(&str1Buf[0],0);	PutStr("-",0);
//									PutStr(&str2Buf[2],0);	PutStr(" Erasing.",0);
									PutStr(&str2Buf[0],0);	PutStr(" Erasing.",0);

    	SectorEraseQspiFlashS25fl512s(spiFlashStatAdd,((spiFlashStatAdd+checkSize)-1));	//SPI-FLASH-Address H'0000-H'FFFF

	}
	return(0);
}


int32_t CkQspiFlash1ClearSectorSize(uint32_t rdBufAdd,uint32_t spiFlashStatAdd,uint32_t checkSize,uint32_t accessSize)
{
	uint32_t flashStatus,flashEraseFlg;
	char str1Buf[10],str2Buf[10];

	char str[64];		//DEBUG

	PutStr("SPI Data Clear(H'FF) Check :",0);
//	QuadIORdQspiFlashS25s128s(spiFlashStatAdd,rdBufAdd,checkSize);					//add 2016.01.19
	FastRd3adQspiFlashS25s128s (spiFlashStatAdd,rdBufAdd,checkSize);				//Change 2015.07.23

	flashEraseFlg = 0;

	if( CkSpiFlashAllF(rdBufAdd,checkSize) ){
		// SPI-FASH�Ƀf�[�^����̏ꍇ����

	    PutStr("H'",0);
		Data2HexAscii(spiFlashStatAdd,str1Buf,4);					PutStr(&str1Buf[0],0);
		PutStr("-",0);
		Data2HexAscii(((spiFlashStatAdd+checkSize)-1),str2Buf,4);	PutStr(&str2Buf[0],0);
		PutStr(",Clear OK?(y/n)",0);

		if( WaitKeyIn_YorN() ){	// Return1=N  �������Ȃ��ꍇ
		    DelStr(34);
			PutStr(" Exit ",1);
			return(1);
		}
		DelStr(34);
		flashEraseFlg = 1;
	}else{
		PutStr(" OK ",1);
	}
    if(flashEraseFlg){		// FLASH: erase
//Add 2015.07.27 ��������
	   	if(spiFlashStatAdd<0x40000){		//Parameter Data Area Erase (H'0-H'7FFF)
			PutStr("H'00000000-H'00007FFF",0);	PutStr(" Erasing.",1);
			ParameterSectorEraseQspiFlashS25s128s(0x0,0x7FFF);
	   	}
//�����܂�
		PutStr("H'",0);	PutStr(&str1Buf[0],0);	PutStr("-",0);	PutStr(&str2Buf[0],0);	PutStr(" Erasing.",0);
   		SectorEraseQspiFlashS25s128s(spiFlashStatAdd,((spiFlashStatAdd+checkSize)-1));	//SPI-FLASH-Address H'0000-H'FFFF
	}
	return(0);
}

int32_t CkQspiFlash2ClearSectorSize(uint32_t rdBufAdd,uint32_t spiFlashStatAdd,uint32_t checkSize,uint32_t accessSize)
{
	uint32_t flashStatus,flashEraseFlg;
	char str1Buf[10],str2Buf[10];

	char str[64];		//DEBUG

	PutStr("SPI Data Clear(H'FF) Check :",0);
//	FastRdQspiFlashS25s512s    (spiFlashStatAdd,rdBufAdd,checkSize);		//4FAST_READ 0Ch Command 4-byte address command
	QuadIORdQspiFlashS25s512s  (spiFlashStatAdd,rdBufAdd,checkSize);		//4QUAD_I/O READ ECh Command 4-byte address command

	flashEraseFlg = 0;

	if( CkSpiFlashAllF(rdBufAdd,checkSize) ){

	    PutStr("H'",0);
		Data2HexAscii(spiFlashStatAdd,str1Buf,4);					PutStr(&str1Buf[0],0);
		PutStr("-",0);
		Data2HexAscii(((spiFlashStatAdd+checkSize)-1),str2Buf,4);	PutStr(&str2Buf[0],0);
		PutStr(",Clear OK?(y/n)",0);

		if( WaitKeyIn_YorN() ){	// Return1=N  �������Ȃ��ꍇ
		    DelStr(34);
			PutStr(" Exit ",1);
			return(1);
		}
		DelStr(34);
		flashEraseFlg = 1;
	}else{
		PutStr(" OK ",1);
	}
    if(flashEraseFlg){		// FLASH: erase
	   	if(spiFlashStatAdd<0x40000){		//Parameter Data Area Erase (H'0-H'7FFF)
			PutStr("H'00000000-H'00007FFF",0);	PutStr(" Erasing.",1);
//			ParameterSectorEraseQspiFlashS25s128s(0x0,0x7FFF);
			ParameterSectorEraseQspiFlashS25s512s(0x0,0x7FFF);
	   	}
		PutStr("H'",0);	PutStr(&str1Buf[0],0);	PutStr("-",0);	PutStr(&str2Buf[0],0);	PutStr(" Erasing.",0);
// 		SectorEraseQspiFlashS25s128s(spiFlashStatAdd,((spiFlashStatAdd+checkSize)-1));	//SPI-FLASH-Address H'0000-H'FFFF
   		SectorEraseQspiFlashS25s512s(spiFlashStatAdd,((spiFlashStatAdd+checkSize)-1));	//SPI-FLASH-Address H'0000-H'FFFF
	}
	return(0);
}



int32_t CkHyperFlashClearSectorSize(uint32_t rdBufAdd,uint32_t spiFlashStatAdd,uint32_t checkSize,uint32_t accessSize)
{
//	unsigned char *bufPtr;
	uint32_t flashStatus,flashEraseFlg;
	char str1Buf[10],str2Buf[10];
//	char str[64];		//DEBUG
//	bufPtr = (unsigned char*)rdBufAdd;

	PutStr("SPI Data Clear(H'FF) Check :",0);
//	RdManuHyperFlash(spiFlashStatAdd,rdBufAdd,checkSize);
	RdHyperFlash(spiFlashStatAdd,rdBufAdd,checkSize);

	flashEraseFlg = 0;
	if( CkSpiFlashAllF(rdBufAdd,checkSize) ){
		// SPI-FASH�Ƀf�[�^����̏ꍇ����
	    PutStr("H'",0);
		Data2HexAscii(spiFlashStatAdd,str1Buf,4);					PutStr(&str1Buf[0],0);
		PutStr("-",0);
		Data2HexAscii(((spiFlashStatAdd+checkSize)-1),str2Buf,4);	PutStr(&str2Buf[0],0);
		PutStr(",Clear OK?(y/n)",0);
		if( WaitKeyIn_YorN() ){	// Return1=N  �������Ȃ��ꍇ
		    DelStr(34);
			PutStr(" Exit ",1);
			return(1);
		}
		DelStr(34);
		flashEraseFlg = 1;
	}else{
		PutStr(" OK ",1);
	}
    if(flashEraseFlg){		// FLASH: erase
		PutStr("H'",0);	PutStr(&str1Buf[0],0);	PutStr("-",0);	PutStr(&str2Buf[0],0);	PutStr(" Erasing.",0);
	   	SectorEraseHyperFlashRange(spiFlashStatAdd,((spiFlashStatAdd+checkSize)-1));	//SPI-FLASH-Address H'0000-H'FFFF
	}
	return(0);
}


//Use RPC module
void mem_copy(uint32_t prgStartAd, uint32_t sector_Ad, uint32_t accessSize)
{
	if(CHK_V3M||CHK_V3H){	// Eagle,Condor (R-CarV3x Only)
		mem_copy_RtDmac(prgStartAd, sector_Ad, accessSize);
	}else{					// Salvator / Kriek / StarterKit / Draak / Ebisu (Other:R-CarH3x/M3x/E3/D3)
		mem_copy_SysDmac(prgStartAd, sector_Ad, accessSize);
	}
}

//void mem_copy(uint32_t prgStartAd, uint32_t sector_Ad, uint32_t accessSize)
void mem_copy_SysDmac(uint32_t prgStartAd, uint32_t sector_Ad, uint32_t accessSize)
{

	uintptr_t readAdd,wrAdd;			//DEBUG
	uint32_t paddingOffset=0;
	uint32_t accessCount=0;

//DEBUG============
//	for(readAdd=(uintptr_t)sector_Ad,wrAdd=(uintptr_t)prgStartAd ; readAdd< (sector_Ad +accessSize ) ; readAdd=readAdd+1,wrAdd=wrAdd+1){
//		*(uint8_t*)wrAdd = *(uint8_t*)readAdd;
//	}
//DEBUG============

//#if 0

	if(CHK_H3_ES1X){	//== R_CarH3_ES1.X ==
		paddingOffset = (accessSize + 0x3F ) & ~0x3F;		//calculate padding size (64byte)  RPC�L���b�V���T�C�Y�ɍ��킹��
	}else{
		paddingOffset = (accessSize + 0xFF ) & ~0xFF;		//calculate padding size (256byte) RPC�L���b�V���T�C�Y�ɍ��킹��
	}

	//accessCount = accessSize/64;
	accessCount = paddingOffset >> 6;

//DMA Setting
	InitDma01_Data(prgStartAd, sector_Ad, accessCount);
	StartDma01();
	WaitDma01();
	DisableDma01();
	ClearDmaCh01();
//#endif
}

void mem_copy_RtDmac(uint32_t prgStartAd, uint32_t sector_Ad, uint32_t accessSize)
{
	uint32_t paddingOffset=0;
	uint32_t accessCount=0;

	paddingOffset = (accessSize + 0xFF ) & ~0xFF;		//calculate padding size (256byte)

	//accessCount = accessSize/64;
	accessCount = paddingOffset >> 6;

//DMA Setting
	InitRtDmaCh0(prgStartAd, sector_Ad, accessCount);
	StartRtDmaCh0_15();
	WaitRtDmaCh0();
	DisableRtDmaCh0();
	ClearRtDmaCh0();
}

#endif				//ifdef COM_SPI_ON �����܂�



//SPI�Ԓn���w�肵�ď������� (�Z�N�^�P��)
/****************************************************************
	MODULE				: dgGen3LoadSpiflash0_2		(S25fl512s)	*
	FUNCTION			: load Program to Spiflash memory		*
	COMMAND				: XLS2									*
	INPUT PARAMETER		: XLS2			 						*
*****************************************************************/
void dgGen3LoadSpiflash0_2(void)
{
#ifdef COM_SPI_ON

	XLoadSpiflash0_2();

#endif

}

void XLoadSpiflash0_2(void)
{
#ifdef COM_SPI_ON

	char str[64];
	uint32_t	readManuId,readDevId;

	uint32_t	Load_workStartAdd,Load_workEndAdd;					//MOT�t�@�C���_�E�����[�h�G���A
	uint32_t	workAdd_Min,workAdd_Max;							//MOT�t�@�C���_�E�����[�h���(���[�N�A�h���X�j

	uint32_t	Read_workStartAdd;									//SPI�f�[�^�`�F�b�N�p�̃_�E�����[�h�A�h���X�i�Z�N�^��؂�j
	uint32_t	ClrSpiStartSecTopAdd,ClrSpiSecEndAdd;				//����SPI�A�h���X�i�Z�N�^��؂�j
	uint32_t	clearSize;											//�����T�C�Y

	uint32_t	MaskSectorSize;										//�Z�N�^��؂�}�X�N�l
	uint32_t	WriteDataStatAdd;									//�������݃��[�N�J�n�A�h���X
	uint32_t	PrgSpiStatAdd,PrgSpiEndAdd;							//��������SPI�A�h���X
	uint32_t	saveSize;											//�������ݎ��̃T�C�Y

	uint32_t	WrittenSize;											//�������݃T�C�Y
	uint32_t	RemainingSize;											//�������ݎc�T�C�Y

//�R�}���h�J�n���b�Z�[�W�\��
	PutStr("===== Qspi/HyperFlash writing of Gen3 Board Command =============",1);
	PutStr("Load Program to Spiflash",1);
	PutStr("Writes to any of SPI address.",1);
	if(RamCheckTest1(LS_WORK_DRAM_SADD)){						//�Ȉ�R/W�`�F�b�N 4MB�̂�
		return;
	}
	SelQspiFlashSetSw();
	InitRPC_Mode();

	if(CheckQspiFlashId())
		return;						//Error abortt

	gUserPrgStartAdd = 0x0;
	PutStr("Program Top Address & Qspi/HyperFlash Save Address ",1);

	gSpiFlashSvArea		= 3;
	Load_workStartAdd	= LS_WORK_DRAM_SADD;
	Load_workEndAdd		= LS_WORK_DRAM_EADD_64M;

	PrgSpiStatAdd		= 0x0;
	gUserPrgStartAdd	= 0x0;

	PutStr("===== Please Input Program Top Address ============",1);
	SetAddInputKey(&gUserPrgStartAdd);
	PutStr(" ",1);
	PutStr("===== Please Input Qspi/HyperFlash Save Address ===",1);
	SetAddInputKey(&PrgSpiStatAdd);
//	if(S25FL512_END_ADDRESS < PrgSpiStatAdd){
//		PutStr("Address Input Error",1);
//		PutStr("Range of H'000_0000 ~ H'3FF_FFFF",1);
//		return;
	if(gSelectQspiFlash ==ONBOARD_QSPI){
		if(S25S128_END_ADDRESS < PrgSpiStatAdd){
			PutStr("Address Input Error",1);
//			PutStr("Range of H'000_0000 ~ H'0FF_FFFF",1);
			PutStr("Range of H'000_0000 ~ H'0FF_7FFF",1);			//Change 2015.07.27
			return;
		}
	}else if( (gSelectQspiFlash==QSPI_BOARD) || (gSelectQspiFlash==HYPER_FLASH) || (gSelectQspiFlash==ONBOARD_QSPI_512M) ){
		if(S25FL512_END_ADDRESS < PrgSpiStatAdd){
			PutStr("Address Input Error",1);
			PutStr("Range of H'000_0000 ~ H'3FF_FFFF",1);
			return;
		}
	}

// WorkMemory CLEAR (Write H'FF)
	PutStr("Work RAM(H'50000000-H'53FFFFFF) Clear....",1);		//
	FillData8Bit(Load_workStartAdd,Load_workEndAdd,0xFF);

// ������MOT�t�@�C�����[�h
	if(dgLS_Load_Offset2(&workAdd_Max ,&workAdd_Min))			//Change �v���O���� SystemRAM�Ή�
		return;													//

	PrgSpiStatAdd = PrgSpiStatAdd + (workAdd_Min - Load_workStartAdd);
	PrgSpiEndAdd  = PrgSpiStatAdd + (workAdd_Max - workAdd_Min);
	saveSize = (PrgSpiEndAdd-PrgSpiStatAdd)+1;
	if(gSelectQspiFlash ==ONBOARD_QSPI){
		if(PrgSpiEndAdd>S25S128_END_ADDRESS){
			PutStr("Program over size Error",1);
			PutStr(" SpiFlashMemory Stat Address : H'",0);
			Data2HexAscii(PrgSpiStatAdd,str,4);
			PutStr(str,1);
			PutStr(" SpiFlashMemory End Address  : H'",0);
			Data2HexAscii(PrgSpiEndAdd,str,4);
			PutStr(str,1);
			return;
		}
	}else if( (gSelectQspiFlash==QSPI_BOARD) || (gSelectQspiFlash==HYPER_FLASH) || (gSelectQspiFlash==ONBOARD_QSPI_512M) ){
		if(PrgSpiEndAdd>S25FL512_END_ADDRESS){
			PutStr("Program over size Error",1);
			PutStr(" SpiFlashMemory Stat Address : H'",0);
			Data2HexAscii(PrgSpiStatAdd,str,4);
			PutStr(str,1);
			PutStr(" SpiFlashMemory End Address  : H'",0);
			Data2HexAscii(PrgSpiEndAdd,str,4);
			PutStr(str,1);
			return;
		}
	}

//���������ΏۃG���A�ŏ����̑ΏۃG���A�ɂ���

	MaskSectorSize= 0xFFFC0000;					//SA�P�ʂɃA�h���X�ύX�i0x40000�P�ʂɃ}�X�N�j

	WriteDataStatAdd     = workAdd_Min;
	ClrSpiStartSecTopAdd = PrgSpiStatAdd &   MaskSectorSize;	//�Z�N�^��؂�̐擪�A�h���X�ɕύX
	ClrSpiSecEndAdd      = PrgSpiEndAdd  | ~(MaskSectorSize);	//�Z�N�^��؂�̍ŏI�A�h���X�ɕύX

	clearSize = (ClrSpiSecEndAdd-ClrSpiStartSecTopAdd)+1;

//SPI Data(H'FF) Check Work Memory (�`�F�b�N�p��SPI���烊�[�h���Ă����f�[�^��W�J����G���A)
	Read_workStartAdd    = WORK_SPI_LOAD_AREA;

	if(gSelectQspiFlash ==ONBOARD_QSPI){														//SA0��256KByte�P�ʂ̏����Ƃ���
		if( CkQspiFlash1ClearSectorSize(Read_workStartAdd,ClrSpiStartSecTopAdd,clearSize,1) )
			return;
	}else if(gSelectQspiFlash ==QSPI_BOARD){
		if( CkQspiFlash0ClearSectorSize(Read_workStartAdd,ClrSpiStartSecTopAdd,clearSize,1) )
			return;
	}else if(gSelectQspiFlash ==HYPER_FLASH){
		if( CkHyperFlashClearSectorSize(Read_workStartAdd,ClrSpiStartSecTopAdd,clearSize,1) )
			return;
	}else if(gSelectQspiFlash ==ONBOARD_QSPI_512M){
		if( CkQspiFlash2ClearSectorSize(Read_workStartAdd,ClrSpiStartSecTopAdd,clearSize,1) )
			return;
	}

// SAVE QSPI-FLASH
	PutStr("SAVE SPI-FLASH.......",0);

//OnBoardFlash�Ή� �ǉ�
	if(gSelectQspiFlash ==ONBOARD_QSPI){
		SaveDataWithBuffeQspiFlashS25s128s(WriteDataStatAdd,PrgSpiStatAdd,saveSize);		//Manual Mode Single WriteBuffe
		PutStr(" complete!",1);
	}else if(gSelectQspiFlash ==QSPI_BOARD){													//H3_ES1.X�g�p����(4ByteAddress+WriteBuffe ��������NG)
		if(CHK_H3_ES1X){		//RarH3_ES1�Ή�
			PutStr(" ",1);
			if(PrgSpiStatAdd <0x1000000){
				if(PrgSpiEndAdd>0x1000000){
					WrittenSize   = 0x1000000-PrgSpiStatAdd;
					RemainingSize = saveSize - WrittenSize;

					Data2HexAscii(WrittenSize,str,4);	PutStr(" WrittenSize      :H' ",0);		PutStr(str,1);
					Data2HexAscii(RemainingSize,str,4);	PutStr(" RemainingSize    :H' ",0);		PutStr(str,1);

					PutStr("SpiArea : H'00000000-H'00FFFFFF",0);
					SaveDataWithBuffeQspiFlashS25fl512s(WriteDataStatAdd,PrgSpiStatAdd,WrittenSize);	//Manual Mode Single WriteBuffe
					PutStr(" complete!",1);
					PutStr("SpiArea : H'01000000-H'03FFFFFF",0);
					SaveDataQspiFlashS25fl512s_CsCont((0x50000000+WrittenSize),0x1000000,RemainingSize);	//Manual Mode Single (512)
					PutStr(" complete!",1);
				}else{
					PutStr("SpiArea : H'00000000-H'00FFFFFF",0);
					SaveDataWithBuffeQspiFlashS25fl512s(WriteDataStatAdd,PrgSpiStatAdd,saveSize);		//Manual Mode Single WriteBuffe
					PutStr(" complete!",1);
				}
			}else{
				PutStr("SpiArea : H'01000000-H'03FFFFFF",0);
				SaveDataQspiFlashS25fl512s_CsCont(WriteDataStatAdd,PrgSpiStatAdd,saveSize);			//Manual Mode Single (512)
				PutStr(" complete!",1);
			}
		}else{
			PutStr(" WriteBuffe Write ",0);														//********************* DEBUG
//			SaveDataWithBuffeQspiFlashS25fl512s   (WriteDataStatAdd,PrgSpiStatAdd,saveSize);	//Manual Mode Single WriteBuffe //3byte_add
			SaveData4PPWithBuffeQspiFlashS25fl512s(WriteDataStatAdd,PrgSpiStatAdd,saveSize);	//Manual Mode Single WriteBuffe //4byte_add
			PutStr(" complete!",1);
		}
	}else if(gSelectQspiFlash ==HYPER_FLASH){
		SetRPC_ClockMode(RPC_CLK_40M);														//Word Program 50MHz(max)
		SaveDataWithBuffeHyperFlash(WriteDataStatAdd,PrgSpiStatAdd,saveSize);				//Manual Mode WriteBuffe
		SetRPC_ClockMode(RPC_CLK_80M);
		PutStr(" complete!",1);
	}else if(gSelectQspiFlash ==ONBOARD_QSPI_512M){
		SaveDataWithBuffeQspiFlashS25s512s(WriteDataStatAdd,PrgSpiStatAdd,saveSize);			//Manual Mode Single WriteBuffe
		PutStr(" complete!",1);
	}

//��񃁃b�Z�[�W�\��
	PutStr("",1);
	PutStr("======= Qspi/HyperFlash Save Information  =================",1);
	PutStr(" SpiFlashMemory Stat Address : H'",0);
	Data2HexAscii(PrgSpiStatAdd,str,4);
	PutStr(str,1);
	PutStr(" SpiFlashMemory End Address  : H'",0);
	Data2HexAscii(PrgSpiEndAdd,str,4);
	PutStr(str,1);
	PutStr("===========================================================",1);
	PutStr("",1);

#endif
}




#ifdef COM_SPI_ON				//ifdef COM_SPI_ON ��������

void SetData(uint32_t *setAdd)
{
	char		buf[16],key[16],chCnt,chPtr;
	uint32_t	loop;
	uint32_t 	wrData;

	loop =1;

	while(loop){
		PutStr(" Set Data : ",0);
		GetStr(key,&chCnt);
		chPtr=0;
		if(!GetStrBlk(key,buf,&chPtr,0)){
			if(chPtr==1){									/* Case Return */

			}else if(chPtr > (char)((SIZE_32BIT<<1)+1) ){	/* Case Data Size Over */
				PutStr("Syntax Error",1);
			}else{
				if(HexAscii2Data((unsigned char*)buf,&wrData)){
					PutStr("Syntax Error",1);
				}else{
					*setAdd = wrData;
					loop =0;
				}
			}
		}else{
			PutStr("Syntax Error",1);
		}
	}
}

int32_t CkSpiFlashAllF(int32_t sAdd,int32_t cap)
{
//	int32_t			ckAdd;
	uintptr_t		ckAdd;
	unsigned char	rdData;

	for(ckAdd=sAdd;ckAdd<(sAdd+cap);ckAdd++){
		rdData = *((volatile unsigned char*)ckAdd);
	    if(rdData != 0xFF){
			return(1);
	    }
	}
	return(0);
}

void SetAddInputKey(uint32_t *Address)
{
	char		str[64];
	char		buf[16],key[16],chCnt,chPtr;
	uint32_t	loop;
	uint32_t	wrData;

	loop=1;
	while(loop){
		PutStr("  Please Input : H'",0);
		GetStr(key,&chCnt);
		chPtr=0;
		if(!GetStrBlk(key,buf,&chPtr,0)){
			if(chPtr==1){									/* Case Return */
				}else if((buf[0]=='.')){					/* Case End */
				gUserPrgStartAdd = 0x40000000;
				loop =0;
			}else if(chPtr > (char)((SIZE_32BIT<<1)+1) ){	/* Case Data Size Over */
				PutStr("Syntax Error",1);
			}else{
				if(HexAscii2Data((unsigned char*)buf,&wrData)){
					PutStr("Syntax Error",1);
				}else{
					if(wrData&0x00000003){
						PutStr("Memory Boundary Error",1);
					}
					else{
//						gUserPrgStartAdd = wrData;
						*Address = wrData;
						loop =0;
					}
				}
			}
		}else{
			PutStr("Syntax Error",1);
		}
	}
}

#endif				//ifdef COM_SPI_ON �����܂�




/****************************************************************
	MODULE				: dgGen3InfoSpiflash0_SA0	(S25fl512s)	*
	FUNCTION			: read SA0 spi Spiflash memory			*
	COMMAND				: XINFO_SA0								*
	INPUT PARAMETER		: XINFO_SA0			 					*
*****************************************************************/
void dgGen3InfoSpiflash0_SA0(void)
{
#ifdef COM_SPI_ON

	char str[64];
	uint32_t bootRomPara;
	uint32_t prgStAdd,prgSize;
	uint32_t prgStAdd_B,prgSize_B;
	uint32_t prgStAdd_v3h,prgSize_v3h;				//V3H�p
	uint32_t prgStAdd_B_v3h,prgSize_B_v3h;			//V3H�p
	uint32_t readManuId,readDevId;
	uint32_t spiFlashStatAdd,workTopAdd,rdBufstatAdd;
	uintptr_t readAdd;

	PutStr("=== SPI SA0 System Area Information  ===",1);
	SelQspiFlashSetSw();
	InitRPC_Mode();
	if(CheckQspiFlashId())
		return;						//Error abortt

//Setting  SPI_Add, workRAM_Add
	spiFlashStatAdd = S25FL512_SA00_STARTAD;				//�V�X�e�����Z�N�^(SA0)�F0x0000000�`

	workTopAdd      = WORK_SPI_LOAD_AREA;
	rdBufstatAdd    = workTopAdd + spiFlashStatAdd;			//0xXX000000 + 0x0000000 = 0xXX000000

//SPI(SA0:H'0000000-H'003FFFF) -> DRAM(H'XX000000-H'XX03FFFF)�Ƀ��[�h �i�f�[�^�ޔ��j
	if(gSelectQspiFlash ==ONBOARD_QSPI){
		SectorRdQspiFlashS25s128s(spiFlashStatAdd,rdBufstatAdd);
	}else if(gSelectQspiFlash ==QSPI_BOARD){
		SectorRdQspiFlashS25fl512s(spiFlashStatAdd,rdBufstatAdd);
	}else if(gSelectQspiFlash ==HYPER_FLASH){
		SectorRdHyperFlash(spiFlashStatAdd,rdBufstatAdd);
	}else if(gSelectQspiFlash ==ONBOARD_QSPI_512M){
		SectorRdQspiFlashS25s512s(spiFlashStatAdd,rdBufstatAdd);
	}

	readAdd  = workTopAdd + SPIBOOT_BTROM_PARA;		bootRomPara = *(uint32_t *)readAdd;		//Read Boot ROM Parameters Address
//	if(CHK_V3H){
		readAdd  = workTopAdd + V3H_SPIBOOT_A_IPL_ADD;	prgStAdd_v3h   = *(uint32_t *)readAdd;	//Read Program Start Address
		readAdd  = workTopAdd + V3H_SPIBOOT_A_IPL_SIZE;	prgSize_v3h    = *(uint32_t *)readAdd;	//Read Program Size
		readAdd  = workTopAdd + V3H_SPIBOOT_B_IPL_ADD;	prgStAdd_B_v3h = *(uint32_t *)readAdd;	//Read Program Start Address
		readAdd  = workTopAdd + V3H_SPIBOOT_B_IPL_SIZE;	prgSize_B_v3h  = *(uint32_t *)readAdd;	//Read Program Size
//	}else{
		readAdd  = workTopAdd + SPIBOOT_A_IPL_ADD;		prgStAdd       = *(uint32_t *)readAdd;	//Read Program Start Address
		readAdd  = workTopAdd + SPIBOOT_A_IPL_SIZE;		prgSize        = *(uint32_t *)readAdd;	//Read Program Size
		readAdd  = workTopAdd + SPIBOOT_B_IPL_ADD;		prgStAdd_B     = *(uint32_t *)readAdd;	//Read Program Start Address
		readAdd  = workTopAdd + SPIBOOT_B_IPL_SIZE;		prgSize_B      = *(uint32_t *)readAdd;	//Read Program Size
//	}

	Data2HexAscii(bootRomPara,str,4);	PutStr(" Boot ROM Parameters                        : H'",0);	PutStr(str,1);	//Now Boot ROM Parameters �\��
	Data2HexAscii(prgStAdd_v3h,str,4);	PutStr(" A-side IPL Address   (Loader Address) [V3H]: H'",0);	PutStr(str,1);	//Now A-side IPL Address �\��
	Data2HexAscii(prgSize_v3h,str,4);	PutStr(" A-side IPL data size (Loader size)    [V3H]: H'",0);	PutStr(str,1);	//Now A-side IPL data size �\��
	Data2HexAscii(prgStAdd_B_v3h,str,4);PutStr(" B-side IPL Address   (Loader Address) [V3H]: H'",0);	PutStr(str,1);	//Now A-side IPL Address �\��
	Data2HexAscii(prgSize_B_v3h,str,4);	PutStr(" B-side IPL data size (Loader size)    [V3H]: H'",0);	PutStr(str,1);	//Now A-side IPL data size �\��
	Data2HexAscii(prgStAdd,str,4);		PutStr(" A-side IPL Address   (Loader Address)      : H'",0);	PutStr(str,1);	//Now A-side IPL Address �\��
	Data2HexAscii(prgSize,str,4);		PutStr(" A-side IPL data size (Loader size)         : H'",0);	PutStr(str,1);	//Now A-side IPL data size �\��
	Data2HexAscii(prgStAdd_B,str,4);	PutStr(" B-side IPL Address   (Loader Address)      : H'",0);	PutStr(str,1);	//Now A-side IPL Address �\��
	Data2HexAscii(prgSize_B,str,4);		PutStr(" B-side IPL data size (Loader size)         : H'",0);	PutStr(str,1);	//Now A-side IPL data size �\��
	PutStr("=========================================================",1);

#endif
}


#ifdef COM_SPI_ON

int32_t CheckDataChange(uintptr_t checkAdd)
{
	uint32_t data;
	uint32_t change;
	char str[64];
	char keyBuf[32],chCnt;

	change = CHANGE_OFF;

	data = *(uint32_t *)checkAdd;

	Data2HexAscii(data,str,4);	PutStr(str,1);
	while(1){
		PutStr(" Change ?(Y/N)",0);	GetStr(keyBuf,&chCnt);
		if(chCnt==1){
			if((keyBuf[0]=='Y')||(keyBuf[0]=='y')){
				PutStr(" Please Input New Data ",1);
				SetData(&data);
				*((uint32_t*)checkAdd) = data;
				change = CHANGE_ON;
				break;
			}
			if((keyBuf[0]=='N')||(keyBuf[0]=='n'))
				break;
		}
	}
	return(change);
}

#endif

/****************************************************************
	MODULE				: dgGen3InfoSpiflash0_SA0	(S25fl512s)	*
	FUNCTION			: set SA0 spi Spiflash memory			*
	COMMAND				: XINFO_SA0_S							*
	INPUT PARAMETER		: XINFO_SA0_S		 					*
*****************************************************************/
//����:OnBoardSpi�̂ݏ��������T�C�Y�قȂ�B
void dgGen3InfoSetSpiflash0_SA0(void)
{
#ifdef COM_SPI_ON

	char str[64];
	uint32_t change;
	uint32_t spiFlashStatAdd,workTopAdd,rdBufstatAdd;
	uintptr_t readAdd;
	uint32_t readManuId,readDevId;
	uint32_t OnBoardSpiSysSize;

	change = CHANGE_OFF;

	PutStr("=== SPI SA0 System Area Information  ===",1);
	SelQspiFlashSetSw();
	InitRPC_Mode();
	if(CheckQspiFlashId())
		return;						//Error abortt

//Setting  SPI_Add, workRAM_Add
	spiFlashStatAdd = S25FL512_SA00_STARTAD;				//�V�X�e�����Z�N�^(SA0) �F0x0000000�`

	workTopAdd      = WORK_SPI_LOAD_AREA;
	rdBufstatAdd    = workTopAdd + spiFlashStatAdd;			//0xXX000000 + 0x0000000 = 0xXX000000
//	OnBoardSpiSysSize    = 0x2000;							//OnBoardSpi�̂� SA0=�p�����[�^�G���A�Ȃ̂ŏ����T�C�Y4K�i�ΏۃG���A�̂ݏ��������Ƃ���j
	OnBoardSpiSysSize    = 0x8000;							//V3H�Ή� 32KB�Ƃ���

//SPI(SA0:H'0000000-H'003FFFF) -> DRAM(H'XX000000-H'6003FFFF)�Ƀ��[�h �i�f�[�^�ޔ��j
	if(gSelectQspiFlash ==ONBOARD_QSPI){
		FastRd3adQspiFlashS25s128s(spiFlashStatAdd,rdBufstatAdd,OnBoardSpiSysSize);		//�V�X�e���Ŏg�p���Ă���ŏ����̂݃��[�h
	}else if(gSelectQspiFlash ==QSPI_BOARD){
		SectorRdQspiFlashS25fl512s(spiFlashStatAdd,rdBufstatAdd);
	}else if(gSelectQspiFlash ==HYPER_FLASH){
		SectorRdHyperFlash(spiFlashStatAdd,rdBufstatAdd);
	}else if(gSelectQspiFlash ==ONBOARD_QSPI_512M){
		FastRdQspiFlashS25s512s(spiFlashStatAdd,rdBufstatAdd,OnBoardSpiSysSize);		//�V�X�e���Ŏg�p���Ă���ŏ����̂݃��[�h
	}
	readAdd  = workTopAdd + SPIBOOT_BTROM_PARA;			PutStr(" Boot ROM Parameters                        : H'",0);	if(CHANGE_ON==CheckDataChange(readAdd))	change=CHANGE_ON;	//Boot ROM Parameters Address
//	if(CHK_V3H){
		readAdd  = workTopAdd + V3H_SPIBOOT_A_IPL_ADD;	PutStr(" A-side IPL Address   (Loader Address) [V3H]: H'",0);	if(CHANGE_ON==CheckDataChange(readAdd))	change=CHANGE_ON;	//A-side IPL Address
		readAdd  = workTopAdd + V3H_SPIBOOT_A_IPL_SIZE;	PutStr(" A-side IPL data size (Loader size)    [V3H]: H'",0);	if(CHANGE_ON==CheckDataChange(readAdd))	change=CHANGE_ON;	//A-side IPL data size
		readAdd  = workTopAdd + V3H_SPIBOOT_B_IPL_ADD;	PutStr(" B-side IPL Address   (Loader Address) [V3H]: H'",0);	if(CHANGE_ON==CheckDataChange(readAdd))	change=CHANGE_ON;	//B-side IPL Address
		readAdd  = workTopAdd + V3H_SPIBOOT_B_IPL_SIZE;	PutStr(" B-side IPL data size (Loader size)    [V3H]: H'",0);	if(CHANGE_ON==CheckDataChange(readAdd))	change=CHANGE_ON;	//B-side IPL data size
//	}else{
		readAdd  = workTopAdd + SPIBOOT_A_IPL_ADD;		PutStr(" A-side IPL Address   (Loader Address)      : H'",0);	if(CHANGE_ON==CheckDataChange(readAdd))	change=CHANGE_ON;	//A-side IPL Address
		readAdd  = workTopAdd + SPIBOOT_A_IPL_SIZE;		PutStr(" A-side IPL data size (Loader size)         : H'",0);	if(CHANGE_ON==CheckDataChange(readAdd))	change=CHANGE_ON;	//A-side IPL data size
		readAdd  = workTopAdd + SPIBOOT_B_IPL_ADD;		PutStr(" B-side IPL Address   (Loader Address)      : H'",0);	if(CHANGE_ON==CheckDataChange(readAdd))	change=CHANGE_ON;	//B-side IPL Address
		readAdd  = workTopAdd + SPIBOOT_B_IPL_SIZE;		PutStr(" B-side IPL data size (Loader size)         : H'",0);	if(CHANGE_ON==CheckDataChange(readAdd))	change=CHANGE_ON;	//B-side IPL data size
//	}
	// for V3H
	PutStr("",1);
	PutStr(" Configuration for R-CarV3H(Condor) ",1);
	PutStr(" SpiBoot Configuration data Write ?(Y/N)",0);
	if( WaitKeyIn_YorN() ){	// Return1=N
		PutStr("",1);
	}else{					// Return0=Y
		change=CHANGE_ON;
		PutStr("",1);
		PutStr(" ---- configuration for V3H ----",1);
		readAdd  = workTopAdd + 0x0003000;		PutStr(" A-side IPL parameter of data code          : Addr=H'3000 -> Data=H'E291F358",1);
		*((volatile uint32_t*)readAdd) = 0xE291F358;
		readAdd  = workTopAdd + 0x0004000;		PutStr(" B-side IPL parameter of data code          : Addr=H'4000 -> Data=H'E291F358",1);
		*((volatile uint32_t*)readAdd) = 0xE291F358;

		readAdd  = workTopAdd + 0x000200C;		PutStr(" key size                                   : Addr=H'200C -> Data=H'00000000",1);
		*((volatile uint32_t*)readAdd) = 0x00000000;
		readAdd  = workTopAdd + 0x000300C;		PutStr(" A-side IPL parameter of key size           : Addr=H'300C -> Data=H'00000000",1);
		*((volatile uint32_t*)readAdd) = 0x00000000;
		readAdd  = workTopAdd + 0x000400C;		PutStr(" B-side IPL parameter of key size           : Addr=H'400C -> Data=H'00000000",1);
		*((volatile uint32_t*)readAdd) = 0x00000000;
		PutStr("",1);
	}
	if(change == CHANGE_ON){
//����  �FSPI_Flash(SA0)����
//		PutStr("SPI Data Clear(H'FF):H'000000-03FFFF Erasing.",0);
		if(gSelectQspiFlash ==ONBOARD_QSPI){
//			SectorEraseQspiFlashS25s128s(spiFlashStatAdd,((spiFlashStatAdd+0x4)-1));	//�擪�A�㔼32KByte�͏����s��
//			PutStr("SPI Data Clear(H'FF):H'000000-001FFF Erasing.",0);
			PutStr("SPI Data Clear(H'FF):H'000000-007FFF Erasing.",0);
			ParameterSectorEraseQspiFlashS25s128s(spiFlashStatAdd,((OnBoardSpiSysSize)-1));
		}else if(gSelectQspiFlash ==QSPI_BOARD){
			PutStr("SPI Data Clear(H'FF):H'000000-03FFFF Erasing.",0);
			SectorEraseQspiFlashS25fl512s(spiFlashStatAdd,((spiFlashStatAdd+0x4)-1));
		}else if(gSelectQspiFlash ==HYPER_FLASH){
			PutStr("SPI Data Clear(H'FF):H'000000-03FFFF Erasing.",0);
			SectorEraseHyperFlashRange(spiFlashStatAdd,((spiFlashStatAdd+0x4)-1));
		}else if(gSelectQspiFlash ==ONBOARD_QSPI_512M){
//			SectorEraseQspiFlashS25s128s(spiFlashStatAdd,((spiFlashStatAdd+0x4)-1));	//�擪�A�㔼32KByte�͏����s��
//			PutStr("SPI Data Clear(H'FF):H'000000-001FFF Erasing.",0);
			PutStr("SPI Data Clear(H'FF):H'000000-007FFF Erasing.",0);
			ParameterSectorEraseQspiFlashS25s512s(spiFlashStatAdd,((OnBoardSpiSysSize)-1));
		}
//		SoftDelay(4000);			//Add 2015.07.21
		ResetHyperFlash();			// ���[�h���[�h�ɖ߂�		Add 2015.07.21
//�����݁FDRAM(H'60000000-H'6003FFFF) -> SPI_Flash(SA0) H'0000000-H'003FFFF
		PutStr("SAVE SPI-FLASH.......",0);
		if(gSelectQspiFlash ==ONBOARD_QSPI){
			SaveDataWithBuffeQspiFlashS25s128s(rdBufstatAdd,spiFlashStatAdd,OnBoardSpiSysSize);		//Manual Mode Single WriteBuffe //o
		}else if(gSelectQspiFlash ==QSPI_BOARD){
			SaveDataQspiFlashS25fl512s_CsCont(rdBufstatAdd,spiFlashStatAdd,S25FL512_SA_SIZE);			//Manual Mode Single (512)
		}else if(gSelectQspiFlash ==HYPER_FLASH){
			SetRPC_ClockMode(RPC_CLK_40M);															//Word Program 50MHz(max)
			SaveDataWithBuffeHyperFlash(rdBufstatAdd,spiFlashStatAdd,S25FL512_SA_SIZE);				//Manual Mode WriteBuffe	//o
			SetRPC_ClockMode(RPC_CLK_80M);
		}else if(gSelectQspiFlash ==ONBOARD_QSPI_512M){
			SaveDataWithBuffeQspiFlashS25s512s(rdBufstatAdd,spiFlashStatAdd,OnBoardSpiSysSize);		//Manual Mode Single WriteBuffe //o
		}
		PutStr(" complete!",1);
	}

#endif
}




/****************************************************************
	MODULE				: dgGen3InfoSpiflash0		(S25fl512s)	*
	FUNCTION			: read SA3 spi Spiflash memory			*
	COMMAND				: XINFO									*
	INPUT PARAMETER		: XINFO				 					*
*****************************************************************/
void dgGen3InfoSpiflash0(void)
{
#ifdef COM_SPI_ON

	char str[64];
	uint32_t prgStAdd,prgSize;
	uint32_t readManuId,readDevId;
	uint32_t spiFlashStatAdd,workTopAdd,rdBufstatAdd;
	uintptr_t readAdd;

	PutStr("=== SPI SA3 System Area Information  ===",1);
	SelQspiFlashSetSw();
	InitRPC_Mode();
	if(CheckQspiFlashId())
		return;						//Error abortt

//Setting  SPI_Add, workRAM_Add
	spiFlashStatAdd = S25FL512_SA03_STARTAD;				//�V�X�e�����Z�N�^(SA3)�F0x00C0000�`

	workTopAdd      = WORK_SPI_LOAD_AREA;
	rdBufstatAdd    = workTopAdd + spiFlashStatAdd;			//0xXX000000 + 0x00C0000 = 0xXX0C0000

//SPI(SA3:H'00C0000-H'00FFFFF) -> DRAM(H'XX0C0000-H'XX0FFFFF)�Ƀ��[�h �i�f�[�^�ޔ��j
	if(gSelectQspiFlash ==ONBOARD_QSPI){
		SectorRdQspiFlashS25s128s(spiFlashStatAdd,rdBufstatAdd);
	}else if(gSelectQspiFlash ==QSPI_BOARD){
		SectorRdQspiFlashS25fl512s(spiFlashStatAdd,rdBufstatAdd);
	}else if(gSelectQspiFlash ==HYPER_FLASH){
		SectorRdHyperFlash(spiFlashStatAdd,rdBufstatAdd);
	}else if(gSelectQspiFlash ==ONBOARD_QSPI_512M){
		SectorRdQspiFlashS25s512s(spiFlashStatAdd,rdBufstatAdd);
	}
//Read Program Start Address
	readAdd  = workTopAdd + SPIBOOT_UPRG_ST_AD;
	prgStAdd = *(uint32_t *)readAdd;
//Read Program Size
	readAdd  = workTopAdd + SPIBOOT_UPRG_SIZE;
	prgSize = *(uint32_t *)readAdd;

//Address �\��
	Data2HexAscii(prgStAdd,str,4);
	PutStr(" Program Start Address : H'",0);		PutStr(str,1);
//data size �\��
	Data2HexAscii(prgSize,str,4);
	PutStr(" Program Size (Byte/4) : H'",0);		PutStr(str,1);
	PutStr("==================================================",1);

#endif
}



/****************************************************************
	MODULE				: dgGen3InfoSetSpiflash0	(S25fl512s)	*
	FUNCTION			: set SA3 spi Spiflash memory			*
	COMMAND				: XINFO_S								*
	INPUT PARAMETER		: XINFO_S			 					*
*****************************************************************/
void dgGen3InfoSetSpiflash0(void)
{
#ifdef COM_SPI_ON

	char str[64];
	uint32_t change;
	uint32_t spiFlashStatAdd,workTopAdd,rdBufstatAdd,readAdd;
	uint32_t readManuId,readDevId;

	change = CHANGE_OFF;

	PutStr("=== SPI SA3 System Area Information  ===",1);
	SelQspiFlashSetSw();
	InitRPC_Mode();
	if(CheckQspiFlashId())
		return;						//Error abortt

//Setting  SPI_Add, workRAM_Add
	spiFlashStatAdd = S25FL512_SA03_STARTAD;				//�V�X�e�����Z�N�^(SA03)�F0x00C0000�`
	workTopAdd      = WORK_SPI_LOAD_AREA;
	rdBufstatAdd    = workTopAdd + spiFlashStatAdd;			//0xXX000000 + 0x00C0000 = 0xXX0C0000

//SPI(SA0:H'00C0000-H'00FFFFF) -> DRAM(H'600C0000-H'600FFFFF)�Ƀ��[�h �i�f�[�^�ޔ��j
	if(gSelectQspiFlash ==ONBOARD_QSPI){
		SectorRdQspiFlashS25s128s(spiFlashStatAdd,rdBufstatAdd);
	}else if(gSelectQspiFlash ==QSPI_BOARD){
		SectorRdQspiFlashS25fl512s(spiFlashStatAdd,rdBufstatAdd);
	}else if(gSelectQspiFlash ==HYPER_FLASH){
		SectorRdHyperFlash(spiFlashStatAdd,rdBufstatAdd);
	}else if(gSelectQspiFlash ==ONBOARD_QSPI_512M){
		SectorRdQspiFlashS25s512s(spiFlashStatAdd,rdBufstatAdd);
	}

//Address
	readAdd  = workTopAdd + SPIBOOT_UPRG_ST_AD;
	PutStr(" Program Start Address : H'",0);
	if(CHANGE_ON==CheckDataChange(readAdd))			change=CHANGE_ON;
//Size
	readAdd  = workTopAdd + SPIBOOT_UPRG_SIZE;
	PutStr(" Program Size (Byte/4) : H'",0);
	if(CHANGE_ON==CheckDataChange(readAdd))			change=CHANGE_ON;

	if(change == CHANGE_ON){
//����  �FSPI_Flash(SA3)����
		PutStr("SPI Data Clear(H'FF):H'0C0000-0FFFFF Erasing.",0);
		if(gSelectQspiFlash ==ONBOARD_QSPI){
			SectorEraseQspiFlashS25s128s(spiFlashStatAdd,((spiFlashStatAdd+0x4)-1));
		}else if(gSelectQspiFlash ==QSPI_BOARD){
			SectorEraseQspiFlashS25fl512s(spiFlashStatAdd,((spiFlashStatAdd+0x4)-1));
		}else if(gSelectQspiFlash ==HYPER_FLASH){
			SectorEraseHyperFlashRange(spiFlashStatAdd,((spiFlashStatAdd+0x4)-1));
		}else if(gSelectQspiFlash ==ONBOARD_QSPI_512M){
			SectorEraseQspiFlashS25s512s(spiFlashStatAdd,((spiFlashStatAdd+0x4)-1));
		}

//�����݁FDRAM(H'600C0000-H'600FFFFF) -> SPI_Flash(SA3) H'00C0000-H'00FFFFF
		PutStr("SAVE SPI-FLASH.......",0);
		if(gSelectQspiFlash ==ONBOARD_QSPI){
			SaveDataWithBuffeQspiFlashS25s128s(rdBufstatAdd,spiFlashStatAdd,S25FL512_SA_SIZE);		//Manual Mode Single WriteBuffe
		}else if(gSelectQspiFlash ==QSPI_BOARD){
			SaveDataQspiFlashS25fl512s_CsCont(rdBufstatAdd,spiFlashStatAdd,S25FL512_SA_SIZE);		//Manual Mode Single (512)
		}else if(gSelectQspiFlash ==HYPER_FLASH){
			SetRPC_ClockMode(RPC_CLK_40M);															//Word Program 50MHz(max)
			SaveDataWithBuffeHyperFlash(rdBufstatAdd,spiFlashStatAdd,S25FL512_SA_SIZE);				//Manual Mode WriteBuffe
			SetRPC_ClockMode(RPC_CLK_80M);
		}else if(gSelectQspiFlash ==ONBOARD_QSPI_512M){
			SaveDataWithBuffeQspiFlashS25s512s(rdBufstatAdd,spiFlashStatAdd,S25FL512_SA_SIZE);		//Manual Mode Single WriteBuffe
		}
		PutStr(" complete!",1);
	}

#endif
}









/****************************************************************
	MODULE				: dgClearSpiflash0	(S25fl512s)			*
	FUNCTION			: Clear Spiflash memory					*
	COMMAND				: CS									*
	INPUT PARAMETER		: CS					 				*
*****************************************************************/
void dgClearSpiflash0(void)
{
#ifdef COM_SPI_ON

	char str[64];
	uint32_t	readManuId,readDevId;
	int32_t	Rtn;

	Rtn=NORMAL_END;

	PutStr("ALL ERASE SpiFlash or HyperFlash memory ",1);
	PutStr("Clear OK?(y/n)",0);
	if( WaitKeyIn_YorN() ){	// Return1=N
	    DelStr(14);
		return;
	}
	DelStr(14);
	SelQspiFlashSetSw();
	InitRPC_Mode();

	if(CheckQspiFlashId())
		return;						//Error abortt
	if(gSelectQspiFlash ==ONBOARD_QSPI){
		PutStr(" ERASE QSPI-FLASH (60sec[typ])....",0);
		Rtn=BulkEraseQspiFlashS25s128s();
	}else if(gSelectQspiFlash ==QSPI_BOARD){
		PutStr(" ERASE QSPI-FLASH (103sec[typ])....",0);
		Rtn=BulkEraseQspiFlashS25fl512s();
	}else if(gSelectQspiFlash ==HYPER_FLASH){
		PutStr(" ERASE HYPER-FLASH (96sec[typ])....",0);
		Rtn=ChipEraseHyperFlash();
	}else if(gSelectQspiFlash ==ONBOARD_QSPI_512M){
		PutStr(" ERASE QSPI-FLASH (220sec[typ])....",0);
		Rtn=BulkEraseQspiFlashS25s512s();
	}
	if(Rtn==NORMAL_END)
		PutStr(" complete!",1);
	else
		PutStr(" Fail!",1);

#endif
}








uint32_t	gSourceFlash,gDestinationFlash;


void WriteCopytoFlash(void)
{
//#ifdef COM_SPI_ON
#ifdef COM_DBG_ON	//ifdef COM_DBG_ON ��������

	char str[64];

	uint32_t	Load_workStartAdd,Load_workEndAdd;
	uint32_t	ReadSpiStartSecTopAdd,ReadSize,ReadBuffeAdd;
	uint32_t	EraseSpiStartSecTopAdd,EraseSize;
	uint32_t	WriteDataStatAdd,WriteSize,WriteSpiStatAdd;

	PutStr("=== copy Write between the Flash memory (copy size = 16MByte) ===",1);
	SelCopyFlashMemory();

//Source Memory========================================================
	PutStr("Source = ",0);
	SetFlashMemory(gSourceFlash);
	InitRPC_Mode();
	if(CheckQspiFlashId())
		return;						//Error abortt

//Load Source Flash Memory---------------------------------------------
	PutStr(" Load Flash data to RAM(H'50000000-)...",0);

//CLEAR Work RAM (Write data H'FF)
	Load_workStartAdd	= LS_WORK_DRAM_SADD;				//0x50000000
	Load_workEndAdd		= LS_WORK_DRAM_EADD_64M;			//0x53FFFFFF
	PutStr("Clear Work RAM(H'50000000-H'53FFFFFF)",0);
	FillData8Bit(Load_workStartAdd,Load_workEndAdd,0xFF);
	DelStr(37);

//Read Flash Data
	ReadSpiStartSecTopAdd = 0x0;
	ReadSize =0xFF8000;
	ReadBuffeAdd =Load_workStartAdd;

	if(gSelectQspiFlash == ONBOARD_QSPI){
		FastRd3adQspiFlashS25s128s (ReadSpiStartSecTopAdd,ReadBuffeAdd,ReadSize);
		PutStr("ok",1);
	}else if(gSelectQspiFlash == HYPER_FLASH){
		RdHyperFlash(ReadSpiStartSecTopAdd,ReadBuffeAdd,ReadSize);
		PutStr("ok",1);
	}else if(gSelectQspiFlash == QSPI_BOARD){
		QuadRdQspiFlashS25fl512s(ReadSpiStartSecTopAdd,ReadBuffeAdd,ReadSize);
		PutStr("ok",1);
	}else if(gSelectQspiFlash == ONBOARD_QSPI_512M){
		FastRdQspiFlashS25s512s (ReadSpiStartSecTopAdd,ReadBuffeAdd,ReadSize);
		PutStr("ok",1);
	}

	PutStr("",1);
//Destination Memory===================================================
	PutStr("Destination = ",0);
	SetFlashMemory(gDestinationFlash);
	InitRPC_Mode();
	if(CheckQspiFlashId())
		return;						//Error abortt

//Erase destination Flash Memory---------------------------------------
	EraseSpiStartSecTopAdd = ReadSpiStartSecTopAdd;
	EraseSize = ReadSize;

	if(gSelectQspiFlash == ONBOARD_QSPI){
		PutStr(" ParameterSectorErase...",0);
		ParameterSectorEraseQspiFlashS25s128s(0x0,0x7FFF);
		PutStr(" SectorErase...",0);
   		SectorEraseQspiFlashS25s128s(EraseSpiStartSecTopAdd,((EraseSpiStartSecTopAdd+EraseSize)-1));
	}else if(gSelectQspiFlash == HYPER_FLASH){
		PutStr(" SectorErase...",0);
		SectorEraseHyperFlashRange(EraseSpiStartSecTopAdd,((EraseSpiStartSecTopAdd+EraseSize)-1));
	}else if(gSelectQspiFlash == QSPI_BOARD){
		PutStr(" SectorErase...",0);
    	SectorEraseQspiFlashS25fl512s(EraseSpiStartSecTopAdd,((EraseSpiStartSecTopAdd+EraseSize)-1));
	}else if(gSelectQspiFlash == ONBOARD_QSPI_512M){
		PutStr(" ParameterSectorErase...",0);
		ParameterSectorEraseQspiFlashS25s512s(0x0,0x7FFF);
		PutStr(" SectorErase...",0);
   		SectorEraseQspiFlashS25s512s(EraseSpiStartSecTopAdd,((EraseSpiStartSecTopAdd+EraseSize)-1));
	}

//Write Flash Memory--------------------------------------------------
	WriteDataStatAdd  = Load_workStartAdd;
	WriteSize =ReadSize;
	WriteSpiStatAdd		= 0x0;

	PutStr(" Write Ram data to Flash Memory...",0);
	if(gSelectQspiFlash == ONBOARD_QSPI){
		SaveDataWithBuffeQspiFlashS25s128s(WriteDataStatAdd,WriteSpiStatAdd,WriteSize);		//Manual Mode Single WriteBuffe
		PutStr("ok",1);
	}else if(gSelectQspiFlash == HYPER_FLASH){
		SetRPC_ClockMode(RPC_CLK_40M);
		SaveDataWithBuffeHyperFlash(WriteDataStatAdd,WriteSpiStatAdd,WriteSize);			//Manual Mode WriteBuffe
		SetRPC_ClockMode(RPC_CLK_80M);
		PutStr("ok",1);
	}else if(gSelectQspiFlash == QSPI_BOARD){
		SaveDataWithBuffeQspiFlashS25fl512s(WriteDataStatAdd,WriteSpiStatAdd,WriteSize);	//Manual Mode Single WriteBuffe ��) Size <0x1000000 �̏ꍇ�̂�
		PutStr("ok",1);
	}else if(gSelectQspiFlash == ONBOARD_QSPI_512M){
		SaveDataWithBuffeQspiFlashS25s512s(WriteDataStatAdd,WriteSpiStatAdd,WriteSize);		//Manual Mode Single WriteBuffe
		PutStr("ok",1);
	}

#endif
}


#ifdef COM_SPI_ON				//ifdef COM_SPI_ON ��������

void SelCopyFlashMemory(void)
{
	switch(ChkBoardCode()){
		case BD_SALVATOR_X:
		case BD_SALVATOR_XS:
			PutStr("Salvator",1);		SelCopyFlashMemory_Salvator();
			break;
		case BD_KRIEK_LP4:
		case BD_KRIEK_DDR3:
			PutStr("Kriek",1);			SelCopyFlashMemory_Salvator();
			break;
		case BD_STARTERKIT_PRO:
		case BD_STARTERKIT_PRE:
			PutStr("Starter Kit",1);	SelCopyFlashMemory_Salvator();
			break;
		case BD_EAGLE:
			PutStr("Eagle",1);			SelCopyFlashMemory_Eagle();
			break;
		case BD_DRAAK:
			PutStr("Draak",1);			SelCopyFlashMemory_Salvator();
			break;
		case BD_CONDOR:
			PutStr("Condor",1);			SelCopyFlashMemory_Eagle();
			break;
		case BD_EBISU:
			PutStr("Ebisu",1);			SelCopyFlashMemory_Salvator();
			break;
		default:
			PutStr("not supported",1);
			break;
	}
}

void SelCopyFlashMemory_Salvator(void)		// Salvator / Kriek / StarterKit
{
	char str[64];
	char		chCnt;
	uint32_t	loop;

	gSelectQspiFlash =0;

	PutStr("Please select.",1);
	PutStr("        From         --->    To",1);
	PutStr(" 1 : QSpiFlash       ---> HyperFlash",1);
	PutStr(" 2 : QSpiFlash       ---> QspiFlash Board",1);
	PutStr(" 3 : HyperFlash      ---> QSpiFlash",1);
	PutStr(" 4 : HyperFlash      ---> QspiFlash Board",1);
	PutStr(" 5 : QspiFlash Board ---> QSpiFlash",1);
	PutStr(" 6 : QspiFlash Board ---> HyperFlash",1);

	loop=1;
	while(loop){
		PutStr("  Select (1-6)>",0);
		GetStr(str,&chCnt);
		  switch(str[0]){
			case '1':	gSourceFlash= ONBOARD_QSPI;	gDestinationFlash= HYPER_FLASH;		loop=0;	break;
			case '2':	gSourceFlash= ONBOARD_QSPI;	gDestinationFlash= QSPI_BOARD;		loop=0;	break;
			case '3':	gSourceFlash= HYPER_FLASH;	gDestinationFlash= ONBOARD_QSPI;	loop=0;	break;
			case '4':	gSourceFlash= HYPER_FLASH;	gDestinationFlash= QSPI_BOARD;		loop=0;	break;
			case '5':	gSourceFlash= QSPI_BOARD;	gDestinationFlash= ONBOARD_QSPI;	loop=0;	break;
			case '6':	gSourceFlash= QSPI_BOARD;	gDestinationFlash= HYPER_FLASH;		loop=0;	break;
		  }
	}
}

void SelCopyFlashMemory_Eagle(void)
{
	char str[64];
	char		chCnt;
	uint32_t	loop;

	gSelectQspiFlash =0;

	PutStr("Please select.",1);
	PutStr("        From            --->    To",1);
	PutStr(" 1 : QSpiFlash(128Mbit) ---> QSpiFlash(512Mbit)",1);
	PutStr(" 2 : QSpiFlash(128Mbit) ---> QspiFlash Board   ",1);
	PutStr(" 3 : QSpiFlash(512Mbit) ---> QSpiFlash(128Mbit)",1);
	PutStr(" 4 : QSpiFlash(512Mbit) ---> QspiFlash Board   ",1);
	PutStr(" 5 : QspiFlash Board    ---> QSpiFlash(128Mbit)",1);
	PutStr(" 6 : QspiFlash Board    ---> QSpiFlash(512Mbit)",1);

	loop=1;
	while(loop){
		PutStr("  Select (1-6)>",0);
		GetStr(str,&chCnt);
		  switch(str[0]){
			case '1':	gSourceFlash= ONBOARD_QSPI;		gDestinationFlash= ONBOARD_QSPI_512M;	loop=0;	break;
			case '2':	gSourceFlash= ONBOARD_QSPI;		gDestinationFlash= QSPI_BOARD;			loop=0;	break;
			case '3':	gSourceFlash= ONBOARD_QSPI_512M;gDestinationFlash= ONBOARD_QSPI;		loop=0;	break;
			case '4':	gSourceFlash= ONBOARD_QSPI_512M;gDestinationFlash= QSPI_BOARD;			loop=0;	break;
			case '5':	gSourceFlash= QSPI_BOARD;		gDestinationFlash= ONBOARD_QSPI;		loop=0;	break;
			case '6':	gSourceFlash= QSPI_BOARD;		gDestinationFlash= ONBOARD_QSPI_512M;	loop=0;	break;
		  }
	}
}



void SetFlashMemory(uint32_t selectFlash)
{
	switch(selectFlash){
		case ONBOARD_QSPI:
			PutStr("QSpiFlash",1);
			gSelectQspiFlash = ONBOARD_QSPI;
	  		gSpiFamilyId     = FS_S_FAMILY;
	  		gSpiDevId        = DEVID_S25FS128S;
			SwChgOnBoard_QSPI0[ChkBoardCode()].program();
			break;
		case HYPER_FLASH:
			PutStr("HyperFlash",1);
			gSelectQspiFlash = HYPER_FLASH;
	  		gSpiDevId        = DEVID_S26KS512S;
			SwChgHyperFlash[ChkBoardCode()].program();
			break;
		case QSPI_BOARD:
			PutStr("QspiFlash Board",1);
			gSelectQspiFlash = QSPI_BOARD;
	  		gSpiFamilyId     = FL_S_FAMILY;
	  		gSpiDevId        = DEVID_S25FL512S;
			SwChgExSPI_QSPI0[ChkBoardCode()].program();
			break;
		case ONBOARD_QSPI_512M:
			PutStr("QSpiFlash(512Mbit)",1);
			gSelectQspiFlash = ONBOARD_QSPI_512M;
	  		gSpiFamilyId     = FS_S_FAMILY;
	  		gSpiDevId        = DEVID_S25FS512S;
			SwChgOnBoard_QSPI0_512M[ChkBoardCode()].program();
			break;
	}
}

#endif				//ifdef COM_SPI_ON �����܂�











void ExtModeOn(void)
{
#ifdef COM_SPI_ON

	char str[64];

	PutStr("== Set Ext Read Mode (Read Only)    ==",1);
	PutStr("== For Onboard / QspiFlash (H'00-  )==",1);
	PutStr("== H'0800_0000-H'0BFF_FFFF          ==",1);
	PutStr("",1);
	SelQspiFlashSetSw();
	InitRPC_Mode();
	if(CheckQspiFlashId())
		return;						//Error abortt

	if(gSelectQspiFlash ==ONBOARD_QSPI){
//		InitRPC_QspiFlash4FastReadExtMode();			//  (4FAST_READ 0Ch) 4-byte address
		InitRPC_QspiFlashFastReadExtMode();				//  (FAST_READ 0Bh)  3-byte address
	}else if(gSelectQspiFlash ==QSPI_BOARD){
//		InitRPC_QspiFlashQuadExtMode();					//  (4QOR 6Ch)
		InitRPC_QspiFlash4FastReadExtMode();			//  (4FAST_READ 0Ch)
	}else if(gSelectQspiFlash ==HYPER_FLASH){
		InitRPC_HyperFlashExtMode();					//   o
	}
	if(gSelectQspiFlash ==ONBOARD_QSPI_512M){
		InitRPC_QspiFlash4FastReadExtMode();			//  (4FAST_READ 0Ch) 4-byte address
//		InitRPC_QspiFlashFastReadExtMode();				//  (FAST_READ 0Bh)  3-byte address
	}
	PutStr("Set Ext Read Mode.",1);

#endif

}










//-----------------------------------------------------------------------------
//�f�o�b�O�p�R�}���h-----------------------------------------------------------
//-----------------------------------------------------------------------------
#ifdef COM_DBG_ON	//ifdef COM_DBG_ON ��������

#endif				//ifdef COM_DBG_ON �����܂�









// ����J
//===============================================================
//  NEW COMMAND (MaskROM Appendix)
//===============================================================
/****************************************************************
	MODULE				: dgGen3InfoSpiflash0_SA0_S2(S25fl512s)	*
	FUNCTION			: read SA0 spi Spiflash memory			*
	COMMAND				: XINFO_SA0_2							*
	INPUT PARAMETER		: XINFO_SA0_2		 					*
*****************************************************************/
void dgGen3InfoSpiflash0_SA0_Ver2(void)
{
#ifdef COM_SPI_ON

	char str[64];
	uint32_t bootRomPara;
	uint32_t prgStAdd,prgSize;
	uint32_t prgStAdd_B,prgSize_B;
	uint32_t readManuId,readDevId;
	uint32_t spiFlashStatAdd,workTopAdd,rdBufstatAdd;
	uintptr_t readAdd;

	ChangeLBSC_Area0();
	InitLBSC();

	PutStr("=== SPI SA0 System Area Information ( MaskROM program design Appendix ) ===",1);
	SelQspiFlashSetSw();
	InitRPC_Mode();
	if(CheckQspiFlashId())
		return;						//Error abortt

//Setting  SPI_Add, workRAM_Add
	spiFlashStatAdd = S25FL512_SA00_STARTAD;				//�V�X�e�����Z�N�^(SA0)�F0x0000000�`

	workTopAdd      = WORK_SPI_LOAD_AREA;
	rdBufstatAdd    = workTopAdd + spiFlashStatAdd;			//0xXX000000 + 0x0000000 = 0xXX000000

//SPI(SA0:H'0000000-H'003FFFF) -> RAM(H'XX000000-H'XX03FFFF)�Ƀ��[�h �i�f�[�^�ޔ��j
	if(gSelectQspiFlash ==ONBOARD_QSPI){
		SectorRdQspiFlashS25s128s(spiFlashStatAdd,rdBufstatAdd);
	}else if(gSelectQspiFlash ==QSPI_BOARD){
		SectorRdQspiFlashS25fl512s(spiFlashStatAdd,rdBufstatAdd);
	}else if(gSelectQspiFlash ==HYPER_FLASH){
		SectorRdHyperFlash(spiFlashStatAdd,rdBufstatAdd);
	}

	readAdd  = workTopAdd + SPIBOOT_BTROM_PARA;				bootRomPara = *(uint32_t *)readAdd;	//Read Boot ROM Parameters
	readAdd  = workTopAdd + SPIBOOT_FLASH_CLOCK_PARA;		prgStAdd = *(uint32_t *)readAdd;	//Read Flash Clock Parameters
	readAdd  = workTopAdd + SPIBOOT_DUMMY_CYCLE_PARA;		prgSize = *(uint32_t *)readAdd;		//Read Dummy Cycle Parameters

	Data2HexAscii(bootRomPara,str,4);	PutStr(" Boot ROM Parameters    : H'",0);	PutStr(str,1);	//Now Boot ROM Parameters �\��
	Data2HexAscii(prgStAdd,str,4);		PutStr(" Flash Clock Parameters : H'",0);	PutStr(str,1);	//Now Flash Clock Parameters �\��
	Data2HexAscii(prgSize,str,4);		PutStr(" Dummy Cycle Parameters : H'",0);	PutStr(str,1);	//Now Dummy Cycle Parameters �\��

	PutStr("==================================================",1);

#endif
}

/****************************************************************
	MODULE				: dgGen3InfoSpiflash0_SA0	(S25fl512s)	*
	FUNCTION			: set SA0 spi Spiflash memory			*
	COMMAND				: XINFO_SA0_S2							*
	INPUT PARAMETER		: XINFO_SA0_S2		 					*
*****************************************************************/
//����:OnBoardSpi�̂ݏ��������T�C�Y�قȂ�B
void dgGen3InfoSetSpiflash0_SA0_Ver2(void)
{
#ifdef COM_SPI_ON

	char str[64];
	uint32_t change;
	uint32_t spiFlashStatAdd,workTopAdd,rdBufstatAdd;
	uintptr_t readAdd;
	uint32_t readManuId,readDevId;
	uint32_t OnBoardSpiSysSize;

	change = CHANGE_OFF;

	ChangeLBSC_Area0();
	InitLBSC();

	PutStr("=== SPI SA0 System Area Information ( MaskROM program design Appendix ) ===",1);
	SelQspiFlashSetSw();
	InitRPC_Mode();
	if(CheckQspiFlashId())
		return;						//Error abortt

//Setting  SPI_Add, workRAM_Add
	spiFlashStatAdd = S25FL512_SA00_STARTAD;				//�V�X�e�����Z�N�^(SA0) �F0x0000000�`

	workTopAdd      = WORK_SPI_LOAD_AREA;
	rdBufstatAdd    = workTopAdd + spiFlashStatAdd;			//0xXX000000 + 0x0000000 = 0xXX000000
//	OnBoardSpiSysSize    = 0x2000;							//OnBoardSpi�̂� SA0=�p�����[�^�G���A�Ȃ̂ŏ����T�C�Y4K�i�ΏۃG���A�̂ݏ��������Ƃ���j
	OnBoardSpiSysSize    = 0x8000;							//V3H�Ή� 32KB�Ƃ���

//SPI(SA0:H'0000000-H'003FFFF) -> RAM(H'XX000000-H'XX03FFFF)�Ƀ��[�h �i�f�[�^�ޔ��j
	if(gSelectQspiFlash ==ONBOARD_QSPI){
		FastRd3adQspiFlashS25s128s(spiFlashStatAdd,rdBufstatAdd,OnBoardSpiSysSize);		//�V�X�e���Ŏg�p���Ă���ŏ����̂݃��[�h
	}else if(gSelectQspiFlash ==QSPI_BOARD){
		SectorRdQspiFlashS25fl512s(spiFlashStatAdd,rdBufstatAdd);
	}else if(gSelectQspiFlash ==HYPER_FLASH){
		SectorRdHyperFlash(spiFlashStatAdd,rdBufstatAdd);
	}

	readAdd  = workTopAdd + SPIBOOT_BTROM_PARA;				PutStr(" Boot ROM Parameters    : H'",0);	if(CHANGE_ON==CheckDataChange(readAdd))	change=CHANGE_ON;//Boot ROM Parameters
	readAdd  = workTopAdd + SPIBOOT_FLASH_CLOCK_PARA;		PutStr(" Flash Clock Parameters : H'",0);	if(CHANGE_ON==CheckDataChange(readAdd))	change=CHANGE_ON;//Read Flash Clock Parameters
	readAdd  = workTopAdd + SPIBOOT_DUMMY_CYCLE_PARA;		PutStr(" Dummy Cycle Parameters : H'",0);	if(CHANGE_ON==CheckDataChange(readAdd))	change=CHANGE_ON;//Read Dummy Cycle Parameters

	if(change == CHANGE_ON){
//����  �FSPI_Flash(SA0)����
//		PutStr("SPI Data Clear(H'FF):H'000000-03FFFF Erasing.",0);
		if(gSelectQspiFlash ==ONBOARD_QSPI){
//			SectorEraseQspiFlashS25s128s(spiFlashStatAdd,((spiFlashStatAdd+0x4)-1));	//�擪�A�㔼32KByte�͏����s��
//			PutStr("SPI Data Clear(H'FF):H'000000-001FFF Erasing.",0);
			PutStr("SPI Data Clear(H'FF):H'000000-007FFF Erasing.",0);
			ParameterSectorEraseQspiFlashS25s128s(spiFlashStatAdd,((OnBoardSpiSysSize)-1));
		}else if(gSelectQspiFlash ==QSPI_BOARD){
			PutStr("SPI Data Clear(H'FF):H'000000-03FFFF Erasing.",0);
			SectorEraseQspiFlashS25fl512s(spiFlashStatAdd,((spiFlashStatAdd+0x4)-1));
		}else if(gSelectQspiFlash ==HYPER_FLASH){
			PutStr("SPI Data Clear(H'FF):H'000000-03FFFF Erasing.",0);
			SectorEraseHyperFlashRange(spiFlashStatAdd,((spiFlashStatAdd+0x4)-1));
		}
//		SoftDelay(4000);			//Add 2015.07.21
		ResetHyperFlash();			// ���[�h���[�h�ɖ߂�		Add 2015.07.21
//�����݁FWorkRAM -> SPI_Flash(SA0) H'0000000-H'003FFFF
		PutStr("SAVE SPI-FLASH.......",0);
		if(gSelectQspiFlash ==ONBOARD_QSPI){
			SaveDataWithBuffeQspiFlashS25s128s(rdBufstatAdd,spiFlashStatAdd,OnBoardSpiSysSize);		//Manual Mode Single WriteBuffe //o
		}else if(gSelectQspiFlash ==QSPI_BOARD){
			SaveDataQspiFlashS25fl512s_CsCont(rdBufstatAdd,spiFlashStatAdd,S25FL512_SA_SIZE);		//Manual Mode Single (512)
		}else if(gSelectQspiFlash ==HYPER_FLASH){
			SetRPC_ClockMode(RPC_CLK_40M);															//Word Program 50MHz(max)
			SaveDataWithBuffeHyperFlash(rdBufstatAdd,spiFlashStatAdd,S25FL512_SA_SIZE);				//Manual Mode WriteBuffe	//o
			SetRPC_ClockMode(RPC_CLK_80M);
		}
		PutStr(" complete!",1);
	}
#endif
}

