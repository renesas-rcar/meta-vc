#include	"common.h"
#include	"dgtable.h"
#include	"dgmodul1.h"
#include	"dgmodul2.h"
#include	"devdrv.h"
#include	"devdrv.h"
#include	"bit.h"
#include	"flashdrv.h"
#include	"cpudrv.h"

#include	"switch.h"

#include "reg_rcargen3.h"
#include "boardid.h"
#include "init_board.h"
#include "dgloadmodul.h"
#include "init_scif.h"


extern const char *const AllHelpMess[ALL_HELP_MESS_LINE];
extern const com_menu MonCom[COMMAND_UNIT];
extern int32_t  gComNo;
extern char gKeyBuf[64];
extern uintptr_t gUDump[3];
extern uintptr_t gUMem[3];
extern uint32_t gUreg[17];
extern uint32_t gDumpMode;
extern uint32_t gDumpStatus;


extern const prg_tbl SwChgLbscArea[BOARD_COUNT];


uint32_t gFLASH_CS1_ID;
uint32_t gGoAddress;


/****************************************************************
	MODULE				: dgHelp								*
	FUNCTION			: HELP	MESSAGE							*
	COMMAND				: H										*
	INPUT PARAMETER		: H										*
*****************************************************************/
void	dgHelp(void)
{
#ifdef	COM_H_ON

	char tmp[64],chPtr,helpNo;

	chPtr=0;
	if(!GetStrBlk(gKeyBuf,tmp,&chPtr,0)){
		PutMess(AllHelpMess);
	}

#endif
}

/****************************************************************
	MODULE				: dgDump 								*
	FUNCTION			: Memory Dump							*
	COMMAND				: D										*
	INPUT PARAMETER		: D  {sadr {eadr}}  					*
*****************************************************************/
void	dgDump(void)
{
#ifdef	COM_D_ON

	uintptr_t dmp1st,dmp2nd;
	char decRtn;

	gDumpStatus = ENABLE;

	/* Init Dump Parameter */
	dmp1st = gUDump[0];						/* Start Address */
	dmp2nd = gUDump[1];						/* End   Address */
	decRtn = DecodeForm01(&dmp1st,&dmp2nd);	/*̫�ϯ�����*/

	/* dmp1st: Start Address */
	/* dmp2nd: dumpSize      */
	switch(gDumpMode){
		case SIZE_16BIT:
			if(dmp1st&0x00000001){
				PutStr("Memory Boundary Error",1);
				return;
			}
			break;
		case SIZE_32BIT:
			if(dmp1st&0x00000003){
				PutStr("Memory Boundary Error",1);
				return;
			}
			break;
		case SIZE_64BIT:
			if(dmp1st&0x00000007){
				PutStr("Memory Boundary Error",1);
				return;
			}
			break;
	}
	if(decRtn == 1)		PutStr("Syntax Error",1);
	if(decRtn == 2)		PutStr("Address Size Error",1);
	if(decRtn == 0){
		DisplayDump(dmp1st,dmp2nd,gDumpMode);
		dmp2nd=dmp2nd|0x0000000F;			/* �X�^�[�g�s����               */
		gUDump[0] = dmp1st+dmp2nd+1;		/* Start Address                */
		gUDump[1] = 255;					/* Dump Size (Byte) �����l�ɖ߂�*/
	}

#endif
}
/****************************************************************
	MODULE				: dgDumpMode							*
	FUNCTION			: set&disp dump mode					*
	COMMAND				: DM									*
	INPUT PARAMETER		: DM {B|W|L}  							*
*****************************************************************/
void	dgDumpMode(void)
{
#ifdef	COM_D_ON

	uint32_t setPara;
	char tmp[64],chPtr;
	char endCh;

	chPtr=0;
	setPara = gDumpMode;

	/*DM         (Display DumpMode) */
	endCh=GetStrBlk(gKeyBuf,tmp,&chPtr,0);
	if(endCh==0){							//DM�ȊO���͂���Ȃ������ꍇ
		PutStr("DMmode = ",0);
		switch(gDumpMode){
			case SIZE_8BIT:		PutStr("byte",1);		break;
			case SIZE_16BIT:	PutStr("word",1);		break;
			case SIZE_32BIT:	PutStr("long",1);		break;
			case SIZE_64BIT:	PutStr("long long",1);	break;
		}
	}
	/*DM <size> (Set DumpMode Size)*/
	else {
		/*********** Ana 2nd parameter  check ****************/
		GetStrBlk(gKeyBuf,tmp,&chPtr,0);
		if(CheckAccessSize(tmp,&setPara))
			PutStr("Syntax Error",1);
		gDumpMode=setPara;
	}

#endif
}

char	CheckAccessSize(char *buf,uint32_t *sizeId)
{
#ifdef	COM_D_ON

	ChgLtl2Lrg(buf);
	if((*buf=='B')&&(*(buf+1)==0))
		*sizeId = SIZE_8BIT;
	else if((*buf=='W')&&(*(buf+1)==0))		*sizeId = SIZE_16BIT;
	else if((*buf=='L')&&(*(buf+1)==0))		*sizeId = SIZE_32BIT;
#ifdef AArch64
	else if((*buf=='X')&&(*(buf+1)==0))		*sizeId = SIZE_64BIT;
#endif
	else
		return(1);
	return(0);

#endif
}

/****************************************************************
	MODULE				: dgMemEdit_byte						*
	FUNCTION			: set memory(BYTE)						*
	COMMAND				: M										*
	INPUT PARAMETER		: M  [adr]  							*
*****************************************************************/
void	dgMemEdit_byte(void)
{
	dgMemEdit(SIZE_8BIT);
}

/****************************************************************
	MODULE				: dgMemEdit_word						*
	FUNCTION			: set memory(WORD)						*
	COMMAND				: MW									*
	INPUT PARAMETER		: MW  [adr]  							*
*****************************************************************/
void	dgMemEdit_word(void)
{
	dgMemEdit(SIZE_16BIT);
}

/****************************************************************
	MODULE				: dgMemEdit_long						*
	FUNCTION			: set memory(LONG)						*
	COMMAND				: ML									*
	INPUT PARAMETER		: ML  [adr]  							*
*****************************************************************/
void	dgMemEdit_long(void)
{
	dgMemEdit(SIZE_32BIT);
}

/****************************************************************
	MODULE				: dgMemEdit_long_long					*
	FUNCTION			: set memory(LONG LONG)					*
	COMMAND				: MX									*
	INPUT PARAMETER		: MX  [adr]  							*
*****************************************************************/
void	dgMemEdit_longlong(void)
{
	dgMemEdit(SIZE_64BIT);
}

void	dgMemEdit(uint32_t width)
{
#ifdef COM_M_ON

	uint32_t  verifyFlg;
	uintptr_t mem1st;
	char decRtn;

//	verifyFlg = VERIFY_ON;
	verifyFlg = VERIFY_OFF;

	mem1st = gUMem[0];					/* Start Address */
	decRtn = DecodeForm02(&mem1st);

	if(decRtn == 1)
		PutStr("Syntax Error",1);
	else if(decRtn == 0){
		switch(width){
			case SIZE_16BIT:
				if(mem1st&0x00000001){
					PutStr("Memory Boundary Error",1);
					return;
				}
				break;
			case SIZE_32BIT:
				if(mem1st&0x00000003){
					PutStr("Memory Boundary Error",1);
					return;
				}
				break;
			case SIZE_64BIT:
				if(mem1st&0x00000007){
					PutStr("Memory Boundary Error",1);
					return;
				}
				break;
		}
		DisplayMemEd(mem1st,width,verifyFlg);
		gUMem[0] = gUMem[0]+width;	/* Start Address */
	}

#endif
}

/****************************************************************
	MODULE				: dgFill_byte							*
	FUNCTION			: fill memory (Byte)					*
	COMMAND				: F										*
	INPUT PARAMETER		: F  [sadr] [eadr] [data]  				*
*****************************************************************/
void	dgFill_byte(void)
{
	dgFill(SIZE_8BIT);
}
/****************************************************************
	MODULE				: dgFill_long							*
	FUNCTION			: fill memory (LONG)					*
	COMMAND				: FL									*
	INPUT PARAMETER		: FL  [sadr] [eadr] [data]  			*
*****************************************************************/
void	dgFill_long(void)
{
	dgFill(SIZE_32BIT);
}
/****************************************************************
	MODULE				: dgFill_longlong						*
	FUNCTION			: fill memory (LONG LONG)				*
	COMMAND				: FX									*
	INPUT PARAMETER		: FX  [sadr] [eadr] [data]  			*
*****************************************************************/
void	dgFill_longlong(void)
{
	dgFill(SIZE_64BIT);
}

/****************************************************************
	FUNCTION			: fill memory							*
*****************************************************************/
void	dgFill(uint32_t width)
{
#ifdef COM_F_ON

	uintptr_t fill1st,fill2nd,fill3rd,wrAdd;
	uint32_t  setPara;
	char decRtn;

/* fill1st: Start Address */
/* fill2nd: FillSize      */
/* fill3rd: FillData      */

	decRtn = DecodeForm03(&fill1st,&fill2nd,&fill3rd,&setPara);
	if(!(setPara==0x03)){
		if(decRtn == 1)
			PutStr("Syntax Error",1);
		else if(decRtn == 2)
			PutStr("Address Size Error",1);
		else
			PutStr("Syntax Error",1);
	}
	else{
		if (width==SIZE_32BIT) {
			if(fill1st&0x00000003){
				PutStr("Memory Boundary Error",1);
				return;
			}
		}
		if (width==SIZE_64BIT) {
			if(fill1st&0x00000007){
				PutStr("Memory Boundary Error",1);
				return;
			}
		}
		for(wrAdd=fill1st;wrAdd<=(fill1st+fill2nd);wrAdd+=width)
			Put1ByteMem(wrAdd,fill3rd,width);
	}

#endif
}

/****************************************************************
	MODULE				: dgMoveMemory							*
	FUNCTION			: move memory							*
	COMMAND				: MV									*
	INPUT PARAMETER		: MV [sadr] [dadr] [len]				*
*****************************************************************/
void	dgMoveMemory(void)
{
#ifdef COM_MV_ON

	uintptr_t	mv1st,mv2nd,mv3rd,wrAdd;
	uint32_t	setPara,width;
	uintptr_t	readAdd,readData,DestAddChk;
	char		decRtn;
	int32_t		Rtn;
	uintptr_t	wrData;		//Verify�p

	gFLASH_CS1_ID=0;

/* mv1st: sadr */
/* mv2nd: dadr */
/* mv3rd: len  */

	width = SIZE_8BIT;
	decRtn = DecodeForm04(&mv1st,&mv2nd,&mv3rd,&setPara);
	DestAddChk = mv2nd;								//2014.05.26

	if(!(setPara==0x03)){			// ERROR
		PutStr("Syntax Error",1);
	}
	else{
		//check the destination address
		if (DestAddChk < 0x04000000){
			PutStr("invalid address",1);
			return;					// ERROR
		}
		else if ((0x04000000 <= DestAddChk) && (DestAddChk < 0x08000000)){
			Rtn = FlashDetect();	//CS1 Check  (SET "gFLASH_CS1_ID")
			if(Rtn!=0)
				return;				// ERROR
			else{
			//�T�C�Y�F���[�h�P�ʂ̃R�s�[
				switch(gFLASH_CS1_ID){
					case S29GL_X16_OnBoard:
						SectorErase_Spn_X16( mv2nd , ((mv2nd+mv3rd)-1) );		// SectorErase_Spn_X16(EraseStatAdd,EraseEndadd)
						Program_Spn_X16( mv2nd , ((mv2nd+mv3rd)-1) , mv1st);	// Program_Spn_X16    (PrgStatAdd  ,PrgEndadd ,CopyAdd)

					break;
					case S29GL_X8_FlashBoard:
						SectorErase_Spn_X8( mv2nd , ((mv2nd+mv3rd)-1) );		// SectorErase_Spn_X8(EraseStatAdd,EraseEndadd)
						Program_Spn_X8( mv2nd , ((mv2nd+mv3rd)-1) , mv1st);		// Program_Spn_X8    (PrgStatAdd  ,PrgEndadd  ,CopyAdd)
					break;
				}
			}
		}
		//CS1(FLASH�ȊO)�̃������ɃR�s�[
		else{	// 0x08000000 <= DestAdd
			//�T�C�Y�F�o�C�g�P�ʂ̃R�s�[
			for(readAdd=mv1st,wrAdd=mv2nd ; readAdd<= ((mv1st +mv3rd)-1) ; wrAdd+=width,readAdd+=width){
				Get1ByteMem(readAdd,&readData,width);
				Put1ByteMem(wrAdd,readData,width);
			}
		}
		PutStr("Verify...",0);
		for(readAdd=mv1st,wrAdd=mv2nd ; readAdd<= ((mv1st +mv3rd)-1) ; wrAdd+=width,readAdd+=width){
			Get1ByteMem(readAdd,&readData,width);
			Get1ByteMem(wrAdd,&wrData,width);

			if(wrData!=readData){
				PutStr(" Error",1);
				return;			// ERROR
			}
		}
		PutStr(" OK",1);
	}

#endif
}


/****************************************************************
	MODULE				: dgLoadFlash							*
	FUNCTION			: load Program to Flash memory			*
	COMMAND				: LF									*
	INPUT PARAMETER		: LF				 					*
*****************************************************************/
void dgLoadFlashGo(void)
{
#ifdef COM_LFCF_ON

	if( (CHK_SALVATOR) || (CHK_KRIEK)  ){
//		if(RamCheckTest(DramArea3_SADD,DramArea3_EADD))	{		//�Ȉ�R/W�`�F�b�N
		if(RamCheckTest1(DramArea3_SADD))	{					//�Ȉ�R/W�`�F�b�N 4MB�̂�
			return;
		}
		LoadFlashGo();
	}
	else{
		PutStr("=== not supported command ===",1);
	}

#endif
}

void LoadFlashGo(void)
{
#ifdef COM_LFCF_ON

	int32_t	Rtn;
	gFLASH_CS1_ID=0;

	PutStr("Load Program to Flash memory",1);
	ChangeLBSC_Area0();
	InitLBSC();
	SwChgLbscArea[ChkBoardCode()].program();
//Switch & FlashBoard Check
	Rtn = FlashDetect();	// CS1 Check  (SET "gFLASH_CS1_ID")
	if(Rtn!=0){
		ChangeLBSC_Spi();
		return;				// error
	}

	dgLoadFlash();
	ChangeLBSC_Spi();

#endif
}


void	Lf_Program_Flash(uint32_t PrgStatAdd,uint32_t PrgEndadd,uint32_t CopyAdd)
{
#ifdef COM_LFCF_ON

	int32_t	Rtn;

	gFLASH_CS1_ID=0;

	Rtn = FlashDetect();	// CS1 Check  (SET "gFLASH_CS1_ID")
	if(Rtn!=0)
		return;				// error
	else{
		switch(gFLASH_CS1_ID){
		case S29GL_X16_OnBoard:
			PutStr("Flash Memory Erase Start",1);
			SectorErase_Spn_X16(PrgStatAdd,PrgEndadd);
			PutStr("FLASH Memory (area 1) Program",1);
			Program_Spn_X16(PrgStatAdd,PrgEndadd,CopyAdd);
			break;
		case S29GL_X8_FlashBoard:
			PutStr("Flash Memory Erase Start",1);
			SectorErase_Spn_X8(PrgStatAdd,PrgEndadd);
			PutStr("FLASH Memory (area 1) Program",1);
			Program_Spn_X8(PrgStatAdd,PrgEndadd,CopyAdd);
			break;
		}
	}

#endif
}

/****************************************************************
	MODULE				: dgGo									*
	FUNCTION			: go program							*
	COMMAND				: G										*
	INPUT PARAMETER		: G  {start_adr}	 					*
*****************************************************************/
uintptr_t goAdd;

#ifdef AArch64
void dgGo(void)
{
#ifdef COM_LG_ON

	if(dgGo_addr()!=ERROR_END){
		GO_COM(setGoAddr(gGoAddress));
	}

#endif
}
#endif

#ifdef AArch32
void	dgGo(void)
{
#ifdef COM_LG_ON

	char decRtn;

	decRtn = DecodeForm02_1(&goAdd);
	if(decRtn == 1)
		PutStr("Syntax Error",1);
	else if(decRtn == 2){			//G return
		PutStr("Syntax Error",1);
	}
	else if(decRtn == 0){
		if(goAdd&0x00000003){
			PutStr("Memory Boundary Error",1);
			return;
		}
		else
			gUreg[ARM_R15(PC)] =  goAdd;
			GO_COM();
	}

#endif
}
#endif


uint32_t dgGo_addr(void)
{
#ifdef COM_LG_ON

	char decRtn;

	decRtn = DecodeForm02_1(&goAdd);
	if(decRtn == 1)
		PutStr("Syntax Error",1);
	else if(decRtn == 2){			//G return
		PutStr("Syntax Error",1);
	}
	else if(decRtn == 0){
		if(goAdd&0x00000003){
			PutStr("Memory Boundary Error",1);
		}
		else{
			gGoAddress = goAdd;
			return(NORMAL_END);
		}
	}
	return(ERROR_END);

#endif
}

uint32_t setGoAddr(uint32_t goAdd)
{
#ifdef COM_LG_ON

	char str[64];
		Data2HexAscii(goAdd,str,4);
		PutStr(" jump to 0x",0);
		PutStr(str,1);
		WaitPutCharSendEnd();
		return(goAdd);

#endif
}

/****************************************************************
	MODULE				: dgClear_Flash							*
	FUNCTION			: Clear Flash memory					*
	COMMAND				: CF									*
	INPUT PARAMETER		: CF					 				*
*****************************************************************/
void	dgClear_FlashGo(void)
{
#ifdef COM_LFCF_ON

	if( (CHK_SALVATOR) || (CHK_KRIEK)  ){
		Clear_FlashGo();
	}
	else{
		PutStr("=== not supported command ===",1);
	}	

#endif
}
void	Clear_FlashGo(void)
{
#ifdef COM_LFCF_ON

	PutStr("Clear of Flash memory",1);
	PutStr("OK?(y/n)",0);
	if( WaitKeyIn_YorN() ){	// Return1=N
	    DelStr(8);
		return;
	}
    DelStr(8);

	ChangeLBSC_Area0();
	InitLBSC();
	SwChgLbscArea[ChkBoardCode()].program();
	dgClear_Flash();
	ChangeLBSC_Spi();

#endif
}

void	dgClear_Flash(void)
{
#ifdef COM_LFCF_ON

	int32_t	Rtn;

	gFLASH_CS1_ID=0;
	PutStr("FLASH MEMORY 64MB ALL CLEAR(256sec[typ])... ",1);

	Rtn = FlashDetect();	//CS1 Check  (SET "gFLASH_CS1_ID")
	if(Rtn!=0)
		return;		//error
	else{
		switch(gFLASH_CS1_ID){
		case S29GL_X16_OnBoard:
			ChipErase_Spn_X16();
			break;
		case S29GL_X8_FlashBoard:
			ChipErase_Spn_X8();
			break;
		}
	}

#endif
}

void	dgScifSpeedUp(void)
{
#ifdef COM_SUP_ON

	if(CHK_DRAAK||CHK_EBISU){				// Draak
//		dgScifSpeedUp_Internal();			// S3D4
		dgScifSpeedUp_921600();				// S3D1
	}
	else{
#ifdef SCIF_CLK_EXTERNAL
		if( CHK_H3_ES10 )		//R-CarH3_ES1.0
			dgScifSpeedUp_460800();
		else
			dgScifSpeedUp_921600();
#endif /* SCIF_CLK_EXTERNAL */
#ifdef SCIF_CLK_INTERNAL
		if( CHK_H3_ES10 )		//R-CarH3_ES1.0
			dgScifSpeedUp_115200();
		else
			dgScifSpeedUp_230400();
#endif /* SCIF_CLK_INTERNAL */
	}
#endif
}

/****************************************************************
	MODULE				: dgScifSpeedUp							*
	FUNCTION			: Scif speed UP		Change 230.4kbps	*
	COMMAND				: SUP									*
	INPUT PARAMETER		: SUP									*
*****************************************************************/
void	dgScifSpeedUp_115200(void)
{
#ifdef COM_SUP_ON
	uint8_t setData;

	PutStr("Scif speed UP",1);
	setData =0x8;			/* 115200bps@33MHz */
	PutStr("Please change to 115.2Kbps baud rate setting of the terminal.",1);
	WaitPutCharSendEnd();
	SetScif2_SCBRR(setData);
#endif
}

/****************************************************************
	MODULE				: dgScifSpeedUp							*
	FUNCTION			: Scif speed UP		Change 230.4kbps	*
	COMMAND				: SUP									*
	INPUT PARAMETER		: SUP									*
*****************************************************************/
void	dgScifSpeedUp_230400(void)
{
#ifdef COM_SUP_ON
	uint8_t setData;

	PutStr("Scif speed UP",1);
	setData =0x8;			/* 230400bps@66MHz */
	PutStr("Please change to 230.4Kbps baud rate setting of the terminal.",1);
	WaitPutCharSendEnd();
	SetScif2_SCBRR(setData);
#endif
}

/****************************************************************
	MODULE				: dgScifSpeedUp							*
	FUNCTION			: Scif speed UP		Change 460.8kbps	*
	COMMAND				: SUP									*
	INPUT PARAMETER		: SUP									*
*****************************************************************/
void	dgScifSpeedUp_460800(void)
{
#ifdef COM_SUP_ON

	uint16_t setData;

	PutStr("Scif speed UP",1);
	setData =0x02;			//14.7456MHz/ (460800*16) =   2
	PutStr("Please change to 460.8Kbps baud rate setting of the terminal.",1);
	WaitPutCharSendEnd();

	switch( gScifMainChNo ){
		case SCIF_CH0: SetScif0_DL(setData); break;	// Eagle / Condor
		case SCIF_CH1: SetScif1_DL(setData); break;	// Condor(EX_MEM Board Debug Version)
		case SCIF_CH2: SetScif2_DL(setData); break;	// Salvator / Kriek / StarterKit / Draak
	}

#endif
}

/****************************************************************
	MODULE				: dgScifSpeedUp							*
	FUNCTION			: Scif speed UP		Change 921kbps		*
	COMMAND				: SUP									*
	INPUT PARAMETER		: SUP									*
*****************************************************************/
void	dgScifSpeedUp_921600(void)
{
#ifdef COM_SUP_ON

	uint16_t setData;
	uint32_t md=0;
	uint32_t sscg=0;

	md = *((volatile uint32_t*)RST_MODEMR);
	sscg = (md & 0x00001000) >> 12;

	PutStr("Scif speed UP",1);

	if(CHK_DRAAK){				// Draak
		if(sscg == 0x0){		//MD12=0 (SSCG off) �F S3D1C��=266.6MHz
			setData =0x12;		//266.66MHz/ (921600*16) =   18.08     @S3D1 (Error Rate = 0.47%)
		}
		else if(sscg == 0x1){	//MD12=1 (SSCG on)  �F S3D1C��=250MHz
			setData =0x11;		//250MHz   / (921600*16) =   16.95     @S3D1 (Error Rate =-0.27%)
		}
	}
	else if(CHK_EBISU){			// Ebisu
		if(sscg == 0x0){		//MD12=0 (SSCG off) �F S3D1C��=266.6MHz
			setData =0x12;		//266.66MHz/ (921600*16) =   18.08     @S3D1 (Error Rate = 0.47%)
		}
		else if(sscg == 0x1){	//MD12=1 (SSCG on)  �F S3D1C��=240MHz
			setData =0x10;		//240MHz   / (921600*16) =   16.28     @S3D1 (Error Rate = 1.70%)
		}
	}
	else{
		setData =0x01;			//14.7456MHz/ (921600*16) =   1         @SCIF_CLK
	}

	PutStr("Please change to 921.6Kbps baud rate setting of the terminal.",1);
	WaitPutCharSendEnd();

	switch( gScifMainChNo ){
		case SCIF_CH0: SetScif0_DL(setData); break;	// Eagle / Condor
		case SCIF_CH1: SetScif1_DL(setData); break;	// Condor(EX_MEM Board Debug Version)
		case SCIF_CH2: SetScif2_DL(setData); break;	// Salvator / Kriek / StarterKit / Draak
	}

#endif
}

/****************************************************************
	MODULE				: dgScifSpeedUp_Internal				*
	FUNCTION			: Scif speed UP		Change 230.4kbps	*
	COMMAND				: SUP									*
	INPUT PARAMETER		: SUP									*
*****************************************************************/
void	dgScifSpeedUp_Internal(void)
{
#ifdef COM_SUP_ON

	uint8_t setData;

	PutStr("Scif speed UP",1);
	setData = 8;			/* 230400 bit-rate: S3D4(66.66MHz) */
	PutStr("Please change to 230.4Kbps baud rate setting of the terminal.",1);
	WaitPutCharSendEnd();

	SetScif2_SCBRR(setData);

#endif
}

