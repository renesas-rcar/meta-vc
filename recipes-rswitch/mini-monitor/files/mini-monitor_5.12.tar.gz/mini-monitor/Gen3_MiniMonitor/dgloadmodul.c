// ���̃\�[�X�t�@�C�����œK��
//#pragma GCC optimize ("O3")		//gcc5.2 NG
//#pragma GCC optimize ("O1")		//gcc5.2 NG
//#pragma GCC optimize ("O2")		//gcc5.2 NG
//#pragma GCC optimize ("Ofast")	//gcc5.2 NG
//#pragma GCC optimize ("Os")		//gcc5.2 NG
#pragma GCC optimize ("Og")		//gcc5.2 OK

#include	"common.h"
#include	"dgmodul4.h"
#include	"dgloadmodul.h"
#include	"boardid.h"



extern uint32_t	gSpiFlashSvArea;
extern uint32_t	gUserPrgStartAdd;


/****************************************************************
	MODULE				: dgLoad 								*
	FUNCTION			: load program							*
	COMMAND				: L										*
	INPUT PARAMETER		: L					 					*
*****************************************************************/
void	dgLoad(void)
{
#ifdef COM_LG_ON

	char 		str[12];			//�ő� getByteCount=4 ->  4 * 2 +1 (NULL) = 9
	uint32_t 	data,getByteCount,byteCount;
	uint32_t 	loadGetCount,adByteCount,loadGetData,loadGetSum,loadGetCR;
	uintptr_t 	loadGetAddress;
	uint32_t 	loop,loop_S0,s0flag,errFlg,checkData,endFlg;

	loop	=1;
	loop_S0	=1;
	errFlg	=0;
	endFlg	=0;
	checkData = 0xFF;

	PutStr("please send ! ('.' & CR stop load)",1);
	while(loop){
		loop_S0=1;
		s0flag =0;
		while(1){
			GetChar(str);
			if(*str=='.'||*str=='s'||*str=='S')
				break;
		}
		if(*str =='.'){
			while(1){
				GetChar(str);
				if(*str==CR_CODE) 	return;
			}
		}
		else if(*str=='s'||*str=='S'){
			GetChar(str);
			switch(*str){
				case '0':				// S0:Title��
					s0flag =1;
					while(loop_S0){		// �f�[�^�擾���� CRorLR�R�[�h�܂Ń��[�v
						GetChar(str);
						if((*str==CR_CODE)||(*str==LF_CODE)) 	loop_S0=0;
					}
					break;
				case '1':				// S1:2Byte Address
					adByteCount =2;
					break;
				case '2':				// S2:3Byte Address
					adByteCount =3;
					break;
				case '3':				// S3:4Byte Address
					adByteCount =4;
					break;
				case '7':				// S7,S8,S9:�I���R�[�h
				case '8':
				case '9':
					endFlg =1;
					break;
				default:
					errFlg =1;
					break;
			}
		}
		if(endFlg==1 || errFlg==1){		// �I���R�[�h ��
			while(1){					// �f�[�^�擾���� CRorLR�R�[�h�܂Ń��[�v�� CRorLR�� Return
				GetChar(str);
				if((*str==CR_CODE)||(*str==LF_CODE))	return;
			}
		}
		if(s0flag == 0){
		//Get Byte count (addressByteCount + dataByteCount + sumCheckByteCount(=1) )
			getByteCount =1;
			GetStr_ByteCount(str,getByteCount);
			HexAscii2Data((unsigned char*)str,&data);
			loadGetCount = data;
		//Get Address
			getByteCount =adByteCount;
			GetStr_ByteCount(str,getByteCount);
			HexAscii2Data((unsigned char*)str,&data);
			loadGetAddress = data;
			loadGetCount = loadGetCount - getByteCount;  // Get Address byte count -
		//Get Data & Data write
			getByteCount =1;
			for(byteCount=loadGetCount;loadGetCount>1;loadGetCount=loadGetCount-1){
				GetStr_ByteCount(str,getByteCount);
				HexAscii2Data((unsigned char*)str,&data);
				loadGetData = data;
				*((unsigned char *)loadGetAddress) = loadGetData;
				loadGetAddress = loadGetAddress +1;
			}
		//Get sum
			getByteCount =1;
			GetStr_ByteCount(str,getByteCount);
			HexAscii2Data((unsigned char*)str,&data);
			loadGetSum = data;
//			if(checkData != loadGetSum)	return;		// Check�Ȃ�
		//Get CR code
			GetChar(str);								//  ��������
			loadGetCR = *str;
			if((loadGetCR==CR_CODE)||(loadGetCR==LF_CODE)){
				loop=1;
			}
		}
	}

#endif
}

int32_t	GetStr_ByteCount(char *str,uint32_t getByteCount)
{
	uint32_t	byteCount;
	int32_t i;

	for(byteCount=1;byteCount<=getByteCount;byteCount=byteCount+1){
		i=1;
		while(i==1){					/*  ��M������I������܂�(i=0�܂�)		*/
			i=GetChar(str);				/*  ��������							*/
		}
		str++;
		i=1;
		while(i==1){					/*  ��M������I������܂�(i=0�܂�)		*/
			i=GetChar(str);				/*  ��������							*/
		}
		str++;
	}
	*str = 0;
}


void dgLoadFlash(void)
{
#ifdef COM_LFCF_ON
	
	char 	str[12];			//�ő� getByteCount=4 ->  4 * 2 +1 (NULL) = 9
	uint32_t data;
	uint32_t getByteCount,byteCount;
	uint32_t loadGetCount,adByteCount,loadGetAddress,loadGetData,loadGetSum,loadGetCR;
	uint32_t loop,loop_S0,s0flag,errFlg,checkData,endFlg;

	uint32_t Load_workStartAdd,Load_workEndAdd;
	uint32_t workAdd_Min,workAdd_Max,writeData,wrAdd;
	uintptr_t workAdd;
	uint32_t PrgStatAdd,PrgEndAdd;

	loop	= 1;
	loop_S0	= 1;
	errFlg	= 0;
	endFlg	= 0;
	checkData = 0xFF;

	workAdd_Min = 0xFFFFFFFF;
	workAdd_Max = 0x00000000;

	Load_workStartAdd	= DramArea3_SADD;	// 0x50000000	DRAM
	Load_workEndAdd		= DramArea3_EADD;	// 0x53FFFFFF	DRAM
	PrgStatAdd			= FlashArea1_SADD;	// 0x04000000   CS1:Flash Memory
	PutStr("RAM(H'50000000-H'53FFFFFF) Clear....",1);

	FillData8Bit(Load_workStartAdd,Load_workEndAdd,0xFF);
//	writeData = 0xFFFFFFFF;
//	for(wrAdd=Load_workStartAdd;wrAdd<=Load_workEndAdd;wrAdd+=SIZE_32BIT){
//		*((unsigned long *)wrAdd) = writeData;
//	}

	PutStr("please send ! ('.' & CR stop load)",1);
	while(loop){
		loop_S0=1;
		s0flag =0;
		while(1){
			GetChar(str);
			if(*str=='.'||*str=='s'||*str=='S')
				break;
		}
		if(*str =='.'){					// '.' & CR �� *** Return ****
			while(1){
				GetChar(str);
				if(*str==CR_CODE) 	return;
			}
		}
		else if(*str=='s'||*str=='S'){
			GetChar(str);
			switch(*str){
				case '0':				// S0:Title��
					s0flag =1;
					while(loop_S0){		// �f�[�^�擾���� CRorLR�R�[�h�܂Ń��[�v
						GetChar(str);
						if((*str==CR_CODE)||(*str==LF_CODE)) 	loop_S0=0;
					}
					break;
				case '1':				// S1:2Byte Address
					adByteCount =2;
					break;
				case '2':				// S2:3Byte Address
					adByteCount =3;
					break;
				case '3':				// S3:4Byte Address
					adByteCount =4;
					break;
				case '7':				// S7,S8,S9:�I���R�[�h
				case '8':
				case '9':
					endFlg =1;
					break;
				default:
					errFlg =1;
					break;
			}
		}
		if(endFlg==1 || errFlg==1){		// �I���R�[�h �� �� *** Return ****
			while(1){					// �f�[�^�擾���� CRorLR�R�[�h�܂Ń��[�v�� CRorLR�� Return
				GetChar(str);
				if((*str==CR_CODE)||(*str==LF_CODE))	{
					PrgStatAdd = PrgStatAdd + (workAdd_Min - Load_workStartAdd);
					PrgEndAdd  = PrgStatAdd + (workAdd_Max - workAdd_Min);
					Lf_Program_Flash(PrgStatAdd,PrgEndAdd,workAdd_Min);
					return;
				}
			}
		}
		if(s0flag == 0){
		//Get Byte count (addressByteCount + dataByteCount + sumCheckByteCount(=1) )
			getByteCount =1;
			GetStr_ByteCount(str,getByteCount);
			HexAscii2Data((unsigned char*)str,&data);
			loadGetCount = data;
		//Get Address
			getByteCount =adByteCount;
			GetStr_ByteCount(str,getByteCount);
			HexAscii2Data((unsigned char*)str,&data);
			loadGetAddress = data;
			loadGetCount = loadGetCount - getByteCount;		// Get Address byte count -
		//workAdd = 0x50000000 | loadGetAddress
			workAdd =Load_workStartAdd | loadGetAddress;

		//Min Address Check
			if(workAdd < workAdd_Min)
				workAdd_Min = workAdd;

		//Get Data & Data write
			getByteCount =1;
			for(byteCount=loadGetCount;loadGetCount>1;loadGetCount=loadGetCount-1){
				GetStr_ByteCount(str,getByteCount);
				HexAscii2Data((unsigned char*)str,&data);
				loadGetData = data;
				*((unsigned char *)workAdd) = loadGetData;	// workAdd = 0x50000000 | loadGetAddress
				workAdd = workAdd +1;
			}
		//Max Address Check
			if((workAdd-1) > workAdd_Max)
				workAdd_Max = (workAdd-1);
		//Get sum
			getByteCount =1;
			GetStr_ByteCount(str,getByteCount);
			HexAscii2Data((unsigned char*)str,&data);
			loadGetSum = data;
//			if(checkData != loadGetSum)	return;				// Check�Ȃ�
		//Get CR code
			GetChar(str);									// ��������
			loadGetCR = *str;
			if((loadGetCR==CR_CODE)||(loadGetCR==LF_CODE)){
				loop=1;
			}
		}
	}

#endif
}





//Special version for SPI writing of Salvator-X �p //
//char dgLS_Load_Offset2(unsigned long *maxADD ,unsigned long *minADD)
char dgLS_Load_Offset2(uint32_t *maxADD ,uint32_t *minADD)
{
#ifdef COM_SPI_ON

//Load����MIN,MAX�A�h���X�v�Z����
	char 	str[12];			//�ő� getByteCount=4 ->  4 * 2 +1 (NULL) = 9
//	unsigned long data,getByteCount,byteCount;
	uint32_t data;
	uint32_t getByteCount,byteCount;
//	uint32_t loadGetCount,adByteCount,loadGetAddress,loadGetData,loadGetSum,loadGetCR;
	uint32_t loadGetCount,adByteCount,loadGetData,loadGetSum,loadGetCR;
	uintptr_t loadGetAddress;
	uint32_t loop,loop_S0,s0flag,errFlg,checkData,endFlg;

//**** Add dgLS_Load2 ********************************************************************
	uint32_t workAdd_Min,workAdd_Max;
	workAdd_Min = 0xFFFFFFFF;
	workAdd_Max = 0x00000000;
//****************************************************************************************


	uint32_t WorkStartAdd,Calculation;
	uint32_t loadOffset;

	WorkStartAdd = LS_WORK_DRAM_SADD;		//H'50000000

//	if(gSpiFlashSvArea==1){					//LoderProgram�̏ꍇ
	if(gSpiFlashSvArea==1||gSpiFlashSvArea==2){					//LoderProgram�̏ꍇ
//		loadOffset = 0;
		loadOffset  = gUserPrgStartAdd - WorkStartAdd ;		//Change
//		Calculation = ADDITION;
			Calculation = SUBTRACTION;						//Change
	}
	if(gSpiFlashSvArea==3){					//UserProgram�̏ꍇ
		if((0x40000000 <= gUserPrgStartAdd) && (gUserPrgStartAdd < WorkStartAdd)) {				//H'40000000 =< gUserPrgStartAdd < H'50000000
			loadOffset = WorkStartAdd - gUserPrgStartAdd ;
			Calculation = ADDITION;
   		}
		else if((WorkStartAdd <= gUserPrgStartAdd) && (gUserPrgStartAdd < 0xC0000000)) {		//H'50000000 =< gUserPrgStartAdd < H'C0000000
			loadOffset = gUserPrgStartAdd - WorkStartAdd ;
			Calculation = SUBTRACTION;
   		}

//		else if(((SECURERAM_SADD + 0x4000 )<= gUserPrgStartAdd) && (gUserPrgStartAdd <= SECURERAM_EADD)) {	//H'E6300000 + H'4000 =< gUserPrgStartAdd < H'E633FFFF
		else if(( SYSTEMRAM_SADD<= gUserPrgStartAdd) && (gUserPrgStartAdd <= PUBLICRAM_EADD))            {	//H'E6300000 =< gUserPrgStartAdd < H'E635FFFF  	//Change 2015.06.19
			loadOffset = gUserPrgStartAdd - WorkStartAdd ;
			Calculation = SUBTRACTION;
   		}
		else if(( RTRAM_SADD <= gUserPrgStartAdd) && (gUserPrgStartAdd <= RTRAM_EADD))                    {	//H'EB200000 =< gUserPrgStartAdd < H'EB2FFFFF  	//Add V3H
			loadOffset = gUserPrgStartAdd - WorkStartAdd ;
			Calculation = SUBTRACTION;
   		}
		else{
			if(CHK_V3H){
				PutStr("ERROR Load file. <Download file DRAM(H'40000000-H'BFFFFFFF),RAM(H'EB200000-H'EB2FFFFF) ONLY> ",1);		//Add V3H
			}else{
				PutStr("ERROR Load file. <Download file DRAM(H'40000000-H'BFFFFFFF),RAM(H'E6300000-H'E635FFFF) ONLY> ",1);		//Change 2015.06.19
			}
			return(1);
		}
	}//--------------------------------------------------------------------------------

	loop	=1;
	loop_S0	=1;
	errFlg	=0;
	endFlg	=0;
	checkData = 0xFF;

	PutStr("please send ! ('.' & CR stop load)",1);
	while(loop){
		loop_S0=1;
		s0flag =0;
		while(1){
			GetChar(str);
			if(*str=='.'||*str=='s'||*str=='S')
				break;
		}
		if(*str =='.'){
			while(1){
				GetChar(str);
				if(*str==CR_CODE) 	return(1);
			}
		}
		else if(*str=='s'||*str=='S'){
			GetChar(str);
			switch(*str){
				case '0':				// S0:Title��
					s0flag =1;
					while(loop_S0){		// �f�[�^�擾���� CRorLR�R�[�h�܂Ń��[�v
						GetChar(str);
						if((*str==CR_CODE)||(*str==LF_CODE)) 	loop_S0=0;
					}
					break;
				case '1':				// S1:2Byte Address
					adByteCount =2;
					break;
				case '2':				// S2:3Byte Address
					adByteCount =3;
					break;
				case '3':				// S3:4Byte Address
					adByteCount =4;
					break;
				case '7':				// S7,S8,S9:�I���R�[�h
				case '8':
				case '9':
					endFlg =1;
					break;
				default:
					errFlg =1;
					break;
			}
		}
		if(endFlg==1 || errFlg==1){		// �I���R�[�h ��
			while(1){					// �f�[�^�擾���� CRorLR�R�[�h�܂Ń��[�v�� CRorLR�� Return
				GetChar(str);
				if((*str==CR_CODE)||(*str==LF_CODE)){

//**** Add dgLS_Load2 ********************************************************************
					*maxADD = workAdd_Max;
					*minADD = workAdd_Min;
//****************************************************************************************

					return(0);
				}
			}
		}
		if(s0flag == 0){
		//Get Byte count (addressByteCount + dataByteCount + sumCheckByteCount(=1) )
			getByteCount =1;
			GetStr_ByteCount(str,getByteCount);
			HexAscii2Data((unsigned char*)str,&data);
			loadGetCount = data;
		//Get Address
			getByteCount =adByteCount;
			GetStr_ByteCount(str,getByteCount);
			HexAscii2Data((unsigned char*)str,&data);
			loadGetAddress = data;

//Add------------------------------------------------------------------------------
			if(Calculation == SUBTRACTION){
				loadGetAddress = loadGetAddress - loadOffset;
   			}
			else{
				loadGetAddress = loadGetAddress + loadOffset;
			}
//---------------------------------------------------------------------------------

			loadGetCount = loadGetCount - getByteCount;  // Get Address byte count -


//**** Add dgLS_Load2 ********************************************************************
		//Min Address Check
			if(loadGetAddress < workAdd_Min)
				workAdd_Min = loadGetAddress;
//****************************************************************************************

		//Get Data & Data write
			getByteCount =1;
			for(byteCount=loadGetCount;loadGetCount>1;loadGetCount=loadGetCount-1){
				GetStr_ByteCount(str,getByteCount);
				HexAscii2Data((unsigned char*)str,&data);
				loadGetData = data;
				*((unsigned char *)loadGetAddress) = loadGetData;
				loadGetAddress = loadGetAddress +1;
			}
//**** Add dgLS_Load2 ********************************************************************
		//Max Address Check
			if((loadGetAddress-1) > workAdd_Max)
				workAdd_Max = (loadGetAddress-1);
//****************************************************************************************

		//Get sum
			getByteCount =1;
			GetStr_ByteCount(str,getByteCount);
			HexAscii2Data((unsigned char*)str,&data);
			loadGetSum = data;
		//Get CR code
			GetChar(str);								//  ��������
			loadGetCR = *str;
			if((loadGetCR==CR_CODE)||(loadGetCR==LF_CODE)){
				loop=1;
			}
		}
	}

#endif
}


