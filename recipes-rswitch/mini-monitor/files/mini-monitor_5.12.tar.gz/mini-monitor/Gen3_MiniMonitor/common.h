typedef long long int			int64_t;
typedef int						int32_t;
typedef short					int16_t;
typedef char					int8_t;

typedef unsigned long long int	uint64_t;
typedef unsigned int			uint32_t;
typedef unsigned short			uint16_t;
typedef unsigned char			uint8_t;


#ifdef AArch64
typedef uint64_t    uintptr_t;
#define CPU_BYTE_SIZE			SIZE_64BIT
#endif

#ifdef AArch32
typedef uint32_t    uintptr_t;
#define CPU_BYTE_SIZE			SIZE_32BIT
#endif


/******************************************************************************/
/* INCLUDE FILE                                                               */
/******************************************************************************/
#include "common_func.h"

