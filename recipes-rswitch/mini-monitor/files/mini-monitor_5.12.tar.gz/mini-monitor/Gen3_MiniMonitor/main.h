void Main(void);
void InitMain(void);
void StartMessMinimonitor( void );
void StartMessBoard( void );
void DecCom(void);
long CmpCom(char *str);
void PutMessWorkMemory( void );
