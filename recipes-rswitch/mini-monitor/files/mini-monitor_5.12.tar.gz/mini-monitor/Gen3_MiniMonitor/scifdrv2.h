int32_t PutCharSCIF2(char outChar);
int32_t GetCharSCIF2(char *inChar);
void PowerOnScif2(void);
void WaitPutScif2SendEnd(void);
void InitScif2_SCIFCLK(void);
void InitScif2_INTERNAL_S3D1(void);
//void InitScif2_INTERNAL(void);
void SetScif2_DL(uint16_t setData);
void SetScif2_SCBRR(uint8_t setData);
