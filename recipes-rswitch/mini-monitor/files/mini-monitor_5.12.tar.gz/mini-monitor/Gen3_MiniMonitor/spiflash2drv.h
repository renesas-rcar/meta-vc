//==============================================
// SPANSION  S25FS512S
//==============================================
void FastRdQspiFlashS25s512s(uint32_t sourceSpiAdd,uint32_t destinationAdd,uint32_t byteCount);
void QuadIORdQspiFlashS25s512s(uint32_t sourceSpiAdd,uint32_t destinationAdd,uint32_t byteCount);
void EnableQuadModeQspiFlashS25fs512s(void);
void SectorErase256kbQspiFlashS25s512s(uint32_t addr);
void ParameterSectorErase4kbQspiFlashS25s512s(uint32_t addr);
int32_t BulkEraseQspiFlashS25s512s(void);
void PageProgramWithBuffeQspiFlashS25s512s(uint32_t addr, uint32_t source_addr);
void SaveDataWithBuffeQspiFlashS25s512s(uint32_t srcAdd,uint32_t svFlashAdd,uint32_t svSize);
void SectorEraseQspiFlashS25s512s(uint32_t EraseStatAdd,uint32_t EraseEndAdd);
void ParameterSectorEraseQspiFlashS25s512s(uint32_t EraseStatAdd,uint32_t EraseEndAdd);
void SectorRdQspiFlashS25s512s(uint32_t spiStatAdd,uint32_t distRamAdd);
