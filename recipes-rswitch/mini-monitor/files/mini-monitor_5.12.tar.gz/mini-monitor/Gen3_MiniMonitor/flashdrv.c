#include "common.h"
#include "flashdrv.h"

extern uint32_t gFLASH_CS1_ID;
uint16_t gFlashWrtBufWords;

/*************************************************************************************/
/*                                                                                   */
/*            Program Command : Write Buffer Version                                 */
/*                                                                                   */
/*************************************************************************************/
/************************
	FlashDetect
*************************/

#if defined(COM_MV_ON) || defined(COM_LFCF_ON)		//ifdef COM_MV_ON or COM_LFCF_ON ��������

int32_t FlashDetect(void)
{
	uint16_t	makerCode;
	uint16_t	devID;
	char buf[16];
	
	char str[10];

	int32_t chCnt;

	makerCode = 0x1234;
	devID     = 0x1234;


		RdFlashMakerCode_X8(&makerCode,&devID);
		if((makerCode==S29GL_X8_FlashBoard) && (devID==S29GL_X8_FlashBoard_DevID) ){
			gFLASH_CS1_ID = makerCode;
			PutStr("Spansion flash was detected in area 1 (Flash Board) ",1);
			// Get Flash Write Buffer Size
			if (GetFlashWrtBufSize_X8()){
				PutStr("Flash write buffer size could not be gotten (CFI Command Error) ",1);
				return(1);
			}
		}
		else{
			PutStr("Flash memory of 1 in area is not Spansion (Maker Code , ID Error) ",1);
			Data2HexAscii(makerCode,str,4);  PutStr(" Read  makerCode = 0x",0);  PutStr(str,1);
			Data2HexAscii(devID,str,4);      PutStr(" Read  devID     = 0x",0);  PutStr(str,1);
			return(1);
		}
	PutStr("Flash write buffer size is ",0);
	Hex2DecAscii((int32_t)gFlashWrtBufWords,buf,&chCnt);
	PutStr(buf,0);
	PutStr(" words.", 1);
	return(0);
}


void RdFlashMakerCode_X8(uint16_t *makerCode , uint16_t *devIDWord1)
{
// FLASH_Board maker code check. (16bit:Byte_mode x 2)
	*((volatile uint16_t *) (FLASH_OFFSET + FLASH_AD_AAA)) = DATA_AAAA;	//	write unlock cycle 1
	__asm__ __volatile__ ("dsb sy");
	*((volatile uint16_t *) (FLASH_OFFSET + FLASH_AD_555)) = DATA_5555;	//	write unlock cycle 2
	__asm__ __volatile__ ("dsb sy");
	*((volatile uint16_t *) (FLASH_OFFSET + FLASH_AD_AAA)) = DATA_9090;	//	write autoselect command
	__asm__ __volatile__ ("dsb sy");

	*makerCode = *((volatile uint16_t *) FLASH_OFFSET);					//	MakerCode Read
	*devIDWord1 = *((volatile uint16_t *) (FLASH_OFFSET+0x0004));		//	Devide ID Word1
// RESET COMMAND
	*((volatile uint16_t *)FLASH_OFFSET) = DATA_F0F0;					// exit autoselect (write reset command)
	__asm__ __volatile__ ("dsb sy");
}


int32_t GetFlashWrtBufSize_X8(void)
{
	uint16_t	readData;

	*((volatile uint16_t *) (FLASH_OFFSET + FLASH_AD_0AA)) = DATA_9898;	//	write CFI entry
	__asm__ __volatile__ ("dsb sy");
	readData = *((volatile uint16_t *) (FLASH_OFFSET + FLASH_AD_054));	//	read write buffer size lower power of 2
	*((volatile uint16_t *)FLASH_OFFSET) = DATA_F0F0;					//	write CFI exit
	__asm__ __volatile__ ("dsb sy");

	if( (readData & 0x00FF) != ((readData >> 8) & 0x00FF) ){
		return(1);
	}

	readData = readData & 0x00FF;
	if(!readData){
		return(1);
	}
	 gFlashWrtBufWords = (1 << readData) >> 1;

	return(0);
}

// ���j�Z�N�^�����ł͂Ȃ��A�A�h���X�����ō쐬
void SectorErase_Spn_X16(uint32_t EraseStatAdd,uint32_t EraseEndAdd)
{
// 16bit(16bitx1)�̃I���{�[�h�t���b�V���̃Z�N�^�P�ʂ� H'20000
//	uint32_t	sectorAd;
	uintptr_t	sectorAd;
	uint16_t	readData;
	uint32_t	SectorStatAdd,SectorEndAdd;
	uint16_t expData = DATA_FFFF;
	char buf[16];


	SectorStatAdd = EraseStatAdd & 0xFFFE0000;		//0x20000�P�ʂɃ}�X�N
	SectorEndAdd  = EraseEndAdd  & 0xFFFE0000;		//0x20000�P�ʂɃ}�X�N

// RESET COMMAND
	*((volatile uint16_t *)FLASH_OFFSET) = DATA_00F0;
	__asm__ __volatile__ ("dsb sy");

// SECTOR ERASE
	for(sectorAd =SectorStatAdd;sectorAd<=SectorEndAdd;sectorAd=sectorAd+0x20000 ){
		*((volatile uint16_t *) (FLASH_OFFSET + FLASH_AD_555)) = DATA_00AA;	//	write unlock cycle 1
		__asm__ __volatile__ ("dsb sy");
		*((volatile uint16_t *) (FLASH_OFFSET + FLASH_AD_2AA)) = DATA_0055;	//	write unlock cycle 2
		__asm__ __volatile__ ("dsb sy");
		*((volatile uint16_t *) (FLASH_OFFSET + FLASH_AD_555)) = DATA_0080;	//	write setup command
		__asm__ __volatile__ ("dsb sy");
		*((volatile uint16_t *) (FLASH_OFFSET + FLASH_AD_555)) = DATA_00AA;	//	write additional unlock cycle 1
		__asm__ __volatile__ ("dsb sy");
		*((volatile uint16_t *) (FLASH_OFFSET + FLASH_AD_2AA)) = DATA_0055;	//	write additional unlock cycle 2
		__asm__ __volatile__ ("dsb sy");
		*((volatile uint16_t *)sectorAd) = DATA_0030;						//	write sector erase command
		__asm__ __volatile__ ("dsb sy");
		readData=*((volatile uint16_t *) sectorAd);
		while( (readData & 0x0080) != (expData & 0x0080) ) // Check DQ7
		{
			// ERROR CHECK(DQ5:TIMEOUT)
			if(readData & 0x0020) { // at least one DQ5==1 ?
				// duble check
				readData=*((volatile uint16_t *) sectorAd);
				if((readData & 0x0080) != (expData & 0x0080)) // Check DQ7
				{
					// RESET COMMAND
					*((volatile uint16_t *)FLASH_OFFSET) = DATA_00F0;
					PutStr("SectorErase Failed : flash erase timeout at address 0x",0);
					Data2HexAscii((uint32_t)(sectorAd),buf,SIZE_32BIT);
					PutStr(buf,0);
					PutStr(" readData 0x",0);
					Data2HexAscii((uint32_t)readData,buf,SIZE_16BIT);
					PutStr(buf,0);
					PutStr(").",1);
					return;
				}else{
					break;
				}
			}
			readData=*((volatile uint16_t *) sectorAd);
		}

		PutStr(".",0);
	}
	PutStr("Erase Completed ",1);
}

void Program_Spn_X16(uintptr_t PrgStatAdd,uintptr_t PrgEndadd,uintptr_t CopyAdd)
{
	volatile uint16_t	*writeFromAdd, *writeToAdd;	// write data from/to address
	volatile uint16_t	*writeSecAdd;				// flash write sector address
	uint32_t	WriteWordLen;						// write data length(Word)
	uint16_t	writeBufCount;						// write buffer count(Word)
	uint16_t	readData,writeData;
	uint32_t	intervalPoint;
	uint16_t	wordCount;
	char buf[16];

	writeFromAdd = (volatile uint16_t *) CopyAdd;	// set write data from address
	writeToAdd = (volatile uint16_t *) PrgStatAdd;	// set write data to address

// Set total write data size to WriteWordLen
	// Check the last write data address(Byte) alignment
	if (PrgEndadd % (sizeof(uint16_t))){
		// odd
		WriteWordLen = ((PrgEndadd +1) - PrgStatAdd) / sizeof(uint16_t);
	}else{
		// even
		WriteWordLen = ((PrgEndadd +1) + 1 - PrgStatAdd) / sizeof(uint16_t);
	}

// RESET COMMAND
//	*((volatile uint16_t *)FLASH_OFFSET) = DATA_00F0;

	while (WriteWordLen > 0)
	{

// Set "writeBufCount" to write buffer size(Word)
		if (WriteWordLen > gFlashWrtBufWords){
			writeBufCount = gFlashWrtBufWords;	// Set Full write buffer size
		}else{
			writeBufCount = WriteWordLen;		// Set remaining write data length(Word)
		}


		intervalPoint=(uintptr_t)writeToAdd & 0x0001FFFF;   //0x0001FFFF;
		if(intervalPoint==0x0)
			PutStr(".",0);


// Write Data to Write Buffer
		// Write Buffer Program Command
		*((volatile uint16_t *) (FLASH_OFFSET + FLASH_AD_555)) = DATA_00AA;	//	write unlock cycle 1
		__asm__ __volatile__ ("dsb sy");
		*((volatile uint16_t *) (FLASH_OFFSET + FLASH_AD_2AA)) = DATA_0055;	//	write unlock cycle 2
		__asm__ __volatile__ ("dsb sy");

		writeSecAdd = writeToAdd;											//	Set SA
		*(writeSecAdd) = DATA_0025;											//	Write write buffer command
		__asm__ __volatile__ ("dsb sy");
		*(writeSecAdd) = writeBufCount-1;									//	Write writeBufCount(word-1) to SA
		__asm__ __volatile__ ("dsb sy");

		// Write up to "writeBufCount" into the write buffer
		for (wordCount = 0; wordCount < writeBufCount ; wordCount++)
		{
			*(writeToAdd++) = *(writeFromAdd++);
			__asm__ __volatile__ ("dsb sy");
		}

		// Flash the write buffer
		*(writeSecAdd) = DATA_0029;
		__asm__ __volatile__ ("dsb sy");

// Wait for Writing. (Flash read data DQ7 != Ram write data DQ7)
		readData=*(writeToAdd-1);
		writeData=*(writeFromAdd-1);

		while( (readData & 0x0080) != (writeData & 0x0080) )
		{
			// ERROR CHECK(DQ5:TIMEOUT)
			if(readData & 0x0020) { // at least one DQ5==1 ?

				// double check DQ7
				readData=*(writeToAdd-1);

				if( (readData & 0x0080) != (writeData & 0x0080) ){
					// RESET COMMAND
					*((volatile uint16_t *)FLASH_OFFSET) = DATA_00F0;
					__asm__ __volatile__ ("dsb sy");

					// printf("Write Failed : flash write timeout at address 0x%x(writeData 0x%x readData 0x%x).\r\n", (writeToAdd-1), writeData, readData);
					PutStr("Write Failed : flash write timeout at address 0x",0);
					Data2HexAscii((uint32_t)((uintptr_t)writeToAdd-1),buf,SIZE_32BIT);
					PutStr(buf,0);
					PutStr("(writeData 0x",0);
					Data2HexAscii((uint32_t)writeData,buf,SIZE_16BIT);
					PutStr(buf,0);
					PutStr(" readData 0x",0);
					Data2HexAscii((uint32_t)readData,buf,SIZE_16BIT);
					PutStr(buf,0);
					PutStr(").",1);
					return;
				}else{
					break; //Flash Write has succeeded.
				}
			}
			// ERROR CHECK(DQ1:WRITE ABORT)
			if(readData & 0x0002) { // at least one DQ1==1 ?

				// double check DQ7
				readData=*(writeToAdd-1);

				if( (readData & 0x0080) != (writeData & 0x0080) ){
					// Write to Buffer Abort Reset Command
					*((volatile uint16_t *) (FLASH_OFFSET + FLASH_AD_555)) = DATA_00AA;	//	write unlock cycle 1
					__asm__ __volatile__ ("dsb sy");
					*((volatile uint16_t *) (FLASH_OFFSET + FLASH_AD_2AA)) = DATA_0055;	//	write unlock cycle 2
					__asm__ __volatile__ ("dsb sy");
					*((volatile uint16_t *) (FLASH_OFFSET + FLASH_AD_555)) = DATA_00F0;	//	write Write to Buffer Abort Reset Command
					__asm__ __volatile__ ("dsb sy");

					// printf("Write Failed : flash write abort at address 0x%x(writeData 0x%x readData 0x%x).\r\n", (writeToAdd-1), writeData, readData);
					PutStr("Write Failed : flash write abort at address 0x",0);
					Data2HexAscii((uint32_t)((uintptr_t)writeToAdd-1),buf,SIZE_32BIT);
					PutStr(buf,0);
					PutStr("(writeData 0x",0);
					Data2HexAscii((uint32_t)writeData,buf,SIZE_16BIT);
					PutStr(buf,0);
					PutStr(" readData 0x",0);
					Data2HexAscii((uint32_t)readData,buf,SIZE_16BIT);
					PutStr(buf,0);
					PutStr(").",1);
					return;
				}else{
					break; //Flash Write has succeeded.
				}
			}
			readData=*(writeToAdd-1);
		}
		//Updating WriteWordLen
		WriteWordLen -= (uint32_t)(writeBufCount);
	}
	PutStr("Write Completed ",1);
}

void ChipErase_Spn_X16(void)
{
//16bit(16bitx1)�̃I���{�[�h�t���b�V��
	uint16_t	readData;

	PutStr("On Board FLASH MEMORY ALL CLEAR... Please wait ",1);

// RESET COMMAND
	*((volatile uint16_t *)FLASH_OFFSET) = DATA_00F0;
	__asm__ __volatile__ ("dsb sy");

// CHIP ERASE
	*((volatile uint16_t *) (FLASH_OFFSET + FLASH_AD_555)) = DATA_00AA;	//	unlock cycle 1
	__asm__ __volatile__ ("dsb sy");
	*((volatile uint16_t *) (FLASH_OFFSET + FLASH_AD_2AA)) = DATA_0055;	//	unlock cycle 2
	__asm__ __volatile__ ("dsb sy");
	*((volatile uint16_t *) (FLASH_OFFSET + FLASH_AD_555)) = DATA_0080;	//	setup command
	__asm__ __volatile__ ("dsb sy");
	*((volatile uint16_t *) (FLASH_OFFSET + FLASH_AD_555)) = DATA_00AA;	//	additional unlock cycle 1
	__asm__ __volatile__ ("dsb sy");
	*((volatile uint16_t *) (FLASH_OFFSET + FLASH_AD_2AA)) = DATA_0055;	//	additional unlock cycle 2
	__asm__ __volatile__ ("dsb sy");
	*((volatile uint16_t *) (FLASH_OFFSET + FLASH_AD_555)) = DATA_0010;	//	chip erase command
	__asm__ __volatile__ ("dsb sy");

	while(1){
		readData=*((volatile uint16_t *) FLASH_OFFSET);
		if( (readData & 0x0080) ){
			break;
		}
	}
// RESET COMMAND
	*((volatile uint16_t *)FLASH_OFFSET) = DATA_00F0;
	__asm__ __volatile__ ("dsb sy");
	PutStr("Completed ",1);
}



// ���j�Z�N�^�����ł͂Ȃ��A�A�h���X�����ō쐬
void SectorErase_Spn_X8(uint32_t EraseStatAdd,uint32_t EraseEndAdd)
{
// 16bit(8bitx2)�̃t���b�V���������{�[�h�̃Z�N�^�P�ʂ� H'40000
//	uint32_t	sectorAd;
	uintptr_t	sectorAd;
	uint16_t	readData;

	uint32_t	SectorStatAdd,SectorEndAdd;

	uint16_t flag_err      = 0;
	uint16_t flag_HighLow  = 0;
	uint16_t expData       = 0;
	uint16_t ori_expData   = DATA_FFFF; // expectation value

	char buf[16];


	SectorStatAdd = EraseStatAdd & 0xFFFC0000;		//0x40000�P�ʂɃ}�X�N
	SectorEndAdd  = EraseEndAdd  & 0xFFFC0000;		//0x40000�P�ʂɃ}�X�N

// RESET COMMAND
	*((volatile uint16_t *)FLASH_OFFSET) = DATA_F0F0;
	__asm__ __volatile__ ("dsb sy");

// SECTOR ERASE
	for(sectorAd =SectorStatAdd;sectorAd<=SectorEndAdd;sectorAd=sectorAd+0x40000 ){
		*((volatile uint16_t *) (FLASH_OFFSET + FLASH_AD_AAA)) = DATA_AAAA;	//	write unlock cycle 1
		__asm__ __volatile__ ("dsb sy");
		*((volatile uint16_t *) (FLASH_OFFSET + FLASH_AD_555)) = DATA_5555;	//	write unlock cycle 2
		__asm__ __volatile__ ("dsb sy");
		*((volatile uint16_t *) (FLASH_OFFSET + FLASH_AD_AAA)) = DATA_8080;	//	write setup command
		__asm__ __volatile__ ("dsb sy");
		*((volatile uint16_t *) (FLASH_OFFSET + FLASH_AD_AAA)) = DATA_AAAA;	//	write additional unlock cycle 1
		__asm__ __volatile__ ("dsb sy");
		*((volatile uint16_t *) (FLASH_OFFSET + FLASH_AD_555)) = DATA_5555;	//	write additional unlock cycle 2
		__asm__ __volatile__ ("dsb sy");
		*((volatile uint16_t *)sectorAd) = DATA_3030;						//	write sector erase command
		__asm__ __volatile__ ("dsb sy");
		for(flag_HighLow=0; flag_HighLow < 2; flag_HighLow++){
			expData = ori_expData;
			HighLow_DeviceMask(&expData, flag_HighLow);
			readData=*((volatile uint16_t *) sectorAd);
			HighLow_DeviceMask(&readData, flag_HighLow);
			while( (readData & 0x8080) != (expData & 0x8080) ) // Check DQ7
			{
				// ERROR CHECK(DQ5:TIMEOUT)
				if(readData & 0x2020) { // at least one DQ5==1 ?
					// duble check
					readData=*((volatile uint16_t *) sectorAd);
					HighLow_DeviceMask(&readData, flag_HighLow);
					if( (readData & 0x8080) != (expData & 0x8080) ){
						if(0 == flag_HighLow){
							flag_err = ERR_ERASE_HIGH_DEV_TIMEOUT | flag_err; // Set error flag
						}else if(1 == flag_HighLow){
							flag_err = ERR_ERASE_LOW_DEV_TIMEOUT | flag_err; // Set error flag
						}
						PutStr("SectorErase Failed : flash erase timeout at address 0x",0);
						Data2HexAscii((uint32_t)(sectorAd),buf,SIZE_32BIT);
						PutStr(buf,0);
						PutStr(" readData 0x",0);
						Data2HexAscii((uint32_t)readData,buf,SIZE_16BIT);
						PutStr(buf,0);
						PutStr(").",1);
						break;
					}else{
						break; // Erase Completed
					}
				}
				readData=*((volatile uint16_t *) sectorAd);
				HighLow_DeviceMask(&readData, flag_HighLow);
			}
		}
		if(0 != flag_err){
			ErrOp(flag_err); // error operation
			return;
		}
		PutStr(".",0);
	}
	PutStr("Erase Completed ",1);
}

void HighLow_DeviceMask(uint16_t* pData, uint16_t HighLow)
{
	uint16_t data;

	data = *pData;

	if(HighLow==1){  // Mask the data of High 8bit device
		data = data & HIGH_DEVICE_MASK;
	}else if(HighLow==0){   // Mask the data of Low 8bit device
		data = data & LOW_DEVICE_MASK;
	}
	*pData = data;
}

void ErrOp(uint16_t flag_err)
{

	if(flag_err & (ERR_LOW_DEV_TIMEOUT | ERR_HIGH_DEV_TIMEOUT)){
		// RESET COMMAND
		*((volatile uint16_t *)FLASH_OFFSET) = DATA_F0F0;
		__asm__ __volatile__ ("dsb sy");
		if(flag_err & ERR_HIGH_DEV_TIMEOUT){
			PutStr("Write Failed : flash write timeout Device High. ",0);
		}
		if(flag_err & ERR_LOW_DEV_TIMEOUT){
			PutStr("Write Failed : flash write timeout Device Low. ",0);
		}

	}
	if(flag_err & (ERR_LOW_DEV_ABORT | ERR_HIGH_DEV_ABORT)){
		// Write to Buffer Abort Reset Command
		*((volatile uint16_t *) (FLASH_OFFSET + FLASH_AD_AAA)) = DATA_AAAA;	//	write unlock cycle 1
		__asm__ __volatile__ ("dsb sy");
		*((volatile uint16_t *) (FLASH_OFFSET + FLASH_AD_555)) = DATA_5555;	//	write unlock cycle 2
		__asm__ __volatile__ ("dsb sy");
		*((volatile uint16_t *) (FLASH_OFFSET + FLASH_AD_AAA)) = DATA_F0F0;	//	write Write to Buffer Abort Reset Command
		__asm__ __volatile__ ("dsb sy");

		if(flag_err & ERR_HIGH_DEV_ABORT){
			PutStr("Write Failed : flash write abort Device High. ",0);
		}
		if(flag_err & ERR_LOW_DEV_ABORT){
			PutStr("Write Failed : flash write abort Device Low. ",0);
		}
	}
	if(flag_err & (ERR_ERASE_HIGH_DEV_TIMEOUT | ERR_ERASE_LOW_DEV_TIMEOUT)){
		// RESET COMMAND
		*((volatile uint16_t *)FLASH_OFFSET) = DATA_F0F0;
		__asm__ __volatile__ ("dsb sy");
		if(flag_err & ERR_ERASE_HIGH_DEV_TIMEOUT){
			PutStr("Erase Failed : Erase Timeout Dev High Error",1);
		}
		if(flag_err & ERR_ERASE_LOW_DEV_TIMEOUT){
			PutStr("Erase Failed : Erase Timeout Dev Low Error",1);
		}
	}
}

void Program_Spn_X8(uintptr_t PrgStatAdd,uintptr_t PrgEndadd,uintptr_t CopyAdd)
{
	volatile uint16_t	*writeFromAdd, *writeToAdd;	// write data from/to address
	volatile uint16_t	*writeSecAdd;				// flash write sector address
	uint32_t	WriteWordLen;						// write data length(Word)
	uint16_t	writeBufCount;						// write buffer count(Word)
	uint16_t	readData,writeData;
	uint32_t	intervalPoint;
	uint16_t	wordCount;
	char buf[16];

	uint16_t	ori_writeData;
	uint16_t	flag_HighLow;
	uint16_t	flag_err;
	writeFromAdd = (volatile uint16_t *) CopyAdd;	// set write data from address
	writeToAdd = (volatile uint16_t *) PrgStatAdd;	// set write data to address

// Set total write data size to WriteWordLen
	// Check the last write data address(Byte) alignment
	if (PrgEndadd % (sizeof(uint16_t))){
		// odd
		WriteWordLen = ((PrgEndadd +1) - PrgStatAdd) / sizeof(uint16_t);
	}else{
		// even
		WriteWordLen = ((PrgEndadd +1) + 1 - PrgStatAdd) / sizeof(uint16_t);
	}

// RESET COMMAND
//	*((volatile uint16_t *)FLASH_OFFSET) = DATA_F0F0;

	while (WriteWordLen > 0){
		flag_err = 0;
// Set "writeBufCount" to write buffer size(Word)
		if (WriteWordLen > gFlashWrtBufWords*2){
			writeBufCount = gFlashWrtBufWords*2;	// Set Full write buffer size per 1 device
		}else{
			writeBufCount = WriteWordLen;			// Set remaining write data length(Word) per 1 device
		}

		intervalPoint=(uintptr_t)writeToAdd & 0x0003FFFF;   //0x0003FFFF;
		if(intervalPoint==0x0)
			PutStr(".",0);

// Write Data to Write Buffer
		// Write Buffer Program Command
		*((volatile uint16_t *) (FLASH_OFFSET + FLASH_AD_AAA)) = DATA_AAAA;	//	write unlock cycle 1
		__asm__ __volatile__ ("dsb sy");
		*((volatile uint16_t *) (FLASH_OFFSET + FLASH_AD_555)) = DATA_5555;	//	write unlock cycle 2
		__asm__ __volatile__ ("dsb sy");

		writeSecAdd = writeToAdd;													//	Set SA
		*(writeSecAdd) = DATA_2525;													//	Write write buffer command
		__asm__ __volatile__ ("dsb sy");
		*(writeSecAdd) = ( ( ( (writeBufCount) -1 ) << 8 ) | ( (writeBufCount) -1 ) );		//	Write writeBufCount(word-1) to SA
		__asm__ __volatile__ ("dsb sy");

		// Write up to "writeBufCount x2" into the write buffer
		for (wordCount = 0; wordCount < writeBufCount ; wordCount++){
			*(writeToAdd++) = *(writeFromAdd++);
			__asm__ __volatile__ ("dsb sy");
		}
		// Flash the write buffer
		*(writeSecAdd) = DATA_2929;
		__asm__ __volatile__ ("dsb sy");

// Wait for Writing. (Flash read data DQ7 != Ram write data DQ7)
		ori_writeData=*(writeFromAdd-1);

		for(flag_HighLow=0; flag_HighLow < 2; flag_HighLow++){
			writeData=ori_writeData;
			HighLow_DeviceMask(&writeData, flag_HighLow);
			readData=*(writeToAdd-1);
			HighLow_DeviceMask(&readData, flag_HighLow);
			while( (readData & 0x8080) != (writeData & 0x8080) ){
				// ERROR CHECK(DQ5:TIMEOUT)
				if(readData & 0x2020) { // at least one DQ5==1 ?
					// double check DQ7
					readData=*(writeToAdd-1);
					HighLow_DeviceMask(&readData, flag_HighLow);
					if( (readData & 0x8080) != (writeData & 0x8080) ){
						if(1 == flag_HighLow){ // error Low 8bit Device
							flag_err = flag_err | ERR_LOW_DEV_TIMEOUT;
						}else if(0 == flag_HighLow){ // error High 8bit Device
							flag_err = flag_err | ERR_HIGH_DEV_TIMEOUT;
						}
						// printf("Write Failed : flash write timeout at address 0x%x(writeData 0x%x readData 0x%x).\r\n", (writeToAdd-1), writeData, readData);
						PutStr("Write Failed : flash write timeout at address 0x",0);
						Data2HexAscii((uint32_t)((uintptr_t)writeToAdd-1),buf,SIZE_32BIT);
						PutStr(buf,0);
						PutStr("(writeData 0x",0);
						Data2HexAscii((uint32_t)writeData,buf,SIZE_16BIT);
						PutStr(buf,0);
						PutStr(" readData 0x",0);
						Data2HexAscii((uint32_t)readData,buf,SIZE_16BIT);
						PutStr(buf,0);
						PutStr(").",1);
						break;
					}else{
						break; //Flash Write has succeeded.
					}
				}
				// ERROR CHECK(DQ1:WRITE ABORT)
				if(readData & 0x0202) { // at least one DQ1==1 ?

				// double check DQ7
					readData=*(writeToAdd-1);
					HighLow_DeviceMask(&readData, flag_HighLow);
					if( (readData & 0x8080) != (writeData & 0x8080) ){
						if(1 == flag_HighLow){ // error Low 8bit Device
							flag_err = flag_err | ERR_LOW_DEV_ABORT;
						}else if(0 == flag_HighLow){ // error High 8bit  Device
							flag_err = flag_err | ERR_HIGH_DEV_ABORT;
						}
					// printf("Write Failed : flash write abort at address 0x%x(writeData 0x%x readData 0x%x).\r\n", (writeToAdd-1), writeData, readData);
						PutStr("Write Failed : flash write abort at address 0x",0);
						Data2HexAscii((uint32_t)((uintptr_t)writeToAdd-1),buf,SIZE_32BIT);
						PutStr(buf,0);
						PutStr("(writeData 0x",0);
						Data2HexAscii((uint32_t)writeData,buf,SIZE_16BIT);
						PutStr(buf,0);
						PutStr(" readData 0x",0);
						Data2HexAscii((uint32_t)readData,buf,SIZE_16BIT);
						PutStr(buf,0);
						PutStr(").",1);
						break;

					}else{
						break; //Flash Write has succeeded.
					}
				}
				readData=*(writeToAdd-1);
				HighLow_DeviceMask(&readData, flag_HighLow);
			}
		} // for(flag_HighLow=0; flag_HighLow < 2; flag_HighLow++){

		if(flag_err){
			ErrOp(flag_err); // error operation
			return;
		}
		//Updating WriteWordLen
		WriteWordLen -= (uint32_t)(writeBufCount);
	}
	PutStr("Write Completed ",1);
}

void ChipErase_Spn_X8(void)
{
//16bit(8bitx2)�̃t���b�V���������{�[�h
	uint16_t	readData;
	uint32_t	i;

	PutStr("Flash Board MEMORY ALL CLEAR... Please wait ",1);

// RESET COMMAND
	*((volatile uint16_t *)FLASH_OFFSET) = DATA_F0F0;
	__asm__ __volatile__ ("dsb sy");

// CHIP ERASE
	*((volatile uint16_t *) (FLASH_OFFSET + FLASH_AD_AAA)) = DATA_AAAA;	//	unlock cycle 1
	__asm__ __volatile__ ("dsb sy");
	*((volatile uint16_t *) (FLASH_OFFSET + FLASH_AD_555)) = DATA_5555;	//	unlock cycle 2
	__asm__ __volatile__ ("dsb sy");
	*((volatile uint16_t *) (FLASH_OFFSET + FLASH_AD_AAA)) = DATA_8080;	//	setup command
	__asm__ __volatile__ ("dsb sy");
	*((volatile uint16_t *) (FLASH_OFFSET + FLASH_AD_AAA)) = DATA_AAAA;	//	additional unlock cycle 1
	__asm__ __volatile__ ("dsb sy");
	*((volatile uint16_t *) (FLASH_OFFSET + FLASH_AD_555)) = DATA_5555;	//	additional unlock cycle 2
	__asm__ __volatile__ ("dsb sy");
	*((volatile uint16_t *) (FLASH_OFFSET + FLASH_AD_AAA)) = DATA_1010;	//	chip erase command
	__asm__ __volatile__ ("dsb sy");

	i=0;
	while(1){
		readData=*((volatile uint16_t *) FLASH_OFFSET);
		if( (readData & 0x8080) ){
			break;
		}
		if(i==800000){
			PutStr(".",0);	i=0;
		}
		i=i+1;
	}
// RESET COMMAND
	*((volatile uint16_t *)FLASH_OFFSET) = DATA_F0F0;
	__asm__ __volatile__ ("dsb sy");

	PutStr("Completed ",1);
}

#endif				//ifdef COM_MV_ON or COM_LFCF_ON �����܂�

