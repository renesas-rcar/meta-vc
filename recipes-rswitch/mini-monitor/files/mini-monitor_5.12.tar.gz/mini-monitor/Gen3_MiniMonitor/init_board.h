#define RC7795SIPB0010S			0x77950000
#define RC7795SIPB0011S			0x77950011
#define RC7795SIPB0012S			0x77950012

extern uint32_t gPcbVer;

void Init_PFC_GPIO(void);
void InitEtherPhyReset(void);
void EtherPhyReset();
void SetEtherPhyRes(uint32_t lvl);
void InitLBSC(void);
void ChangeLBSC_Area0(void);
void ChangeLBSC_Spi(void);
void SelPcbVersion(void);
