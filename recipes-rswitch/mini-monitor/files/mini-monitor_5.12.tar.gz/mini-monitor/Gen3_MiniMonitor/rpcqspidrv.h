#define SPI_IOADDRESS_TOP		0x08000000		//RPC memory space 0x08000000-0x0BFFFFFF = 64MBytes
#define RPC_CLK_160M	160		//160MHz
#define RPC_CLK_133M	133		//133MHz V3M
#define RPC_CLK_80M		 80		// 80MHz
#define RPC_CLK_40M		 40		// 40MHz


void InitRPC_QspiFlashQuadExtMode(void);
void InitRPC_QspiFlash4FastReadExtMode(void);
void InitMainRPC(uint32_t clk);
void InitRPC_QspiFlash(void);
void InitRPC_QspiFlashBoard(void);


void InitRPC_SpiEnable_HyperBoot(void);


void SetRPC_SecConf(void);
void ReadConfigRegQspiFlash(uint32_t *cnfigReg);
void WriteRegisterQspiFlash(uint32_t statusReg, uint32_t configReg);
void WriteRegisterQspiFlash_Byte2(uint32_t statusReg, uint32_t configReg);
void SectorErase4QspiFlash(uint32_t sector_addr);
void WriteData4ppWithBufferQspiFlash(uint32_t addr, uint32_t source_addr);
void WriteData4ppQspiFlash(uint32_t addr, uint32_t writeData);
void WriteData4ppQspiFlash_CsCont(uint32_t addr, uint32_t *writeData,uint32_t cnt);
void WriteData4qppQspiFlash(uint32_t addr, uint32_t writeData);
uint32_t SingleFastReadQspiFlashData4Byte(uint32_t addr, uint32_t *readData);	//for QSPIx1ch
uint32_t SingleFastReadQspiFlashData1Byte(uint32_t addr, uint32_t *readData);	//for QSPIx1ch
uint32_t ReadAnyRegisterQspiFlash(uint32_t addr, unsigned char *readData);		// Add24bit,Data8bit
void WriteAnyRegisterQspiFlash(uint32_t addr, unsigned char writeData);			// Add24bit,Data8bit
void SetRPC_ClockMode(uint32_t clk);
void SetRPC_Clock_H3M3V3H(uint32_t clk);
void SetRPC_Clock_D3E3(uint32_t clk);
void SetRPC_Clock_V3M(uint32_t clk);
void QSpiIO_HIZ_ChgClkWA(void);
void WaitRpcTxEnd(void);

void InitRPC_QspiFlashFastReadExtMode(void);
void WriteDataPpWithBufferQspiFlash(uint32_t addr, uint32_t source_addr);

void ParameterSectorErase4QspiFlash(uint32_t sector_addr);
void ResetRPC(void);
void SetRPC_SSL_Delay(void);


uint32_t ReadQspiFlashID64(uint32_t *readData1,uint32_t *readData2);	//for QSPIx1ch

////////////////////////////////////////////////////////////////////
// rpcdrv.c  [QSPI Flash����]
////////////////////////////////////////////////////////////////////
void PowerOnRPC(void);
uint32_t ReadQspiFlashID(uint32_t *readData);	//for QSPIx1ch
uint32_t ReadStatusQspiFlash(uint32_t *readData);	//for QSPIx1ch
void WriteCommandQspiFlash(uint32_t command);	//for QSPIx1ch
void WriteDataWithBufferQspiFlash(uint32_t addr, uint32_t source_addr);	//for QSPIx1ch
void SectorEraseQspiFlash(uint32_t sector_addr);	//for QSPIx1ch
void InitRPC_ExtMode_QuadIORead(void);	//for QSPIx1ch
void InitRPC_ExtMode_4QuadIORead(void);	//for QSPIx1ch
void EnableQuadModeQspiFlashS25fs128s(void);
