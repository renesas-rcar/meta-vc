#include	"common.h"
#include	"common_func.h"
#include	"devdrv.h"

/************************************************************************/
/*NAME		: PutMes													*/
/************************************************************************/
int32_t PutMess(const char *const mess[])
{
	int32_t i=0;
	while(mess[i]){
		PutStr(mess[i],ENB_RTN);
		i++;
	}
	return(0);
}

int32_t PutMess1LineDisRtn(const char *const mess[])
{
	int32_t i=0;
	while(mess[i]){
		PutStr(mess[i],DIS_RTN);
		i++;
	}
	return(0);
}



/************************************************************************/
/*NAME		: PutStr													*/
/************************************************************************/
int32_t	PutStr(const char *str,char rtn)
{
	while(*str){
		PutChar(*str);
		str++;
	}
	if(rtn == 1){
		PutChar(CR_CODE);
		PutChar(LF_CODE);
	}
	return(0);

}

/************************************************************************/
/*NAME		: GetStr													*/
/************************************************************************/
int32_t	GetStr(char *str,char *chCnt)
{
	char	*intstr;
	int32_t	i;

	intstr = str;
	*chCnt=0;

	while(1)
	{
		i=1;
		while(i==1)
		{
			i=GetChar(str);
		}
		if(*str==CR_CODE) break;
		switch(*str)
		{
			case BS_CODE: if(*chCnt==0) break;
						  else
						  {
							 PutChar(BS_CODE);
							 PutChar(SP_CODE);
							 PutChar(BS_CODE);
							 *chCnt = *chCnt - 1;
							 str--;
						  }
						  break;
			case LF_CODE: break;
			default: PutChar(*str);
				     str++;
					 *chCnt = *chCnt+1;
		}
	}
	*str = 0;
	PutChar(LF_CODE);
	PutChar(CR_CODE);
	return(0);

}


/************************************************************************/
/*NAME		: GetStr_MemEd												*/
/************************************************************************/
int32_t	GetStr_MemEd(char *str,char *chCnt)
{
	char	*intstr;
	int32_t	i;

	intstr = str;
	*chCnt=0;

	while(1)
	{
		i=1;
		while(i==1)
		{
			i=GetChar(str);
		}
		if(*str==CR_CODE) break;
		switch(*str)
		{
			case BS_CODE: if(*chCnt==0) break;
						  else
						  {
							 PutChar(BS_CODE);
							 PutChar(SP_CODE);
							 PutChar(BS_CODE);
							 *chCnt = *chCnt - 1;
							 str--;
						  }
						  break;
			case LF_CODE: break;
			default: PutChar(*str);
				     str++;
					 *chCnt = *chCnt+1;
		}
		if(*intstr =='.'){
			break;
		}
		else if(*intstr =='^'){
			break;
		}
	}
	*str = 0;
	PutChar(LF_CODE);
	PutChar(CR_CODE);
	return(0);
}

/************************************************************************/
/*NAME		: Hex2decAscii	�i16�i���ް���10�i���������ނɕϊ��j		*/
/************************************************************************/
uint32_t Hex2DecAscii(int32_t hexdata,char *str,int32_t *chcnt)
{
	char Count;
	char countstart;
	uint32_t Compdata;

	unsigned char dataB;
	uint32_t dataL;
	uint32_t i;

	Count			= 0;
	countstart		= 0x0;
	dataB = 0;
	dataL = 10;
	while( dataL > 0 ){
		Compdata = 1;
		i = 1;
		while( i < dataL ){
			Compdata *= 10;
			i++;
		}
		while( hexdata >= Compdata ){
			hexdata -= Compdata;
			dataB++;
			countstart = 1;
		}
		if( countstart == 1 ){
			*(str++) = dataB + '0';
			Count++;
		}
		dataB = 0;
		dataL--;
	}

	if(Count==0){
		*str = '0';	str++;	Count++;
	}
	*str = NULL;
	*chcnt = Count;
	return(0);

}


/************************************************************************/

void	DelStr(int32_t delCnt)
{
	int32_t i,j;
	for(i=0;i<delCnt;i++){	PutChar(BS_CODE);for(j=0;j<100;j++); }
	for(i=0;i<delCnt;i++){	PutChar(' ');for(j=0;j<100;j++); }
	for(i=0;i<delCnt;i++){	PutChar(BS_CODE);for(j=0;j<100;j++); }
}

void ChgLtl2Lrg(char *str)
{
	while(*str!=0){
		if(('a' <= *str)&&(*str<='z'))
			*str -= 0x20;
		str++;
	}
}
char HexAscii2Data(unsigned char *buf,uint32_t *data)
{
	char chCnt;
	uint32_t tmpData;
	*data = 0;	chCnt = 0;

	ChgLtl2Lrg(buf);

	if(*buf=='@') return(3);
	while(*buf){
		if(('0'<= *buf)&&(*buf<='9')){
			tmpData = (uint32_t)(*buf - '0');
			*data <<= 4;
			*data |= tmpData;
		}else if(('A'<= *buf)&&(*buf<='F')){
			tmpData = (uint32_t)(*buf - 55);
			*data <<= 4;
			*data |= tmpData;
		}else{
			return(1);
		}
		buf++; chCnt++;
		if(chCnt>(SIZE_32BIT*2))	return(1);
	}
	return(0);
}

char HexAscii2Data_64(unsigned char *buf,uintptr_t *data)
{
	char chCnt;
	uintptr_t tmpData;
	*data = 0;	chCnt = 0;

	ChgLtl2Lrg(buf);

	if(*buf=='@') return(3);
	while(*buf){
		if(('0'<= *buf)&&(*buf<='9')){
			tmpData = (uintptr_t)(*buf - '0');
			*data <<= 4;
			*data |= tmpData;
		}else if(('A'<= *buf)&&(*buf<='F')){
			tmpData = (uintptr_t)(*buf - 55);
			*data <<= 4;
			*data |= tmpData;
		}else{
			return(1);
		}
		buf++; chCnt++;
		if(chCnt>(CPU_BYTE_SIZE*2))	return(1);
	}
	return(0);
}



char Data2HexAscii(uint32_t data,char *buf,char size)
{
	char loopCnt,i;
	uint32_t tmpData;
	switch(size){
	case SIZE_8BIT:
		data <<= (SIZE_32BIT*8-8); loopCnt=2;
		break;
	case SIZE_16BIT:
		data <<= (SIZE_32BIT*8-16); loopCnt=4;
		break;
	case SIZE_32BIT:
		data <<= (SIZE_32BIT*8-32); loopCnt=8;
		break;
	}
	for(i=0;i<loopCnt;i++,buf++){
		tmpData = (data >> (SIZE_32BIT*8-4));
		if(tmpData < 0x0a){ /* case 1 to 9 */
			*buf = (char)(tmpData + '0');
		}else{	/* case A to F */
			*buf = (char)(tmpData + 55);
		}
		data <<= 4;
	}
	*buf = 0;
	return(0);
}

char Data2HexAscii_64(uintptr_t data,char *buf,char size)
{
	char loopCnt,i;
	uintptr_t tmpData;
	switch(size){
	case SIZE_8BIT:
		data <<= (CPU_BYTE_SIZE*8-8); loopCnt=2;
		break;
	case SIZE_16BIT:
		data <<= (CPU_BYTE_SIZE*8-16); loopCnt=4;
		break;
	case SIZE_32BIT:
		data <<= (CPU_BYTE_SIZE*8-32); loopCnt=8;
		break;
#ifdef AArch64
	case SIZE_64BIT:
		data <<= (CPU_BYTE_SIZE*8-64); loopCnt=16;
		break;
#endif
	}
	for(i=0;i<loopCnt;i++,buf++){
		tmpData = (data >> (CPU_BYTE_SIZE*8-4));
		if(tmpData < 0x0a){ /* case 1 to 9 */
			*buf = (char)(tmpData + '0');
		}else{	/* case A to F */
			*buf = (char)(tmpData + 55);
		}
		data <<= 4;
	}
	*buf = 0;
	return(0);
}



char GetStrBlk(char *inStr,char *outStr,
			   char *chPtr,char method)
{
	char serchEnd,frstSpace,endCh;
	inStr = inStr + *chPtr;
	serchEnd = 0;	frstSpace = 0;
	while(!serchEnd){
		switch(*inStr){
			case ' ':   /* space Code */
				if(frstSpace)
					if((method==0)||(method==' ')){
						serchEnd = 1; *outStr = 0;
						endCh = ' ';
				}
				break;
			case 0:
				serchEnd = 1;	*outStr = 0;
				inStr++;
				endCh = 0;
				break;
			default:
				frstSpace=1;
				*outStr = *inStr;
				outStr++;
				break;
		}
		*chPtr += 1; inStr++;
	}
	return(endCh);
}





/****************************************************/
/*		�\�t�g�f�B���C								*/
/****************************************************/
void SoftDelay(uint32_t loop)
{
	volatile uint32_t i;
	for(i=0;i<loop;i++);
}

void WaitKeyIn_Y(void)
{
	uint32_t loop;
	char tmp;

	loop=1;
	while(loop){
		GetChar(&tmp);
		if((tmp=='y')||(tmp=='Y'))	loop=0;
	}
}

char WaitKeyIn_YorN(void)
{
	char tmp;

	while(1){
		GetChar(&tmp);
		if((tmp=='y')||(tmp=='Y')){			return(0);	}
		else if((tmp=='n')||(tmp=='N')){	return(1);	}
	}
}





//====================================================================
//"boot_init_dram.c  AArch32(CR7)�Ή�
//====================================================================
//--------------------------------------------------------------------
// AArch32(CR7)�Ή��BCR7�w��ŕW�����C�u�������N�G���[�B
// �W�����C�u�������g�p�����Bmemcpy�쐬�B
//--------------------------------------------------------------------
char *memcpy(char *s1,char *s2,unsigned long n)
{
	unsigned long i;

	for(i=0;i<n;i++){
		*s1 = *s2;
		s1++;	s2++;
	}
	return(s1);
}

//--------------------------------------------------------------------
//AArch32(CR7) gcc -Og �œK���Ή��B 
//("boot_init_dram.c: undefined reference to "__aeabi_llsr","__aeabi_llsl")
//--------------------------------------------------------------------
uint64_t __aeabi_llsl(uint64_t val, uint32_t shift)
{
//	shift &= 0x0000003F;		// AArch64�͂������̋���
	if(shift>=64) return 0;		// AArch32�͂������̋���

	uint32_t lo = (uint32_t)(val >> 0);
	uint32_t hi = (uint32_t)(val >> 32);

	uint32_t hi_lsb;
	if(shift==0)       hi_lsb = 0;
	else if(shift<=32) hi_lsb = (lo >> (32-shift));
	else               hi_lsb = (lo << (shift-32));

	uint32_t s_lo;
	if(shift<=31) s_lo = (lo << shift);
	else          s_lo = 0;

	uint32_t s_hi;
	if(shift<=31) s_hi = (hi << shift);
	else          s_hi = 0;

	return ((uint64_t)(s_hi|hi_lsb) << 32) | (s_lo);
}
uint64_t __aeabi_llsr(uint64_t val, uint32_t shift)
{
//	shift &= 0x0000003F;		// AArch64�͂������̋���
	if(shift>=64) return 0;		// AArch32�͂������̋���

	uint32_t lo = (uint32_t)(val >> 0);
	uint32_t hi = (uint32_t)(val >> 32);

	uint32_t lo_msb;
	if(shift==0)       lo_msb = 0;
	else if(shift<=32) lo_msb = (hi << (32-shift));
	else               lo_msb = (hi >> (shift-32));

	uint32_t s_lo;
	if(shift<=31) s_lo = (lo >> shift);
	else          s_lo = 0;

	uint32_t s_hi;
	if(shift<=31) s_hi = (hi >> shift);
	else          s_hi = 0;

	return ((uint64_t)(s_hi) << 32) | (s_lo|lo_msb);
}

