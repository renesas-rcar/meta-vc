#include	"common.h"
#include	"boarddrv.h"
#include	"cpudrv.h"
#include	"switch.h"
#include	"boardid.h"
#include	"reg_rcargen3.h"


//===========================================================================
//File:switch.h
//BOARD_CODE
//#define BD_SALVATOR_X			0x00000000	// R-Car H3_SIP/M3_SIP
//#define BD_KRIEK				0x00000001	// R-Car M3
//#define BD_STARTERKIT_PRO		0x00000002	// R-Car M3_SIP
//#define BD_EAGLE				0x00000003	// R-Car V3M	( EAGLE / EAGLE-R )
//#define BD_SALVATOR_XS		0x00000004	// R-Car H3_SIP/M3_SIP
//#define BD_DRAAK				0x00000005	// R-Car D3
//#define BD_STARTERKIT_PRE		0x00000006	// R-Car H3_SIP
//#define BD_KRIEK_DDR3			0x00000007	// R-Car M3
//#define BD_CONDOR				0x00000008	// R-Car V3H
//#define BD_EBISU				0x00000009	// R-Car E3		( EBISU_2D / EBISU4D )
//===========================================================================



uint32_t ChkBoardCode(void)
{
	uint8_t  boardID;
	uint32_t boardCode;

	boardID=gBoardId&BID_MASK;

	switch(boardID){
		case BID_SALVATOR_X		: boardCode = BD_SALVATOR_X;		break;
		case BID_KRIEK_LP4		: boardCode = BD_KRIEK_LP4;			break;
		case BID_STARTERKIT_PRO	: boardCode = BD_STARTERKIT_PRO;	break;
		case BID_EAGLE_D		: boardCode = BD_EAGLE;				break;
		case BID_EAGLE_R		: boardCode = BD_EAGLE;				break;
		case BID_SALVATOR_XS	: boardCode = BD_SALVATOR_XS;		break;
		case BID_DRAAK			: boardCode = BD_DRAAK;				break;
		case BID_STARTERKIT_PRE	: boardCode = BD_STARTERKIT_PRE;	break;
		case BID_KRIEK_DDR3		: boardCode = BD_KRIEK_DDR3;		break;
		case BID_CONDOR			: boardCode = BD_CONDOR;			break;
		case BID_EBISU_2D		: boardCode = BD_EBISU;				break;
		case BID_EBISU_4D		: boardCode = BD_EBISU;				break;
	}
	return(boardCode);
}



//== SPI / HYPER Interface Message ==========================================
// On Board SPI Flash Memory 128Mbit [S25FS128S]
const prg_tbl SwChgOnBoard_QSPI0[BOARD_COUNT] = {
	(void (*)())SwChgOnBoard_QSPI0_SALVATOR,
	(void (*)())SwChgOnBoard_QSPI0_KRIEK_DRAAK, //Kriek_LP4
	(void (*)())SwChgOnBoard_QSPI0_SKIT,
	(void (*)())SwChgOnBoard_QSPI0_128_EAGLE,
	(void (*)())SwChgOnBoard_QSPI0_SALVATOR,	//Salvator-XS (Salvator-X�Ɠ����j
	(void (*)())SwChgOnBoard_QSPI0_KRIEK_DRAAK,	//Draak (Kriek�Ɠ����j
	(void (*)())SwChgOnBoard_QSPI0_SKIT,		//SK_PRE�iSK_PRO�Ɠ����j
	(void (*)())SwChgOnBoard_QSPI0_KRIEK_DRAAK, //Kriek_DDR3
	(void (*)())SwChgOnBoard_QSPI0_128_EAGLE,	//CONDOR (Eagle�Ɠ����j
	(void (*)())SwChgOnBoard_QSPI0_KRIEK_DRAAK,	//EBISU  (Kriek,Draak�Ɠ����j
	(void (*)())SwChgOnBoard_QSPI0_other
};
void SwChgOnBoard_QSPI0_other(void){
	PutStr("Please set the switch to OnBoard-SPI0(128Mbit) side. Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(77);
}

// Ex Board SPI Flash Memory 128Mbit [S25FL512S]
const prg_tbl SwChgExSPI_QSPI0[BOARD_COUNT] = {
	(void (*)())SwChgExSPI_QSPI0_SALVATOR,
	(void (*)())SwChgExSPI_QSPI0_KRIEK_DRAAK,	//Kriek_LP4
	(void (*)())SwChgExSPI_QSPI0_SKIT,
	(void (*)())SwChgExSPI_QSPI0_EAGLE,
	(void (*)())SwChgExSPI_QSPI0_SALVATOR,		//Salvator-XS (Salvator-X�Ɠ����j
	(void (*)())SwChgExSPI_QSPI0_KRIEK_DRAAK,	//Draak (Kriek�Ɠ����j
	(void (*)())SwChgExSPI_QSPI0_SKIT,			//SK_PRE�iSK_PRO�Ɠ����j
	(void (*)())SwChgExSPI_QSPI0_KRIEK_DRAAK,	//Kriek_DDR3
	(void (*)())SwChgExSPI_QSPI0_EAGLE,			//CONDOR (Eagle�Ɠ����j
	(void (*)())SwChgExSPI_QSPI0_KRIEK_DRAAK,	//EBISU  (Kriek,Draak�Ɠ����j
	(void (*)())SwChgExSPI_QSPI0_other
};
void SwChgExSPI_QSPI0_other(void){
	PutStr("Please set the switch to QspiBoard-SPI0 side. Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(70);
}

// Hyper Flash Memory
const prg_tbl SwChgHyperFlash[BOARD_COUNT] = {
	(void (*)())SwChgHyperFlash_SALVATOR,
	(void (*)())SwChgHyperFlash_KRIEK_DRAAK,	//Kriek_LP4
	(void (*)())SwChgHyperFlash_SKIT,
	(void (*)())SwChgHyperFlash_other,			//EAGLE  No interface
	(void (*)())SwChgHyperFlash_SALVATOR,		//Salvator-XS (Salvator-X�Ɠ����j
	(void (*)())SwChgHyperFlash_KRIEK_DRAAK,	//Draak (Kriek�Ɠ����j
	(void (*)())SwChgHyperFlash_SKIT,			//SK_PRE�iSK_PRO�Ɠ����j
	(void (*)())SwChgHyperFlash_KRIEK_DRAAK,	//Kriek_DDR3
	(void (*)())SwChgHyperFlash_other,			//CONDOR No interface
	(void (*)())SwChgHyperFlash_KRIEK_DRAAK,	//EBISU (Kriek,Draak�Ɠ����j
	(void (*)())SwChgHyperFlash_other
};
void SwChgHyperFlash_other(void){
	PutStr("Please set the switch to HyperFlash side. Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(66);
}


// On Board SPI Flash Memory 512Mbit [S25FS512S]			//New Eagle
const prg_tbl SwChgOnBoard_QSPI0_512M[BOARD_COUNT] = {
	(void (*)())SwChgOnBoard_QSPI0_other,		//SALVATOR    No interface
	(void (*)())SwChgOnBoard_QSPI0_other,		//KRIEK_LP4   No interface
	(void (*)())SwChgOnBoard_QSPI0_other,		//SK_PRO   T  No interface
	(void (*)())SwChgOnBoard_QSPI0_512_EAGLE,
	(void (*)())SwChgOnBoard_QSPI0_other,		//SALVATOR-XS No interface
	(void (*)())SwChgOnBoard_QSPI0_other,		//Draak       No interface
	(void (*)())SwChgOnBoard_QSPI0_other,		//SK_PRE      No interface
	(void (*)())SwChgOnBoard_QSPI0_other,		//KRIEK_DDR3  No interface
	(void (*)())SwChgOnBoard_QSPI0_512_EAGLE,	//CONDOR (Eagle�Ɠ����j
	(void (*)())SwChgOnBoard_QSPI0_other,		//EBISU       No interface
	(void (*)())SwChgOnBoard_QSPI0_other
};
void SwChgOnBoard_QSPI0_512M_other(void){
	PutStr("Please set the switch to OnBoard-SPI0(512Mbit) side. Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(77);
}


//-- SALBATOR ---------------------------------------------------------------
void SwChgOnBoard_QSPI0_SALVATOR(void){
#if !defined(E3) && !defined(D3)
	PutStr("SW1 SW2 All ON!    Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(43);
	PutStr("SW3 OFF!           Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(43);
	PutStr("SW13 1pin-Side!    Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(43);
#endif
}
void SwChgExSPI_QSPI0_SALVATOR(void){
#if !defined(E3) && !defined(D3)
	PutStr("SW1 SW2 All ON!    Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(43);
	PutStr("SW3 OFF!           Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(43);
	PutStr("SW13 3pin-Side!    Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(43);
	PutStr("CN3 : QSPI Flash Board Set OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(43);
#endif
}
void SwChgHyperFlash_SALVATOR(void){
#if !defined(E3) && !defined(D3)
	PutStr("SW1 SW2 All OFF!   Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(43);
	PutStr("SW3 ON!            Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(43);
#endif
}

//-- KRIEK / DRAAK-----------------------------------------------------------
void SwChgOnBoard_QSPI0_KRIEK_DRAAK(void){
	if(CHK_EBISU_SP){		// Ebisu Specific
		PutStr("SW1 All ON!        Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(43);
	}else{	
		PutStr("SW1 SW2 All ON!    Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(43);
	}
	PutStr("SW3 OFF!           Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(43);
	PutStr("SW31 OFF!          Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(43);
	PutStr("SW13 1pin-Side!    Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(43);
}
void SwChgExSPI_QSPI0_KRIEK_DRAAK(void){
	if(CHK_EBISU_SP){		// Ebisu Specific
		PutStr("SW1 All ON!        Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(43);
	}else{
		PutStr("SW1 SW2 All ON!    Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(43);
	}
	PutStr("SW3 OFF!           Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(43);
	PutStr("SW31 OFF!          Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(43);
	PutStr("SW13 3pin-Side!    Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(43);
	PutStr("CN3 : QSPI Flash Board Set OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(43);
}
void SwChgHyperFlash_KRIEK_DRAAK(void){
	if(CHK_EBISU_SP){		// Ebisu Specific
		PutStr("SW1 All OFF!       Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(43);
	}else{
		PutStr("SW1 SW2 All OFF!   Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(43);
	}
	PutStr("SW3 ON!            Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(43);
	PutStr("SW31 ON!           Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(43);
}

//-- STARTER KIT ------------------------------------------------------------
void SwChgOnBoard_QSPI0_SKIT(void){
#if !defined(E3) && !defined(D3)
	PutStr("SW1    OFF!               Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(50);
	PutStr("SW6[3] OFF!               Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(50);
	PutStr("JP1 1pin-2pin Connection! Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(50);
#endif
}
void SwChgExSPI_QSPI0_SKIT(void){
#if !defined(E3) && !defined(D3)
	PutStr("SW1    OFF!               Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(50);
	PutStr("SW6[3] OFF!               Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(50);
	PutStr("JP1 3pin-2pin Connection! Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(50);
#endif
}
void SwChgHyperFlash_SKIT(void){
#if !defined(E3) && !defined(D3)
	PutStr("SW1    ON!                Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(50);
	PutStr("SW6[3] ON!                Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(50);
#endif
}

//-- EAGLE ------------------------------------------------------------------
void SwChgOnBoard_QSPI0_128_EAGLE(void){
#if !defined(E3) && !defined(D3)
	PutStr("SW5 3pin-Side! Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(39);
	PutStr("SW6 1pin-Side! Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(39);
	PutStr("SW7 All ON!    Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(39);
#endif
}
void SwChgExSPI_QSPI0_EAGLE(void){
#if !defined(E3) && !defined(D3)
	PutStr("SW5 3pin-Side! Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(39);
	PutStr("SW6 3pin-Side! Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(39);
	PutStr("SW7 All ON!    Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(39);
#endif
}
void SwChgOnBoard_QSPI0_512_EAGLE(void){
#if !defined(E3) && !defined(D3)
	PutStr("SW5 1pin-Side! Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(39);
//	PutStr("SW6 1pin-Side! Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(39);	// 1 or 3pin
	PutStr("SW7 All OFF!   Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(39);
#endif
}
//===========================================================================



//== LBSC EX_MEM Board Interface Message ======================================
#ifdef COM_LFCF_ON
const prg_tbl SwChgLbscArea[BOARD_COUNT] = {
	(void (*)())SwChgLbscArea_SALVATOR_KRIEK,	//SALVATOR
	(void (*)())SwChgLbscArea_SALVATOR_KRIEK,	//KRIEK_LP4
	(void (*)())SwChgLbscArea_other,			//SK_PRO       "EX_MEM" No interface
	(void (*)())SwChgLbscArea_other,			//EAGLE        "EX_MEM" No interface
	(void (*)())SwChgLbscArea_SALVATOR_KRIEK,	//SALVATOR-XS
	(void (*)())SwChgLbscArea_other,			//Draak        "EX_MEM" No interface
	(void (*)())SwChgLbscArea_other,			//SK_PRE       "EX_MEM" No interface
	(void (*)())SwChgLbscArea_SALVATOR_KRIEK,	//KRIEK_DDR3
	(void (*)())SwChgLbscArea_other,			//CONDOR       "EX_MEM" No interface
	(void (*)())SwChgLbscArea_other,			//EBISU        "EX_MEM" No interface
	(void (*)())SwChgLbscArea_other
};
void SwChgLbscArea_other(void){
	PutStr("Please set the switch to LBSC(EX_MEM) side. Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(68);
}

//-- SALBATOR ---------------------------------------------------------------
//-- KRIEK ------------------------------------------------------------------
void SwChgLbscArea_SALVATOR_KRIEK(void){
	PutStr("SW5,SW6 1pin side!        Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(50);
	PutStr("SW7 center!               Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(50);
	PutStr("Flash Board SW1 CS1 side! Setting OK? (Push Y key)",0);	WaitKeyIn_Y();	DelStr(50);
}
//STARTER KIT
//"EX_MEM" No interface

//-- EAGLE ------------------------------------------------------------------
void SwChgLbscArea_EAGLE(void){
	PutStr("Change LBSC Setting OK? (Push Y key)",0);				WaitKeyIn_Y();	DelStr(36);
}
#endif
//===========================================================================


void MessBoardFlagError(void){
		PutStr(" Error : Board flag not match",1);
}

