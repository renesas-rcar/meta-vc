char DecodeForm01(uintptr_t *para1st,
				  uintptr_t *para2nd);
char DecodeForm02(uintptr_t *para1st);
char DecodeForm02_1(uintptr_t *para1st);
char DecodeForm03(uintptr_t *para1st,
				 uintptr_t  *para2nd,
				 uintptr_t  *para3rd,
				 uint32_t   *setPara);
char DecodeForm04(uintptr_t *para1st,
				  uintptr_t *para2nd,
				  uintptr_t *para3rd,
				  uint32_t *setPara);
char DecodeHexAscStr(uintptr_t *para, char *buf);
char DecodeHexAscStr2(uintptr_t *para1st,
					  uintptr_t *para2nd,
					  char *buf);
char DecodeForm5(uintptr_t *para1st,
				 uintptr_t *para2nd,
				 uint32_t *setPara);
