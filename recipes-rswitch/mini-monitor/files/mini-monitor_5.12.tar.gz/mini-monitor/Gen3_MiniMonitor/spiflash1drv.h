//==============================================
// SPANSION  S25FS128SAGMFV10
//==============================================

#define SPIREG_CR3V 0x00800004			//Volatile Status and Configuration Registers (CR3V)

void FastRdQspiFlashS25s128s(uint32_t sourceSpiAdd,uint32_t destinationAdd,uint32_t byteCount);
void QuadIORdQspiFlashS25s128s(uint32_t sourceSpiAdd,uint32_t destinationAdd,uint32_t byteCount);
void FastRdManuQspiFlashS25s128s(uint32_t sourceSpiAdd,uintptr_t destinationAdd,uint32_t byteCount);
void SetSectorErase256kbQspiFlashS25s128s(void);
void SectorErase256kbQspiFlashS25s128s(uint32_t addr);
int32_t BulkEraseQspiFlashS25s128s(void);
void PageProgramQspiFlashS25s128s(uint32_t addr,uint32_t writeData);
void PageProgramQspiFlashS25s128s_CsCont(uint32_t addr, uint32_t *writeData,uint32_t byteCount);
void PageProgramWithBuffeQspiFlashS25s128s(uint32_t addr, uint32_t source_addr);
void SaveDataQspiFlashS25s128s(uintptr_t srcAdd,uint32_t svFlashAdd,uint32_t svSize);
void SaveDataQspiFlashS25s128s_CsCont_Byte(uintptr_t srcAdd,uint32_t svFlashAdd,uint32_t svSize);
void SaveDataQspiFlashS25s128s_CsCont(uintptr_t srcAdd,uint32_t svFlashAdd,uint32_t svSize);
void SaveDataWithBuffeQspiFlashS25s128s(uint32_t srcAdd,uint32_t svFlashAdd,uint32_t svSize);
void SectorEraseQspiFlashS25s128s(uint32_t EraseStatAdd,uint32_t EraseEndAdd);
void SectorRdQspiFlashS25s128s(uint32_t spiStatAdd,uint32_t distRamAdd);

void FastRd3adQspiFlashS25s128s (uint32_t sourceSpiAdd,uint32_t destinationAdd,uint32_t byteCount);

void SectorErase256kbQspiFlashS25s128s_D8(uint32_t addr);

void ParameterSectorErase4kbQspiFlashS25s128s(uint32_t addr);

