#include	"dgtable.h"
/**********************
*  TITLE              *
***********************/

const char *const StartMessMonitor[START_MESS_MON_LINE] = {
#ifdef Writer
				"R-Car Gen3 Writer",
#elif defined ScifBoot
				"R-Car Gen3 Scif Download MiniMonitor",
#else			
				"R-Car Gen3 MiniMonitor",
#endif
				MESSAGE_END,
};

const char *const VersionDate[VERSION_DATE_LINE] = {
				" V5.12 2019.06.17",
				MESSAGE_END,
};

const char *const AllHelpMess[ALL_HELP_MESS_LINE] = {
#ifdef	COM_H_ON

				"        MINI monitor command",
				" D  {sadr {eadr}}          memory dump  (DM sets dump size)",
#ifdef AArch64
				" DM {B|W|L|X}              set&disp dump mode",
#endif
#ifdef AArch32
				" DM {B|W|L}                set&disp dump mode",
#endif
				" F  [sadr] [eadr] [data]   fill memory",
				" FL [sadr] [eadr] [data]   fill memory(LONG)",
#ifdef AArch64
				" FX [sadr] [eadr] [data]   fill memory(LONG LONG)",
#endif
				" M  [adr]                  set memory(BYTE)",
				" MW [adr]                  set memory(WORD)",
				" ML [adr]                  set memory(LONG)",
#ifdef AArch64
				" MX [adr]                  set memory(LONG LONG)",
#endif
				" MV [sadr] [dadr] [len]    move memory",
				" RAMCK [sadr] [eadr/@size] ram read write check",
				" DDRCK                     DDR memory read write check",
#ifdef AArch64
				" DDRCK_8GB                 DDR memory read write check (DRAM_SIZE=8GB)",
#endif
				" L                         load program",
				" G  {start_adr}            go program",
#if defined(SpiBoot) || defined(ScifBoot)
				" LF                        load Program to Flash memory sub-board",
				" CF                        Clear Flash memory sub-board",
#endif
				" XCS                       Clear SpiFlash or HyperFlash",
				" XLS                       Load program to SpiFlash or HyperFlash",
				" XLS2                      SpiFlash or HyperFlash address input version of XLS command",
				" XINFO_SA0                 read SA0 Information (SpiFlash or HyperFlash)",
				" XINFO_SA0_S               set  SA0 Information (SpiFlash or HyperFlash)",
				" XINFO                     read SA3 Information (SpiFlash or HyperFlash)",
				" XINFO_S                   set  SA3 Information (SpiFlash or HyperFlash)",
				" SUP                       Scif speed UP (Change to speed up baud rate setting)",
				" READ_PMIC                 read PMIC Firmware from EEPROM",
				" SET_PMIC                  set  PMIC Firmware to EEPROM",
				" SET_IIC0                  set  IIC0 Slave Address",
				" IIC0_M [adr]              set  IIC0 memory(BYTE)",
				" SET_I2C0                  set  I2C0 Slave Address",
				" I2C0_M [adr]              set  I2C0 memory(BYTE)",
				" H                         help",
				MESSAGE_END,

#endif
};
