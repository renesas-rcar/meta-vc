#include	"common.h"
#include	"dgtable.h"
#include	"dginit.h"
#include	"dgmodul1.h"
#include	"dgmodul3.h"
#include	"dgmodul4.h"
#include	"spiflash1drv.h"
#include	"rpcqspidrv.h"
#include	"dgloadmodul.h"
#include	"boardid.h"
#include	"init_board.h"
#include	"cpudrv.h"

/********************************************************/
/*        ROM TABLE                                     */
/********************************************************/
const com_menu MonCom[COMMAND_UNIT] = {
/*--------------------- Basic command ------------------------------*/
	 "H"			, dgHelp							,  0	,
	 "D"			, dgDump							,  0	,
	 "DM"			, dgDumpMode						,  0	,
	 "F"			, dgFill_byte						,  0	,
	 "FL"			, dgFill_long						,  0	,
#ifdef AArch64
	 "FX"			, dgFill_longlong					,  0	,
#endif
	 "M"			, dgMemEdit_byte					,  0	,
	 "MW"			, dgMemEdit_word					,  0	,
	 "ML"			, dgMemEdit_long					,  0	,
#ifdef AArch64
	 "MX"			, dgMemEdit_longlong				,  0	,
#endif
	 "MV"			, dgMoveMemory						,  0	,
	 "RAMCK"		, dgRamTest							,  0	,
	 "DDRCK"		, dgDdrTest							,  0	,
	 "DDRCK_2GB"	, dgDdrTest_2GB						,  0	,	//Debug:for 2GB DDR setting check
#ifdef AArch64
	 "DDRCK_8GB"	, dgDdrTest_8GB						,  0	,
#endif
	 "L"			, dgLoad							,  0	,
	 "G"			, dgGo								,  0	,
#if defined(SpiBoot) || defined(ScifBoot)
	 "LF"			, dgLoadFlashGo						,  0	,	//Other than StarterKit
	 "CF"			, dgClear_FlashGo					,  0	,	//Other than StarterKit
#endif
	 "XCS"			, dgClearSpiflash0					,  0	,
	 "XLS"			, dgGen3LoadSpiflash0				,  0	,
	 "XLS2"			, dgGen3LoadSpiflash0_2				,  0	,
	 "XINFO_SA0"	, dgGen3InfoSpiflash0_SA0			,  0	,
	 "XINFO_SA0_S"	, dgGen3InfoSetSpiflash0_SA0		,  0	,
	 "XINFO"		, dgGen3InfoSpiflash0				,  0	,
	 "XINFO_S"		, dgGen3InfoSetSpiflash0			,  0	,
	 "SUP"			, dgScifSpeedUp						,  0	,
	 "READ_PMIC"	, dgReadPmicEeprom					,  0	,	// Salvator / Kriek / StarterKit / Condor / Ebisu only
	 "SET_PMIC"		, dgSetPmicEeprom					,  0	,	// Salvator / Kriek / StarterKit / Condor / Ebisu only
	 "SET_PMIC_M3N"	, dgSetPmicEepromM3N_WA				,  0	,	// Salvator only
	 "SET_IIC0"		, dgSetIIC0							,  0	,	// Salvator / Kriek / StarterKit / Ebisu only
	 "IIC0_M"		, dgMemEdit_Iic0					,  0	,	// Salvator / Kriek / StarterKit / Ebisu only
	 "SET_I2C0"		, dgSetI2C0							,  0	,	// Condor only
	 "I2C0_M"		, dgMemEdit_I2c0					,  0	,	// Condor / Draak only
/********************************************************/
	 "SET_AREA0"	, ChangeLBSC_Area0					,  0	,
	 "SET_LBSC"		, InitLBSC							,  0	,
	 "EXT_MODE"		, ExtModeOn							,  0	,
	 "WF"			, WriteCopytoFlash					,  0	,
	 "SET_BID"		, SetBoardID						,  0	,
#ifdef COM_DBG_ON
	 "PRR"			, debug_PrrCode						,  0	,
	 "CLR_PMIC"		, dgClearPmicEeprom					,  0	,
#endif
/********************************************************/
	 "XINFO_SA0_2"	, dgGen3InfoSpiflash0_SA0_Ver2		,  0	,	//����J
	 "XINFO_SA0_S2"	, dgGen3InfoSetSpiflash0_SA0_Ver2	,  0	,	//����J
/********************************************************/
	TBL_END			, 0									,  0
};

/********************************************************/
/*        RAM TABLE                                     */
/********************************************************/
uintptr_t gUDump[3];
uintptr_t gUMem[3];
uint32_t gUreg[17];
uint32_t gDumpMode;
uint32_t gSPIDump[3];
uint32_t gIic0Mem[3];
uint32_t gIic0Dump[3];
uint32_t gI2c0Mem[3];
uint32_t gI2c0Dump[3];

