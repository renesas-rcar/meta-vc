//Set Parameter for SCIF Download mode
.EQU	AUTH_SELECT		,	0x00000000	// Set Authorization select
.EQU	WRITER_TYPE		,	0x00000000	// Set Writer Type
.EQU	WRITER_ADD		,	0xEB203A00	// Set Writer Address   (MiniMonotor Start Address)
.EQU	WRITER_SIZE 	,	0x00030000	// Set Writer data size (MiniMonitor Size)
.EQU	WRITER_KYE_SIZE	,	0x00000000	// Set Writer key size

