//Set Parameter for SCIF Download mode
.EQU	AUTH_SELECT	,	0x00000000	// Set Authorization select
.EQU	WRITER_TYPE	,	0x00000000	// Set Writer Type
.EQU	WRITER_ADD	,	0xE6302000	// Set Writer Address   (MiniMonotor Start Address)
.EQU	WRITER_SIZE	,	0x0002C000	// Set Writer data size (MiniMonitor Size)

