/*************************************************************************************/
/*                                                                                   */
/*            Program Command : Write Buffer Version                                 */
/*                                                                                   */
/*************************************************************************************/

#define FLASH_OFFSET		0x04000000

//S29GL
#define S29GL_X16_OnBoard	0x0001
#define S29GL_X8_FlashBoard	0x0101

#define S29GL_X16_OnBoard_DevID		0x227E			//Add 2015.08.03
#define S29GL_X8_FlashBoard_DevID	0x7E7E			//Add 2015.08.03

#define FLASH_AD_02A		0x0054  // 0x02A << 1
#define FLASH_AD_054		0x00A8	// 0x054 << 1
#define FLASH_AD_055		0x00AA	// 0x055 << 1
#define FLASH_AD_0AA		0x0154	// 0x0AA << 1
#define FLASH_AD_555		0x0AAA	// 0x555 << 1
#define FLASH_AD_2AA		0x0554	// 0x2AA << 1
#define FLASH_AD_AAA		0x1554	// 0xAAA << 1

#define DATA_00AA			0x00AA
#define DATA_0055			0x0055
#define DATA_0090			0x0090
#define DATA_00F0			0x00F0
#define DATA_0030			0x0030
#define DATA_0080			0x0080
#define DATA_0020			0x0020
#define DATA_00A0			0x00A0
#define DATA_0000			0x0000
#define DATA_0010			0x0010
#define DATA_0025			0x0025
#define DATA_0029			0x0029
#define DATA_0098			0x0098


#define DATA_AAAA			0xAAAA
#define DATA_5555			0x5555
#define DATA_9090			0x9090
#define DATA_F0F0			0xF0F0
#define DATA_3030			0x3030
#define DATA_8080			0x8080
#define DATA_2020			0x2020
#define DATA_A0A0			0xA0A0
#define DATA_1010			0x1010
#define DATA_2525			0x2525
#define DATA_2929			0x2929
#define DATA_9898			0x9898


#define HIGH_DEVICE_MASK			0x00FF
#define LOW_DEVICE_MASK				0xFF00
#define ERR_LOW_DEV_TIMEOUT			0x1
#define ERR_HIGH_DEV_TIMEOUT		0x2
#define ERR_LOW_DEV_ABORT			0x4
#define ERR_HIGH_DEV_ABORT			0x8

#define DATA_FFFF					0xFFFF
#define ERR_ERASE_LOW_DEV_TIMEOUT	0x10
#define ERR_ERASE_HIGH_DEV_TIMEOUT	0x20

int32_t FlashDetect(void);
void RdFlashMakerCode_X8(uint16_t *makerCode , uint16_t *devIDWord1);
int32_t GetFlashWrtBufSize_X8(void);

void SectorErase_Spn_X16(uint32_t EraseStatAdd,uint32_t EraseEndAdd);
void Program_Spn_X16(uintptr_t PrgStatAdd,uintptr_t PrgEndadd,uintptr_t CopyAdd);
void ChipErase_Spn_X16(void);

void SectorErase_Spn_X8(uint32_t EraseStatAdd,uint32_t EraseEndAdd);
void Program_Spn_X8(uintptr_t PrgStatAdd,uintptr_t PrgEndadd,uintptr_t CopyAdd);
void ChipErase_Spn_X8(void);

void HighLow_DeviceMask(uint16_t* pData, uint16_t HighLow);
void ErrOp(uint16_t flag_err);
