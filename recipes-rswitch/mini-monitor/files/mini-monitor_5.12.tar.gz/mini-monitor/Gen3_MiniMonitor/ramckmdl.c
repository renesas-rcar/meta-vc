#include	"dgtable.h"

// ���̃\�[�X�t�@�C���𑬓x�ōœK��
#pragma GCC optimize ("Og")

#include "common.h"

extern uintptr_t gSubErrAdd;
extern uintptr_t gSubErrData;
extern uintptr_t gSubTrueData;


///////////////////////////////////////////////////////////////////////////////////////////////////
// Function : CheckAndFillData8Bit                                                               //
// Parameter: startAddr = �J�n�A�h���X                                                           //
//          : endAddr   = �I���A�h���X (endAddr-startAddr=8bit*16=0x10���E�ɍ��킹��)            //
//          : writeData = Verify��ɏ������ރf�[�^                                               //
//          : checkData = Verify����f�[�^                                                       //
// Return   : NORMAL_END = 0 = ����I��                                                          //
//          : ERROR_END  = 1 = �ُ�I�� �� gSubErrAdd,gSubErrData,gSubTrueData�ɃG���[���i�[   //
// Outline  : �w��A�h���X���̃f�[�^���x���t�@�C���f�[�^����������(8Bit�P��)                 //
///////////////////////////////////////////////////////////////////////////////////////////////////
int32_t CheckAndFillData8Bit( uint8_t *startAddr, uint8_t *endAddr, uint8_t writeData, uint8_t checkData )
{
#ifdef COM_RAMCK_ON

	volatile uint8_t *pData;
	pData = (uint8_t *)startAddr;
	while(1){
		if(*pData!=checkData) break;  *(pData++) = writeData;
		if(*pData!=checkData) break;  *(pData++) = writeData;
		if(*pData!=checkData) break;  *(pData++) = writeData;
		if(*pData!=checkData) break;  *(pData++) = writeData;
		if(*pData!=checkData) break;  *(pData++) = writeData;
		if(*pData!=checkData) break;  *(pData++) = writeData;
		if(*pData!=checkData) break;  *(pData++) = writeData;
		if(*pData!=checkData) break;  *(pData++) = writeData;
		if(*pData!=checkData) break;  *(pData++) = writeData;
		if(*pData!=checkData) break;  *(pData++) = writeData;
		if(*pData!=checkData) break;  *(pData++) = writeData;
		if(*pData!=checkData) break;  *(pData++) = writeData;
		if(*pData!=checkData) break;  *(pData++) = writeData;
		if(*pData!=checkData) break;  *(pData++) = writeData;
		if(*pData!=checkData) break;  *(pData++) = writeData;
		if(*pData!=checkData) break;  *(pData++) = writeData;
		if( pData >= endAddr )  return NORMAL_END;
	}
#ifdef AArch64
	gSubErrAdd   = (uint64_t)pData;
	gSubErrData  = (uint64_t)*pData;
	gSubTrueData = (uint64_t)checkData;
#endif
#ifdef AArch32
	gSubErrAdd   = (uint32_t)pData;
	gSubErrData  = (uint32_t)*pData;
	gSubTrueData = (uint32_t)checkData;
#endif
	return ERROR_END;

#endif
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Function : FillData8Bit                                                                       //
// Parameter: startAddr = �J�n�A�h���X                                                           //
//          : endAddr   = �I���A�h���X (endAddr-startAddr=8bit*16=0x10���E�ɍ��킹��)            //
//          : writeData = �������ރf�[�^                                                         //
// Return   : NORMAL_END = 0 = ����I��                                                          //
// Outline  : �w��A�h���X���Ƀf�[�^����������(8Bit�P��)                                         //
///////////////////////////////////////////////////////////////////////////////////////////////////
int32_t FillData8Bit( uint8_t *startAddr, uint8_t *endAddr, uint8_t writeData )
{
	volatile uint8_t *pData;
	pData = (uint8_t *)startAddr;
	while(1){
		*(pData++) = writeData;
		*(pData++) = writeData;
		*(pData++) = writeData;
		*(pData++) = writeData;
		*(pData++) = writeData;
		*(pData++) = writeData;
		*(pData++) = writeData;
		*(pData++) = writeData;
		*(pData++) = writeData;
		*(pData++) = writeData;
		*(pData++) = writeData;
		*(pData++) = writeData;
		*(pData++) = writeData;
		*(pData++) = writeData;
		*(pData++) = writeData;
		*(pData++) = writeData;
		if( pData >= endAddr )  return NORMAL_END;
	}
	return NORMAL_END;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Function : CheckData8Bit                                                                      //
// Parameter: startAddr = �J�n�A�h���X                                                           //
//          : endAddr   = �I���A�h���X (endAddr-startAddr=8bit*16=0x10���E�ɍ��킹��)            //
//          : checkData = Verify����f�[�^                                                       //
// Return   : NORMAL_END = 0 = ����I��                                                          //
//          : ERROR_END  = 1 = �ُ�I�� �� gSubErrAdd,gSubErrData,gSubTrueData�ɃG���[���i�[   //
// Outline  : �w��A�h���X���̃f�[�^���x���t�@�C����(8Bit�P��)                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////
int32_t CheckData8Bit( uint8_t *startAddr, uint8_t *endAddr, uint8_t checkData )
{
#ifdef COM_RAMCK_ON

	volatile uint8_t *pData;
	pData = (uint8_t *)startAddr;
	while(1){
		if(*(pData++)!=checkData) break;
		if(*(pData++)!=checkData) break;
		if(*(pData++)!=checkData) break;
		if(*(pData++)!=checkData) break;
		if(*(pData++)!=checkData) break;
		if(*(pData++)!=checkData) break;
		if(*(pData++)!=checkData) break;
		if(*(pData++)!=checkData) break;
		if(*(pData++)!=checkData) break;
		if(*(pData++)!=checkData) break;
		if(*(pData++)!=checkData) break;
		if(*(pData++)!=checkData) break;
		if(*(pData++)!=checkData) break;
		if(*(pData++)!=checkData) break;
		if(*(pData++)!=checkData) break;
		if(*(pData++)!=checkData) break;
		if( pData >= endAddr )  return NORMAL_END;
	}
	pData--;									// break�O��++���Ă���̂łЂƂ߂�
#ifdef AArch64
	gSubErrAdd   = (uint64_t)pData;
	gSubErrData  = (uint64_t)*pData;
	gSubTrueData = (uint64_t)checkData;
#endif
#ifdef AArch32
	gSubErrAdd   = (uint32_t)pData;
	gSubErrData  = (uint32_t)*pData;
	gSubTrueData = (uint32_t)checkData;
#endif
	return ERROR_END;

#endif
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Function : WriteIncData8Bit                                                                   //
// Parameter: startAddr = �J�n�A�h���X                                                           //
//          : endAddr   = �I���A�h���X (endAddr-startAddr=8bit*16=0x10���E�ɍ��킹��)            //
//          : startData = �J�n�f�[�^                                                             //
// Return   : NORMAL_END = 0 = ����I��                                                          //
//          : ERROR_END  = 1 = �ُ�I�� �� gSubErrAdd,gSubErrData,gSubTrueData�ɃG���[���i�[   //
// Outline  : �w��A�h���X���ɃC���N�������g�f�[�^(+1�����Z)����������(8Bit�P��)               //
///////////////////////////////////////////////////////////////////////////////////////////////////
int32_t WriteIncData8Bit( uint8_t *startAddr, uint8_t *endAddr, uint8_t startData )
{
#ifdef COM_RAMCK_ON

	volatile uint8_t *pData;
	pData = (uint8_t *)startAddr;
	while(1){
		*(pData++) = (startData++);
		*(pData++) = (startData++);
		*(pData++) = (startData++);
		*(pData++) = (startData++);
		*(pData++) = (startData++);
		*(pData++) = (startData++);
		*(pData++) = (startData++);
		*(pData++) = (startData++);
		*(pData++) = (startData++);
		*(pData++) = (startData++);
		*(pData++) = (startData++);
		*(pData++) = (startData++);
		*(pData++) = (startData++);
		*(pData++) = (startData++);
		*(pData++) = (startData++);
		*(pData++) = (startData++);
		if( pData >= endAddr )  return NORMAL_END;
	}
	return NORMAL_END;

#endif
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Function : CheckIncData8Bit                                                                   //
// Parameter: startAddr = �J�n�A�h���X                                                           //
//          : endAddr   = �I���A�h���X (endAddr-startAddr=8bit*16=0x10���E�ɍ��킹��)            //
//          : startData = �J�n�f�[�^                                                             //
// Return   : NORMAL_END = 0 = ����I��                                                          //
//          : ERROR_END  = 1 = �ُ�I�� �� gSubErrAdd,gSubErrData,gSubTrueData�ɃG���[���i�[   //
// Outline  : �w��A�h���X���̃C���N�������g�f�[�^���x���t�@�C����(8Bit�P��)                     //
///////////////////////////////////////////////////////////////////////////////////////////////////
int32_t CheckIncData8Bit( uint8_t *startAddr, uint8_t *endAddr, uint8_t startData )
{
#ifdef COM_RAMCK_ON

	volatile uint8_t *pData;
	pData = (uint8_t *)startAddr;
	while(1){
		if(*(pData++)!=(startData++)) break;
		if(*(pData++)!=(startData++)) break;
		if(*(pData++)!=(startData++)) break;
		if(*(pData++)!=(startData++)) break;
		if(*(pData++)!=(startData++)) break;
		if(*(pData++)!=(startData++)) break;
		if(*(pData++)!=(startData++)) break;
		if(*(pData++)!=(startData++)) break;
		if(*(pData++)!=(startData++)) break;
		if(*(pData++)!=(startData++)) break;
		if(*(pData++)!=(startData++)) break;
		if(*(pData++)!=(startData++)) break;
		if(*(pData++)!=(startData++)) break;
		if(*(pData++)!=(startData++)) break;
		if(*(pData++)!=(startData++)) break;
		if(*(pData++)!=(startData++)) break;
		if( pData >= endAddr )  return NORMAL_END;
	}
	pData--;									// break�O��++���Ă���̂łЂƂ߂�
	startData--;								// break�O��++���Ă���̂łЂƂ߂�
#ifdef AArch64
	gSubErrAdd   = (uint64_t)pData;
	gSubErrData  = (uint64_t)*pData;
	gSubTrueData = (uint64_t)startData;
#endif
#ifdef AArch32
	gSubErrAdd   = (uint32_t)pData;
	gSubErrData  = (uint32_t)*pData;
	gSubTrueData = (uint32_t)startData;
#endif
	return ERROR_END;

#endif
}

