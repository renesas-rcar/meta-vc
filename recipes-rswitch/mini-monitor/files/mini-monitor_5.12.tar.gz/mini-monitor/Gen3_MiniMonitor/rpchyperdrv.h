void InitRPC_HyperFlashExtMode(void);
void InitRPC_HyperFlash(void);
uint32_t ReadHyperFlashData(uint32_t addr, uint32_t *readData, uint32_t byteCount);
void WriteCommandHyperFlash(uint32_t addr, uint32_t command);
void WriteDataHyperFlash(uint32_t addr, uint32_t writeData);

////////////////////////////////////////////////////////////////////
// rpcdrv.c  [HyperFlash]
////////////////////////////////////////////////////////////////////
void WriteProtectDisable(void);
uint32_t ReadHyperFlashData8Byte(uint32_t addr, uint32_t *readData);	//for HyperFlash
uint32_t ReadStatusHyperFlash(uint32_t *readData);	//for HyperFlash
void WriteDataWithBufferHyperFlash(uint32_t addr, uint32_t source_addr);	//for HyperFlash
void WriteBufferOperationHyperFlash(uint32_t writeAddr, uint32_t source_addr);
