void InitDma01_Data(uint32_t prgStartAd, uint32_t sector_Ad, uint32_t accessCount);
void DisableDma01(void);
void ClearDmaCh01(void);
void StartDma01(void);
uint32_t WaitDma01(void);

void InitRtDmaCh0(uint32_t prgStartAd, uint32_t sector_Ad, uint32_t accessCount);
void DisableRtDmaCh0(void);
void ClearRtDmaCh0(void);
void StartRtDmaCh0_15(void);
uint32_t WaitRtDmaCh0(void);
