/*                                                                                           

*  Rswitch2 Configuration Tool - Forwarding Engine

*

*  Copyright (C) 2014 Renesas Electronics Corporation

*

*  This program is free software; you can redistribute it and/or modify it

*  under the terms and conditions of the GNU General Public License,

*  version 2, as published by the Free Software Foundation.

*

*  This program is distributed in the hope it will be useful, but WITHOUT

*  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or

*  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for

*  more details.

*  You should have received a copy of the GNU General Public License along wit

*  this program; if not, write to the Free Software Foundation, Inc.,

*  51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.

*

*  The full GNU General Public License is included in this distribution in

*  the file called "COPYING".

*/



#include "rswitch2tool.h"

#include "rswitch2_FWD.h"

#include <stdlib.h>

#include <math.h>

#include <inttypes.h>

#include <drivers/net/ethernet/renesas/rswitch2/rswitch2_fwd.h> 






#define DEFAULT_REPORT_PRINT '-'

#define INVALID_THRESHOLD_CONFIG_VAL 20

#define MAX_CSDN 255

#define MAX_PRIORITY 7
unsigned int           G_Reconfig = 0;

extern char          * gOptConfigFile;

static int             gFwdFd          = -1;

char gMACArray[RENESAS_RSWITCH2_MAX_FWD_TBL_ENTRY][18];

char gIPV4Array[RENESAS_RSWITCH2_MAX_IPV4_ENTRY][16];

struct rswitch2_fwd_config FWDConfig_t;







static void Print_uint128(uint128_t value)

{

    uint128_t hightemp = value;

    uint128_t lowtemp = 0;

    int length = 0, hlength = 0, llength = 0;

    if(hightemp > UINT64_MAX)

    {

        for(int i = 0; hightemp > UINT64_MAX; i++)

        {

            lowtemp = lowtemp + pow(10,i) * (hightemp % 10);

            hightemp = hightemp / 10;

        }

    }

    length = (int)((ceil(log10(value))+1)*sizeof(char)) - 1;

    hlength = (int)((ceil(log10(hightemp))+1)*sizeof(char)) - 1;

    llength = (int)((ceil(log10(lowtemp))+1)*sizeof(char)) - 1;



    printf("%"PRIu64"", (uint64_t)hightemp);



    if((lowtemp != 0) && ((hlength+llength) < length))

    {

        for(int i = (hlength + llength); i < length; i++)

            printf("0");                                    //in case lowtemp begins with one or multiple 0 characters

        printf("%"PRIu64"", (uint64_t)lowtemp);

    }

    for(int i = 0; i <= (24 - (length)); i++)

    printf(" ");

}


static bool SetConfig_Integer(mxml_node_t * ParentNode, char const * const Tag, uint32_t *structure, uint32_t ulimit)

{

    uint64_t Data = 0;

    char const * ch = NULL;

    if ((ch = SetConfig_GetText(ParentNode, ParentNode, Tag)) != NULL)

    {

        if (sscanf(ch, "%"PRIu64, &Data) != 1)

        {

            fprintf(stderr, "\nInvalid <%s>\n", Tag);

            return FALSE;

        }

        if(Data > ulimit)

        {

            printf("%s = %"PRIu64"\n", Tag, Data);

            fprintf(stderr, "Invalid <%s> - cannot be larger than %lu", Tag, ulimit);

            return FALSE;

        }

        *structure = Data;

        return TRUE;

    }

    return FALSE;

}





static bool SetConfig_BinaryText(mxml_node_t * ParentNode, char const * const Tag, uint32_t *structure, 

char const * const s1, char const * const s2, uint32_t l1, uint32_t l2)

{

    char const * ch = NULL;

    if((ch = SetConfig_GetText(ParentNode, ParentNode, Tag)) != NULL)

    {

        if(strncasecmp(ch, s1, l1) == 0)

        {

            

            *structure = TRUE;

            return TRUE;

        }

        else if (strncasecmp(ch, s2, l2) == 0)

        {

            

            *structure = FALSE;

            return TRUE;

        }

        else

        {

            fprintf(stderr, "\nInvalid <%s> - can only be \"%s\" or \"%s\"\n", 

            Tag, s1, s2);

            return FALSE;

        }

    }

    return FALSE;

}

static bool SetConfig_Destportnumber(mxml_node_t *portnumber, uint32_t *structure, uint32_t PortCount)
{
    uint32_t PortInt = 0;
    mxml_node_t *value = NULL;
    unsigned char  * PortChar[RENESAS_RSWITCH2_MAX_ETHERNET_PORTS];
    
    //printf("insife setport \n");
    if (strcasecmp("Dest-PortNumber", portnumber->value.element.name) == 0)
    {
        //printf("insife setport \n");
        if ((value = mxmlGetFirstChild(portnumber)) == NULL)
        {
            fprintf(stderr, "\n No <Dest-PortNumber>");
            return FALSE;
        }
        if (value->type != MXML_TEXT)
        {
            fprintf(stderr, "\n Invalid  <Dest-PortNumber>");
            return FALSE;

        }
       

        PortChar[PortCount] = value->value.text.string;
        //printf("PortNumchar = %s \n", PortChar[PortCount]);
        if (sscanf(PortChar[PortCount], "%u", &PortInt) != 1)
        {
            fprintf(stderr, "\n Invalid  <Dest-PortNumber>");
            return FALSE;
        }

        if (PortInt >= max_port_number)
        {
            fprintf(stderr, "\nInvalid  <Dest-PortNumber>, Range (0-%d)\n", (max_port_number-1));
            return FALSE;
        }
        //printf("Portnum = %d \n", PortInt);
        *structure = PortInt;
        return TRUE;
    }
    return FALSE;
    
}

static bool SetConfig_portnumber(mxml_node_t *portnumber, uint32_t *structure, uint32_t PortCount)
{
    uint32_t PortInt = 0;
    mxml_node_t *value = NULL;
    unsigned char  * PortChar[RENESAS_RSWITCH2_MAX_ETHERNET_PORTS];
    
    //printf("insife setport \n");
    if (strcasecmp("PortNumber", portnumber->value.element.name) == 0)
    {
        //printf("insife setport \n");
        if ((value = mxmlGetFirstChild(portnumber)) == NULL)
        {
            fprintf(stderr, "\n No <PortNumber>");
            return FALSE;
        }
        if (value->type != MXML_TEXT)
        {
            fprintf(stderr, "\n Invalid  <PortNumber>");
            return FALSE;

        }
       

        PortChar[PortCount] = value->value.text.string;
        //printf("PortNumchar = %s \n", PortChar[PortCount]);
        if (sscanf(PortChar[PortCount], "%u", &PortInt) != 1)
        {
            fprintf(stderr, "\n Invalid  <PortNumber>");
            return FALSE;
        }

        if (PortInt >= max_port_number)
        {
            fprintf(stderr, "\nInvalid  <PortNumber>, Range (0-%d)\n", (max_port_number-1));
            return FALSE;
        }
        //printf("Portnum = %d \n", PortInt);
        *structure = PortInt;
        return TRUE;
    }
    
    return FALSE;
    
}

static bool SetConfig_lockportnumber(mxml_node_t *portnumber, uint32_t *structure, uint32_t PortCount)
{
    uint32_t PortInt = 0;
    mxml_node_t *value = NULL;
    unsigned char  * PortChar[RENESAS_RSWITCH2_MAX_ETHERNET_PORTS];
    
    //printf("insife setport \n");
    if (strcasecmp("Source-Lock-Port", portnumber->value.element.name) == 0)
    {
        //printf("insife setport \n");
        if ((value = mxmlGetFirstChild(portnumber)) == NULL)
        {
            fprintf(stderr, "\n No <Source-Lock-Port>");
            return FALSE;
        }
        if (value->type != MXML_TEXT)
        {
            fprintf(stderr, "\n Invalid  <Source-Lock-Port>");
            return FALSE;

        }
       

        PortChar[PortCount] = value->value.text.string;
        //printf("PortNumchar = %s \n", PortChar[PortCount]);
        if (sscanf(PortChar[PortCount], "%u", &PortInt) != 1)
        {
            fprintf(stderr, "\n Invalid  <Source-Lock-Port>");
            return FALSE;
        }

        if (PortInt >= max_port_number)
        {
            fprintf(stderr, "\nInvalid  <Source-Lock-Port>, Range (0-%d)\n", (max_port_number-1));
            return FALSE;
        }
        //printf("Portnum = %d \n", PortInt);
        *structure = PortInt;
        return TRUE;
    }
    
    return FALSE;
    
}


static bool SetConfig_routingportnumber(mxml_node_t *portnumber, uint32_t *structure, uint32_t PortCount)
{
    uint32_t PortInt = 0;
    mxml_node_t *value = NULL;
    unsigned char  * PortChar[RENESAS_RSWITCH2_MAX_ETHERNET_PORTS];
    
    //printf("insife setport \n");
    if (strcasecmp("Routing-Port", portnumber->value.element.name) == 0)
    {
        //printf("insife setport \n");
        if ((value = mxmlGetFirstChild(portnumber)) == NULL)
        {
            fprintf(stderr, "\n No <Routing-Port>");
            return FALSE;
        }
        if (value->type != MXML_TEXT)
        {
            fprintf(stderr, "\n Invalid  <Routing-Port>");
            return FALSE;

        }
       

        PortChar[PortCount] = value->value.text.string;
        //printf("PortNumchar = %s \n", PortChar[PortCount]);
        if (sscanf(PortChar[PortCount], "%u", &PortInt) != 1)
        {
            fprintf(stderr, "\n Invalid  <Routing-Port>");
            return FALSE;
        }

        if (PortInt >= max_port_number)
        {
            fprintf(stderr, "\nInvalid  <Routing-Port>, Range (0-%d)\n", (max_port_number-1));
            return FALSE;
        }
        //printf("Portnum = %d \n", PortInt);
        *structure = PortInt;
        return TRUE;
    }
    
    return FALSE;
    
}

void FWD_Print_Configuration()
{
    int Count = 0;
    int Count2 = 0;
    int Count3 = 0;
    char first_print = 0;
    /*MAC Printing*/
    printf("\n======================================= FORWARDING ENGINE =====================================\n");
    if(FWDConfig_t.fwd_gen_config.bEnable)
    {
        printf("----------------------------  General Configuration  ---------------------------------\n");
        printf("VLAN-MODE    TPID\n");
        if(FWDConfig_t.fwd_gen_config.vlan_mode == 0x0)
        {
            printf("%s", "NO-VLAN");
        }
        if(FWDConfig_t.fwd_gen_config.vlan_mode == 0x1)
        {
            printf("%s", "CTAG");
        }
        if(FWDConfig_t.fwd_gen_config.vlan_mode == 0x2)
        {
            printf("%s", "STAG");
        }
        printf("%10x", FWDConfig_t.fwd_gen_config.tpid);
        for(Count = 0; Count < (max_port_number  + 1); Count++)
        {
            printf("\n-----------------------------  AGENT Specific   ------------------------------------\n");
            if(!FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].cpu)
            {
                printf("PortNumber");
                printf("%-16u \n", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].portnumber);
            }
            else
            {
                printf("CPU \n");
                
            }
                printf("VLAN-Reject-Unknown-Secure      VLAN-Reject-Unknown      VLAN-Search-Active    \n");
                printf("%s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].vlan_reject_unknown_secure ? "Enable" : "Disable");
                printf("%32s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].vlan_reject_unknown ? "Enable" : "Disable");
                printf("%25s\n", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].vlan_search_active ? "Enable" : "Disable");
            
                printf("MAC-HW-Migration   MAC-HW-LEARN   \n");
                printf("%s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].mac_hw_migration_active ? "Enable" : "Disable");
                printf("%19s \n", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].mac_hw_learn_active ? "Enable" : "Disable");
                printf("MAC-Reject-Unknown-Src-Secure   MAC-Reject-Unknown-Src      MAC-Src-Search-Active    \n");
                printf("%s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].mac_reject_unknown_src_secure_addr ? "Enable" : "Disable");
                printf("%32s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].mac_reject_unknown_src_addr ? "Enable" : "Disable");
                printf("%28s\n", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].mac_src_search_active ? "Enable" : "Disable");
                printf("MAC-Reject-Unknown-Dest-Secure   MAC-Reject-Unknown-Dest      MAC-Dest-Search-Active    \n");
                printf("%s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].mac_reject_unknown_dest_secure_addr ? "Enable" : "Disable");
                printf("%33s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].mac_reject_unknown_dest_addr ? "Enable" : "Disable");
                printf("%29s\n", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].mac_dest_search_active ? "Enable" : "Disable");
                printf("IP-HW-Migration   IP-HW-LEARN   \n");
                printf("%s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ip_hw_migration_active ? "Enable" : "Disable");
                printf("%18s \n", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ip_hw_learn_active ? "Enable" : "Disable");
                printf("IP-Reject-Unknown-Src-Secure   IP-Reject-Unknown-Src      IP-Src-Search-Active    \n");
                printf("%s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ip_reject_unknown_src_secure_addr ? "Enable" : "Disable");
                printf("%31s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ip_reject_unknown_src_addr ? "Enable" : "Disable");
                printf("%27s\n", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ip_src_search_active ? "Enable" : "Disable");
                printf("IP-Reject-Unknown-Dest-Secure   IP-Reject-Unknown-Dest      IP-Dest-Search-Active    \n");
                printf("%s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ip_reject_unknown_dest_secure_addr ? "Enable" : "Disable");
                printf("%32s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ip_reject_unknown_dest_addr ? "Enable" : "Disable");
                printf("%28s\n", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ip_dest_search_active ? "Enable" : "Disable");
                printf("IPV6-Extract   IPV4-Extract     L2-Stream        \n");
                printf("%s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ipv6_extract_active ? "Enable" : "Disable");
                printf("%15s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ipv4_extract_active ? "Enable" : "Disable");
                printf("%17s\n", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].l2_stream_enabled ? "Enable" : "Disable");
                printf("IPV6-Other   IPV6-TCP     IPV6-UDP       \n");
                printf("%s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ipv6_other_enabled ? "Enable" : "Disable");
                printf("%13s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ipv6_tcp_enabled ? "Enable" : "Disable");
                printf("%13s\n", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ipv6_udp_enabled ? "Enable" : "Disable");
                printf("IPV4-Other   IPV4-TCP     IPV4-UDP       \n");
                printf("%s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ipv4_other_enabled ? "Enable" : "Disable");
                printf("%13s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ipv4_tcp_enabled ? "Enable" : "Disable");
                printf("%13s\n", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ipv4_udp_enabled ? "Enable" : "Disable");
                printf("L3-Reject-Unknown-Secure-Stream   L3-Reject-Unknown-Stream     L3-Table       \n");
                printf("%s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].l3_reject_unknown_secure_stream ? "Enable" : "Disable");
                printf("%34s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].l3_reject_unknown_stream ? "Enable" : "Disable");
                printf("%29s\n", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].l3_tbl_active ? "Enable" : "Disable");
                
           
        }
    }
    if(FWDConfig_t.l3_stream_fwd.bEnable)
    {
        printf("\n-----------------------------  L3-Stream-Forwading   ------------------------------------\n");
        printf("MAX-L3-Unsecure-Entry   MAX-L3-Collision  L3-Hash-Equation\n");
        printf("%d", FWDConfig_t.l3_stream_fwd.max_l3_unsecure_entry);
        printf("%24d", FWDConfig_t.l3_stream_fwd.max_l3_collision);
        printf("%18d", FWDConfig_t.l3_stream_fwd.l3_hash_eqn);

    }
    if(FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.bEnable)
    {
        printf("\n-----------------------------  IPV4-Stream-Forwading   ------------------------------------\n");
        printf("IPV4-Hash-Equation   Hash-Destination-Port  Hash-Source-Port\n");
        printf("%d", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.hash_configuration.ipv4_hash_eqn);
        printf("%27s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.destination_port ? "Include" : "Exclude");
        printf("%23s\n", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.source_port ? "Include" : "Exclude");
        printf("Hash-Source-IP    Hash-Dest-IP   Hash-protocol  \n");
        printf("%s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.source_ip ? "Include" : "Exclude");
        printf("%18s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.destination_ip ? "Include" : "Exclude");
        printf("%15s\n", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.protocol ? "Include" : "Exclude");
        printf("Hash-CTAG-DEI    Hash-CTAG-PCP   Hash-CTAG-ID  \n");
        printf("%s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.ctag_dei ? "Include" : "Exclude");
        printf("%17s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.ctag_pcp ? "Include" : "Exclude");
        printf("%16s\n", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.ctag_vlan ? "Include" : "Exclude");
        printf("Hash-STAG-DEI    Hash-STAG-PCP   Hash-STAG-ID  \n");
        printf("%s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.stag_dei ? "Include" : "Exclude");
        printf("%17s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.stag_pcp ? "Include" : "Exclude");
        printf("%16s\n", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.stag_vlan ? "Include" : "Exclude");
        printf("Hash-STAG-DEI    Hash-STAG-PCP   Hash-STAG-ID  \n");
        printf("%s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.stag_dei ? "Include" : "Exclude");
        printf("%17s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.stag_pcp ? "Include" : "Exclude");
        printf("%16s\n", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.stag_vlan ? "Include" : "Exclude");
        printf("Hash-Dest-MAC    Hash-Src-MAC   \n");
        printf("%s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.dest_mac ? "Include" : "Exclude");
        printf("%17s\n", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.src_mac ? "Include" : "Exclude");
        printf("Destination-Port  Dest-IP    Source-IP \n");
        printf("%s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.destination_port ? "Include" : "Exclude");
        printf("%18s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.destination_ip ? "Include" : "Exclude");
        printf("%11s\n", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.source_ip ? "Include" : "Exclude");
        printf("CTAG-DEI  CTAG-PCP    CTAG-ID \n");
        printf("%s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ctag_dei ? "Include" : "Exclude");
        printf("%10s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ctag_pcp ? "Include" : "Exclude");
        printf("%12s\n", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ctag_vlan ? "Include" : "Exclude");
        printf("STAG-DEI  STAG-PCP    STAG-ID \n");
        printf("%s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.stag_dei ? "Include" : "Exclude");
        printf("%10s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.stag_pcp ? "Include" : "Exclude");
        printf("%12s\n", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.stag_vlan ? "Include" : "Exclude");
        if(FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entries)
        {
            printf("\n\n\n---------------------------  L3-IPV4-Stream-Entries  ------------------------------\n");
            printf("Dest-IP-Addr                  Src-IP-Addr                   Dest-MAC                   Src-MAC\n");
            printf("-------------------------------------------------------------------------------\n");
            for(Count = 0; Count < FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entries; Count++)
            {
                printf("%d.%d.%d.%d", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].destination_ip_addr[0], 
                FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].destination_ip_addr[1],
                FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].destination_ip_addr[2],
                FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].destination_ip_addr[3]);
                printf("%19d.%d.%d.%d", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].source_ip_addr[0], 
                FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].source_ip_addr[1],
                FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].source_ip_addr[2],
                FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].source_ip_addr[3]);
                printf("                       %02x:%02x:%02x:%02x:%02x:%02x   ", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.
                          ipv4_stream_fwd_entry[Count].dest_mac[0],
                FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].dest_mac[1], 
                FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].dest_mac[2],
                FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].dest_mac[3],
                FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].dest_mac[4],
                FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].dest_mac[5]);
                printf("       %02x:%02x:%02x:%02x:%02x:%02x \n", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.
                ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].src_mac[0],
                FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].src_mac[1], 
                FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].src_mac[2],
                FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].src_mac[3],
                FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].src_mac[4],
                FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].src_mac[5]);
                
            }
            printf("Destination-Port     Source-Port      CTAG--DEI      CTAG--PCP      CTAG-ID      STAG--DEI      STAG--PCP      STAG-ID\n");
            printf("-------------------------------------------------------------------------------\n");
            for(Count = 0; Count < FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entries; Count++)
            {
                printf("%d", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].destination_port); 
                printf("%21d", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].source_port); 
                printf("%17d", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].ctag_dei);
                printf("%15d", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].ctag_pcp);
                printf("%15d", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].ctag_vlan);
                printf("%15d", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].stag_dei);
                printf("%15d", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].stag_pcp);
                printf("%15d\n", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].stag_vlan);
            }
            
            printf("Security-Learn     Frame-Fmt-Code         Routing-Number      Routing-Valid      CPU-Mirror      Eth-Mirror      IPV-Update      IPV-Value\n");
            printf("-------------------------------------------------------------------------------\n");
            for(Count = 0; Count < FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entries; Count++)
            {
                printf("%s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].security_learn ? "Yes" : "No");
                if(FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].ipv4_stream_frame_format_code == ipv4_notcp_noudp)
                {
                    printf("%34s", "IPV4-NO-TCP-No-UDP");
                }
                else if(FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].ipv4_stream_frame_format_code == ipv4_udp)
                {
                    printf("%34s", "UDP");
                }
                else if(FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].ipv4_stream_frame_format_code == ipv4_tcp)
                {
                    printf("%34s", "TCP");
                }
                printf("%6d", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].routing_number);
                printf("%22s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].routing_valid ? "Yes" : "No");
                printf("%18s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].mirroring_config.
                      cpu_mirror_enable ? "Yes" : "No");
                printf("%16s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].mirroring_config.
                      eth_mirror_enable ? "Yes" : "No");
                printf("%16s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].mirroring_config.
                      ipv_config.ipv_update_enable ? "Yes" : "No");
                if(FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].mirroring_config.ipv_config.ipv_update_enable)
                {

                    printf("%18d\n", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
                          mirroring_config.ipv_config.ipv_value);
                }
                else
                {
                    printf("                   - \n");
                }
            }
            printf("Source Lock Ports \n");
            printf("-------------------------------------------------------------------------------\n");
            for(Count = 0; Count < FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entries; Count++)
            {
                if(FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.
                       ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].source_lock.cpu)
                {
                    printf("%s\n", "CPU");
                }
                for(Count2 = 0; Count2 < FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.
                   ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].source_lock.source_ports; Count2++)
                {
                    printf("Port%d\n",FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.
                       ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].source_lock.source_port_number[Count2]);
                    
                }
            }
            printf("Dest-Port-Number         \n");
            printf("-------------------------------------------------------------------------------\n");
            for(Count = 0; Count < FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entries; Count++)
            {
               for(Count2 = 0; Count2 < FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.
                   ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].destination_vector_config.dest_eth_ports; Count2++)
               {
                   
                   
                   printf("%5d", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
                   destination_vector_config.port_number[Count2]);
               }
               printf("\n");
            }
            printf("Dest-CPU       CSDN     \n");
            for(Count = 0; Count < FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entries; Count++)
            {
               printf("%s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].destination_vector_config.
                      cpu ? "Yes" : "No");
               if(FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].destination_vector_config.
                      cpu)
               {
                   printf("%15d\n", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].csdn);
               }
               else
               {
                   printf("                 -\n");
               }
            }  
        }
    }
    if(FWDConfig_t.l23_update.entries)
    {
        printf("------------------------------------------------------------------------------------------------------------------------------\n");
        printf("--------------------------------------Routing-Update-Table-----------------------------------------------------\n");
        printf("Routing-Number    RTAG      STAG-DEI    STAG-PCP    STAG-ID     CTAG-DEI    CTAG-PCP    CTAG-ID \n");
        for(Count = 0; Count < FWDConfig_t.l23_update.entries; Count++)
        {
            printf("%d", FWDConfig_t.l23_update.l23_update_config[Count].routing_number);
            printf("%18d", FWDConfig_t.l23_update.l23_update_config[Count].rtag);
            if(FWDConfig_t.l23_update.l23_update_config[Count].stag_dei_update)
            {
                printf("%10d", FWDConfig_t.l23_update.l23_update_config[Count].stag_dei);
            }
            else
            {
                printf("%10s", "-");
            }
            if(FWDConfig_t.l23_update.l23_update_config[Count].stag_pcp_update)
            {
                printf("%12d", FWDConfig_t.l23_update.l23_update_config[Count].stag_pcp);
            }
            else
            {
                printf("%12s", "-");
            }
            if(FWDConfig_t.l23_update.l23_update_config[Count].stag_vlan_update)
            {
                printf("%13d", FWDConfig_t.l23_update.l23_update_config[Count].stag_vlan);
            }
            else
            {
                printf("%13s", "-");
            }
            if(FWDConfig_t.l23_update.l23_update_config[Count].ctag_dei_update)
            {
                printf("%11d", FWDConfig_t.l23_update.l23_update_config[Count].ctag_dei);
            }
            else
            {
                printf("%11s", "-");
            }
            if(FWDConfig_t.l23_update.l23_update_config[Count].ctag_pcp_update)
            {
                printf("%12d", FWDConfig_t.l23_update.l23_update_config[Count].ctag_pcp);
            }
            else
            {
                printf("%12s", "-");
            }
            if(FWDConfig_t.l23_update.l23_update_config[Count].ctag_vlan_update)
            {
                printf("%13d\n", FWDConfig_t.l23_update.l23_update_config[Count].ctag_vlan);
            }
            else
            {
                printf("%13s", "-\n");
            }
            if(!first_print)
            {
                printf("TTL-Update    Src-MAC-Update      Dest-MAC             Routing-Ports     Routing-CPU \n");
                first_print = 1;
            }
            if(FWDConfig_t.l23_update.l23_update_config[Count].ttl_update)
            {
                printf("%s", "Yes");
            }
            else
            {
                printf("%s", "No");
            }
            if(FWDConfig_t.l23_update.l23_update_config[Count].src_mac_update)
            {
                printf("%14s", "Yes");
            }
            else
            {
                printf("%14s", "No");
            }
            if(FWDConfig_t.l23_update.l23_update_config[Count].dest_mac_update)
            {
                printf("%20x:%2x:%2x:%2x:%2x:%2x",FWDConfig_t.l23_update.l23_update_config[Count].dest_mac[0],FWDConfig_t.l23_update.l23_update_config[Count].dest_mac[1]
                                                ,FWDConfig_t.l23_update.l23_update_config[Count].dest_mac[2],FWDConfig_t.l23_update.l23_update_config[Count].dest_mac[3]
                                                ,FWDConfig_t.l23_update.l23_update_config[Count].dest_mac[4],FWDConfig_t.l23_update.l23_update_config[Count].dest_mac[5]);
            }
            else
            {
                printf("%8s:%2s:%2s:%2s:%2s:%2s", "--:--:--:--:--:--");
            }
            for(Count2 = 0; Count2 < FWDConfig_t.l23_update.l23_update_config[Count].routing_port_update.dest_eth_ports; Count2++)
            {
                 printf("%5d", FWDConfig_t.l23_update.l23_update_config[Count].routing_port_update.port_number[Count2]);
            }
            printf("%16s", FWDConfig_t.l23_update.l23_update_config[Count].routing_port_update.cpu ? "Yes\n" : "No\n");
        }
    }
}
static bool Is_Any_Duplicate_MAC(char MACAddr[][18], int MACSize)

{   

    char temp[18];

    int j, i;

    

    //~ // Sorting strings using bubble sort

    for (j = 0; j < MACSize - 1; j++)                                                                                                      

    {   

        for (i = j + 1; i < MACSize; i++)

        {   

            if (strcmp(MACAddr[j], MACAddr[i]) > 0)

            {   

                strcpy(temp, MACAddr[j]);

                strcpy(MACAddr[j], MACAddr[i]);

                strcpy(MACAddr[i], temp);

            }

        }

    }

    for (i = 0; i < MACSize; i++)

    { 

        if (strcmp(MACAddr[i], MACAddr[i+1]) == 0)

        {   

            fprintf(stderr, "\nDuplicate MAC Address with MAC : %s\n", MACAddr[i]);

            return FALSE;

        }

    }

    return TRUE;

}



static bool Is_Any_Duplicate_IPV4(char IPV4Add[][16], int IPV4Size)

{   

    char temp[18];

    int j, i;

    

    //~ // Sorting strings using bubble sort

    for (j = 0; j < IPV4Size - 1; j++)                                                                                                      

    {   

        for (i = j + 1; i < IPV4Size; i++)

        {   
           // printf("IPV4Add[j] = %s IPV4Add[i]= %s \n", IPV4Add[j], IPV4Add[i]);
            if (strcmp(IPV4Add[j], IPV4Add[i]) > 0)

            {   

                strcpy(temp, IPV4Add[j]);

                strcpy(IPV4Add[j], IPV4Add[i]);

                strcpy(IPV4Add[i], temp);

            }

        }

    }

    for (i = 0; i < IPV4Size; i++)

    { 

        if (strcmp(IPV4Add[i], IPV4Add[i+1]) == 0)

        {   

            fprintf(stderr, "\nDuplicate IPV4 Address with IP : %s\n", IPV4Add[i]);

            return FALSE;

        }

    }

    return TRUE;

}



static bool SetConfig_MAC(mxml_node_t * ParentNode, uint32_t structure[], const char * const Tag, uint32_t Count)

{

    char const    * XMLResult = NULL;

    char            MACChar0[32];

    char            MACChar1[32];

    char            MACChar2[32];

    char            MACChar3[32];

    char            MACChar4[32];

    char            MACChar5[32];

    uint8_t         sMAC[6];

    mxml_node_t   * MAC = NULL;
    if((MAC = mxmlFindElement(ParentNode, ParentNode, Tag, NULL, NULL, MXML_DESCEND_FIRST)) != NULL)

    {

        if ((XMLResult = SetConfig_GetText(ParentNode, ParentNode, Tag)) != NULL)

        {

            if (strlen(XMLResult) != 17)

            {

                fprintf(stderr, "\nInvalid <%s> (length) '%.31s'\n", Tag, XMLResult);

                return FALSE;

            }

            if(Tag != "Mask")

            strcpy (gMACArray[Count], XMLResult);



            if(sscanf(XMLResult, "%2s:%2s:%2s:%2s:%2s:%2s", MACChar0, MACChar1, MACChar2, MACChar3, MACChar4, MACChar5) != 6)

            {

                fprintf(stderr, "\nInvalid <%s> (hex) '%.31s'\n",

                Tag, XMLResult);

                return FALSE;

            }



            sMAC[0] = strtoul(MACChar0, 0, 16);
            //printf("sMAC[0]=%x\n",sMAC[0]);
            sMAC[1] = strtoul(MACChar1, 0, 16);
            //printf("sMAC[1]=%x\n",sMAC[1]);
            sMAC[2] = strtoul(MACChar2, 0, 16);
            //printf("sMAC[2]=%x\n",sMAC[2]);
            sMAC[3] = strtoul(MACChar3, 0, 16);
            //printf("sMAC[3]=%x\n",sMAC[3]);
            sMAC[4] = strtoul(MACChar4, 0, 16);
            //printf("sMAC[4]=%x\n",sMAC[4]);
            sMAC[5] = strtoul(MACChar5, 0, 16);
            //printf("sMAC[5]=%x\n",sMAC[5]);
            structure[0] = sMAC[0];

            structure[1] = sMAC[1];

            structure[2] = sMAC[2];

            structure[3] = sMAC[3];

            structure[4] = sMAC[4];

            structure[5] = sMAC[5];

        }

    }
    else
    {
        return FALSE;
    }

    if (NOT Is_Any_Duplicate_MAC(gMACArray, Count))

    {

        fprintf(stderr, "ERROR : Duplicate <MAC>\n", gOptConfigFile);

        return FALSE;

    }

    return TRUE;

}


static bool SetConfig_IPV4(mxml_node_t * ParentNode, uint32_t structure[], const char * const Tag, uint32_t Count)

{

    char const    * XMLResult = NULL;

    char            IPV4Char[4][32];

    uint32_t i  =0 ;
    uint32_t j = 0;
    uint32_t k = 0;

    

    uint8_t         sIPV4[6];
   // printf("Inside IPV4 \n");
    mxml_node_t   * IPV4 = NULL;

    if((IPV4 = mxmlFindElement(ParentNode, ParentNode, Tag, NULL, NULL, MXML_DESCEND_FIRST)) != NULL)

    {

        if ((XMLResult = SetConfig_GetText(ParentNode, ParentNode, Tag)) != NULL)

        {

            if (strlen(XMLResult) >= 15)

            {

                fprintf(stderr, "\nInvalid <%s> (length) '%.31s'\n", Tag, XMLResult);

                return FALSE;

            }

            if(Tag != "Mask")

            strcpy (gIPV4Array[Count], XMLResult);
            i = 0;
            j = 0;
            k = 0;
            while (XMLResult[i] != '\0') 
            {       /* Stop looping when we reach the null-character. */
                while (XMLResult[i] != '.') 
                {
                    //printf("j=%d k=%d %c\n", j,k,XMLResult[i]);    /* Print each character of the string. */
                    
                    IPV4Char[j][k] = XMLResult[i];
                    k++;
                    i++;
                    if(XMLResult[i] == '\0')
                    {
                        IPV4Char[j][k] = '\0';
                        break;
                    }
                }
                if(XMLResult[i] != '\0')
                {
                    i++;
                    IPV4Char[j][k] = '\0';
                    k = 0;
                }
                j++;
            }

#if 0

            if(sscanf(XMLResult, "%3s.%3s.%3s.%2s:%2s:%2s", MACChar0, MACChar1, MACChar2, MACChar3, MACChar4, MACChar5) != 6)

            {

                fprintf(stderr, "\nInvalid <%s> (hex) '%.31s'\n",

                Tag, XMLResult);

                return FALSE;

            }

#endif
            //printf("IPV4[0][1]=%c\n", IPV4Char[0][0]);
           // printf("IPV4[0][2]=%c\n", IPV4Char[0][1]);
           // printf("IPV4[0][3]=%c\n", IPV4Char[0][2]);
           // printf("IPV4[1][1]=%c\n", IPV4Char[1][0]);
           // printf("IPV4[1][2]=%c\n", IPV4Char[1][1]);
            //printf("IPV4[1][3]=%c\n", IPV4Char[1][2]);
           // printf("IPV4[2][1]=%c\n", IPV4Char[2][0]);
           // printf("IPV4[2][2]=%c\n", IPV4Char[2][1]);
           // printf("IPV4[2][3]=%c\n", IPV4Char[2][2]);
           // printf("IPV4[3][1]=%c\n", IPV4Char[3][0]);
           // printf("IPV4[3][2]=%c\n", IPV4Char[3][1]);
            //printf("IPV4[0]=%s\n", IPV4Char[0]);
            //printf("IPV4[1]=%s\n", IPV4Char[1]);
            //printf("IPV4[2]=%s\n", IPV4Char[2]);
            //printf("IPV4[3]=%s\n", IPV4Char[3]);
            
 
            sIPV4[0] = strtoul(IPV4Char[0], 0, 0);

            sIPV4[1] = strtoul(IPV4Char[1], 0, 0);

            sIPV4[2] = strtoul(IPV4Char[2], 0, 0);

            sIPV4[3] = strtoul(IPV4Char[3], 0, 0);



            structure[0] = sIPV4[0];

            structure[1] = sIPV4[1];

            structure[2] = sIPV4[2];

            structure[3] = sIPV4[3];
            //printf("structure[0]=%d \n", structure[0]);
            //printf("structure[1]=%d \n", structure[1]);
            //printf("structure[2]=%d \n", structure[2]);
            //printf("structure[3]=%d \n", structure[3]);

        }

    }
    else
    {

        return FALSE;
    }

    if (NOT Is_Any_Duplicate_IPV4(gIPV4Array, Count))

    {

        fprintf(stderr, "ERROR : Duplicate <IP>\n", gOptConfigFile);

        return FALSE;

    }

    return TRUE;

}


static bool Set_Config_L2L3_Update(mxml_node_t * L2L3UpdateNode)
{
    /*Entry*/
    mxml_node_t   * portnumber = NULL;
    mxml_node_t   * SecondNode = NULL;
   
    uint32_t    Count = 0;

    uint32_t    PortCount = 0;
    if((SecondNode = mxmlFindElement(L2L3UpdateNode, L2L3UpdateNode, "Entry", NULL, NULL, MXML_DESCEND_FIRST)) == NULL)
    {

        fprintf(stderr, "\nERROR : No <Entry> in <Routing-Update-Table>  in <Forwarding> in '%s'\n",

            gOptConfigFile);

        return FALSE;

    }
    else
    {
        Count = 0;
                
        for(; SecondNode != NULL; SecondNode = mxmlWalkNext(SecondNode, L2L3UpdateNode, MXML_NO_DESCEND))
        {        
            if (SecondNode->type != MXML_ELEMENT)
            {
                continue;
            }
            if(Count >= RSWITCH2_MAX_L2_3_UPDATE_ENTRIES)
            {
                fprintf(stderr, "ERROR : A maximum of %d <Entry> entries allowed in <Routing-Update-Table> in <Forwarding> in %s\n",
                    RSWITCH2_MAX_L2_3_UPDATE_ENTRIES, gOptConfigFile);
                return FALSE;
            }
            /* Check This Logic */
            if((portnumber = mxmlFindElement(SecondNode, SecondNode, "Routing-Port", NULL, NULL, MXML_DESCEND_FIRST)) == NULL)
            {
                if(NOT SetConfig_BinaryText(SecondNode, "Routing-CPU", &FWDConfig_t.l23_update.l23_update_config[Count].routing_port_update.cpu,
                    "Yes", "No", 3, 2))
                {
                    fprintf(stderr, "\nERROR : No <Routing-CPU> or <Routing-Port> in <Entry>  in <Routing-Update-Table> in <Forwarding> in '%s'\n",
                        gOptConfigFile);
                    return FALSE;
                }                        
            }
            else
            {    
                if(NOT SetConfig_BinaryText(SecondNode, "Routing-CPU", &FWDConfig_t.l23_update.l23_update_config[Count].routing_port_update.cpu,
                    "Yes", "No", 3, 2))
                {     
                }                        
                PortCount = 0;
                for(; portnumber != NULL; portnumber = mxmlWalkNext(portnumber, SecondNode, MXML_NO_DESCEND))
                {
                    if (portnumber->type != MXML_ELEMENT)
                    {
                        continue;
                    }
                    if(NOT SetConfig_routingportnumber(portnumber, 
                          &FWDConfig_t.l23_update.l23_update_config[Count].routing_port_update.port_number[PortCount], PortCount))
                    {
                        continue;
                    }
                    for(int i = 0; i < PortCount; i++)
                    {
                        if(FWDConfig_t.l23_update.l23_update_config[Count].routing_port_update.port_number[PortCount] == 
                            FWDConfig_t.l23_update.l23_update_config[Count].routing_port_update.port_number[i])
                        {
                            fprintf(stderr, "\nERROR: Duplicate <Routing-Port> '%d' in <Entry> in <Routing-Update-Table>  in <Forwarding> in '%s'\n",
                                    FWDConfig_t.l23_update.l23_update_config[Count].routing_port_update.port_number[PortCount], gOptConfigFile);
                            return FALSE;                               

                        }

                    }
                    PortCount++;
                }

                FWDConfig_t.l23_update.l23_update_config[Count].routing_port_update.dest_eth_ports = PortCount;

            } 

        
            if(NOT SetConfig_Integer(SecondNode, "Routing-Number",
                &FWDConfig_t.l23_update.l23_update_config[Count].routing_number, RSWITCH2_MAX_ROUTING_NUMBER))
            {    
            }
            if(NOT SetConfig_Integer(SecondNode, "RTAG-Update",
                &FWDConfig_t.l23_update.l23_update_config[Count].rtag, RSWITCH2_MAX_RTAG))
            {    
            }
            if(NOT SetConfig_Integer(SecondNode, "STAG-DEI",
                &FWDConfig_t.l23_update.l23_update_config[Count].stag_dei, RSWITCH2_MAX_STAG_DEI))
            {    
            }
            else
            {
                FWDConfig_t.l23_update.l23_update_config[Count].stag_dei_update = enable;
            }
            if(NOT SetConfig_Integer(SecondNode, "STAG-PCP",
                &FWDConfig_t.l23_update.l23_update_config[Count].stag_pcp, RSWITCH2_MAX_STAG_PCP))
            {    
            }
            else
            {
                FWDConfig_t.l23_update.l23_update_config[Count].stag_pcp_update = enable;
            }
            if(NOT SetConfig_Integer(SecondNode, "STAG-ID",
                &FWDConfig_t.l23_update.l23_update_config[Count].stag_vlan, RSWITCH2_MAX_STAG_VLAN))
            {    
            }
            else
            {
                FWDConfig_t.l23_update.l23_update_config[Count].stag_vlan_update = enable;
            }
            if(NOT SetConfig_Integer(SecondNode, "CTAG-DEI",
                &FWDConfig_t.l23_update.l23_update_config[Count].ctag_dei, RSWITCH2_MAX_CTAG_DEI))
            {    
            }
            else
            {
                FWDConfig_t.l23_update.l23_update_config[Count].ctag_dei_update = enable;
            }
            if(NOT SetConfig_Integer(SecondNode, "CTAG-PCP",
                &FWDConfig_t.l23_update.l23_update_config[Count].ctag_pcp, RSWITCH2_MAX_CTAG_PCP))
            {    
            }
            else
            {
                FWDConfig_t.l23_update.l23_update_config[Count].ctag_pcp_update = enable;
            }
            if(NOT SetConfig_Integer(SecondNode, "CTAG-ID",
                &FWDConfig_t.l23_update.l23_update_config[Count].ctag_vlan, RSWITCH2_MAX_CTAG_VLAN))
            {    
            }
            else
            {
                FWDConfig_t.l23_update.l23_update_config[Count].ctag_vlan_update = enable;
            }
            if (NOT SetConfig_MAC(SecondNode,  FWDConfig_t.l23_update.l23_update_config[Count].dest_mac, "Dest-MAC", Count))
            {           
            }
            else
            {
                FWDConfig_t.l23_update.l23_update_config[Count].dest_mac_update = enable;
            }
            if(NOT SetConfig_BinaryText(SecondNode, "Src-MAC-Update", &FWDConfig_t.l23_update.l23_update_config[Count].src_mac_update,"Enable", "Disable", 6, 7))
            {
            }
            if(NOT SetConfig_BinaryText(SecondNode, "TTL-Update", &FWDConfig_t.l23_update.l23_update_config[Count].ttl_update,"Enable", "Disable", 6, 7))
            {           
            }
            Count++;        
        }
        FWDConfig_t.l23_update.entries = Count;
        printf("Entries = %d \n", FWDConfig_t.l23_update.entries);
    }

    return TRUE;
}

static bool Set_Config(mxml_node_t * Tree, const char * const PortNode)

{
    mxml_node_t   * L2L3UpdateNode;
    mxml_node_t   * ForwardingEngine = NULL;
    mxml_node_t   * StreamNode = NULL; 
    mxml_node_t   * LockNode = NULL;
    mxml_node_t   * PortLockNode = NULL;
    uint32_t SourceLockCount = 0;
    mxml_node_t   * portnumber = NULL;

    

    mxml_node_t   * FirstNode = NULL;

    mxml_node_t   * SecondNode = NULL;

    mxml_node_t   * ThirdNode = NULL;

    mxml_node_t   * FourthNode = NULL;

    mxml_node_t   * FifthNode = NULL;

    mxml_node_t   * value = NULL;

    uint32_t    CPU = 0;



    uint32_t    Count = 0;

    uint32_t    PortCount = 0;


    char const    * XMLResult = NULL;

    char  const   * ch = NULL;

    

    
    

    
    unsigned int GenCPU = 0;
    unsigned int GenPort = 0;
    

    if ((ForwardingEngine = mxmlFindElement(Tree, Tree, PortNode, NULL, NULL, MXML_DESCEND_FIRST)) == NULL)

    {

        fprintf(stderr, "\nERROR : Unable to find <%s> in '%s'\n",

        PortNode, gOptConfigFile);

        return FALSE;

    }

    if ((FirstNode = mxmlFindElement(ForwardingEngine, ForwardingEngine, "General-Configuration", NULL, NULL, MXML_DESCEND_FIRST)) != NULL)

    {
        /*VLAN-Mode*/

        if ((ch = SetConfig_GetText(FirstNode, FirstNode, "VLAN-Mode")) != NULL)

        {

            if (strncasecmp(ch, "No-VLAN", 7) == 0)

            {

                FWDConfig_t.fwd_gen_config.vlan_mode = 0;

            }

            else if (strncasecmp(ch, "CTAG", 4) == 0)

            {

                FWDConfig_t.fwd_gen_config.vlan_mode = 1;

            }

            else if (strncasecmp(ch, "STAG", 4) == 0)

            {

                FWDConfig_t.fwd_gen_config.vlan_mode = 2;

            }

            

            else

            {

                fprintf(stderr, "\nERROR: Invalid <VLAN-Mode> in <General-Configuration> in <Forwarding> in '%s'\n",

                gOptConfigFile);

                return FALSE;

            }

        }


        else

        {

            fprintf(stderr, "\nERROR: Unable to find <VLAN-Mode> in <General-Configuration> in <Forwarding> in '%s'\n",

            gOptConfigFile);

            return FALSE;

        }
        /*Priority*/

        if((NOT SetConfig_Integer(FirstNode, "TPID",

                    &FWDConfig_t.fwd_gen_config.tpid, RSWITCH2_MAX_TPID)) && (FWDConfig_t.fwd_gen_config.vlan_mode !=0))

        {

            fprintf(stderr, "ERROR : Unable to find <TPID> in <General-Configuration> in <Forwarding> in %s\n",

            gOptConfigFile);

            return FALSE;

        }
       

        /*Port-Specific*/

        if((SecondNode = mxmlFindElement(FirstNode, FirstNode, "Port-Specific", NULL, NULL, MXML_DESCEND_FIRST)) == NULL)

        {

            fprintf(stderr, "\nERROR : No <Port-Specific> in <General-Configuration> in <Forwarding> in '%s'\n",

            gOptConfigFile);

            return FALSE;

        }
        else

        {
            

            Count = 0;

            for(; SecondNode != NULL; SecondNode = mxmlWalkNext(SecondNode, FirstNode, MXML_NO_DESCEND))

            {

                if (SecondNode->type != MXML_ELEMENT)

                {

                    continue;

                }

                

                if(Count >= (max_port_number  + 1))

                {

                    fprintf(stderr, "ERROR : A maximum of %d <Port-Specific> entries allowed in <General-Configuration> in <Forwarding> in %s\n",

                    (max_port_number  + 1), gOptConfigFile);

                    return FALSE;

                }



                

              // printf("Port Number \n");
                /*portnumber*/
                if((portnumber = mxmlFindElement(SecondNode, SecondNode, "PortNumber", NULL, NULL, MXML_DESCEND_FIRST)) == NULL)

                {
                    /*CPU*/

                    if(NOT SetConfig_BinaryText(SecondNode, "CPU", &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].cpu,

                            "Yes", "No", 3, 2))

                    {
                        fprintf(stderr, "\nERROR: Unable to find <CPU> or <Portnumber> in <Port-Specific> in <General-Configuration> in <Forwarding> in '%s'\n",

                        gOptConfigFile);

                        return FALSE;

                    

                    }
                    else if (GenCPU == 1)
                    {

                        printf("GenCPU = %d \n", GenCPU);
                        fprintf(stderr, "\nERROR: Multiple <CPU>  in <Port-Specific> in <General-Configuration> in <Forwarding> in '%s'\n",

                        gOptConfigFile);

                        return FALSE;




                    }
                    else
                    {
                        
                        GenCPU = 1;
                    }
                    

                        

                }
                else
                {
                    printf("Gen Port \n");
                    GenPort = 1;

                }
                if(GenPort)
                {
                    if(NOT SetConfig_portnumber(portnumber, &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].portnumber, Count))

                    {

                            

                    }
                    GenPort = 0;
                }
                
                /*VLAN-Reject-Unknown-Secure*/

                if(NOT SetConfig_BinaryText(SecondNode, "VLAN-Reject-Unknown-Secure", &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].vlan_reject_unknown_secure,

                            "Enable", "Disable", 6, 7))

                {

                    

                }
                //printf("Reject VLAN \n");
                 /*VLAN-Reject-Unknown*/

                if(NOT SetConfig_BinaryText(SecondNode, "VLAN-Reject-Unknown", &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].vlan_reject_unknown,

                            "Enable", "Disable", 6, 7))

                {

                    

                }
                /*VLAN-Search-Active*/

                if(NOT SetConfig_BinaryText(SecondNode, "VLAN-Search-Active", &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].vlan_search_active,

                            "Enable", "Disable", 6, 7))

                {

                    

                }
                /*MAC-Hardware-Migration-Active*/

                if(NOT SetConfig_BinaryText(SecondNode, "MAC-Hardware-Migration-Active", &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].mac_hw_migration_active,

                            "Enable", "Disable", 6, 7))

                {

                    

                }
                /*MAC-Hardware-Learning-Active*/

                if(NOT SetConfig_BinaryText(SecondNode, "MAC-Hardware-Learning-Active", &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].mac_hw_learn_active,

                            "Enable", "Disable", 6, 7))

                {

                    

                }
                /*MAC-Reject-Unknown-Src-Secure-Addr*/

                if(NOT SetConfig_BinaryText(SecondNode, "MAC-Reject-Unknown-Src-Secure-Addr", 
                           &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].mac_reject_unknown_src_secure_addr,

                            "Enable", "Disable", 6, 7))

                {

                    

                }
                /*MAC-Reject-Unknown-Src-Addr*/

                if(NOT SetConfig_BinaryText(SecondNode, "MAC-Reject-Unknown-Src-Addr", 
                           &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].mac_reject_unknown_src_addr,

                            "Enable", "Disable", 6, 7))

                {

                    

                }
                 /*MAC-Src-Search-Active*/

                if(NOT SetConfig_BinaryText(SecondNode, "MAC-Src-Search-Active", 
                           &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].mac_src_search_active,

                            "Enable", "Disable", 6, 7))

                {

                    

                }
                 /*MAC-Reject-Unknown-Dest-Secure-Addr*/

                if(NOT SetConfig_BinaryText(SecondNode, "MAC-Reject-Unknown-Dest-Secure-Addr", 
                           &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].mac_reject_unknown_dest_secure_addr,

                            "Enable", "Disable", 6, 7))

                {

                    

                }
                 /*MAC-Reject-Unknown-Dest-Addr*/

                if(NOT SetConfig_BinaryText(SecondNode, "MAC-Reject-Unknown-Dest-Addr", 
                           &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].mac_reject_unknown_dest_addr,

                            "Enable", "Disable", 6, 7))

                {

                    

                }
                /*MAC-Dest-Search-Active*/

                if(NOT SetConfig_BinaryText(SecondNode, "MAC-Dest-Search-Active", 
                           &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].mac_dest_search_active,

                            "Enable", "Disable", 6, 7))

                {

                    

                }
                /*IP-Hardware-Migration-Active*/

                if(NOT SetConfig_BinaryText(SecondNode, "IP-Hardware-Migration-Active", 
                           &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ip_hw_migration_active,

                            "Enable", "Disable", 6, 7))

                {

                    

                }
                /*IP-Hardware-Learning-Active*/

                if(NOT SetConfig_BinaryText(SecondNode, "IP-Hardware-Learning-Active", 
                           &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ip_hw_learn_active,

                            "Enable", "Disable", 6, 7))

                {

                    

                }
               
                /*IP-Reject-Unknown-Src-Secure-Addr*/

                if(NOT SetConfig_BinaryText(SecondNode, "IP-Reject-Unknown-Src-Secure-Addr", 
                           &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ip_reject_unknown_src_secure_addr,

                            "Enable", "Disable", 6, 7))

                {

                    

                }
                 /*IP-Reject-Unknown-Src-Addr*/

                if(NOT SetConfig_BinaryText(SecondNode, "IP-Reject-Unknown-Src-Addr", 
                           &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ip_reject_unknown_src_addr,

                            "Enable", "Disable", 6, 7))

                {

                    

                }

                  /*IP-Src-Search-Active*/

                if(NOT SetConfig_BinaryText(SecondNode, "IP-Reject-Unknown-Secure", 
                           &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ip_src_search_active,

                            "Enable", "Disable", 6, 7))

                {

                    

                }
                /*IP-Reject-Unknown-Dest-Secure-Addr*/

                if(NOT SetConfig_BinaryText(SecondNode, "IP-Reject-Unknown-Dest-Secure-Addr", 
                           &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ip_reject_unknown_dest_secure_addr,

                            "Enable", "Disable", 6, 7))

                {

                    

                }
                 /*IP-Reject-Unknown-Dest-Addr*/

                if(NOT SetConfig_BinaryText(SecondNode, "IP-Reject-Unknown-Src-Addr", 
                           &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ip_reject_unknown_dest_addr,

                            "Enable", "Disable", 6, 7))

                {

                    

                }

                  /*IP-Dest-Search-Active*/

                if(NOT SetConfig_BinaryText(SecondNode, "IP-Reject-Unknown-Secure", 
                           &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ip_dest_search_active,

                            "Enable", "Disable", 6, 7))

                {

                    

                }
                  /*IPV6-Extract-Active*/

                if(NOT SetConfig_BinaryText(SecondNode, "IPV6-Extract-Active", 
                           &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ipv6_extract_active,

                            "Enable", "Disable", 6, 7))

                {

                    

                }
                 /*IPV4-Extract-Active*/

                if(NOT SetConfig_BinaryText(SecondNode, "IPV4-Extract-Active", 
                           &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ipv4_extract_active,

                            "Enable", "Disable", 6, 7))

                {

                    

                }
                 /*L2-Stream-Enabled*/

                if(NOT SetConfig_BinaryText(SecondNode, "L2-Stream", 
                           &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].l2_stream_enabled,

                            "Enable", "Disable", 6, 7))

                {

                    

                }
                 /*IPV6-OTHER*/

                if(NOT SetConfig_BinaryText(SecondNode, "IPV6-OTHER", 
                           &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ipv6_other_enabled,

                            "Enable", "Disable", 6, 7))

                {

                    

                }
                 /*IPV6-TCP*/

                if(NOT SetConfig_BinaryText(SecondNode, "IPV6-TCP", 
                           &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ipv6_tcp_enabled,

                            "Enable", "Disable", 6, 7))

                {

                    

                }
                 /*IPV6-UDP*/

                if(NOT SetConfig_BinaryText(SecondNode, "IPV6-UDP", 
                           &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ipv6_udp_enabled,

                            "Enable", "Disable", 6, 7))

                {

                    

                }
                 /*IPV4-OTHER*/

                if(NOT SetConfig_BinaryText(SecondNode, "IPV4-OTHER", 
                           &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ipv4_other_enabled,

                            "Enable", "Disable", 6, 7))

                {

                    

                }
                 /*IPV4-TCP*/

                if(NOT SetConfig_BinaryText(SecondNode, "IPV4-TCP", 
                           &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ipv4_tcp_enabled,

                            "Enable", "Disable", 6, 7))

                {

                    

                }
                 /*IPV4-UDP*/

                if(NOT SetConfig_BinaryText(SecondNode, "IPV4-UDP", 
                           &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ipv4_udp_enabled,

                            "Enable", "Disable", 6, 7))

                {

                    

                }
                /*L3-Reject-Unknown-Secure-Stream*/
                if(NOT SetConfig_BinaryText(SecondNode, "L3-Reject-Unknown-Secure-Stream", 
                           &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].l3_reject_unknown_secure_stream,

                            "Enable", "Disable", 6, 7))

                {

                    

                }
                /*L3-Reject-Unknown-Stream*/
                if(NOT SetConfig_BinaryText(SecondNode, "L3-Reject-Unknown-Stream", 
                           &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].l3_reject_unknown_stream,

                            "Enable", "Disable", 6, 7))

                {

                    

                }
                /*L3-Table-Active*/
                if(NOT SetConfig_BinaryText(SecondNode, "L3-Table-Active", 
                           &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].l3_tbl_active,

                            "Enable", "Disable", 6, 7))

                {

                    

                }
                Count++;

            }
            if(Count < (max_port_number  + 1))
            {
                fprintf(stderr, "\nERROR : <Port-Specific> in  <General-Configuratio> in <Forwarding> in '%s' should have entries for all Ports\n",

                gOptConfigFile);

                return FALSE;

            }
            else
            {
                FWDConfig_t.fwd_gen_config.bEnable = TRUE;

            }
        }
    }
    else if (G_Reconfig != TRUE)

    {

        fprintf(stderr, "\nERROR : Unable to find <General-Configuratio> in <Forwarding> in '%s'\n",

        gOptConfigFile);

        return FALSE;

    }
    if ((StreamNode = mxmlFindElement(ForwardingEngine, ForwardingEngine, "Stream-Forwarding", NULL, NULL, MXML_DESCEND_FIRST)) != NULL)
    {
        if(NOT SetConfig_Integer(StreamNode, "MAX-L3-Unsecure-Entry",

                         &FWDConfig_t.l3_stream_fwd.max_l3_unsecure_entry, RSWITCH2_MAX_UNSECURE_ENTRY))
        {
            FWDConfig_t.l3_stream_fwd.max_l3_unsecure_entry = 1; // Allow at least 1 unsecure entry by default

        }
        if(NOT SetConfig_Integer(StreamNode, "MAX-L3-Collision",

                         &FWDConfig_t.l3_stream_fwd.max_l3_collision, RSWITCH2_MAX_L3_COLLISION))
        {
            FWDConfig_t.l3_stream_fwd.max_l3_collision = 0x3FF; // Allow at least 1 unsecure entry by default

        }
        if(NOT SetConfig_Integer(StreamNode, "L3-Hash-Equation",

                         &FWDConfig_t.l3_stream_fwd.l3_hash_eqn, RENESAS_RSWITCH2_MAX_HASH_EQUATION))
        {
            FWDConfig_t.l3_stream_fwd.l3_hash_eqn = 0x1; // Allow at least 1 unsecure entry by default
 
        }

    
        if ((FirstNode = mxmlFindElement(StreamNode, StreamNode, "IP-Streams", NULL, NULL, MXML_DESCEND_FIRST)) != NULL)
        {
            if(NOT SetConfig_BinaryText(FirstNode, "Destination-Port", &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.destination_port,
      
                                "Include", "Exclude", 7, 7))

            {

                    

            }
            if(NOT SetConfig_BinaryText(FirstNode, "Dest-IPAddr", &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.destination_ip,
    
                                "Include", "Exclude", 7, 7))

            {

                    

            }
            if(NOT SetConfig_BinaryText(FirstNode, "Src-IPAddr", &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.source_ip,

                                "Include", "Exclude", 7, 7))

            {	

                    

            }
            if(NOT SetConfig_BinaryText(FirstNode, "CTag-DEI", &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ctag_dei,

                                "Include", "Exclude", 7, 7))

            {

                    

            }
            if(NOT SetConfig_BinaryText(FirstNode, "CTag-PCP", &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ctag_pcp,

                                "Include", "Exclude", 7, 7))

            {

                    

            }
            if(NOT SetConfig_BinaryText(FirstNode, "CTag-ID", &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ctag_vlan,

                                "Include", "Exclude", 7, 7))

            {

                    

            }
            if(NOT SetConfig_BinaryText(FirstNode, "STag-DEI", &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.stag_dei,
        
                               "Include", "Exclude", 7, 7))

            {

                    

            }
            if(NOT SetConfig_BinaryText(FirstNode, "STag-PCP", &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.stag_pcp,

                                "Include", "Exclude", 7, 7))

            {

                    

            }
            if(NOT SetConfig_BinaryText(FirstNode, "STag-ID", &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.stag_vlan,

                                "Include", "Exclude", 7, 7))

            {

                    

            }
            if(NOT SetConfig_BinaryText(FirstNode, "Hash-Destination-Port", 
                                &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.destination_port,

                                "Include", "Exclude", 7, 7))

            {

                    

            }
            if(NOT SetConfig_BinaryText(FirstNode, "Hash-Source-Port", 
                                &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.source_port,

                                "Include", "Exclude", 7, 7))

            {

                    

            }
            if(NOT SetConfig_BinaryText(FirstNode, "Hash-Dest-IPAddr",
                                &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.destination_ip,

                                "Include", "Exclude", 7, 7))

            {

                    

            }
            if(NOT SetConfig_BinaryText(FirstNode, "Hash-Src-IPAddr", 
                                &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.source_ip,

                                "Include", "Exclude", 7, 7))

            {

                    

            }
            if(NOT SetConfig_BinaryText(FirstNode, "Hash-protocol", 
                                &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.protocol,

                                "Include", "Exclude", 7, 7))

            {

                    

            }
            if(NOT SetConfig_BinaryText(FirstNode, "Hash-CTag-DEI",
                                 &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.ctag_dei,

                                "Include", "Exclude", 7, 7))

            {

                    

            }
            if(NOT SetConfig_BinaryText(FirstNode, "Hash-CTag-PCP", 
                                 &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.ctag_pcp,

                                "Include", "Exclude", 7, 7))

            {

                    

            }
            if(NOT SetConfig_BinaryText(FirstNode, "Hash-CTag-ID", 
                                &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.ctag_vlan,

                                "Include", "Exclude", 7, 7))

            {

                    

            }
            if(NOT SetConfig_BinaryText(FirstNode, "Hash-STag-DEI", 
                                &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.stag_dei,

                                "Include", "Exclude", 7, 7))

            {

                    

            }
            if(NOT SetConfig_BinaryText(FirstNode, "Hash-STag-PCP", 
                                &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.stag_pcp,

                                "Include", "Exclude", 7, 7))

            {

                    

            }
            if(NOT SetConfig_BinaryText(FirstNode, "Hash-STag-ID", 
                                &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.stag_vlan,

                                "Include", "Exclude", 7, 7))

            {

                    

            }
            if(NOT SetConfig_BinaryText(FirstNode, "Hash-Dest-MAC", 
                                 &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.dest_mac,

                                "Include", "Exclude", 7, 7))

            {

                    

            }	
            if(NOT SetConfig_BinaryText(FirstNode, "Hash-Src-MAC", 
                                 &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.src_mac		,

                                "Include", "Exclude", 7, 7))

            {

                    

            }
        
            if(NOT SetConfig_Integer(FirstNode, "IPV4-Hash-Equation",

                                &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.hash_configuration.ipv4_hash_eqn, RENESAS_RSWITCH2_MAX_HASH_EQUATION))
   
            {

                FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.hash_configuration.ipv4_hash_eqn = 1;

            }
            FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.bEnable = 1;
            FWDConfig_t.l3_stream_fwd.bEnable = 1;


            /*Entry*/

            if((SecondNode = mxmlFindElement(FirstNode, FirstNode, "Entry", NULL, NULL, MXML_DESCEND_FIRST)) == NULL)

            {

                fprintf(stderr, "\nERROR : No <Entry> in <IP-Streams> in <Stream-Forwarding> in <Forwarding> in '%s'\n",

                gOptConfigFile);

                return FALSE;

            }
            else

            {
            

                Count = 0;
                CPU = 0;
                for(; SecondNode != NULL; SecondNode = mxmlWalkNext(SecondNode, FirstNode, MXML_NO_DESCEND))

                {
                
                    if (SecondNode->type != MXML_ELEMENT)

                    {

                        continue;

                    }

                

                    if(Count >= RSWITCH2_MAX_IPV4_STREAM_ENTRIES)

                    {

                        fprintf(stderr, "ERROR : A maximum of %d <Entry> entries allowed in <IP-Streams> in <Stream-Forwarding> in <Forwarding> in %s\n",

                        RSWITCH2_MAX_IPV4_STREAM_ENTRIES, gOptConfigFile);

                        return FALSE;

                    }
                    /* Check This Logic */
                    if((portnumber = mxmlFindElement(SecondNode, SecondNode, "Dest-PortNumber", NULL, NULL, MXML_DESCEND_FIRST)) == NULL)

                    {

                        if(NOT SetConfig_Integer(SecondNode, "Dest-CPU",

                                &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].csdn, RSWITCH2_MAX_CSDN))
                        {

                            fprintf(stderr, "\nERROR : No <Dest-Port-Number> or <Dest-CPU> in <Entry>  in <IP-Streams> in <Stream-Forwarding> in <Forwarding> in '%s'\n",

                            gOptConfigFile);

                            return FALSE;
                        }
                        else 
                        {
                            
                            FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
                                 destination_vector_config.cpu = 1;
                            //printf("In CPU \n");
                            
                            //printf("CSDN=%d \n",FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].csdn);
                        }
                        

                    }

                    else
                    {    
                        if(NOT SetConfig_Integer(SecondNode, "Dest-CPU",

                                &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].csdn, RSWITCH2_MAX_CSDN))
                        {

                       
                        }
                        else
                        {
                            FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
                                 destination_vector_config.cpu = 1;

                        }
                        PortCount = 0;

                        for(; portnumber != NULL; portnumber = mxmlWalkNext(portnumber, SecondNode, MXML_NO_DESCEND))
                        {

                            if (portnumber->type != MXML_ELEMENT)

                            {
    
                                continue;

                            }

                        

                            if(NOT SetConfig_Destportnumber(portnumber, 
                            &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
                            destination_vector_config.port_number[PortCount], PortCount))

                            {
                                continue;
                            

                            }
                            //printf("portnumber = %d \n", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
                            //destination_vector_config.port_number[PortCount]);
                            for(int i = 0; i < PortCount; i++)

                            {
                                //printf("PortCount in loop = %d \n",PortCount); 
                                if(FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
                                destination_vector_config.port_number[PortCount] == 
                                FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
                                destination_vector_config.port_number[i])

                                {

                                    fprintf(stderr, "\nERROR: Duplicate <PortNumber> '%d' in <Entry> in <IP-Streams>  in <Stream-Forwarding> in <Forwarding> in '%s'\n",

                                    FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
                                    destination_vector_config.port_number[PortCount], gOptConfigFile);

                                    return FALSE;                               

                                }

                            }
                            //printf("PortCount = %d \n",PortCount); 
                            PortCount++;

                        }

                        FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
                        destination_vector_config.dest_eth_ports = PortCount;

                    } 

               
                    /*Source-LOck-CPU*/
                    if(NOT SetConfig_BinaryText(SecondNode, "Source-Lock-CPU", &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.
                          ipv4_stream_fwd_entry[Count].
                           source_lock.cpu,
                            "Yes", "No", 3, 2))
                    {
                    
                    }
                    if((PortLockNode = mxmlFindElement(SecondNode, SecondNode, "Source-Lock-Port", NULL, NULL, MXML_DESCEND_FIRST)) == NULL)
                    {
                        fprintf(stderr, "\nERROR : No <Source-Lock-Port> in  <Entry> in <IP-Streams> in<Stream-Forwarding> in <Forwarding>  '%s'\n",
                        gOptConfigFile);
                        return FALSE;
                    }
                    SourceLockCount = 0;
                    for(; PortLockNode != NULL; PortLockNode = mxmlWalkNext(PortLockNode, SecondNode, MXML_NO_DESCEND))
                    {
                        if (PortLockNode->type != MXML_ELEMENT)
                        {
                            continue;
                        }
                       
                
                        //if(NOT FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
                          // source_lock.cpu)
                        {
                            /*portnumber*/
                            //if((portnumber = mxmlFindElement(LockNode, LockNode, "portnumber", NULL, NULL, MXML_DESCEND_FIRST)) == NULL)
                            //{
                              //  fprintf(stderr, "\nERROR : No <Port-Number> in <Source-Lock-Ports> in <Entry> in <IP-Streams> in <Forwarding> in '%s'\n",
                                //gOptConfigFile);
                                //return FALSE;
                            //}
                            if(NOT SetConfig_lockportnumber(PortLockNode, &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.
                               ipv4_stream_fwd_entry[Count].source_lock.source_port_number[SourceLockCount], SourceLockCount))
                            {
                                //fprintf(stderr, "ERROR : Unable to find <Port-Number> in <Source-Lock-Ports> in <Entry> in <IP-Streams> in <Forwarding> in %s\n",
                                //gOptConfigFile);
                                //return FALSE;
                                continue;
                            }
                            for(int i = 0; i < SourceLockCount; i++)
                            {
                                if((FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
                                source_lock.source_port_number[SourceLockCount] ==
                                FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
                                source_lock.source_port_number[i]) && (FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
                                source_lock.cpu == 0))
                                {
                                    fprintf(stderr, "\nERROR: Duplicate <PortNumber> %d <Source-Lock-Port> in <Entry> in <IP-Streams> in \
                                            <Stream-Forwarding> in <Forwarding> '%s'\n",
                                           FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
                                           source_lock.source_port_number[SourceLockCount], gOptConfigFile);
                                    return FALSE;                               
                                }
                            }
                            SourceLockCount++;
                            //printf("SourceLockCount = %d \n", SourceLockCount);
                        }
                        
                    }
                    
                
#if 0                    
                else
                {
                    fprintf(stderr, "\nERROR : No <Source-Lock-Ports> in <Entry> in <IP-Streams> in <Forwarding> in '%s'\n",
                                gOptConfigFile);
                    return FALSE;

                }
#endif
                    FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
                                               source_lock.source_ports = SourceLockCount;
                    if(NOT SetConfig_Integer(SecondNode, "DestTCPUDP-Port",

                        &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
                        destination_port, RSWITCH2_MAX_TCPUDP_PORTNUMBER))

                    {    

                    } 
                    if(NOT SetConfig_Integer(SecondNode, "SourceTCPUDP-Port",

                        &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].source_port, RSWITCH2_MAX_TCPUDP_PORTNUMBER))

                    {    

                    }  
                    if(NOT SetConfig_Integer(SecondNode, "CTAG-DEI",

                        &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].ctag_dei, RSWITCH2_MAX_CTAG_DEI))

                    {    

                    } 
                    if(NOT SetConfig_Integer(SecondNode, "CTAG-PCP",

                        &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].ctag_pcp, RSWITCH2_MAX_CTAG_PCP))

                    {    

                    } 
                    if(NOT SetConfig_Integer(SecondNode, "CTAG-ID",

                        &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].ctag_vlan, RSWITCH2_MAX_CTAG_VLAN))

                    {    

                    }   
                    if(NOT SetConfig_Integer(SecondNode, "STAG-DEI",

                        &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].stag_dei, RSWITCH2_MAX_STAG_DEI))

                    {    

                    } 
                    if(NOT SetConfig_Integer(SecondNode, "STAG-PCP",

                        &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].stag_pcp, RSWITCH2_MAX_STAG_PCP))

                    {    

                    } 
                    if(NOT SetConfig_Integer(SecondNode, "STAG-ID",

                        &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].stag_vlan, RSWITCH2_MAX_STAG_VLAN))

                    {    

                    }
                    if(NOT SetConfig_BinaryText(SecondNode, "Security-Level", 
                    &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
                    security_learn,"Yes", "No", 3, 2))
                    {
                    }
                    /*VLAN-Mode*/

                    if ((ch = SetConfig_GetText(SecondNode, SecondNode, "TCPUDPSUPPORT")) != NULL)

                    {

                        if (strncasecmp(ch, "Others", 8) == 0)

                        {

                            FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
                            ipv4_stream_frame_format_code = ipv4_notcp_noudp;

                        }

                        else if (strncasecmp(ch, "UDP", 3) == 0)

                        {

                            FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].ipv4_stream_frame_format_code = ipv4_udp;

                        }

                        else if (strncasecmp(ch, "TCP", 3) == 0)

                        {

                            FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].ipv4_stream_frame_format_code = ipv4_tcp;

                        }

                        else

                        {

                            fprintf(stderr, "\nERROR: Invalid <Frame-Fmt-Code> in <Entry> in <IP-Streams> in <Stream-Forwarding> in <Forwarding> in '%s'\n",

                            gOptConfigFile);

                            return FALSE;

                        }

                    }
                    if(NOT SetConfig_Integer(SecondNode, "Routing-Number",

                        &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].routing_number, RSWITCH2_MAX_ROUTING_NUMBER))

                    {    

                    }
                    else
                    {
                        FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
                        routing_valid = 1;

                    }
               
                    /*Dest-MAC*/

                    if (NOT SetConfig_MAC(SecondNode, FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].dest_mac, 
                                     "Dest-MAC", Count))

                    {

                    

                    }
                    /*Src-MAC*/

                    if (NOT SetConfig_MAC(SecondNode, FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].src_mac, 
                                     "Src-MAC", Count))

                    {

                    

                    }
                     /*Dest-IP*/

                    if (NOT SetConfig_IPV4(SecondNode, FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.
                    ipv4_stream_fwd_entry[Count].destination_ip_addr, 
                                     "Dest-IP-Addr", Count))

                    {

                    

                    }
                    //printf("IP=%d \n",FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].destination_ip_addr[0]);
                    //printf("IP=%d \n",FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].destination_ip_addr[1]);
                    //printf("IP=%d \n",FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].destination_ip_addr[2]);
                    //printf("IP=%d \n",FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].destination_ip_addr[3]);
                     /*Dest-IP*/

                    if (NOT SetConfig_IPV4(SecondNode, FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].source_ip_addr, 
                                         "Src-IP-Addr", Count))

                    { 

                    

                    }
                    if(NOT SetConfig_BinaryText(SecondNode, "CPU-Mirror", 
                        &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
                        mirroring_config.cpu_mirror_enable,"Yes", "No", 3, 2))
                    {
                    }
                    if(NOT SetConfig_BinaryText(SecondNode, "Eth-Mirror", 
                        &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
                        mirroring_config.eth_mirror_enable,"Yes", "No", 3, 2))
                    {
                    }
        
                    if(SetConfig_Integer(SecondNode, "IPV-Update",

                        &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].mirroring_config.ipv_config.ipv_value, 
                         RSWITCH2_MAX_IPV))
                    {
                    
                    }
                    else
                    {
                        FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
                            mirroring_config.ipv_config.ipv_update_enable = 1;

                    }
		        Count++;
                }
                FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entries = Count;
            }

                
        }
        else
        {
            fprintf(stderr, "\nERROR : Unable to find <IP-Streams> in <Stream-Forwarding> in <Forwarding> in '%s'\n",

            gOptConfigFile);

            return FALSE;


        }
        if ((L2L3UpdateNode = mxmlFindElement(StreamNode, StreamNode, "Routing-Update-Table", NULL, NULL, MXML_DESCEND_FIRST)) != NULL)
        {
            if(NOT Set_Config_L2L3_Update(L2L3UpdateNode))
            {
                return FALSE;
            }
        }
    }
    
    return TRUE;

 
}
/*

* FWD_Set_Config : Function called by rswitch tool to update the FWD Configuration

* Tree           : TSN XML Tree

*/

extern bool FWD_Set_Config(mxml_node_t * Tree)

{

    int ret = 0;

    if (gFwdFd != -1)

    {
#if 1
       if ((ret = ioctl(gFwdFd, RSWITCH2_FWD_GET_CONFIG, &FWDConfig_t)) != 0)

        {

            fprintf(stderr, "\nERROR : RSWITCH2_FWD_GET_CONFIG failed (%d) : %s\n", ret, strerror(errno));

            return FALSE;

        }

        G_Reconfig = FWDConfig_t.config_done;

        printf("Value of G_Reconfig=%d \n", G_Reconfig);
#endif
    }

    else

    {

        fprintf(stderr, "WARNING, Omitting RSWITCH_FWD_GET_CONFIG as module not open\n");

    }

    if (NOT Set_Config(Tree, "Forwarding"))
 
    {
        FWD_Report_Device();
        return FALSE;

    }
    printf("Report True \n");
   // FWD_Print_Configuration();
    return TRUE;

}



extern bool FWD_Configure_Device(void)

{

    int ret = 0;

    if (gFwdFd != -1)

    {
#if 1
        if ((ret = ioctl(gFwdFd, RSWITCH2_FWD_SET_CONFIG, &FWDConfig_t)) != 0)   

        {

            fprintf(stderr, "\nERROR : RSWITCH_FWD_SET_CONFIG failed (%d) : %s\n", ret, strerror(errno));

            return FALSE;

        }
#endif

    }

    else

    {

        fprintf(stderr, "WARNING, Omitting RSWITCH_FWD_SET_CONFIG as module not open\n");

    }



    return TRUE;

}



extern bool FWD_Report_Device(void)

{

    int ret = 0;
    //gFwdFd = 0;
    if (gFwdFd != -1)

    {
#if 1
        if ((ret = ioctl(gFwdFd, RSWITCH2_FWD_GET_CONFIG, &FWDConfig_t)) != 0)   

        {

            fprintf(stderr, "\nERROR : RSWITCH_FWD_GET_CONFIG failed (%d) : %s\n", ret, strerror(errno));

            return FALSE;

        }
#endif
        printf("Print Config \n");
        FWD_Print_Configuration();

    }

    else

    {

        fprintf(stderr, "WARNING, Omitting RSWITCH_FWD_GET_CONFIG as module not open\n");

    }

    return TRUE;

}





/*

*   FWD_Open_Driver : Function to open the Forwarding Engine Driver File descriptor

*/



extern bool FWD_Open_Driver(void)

{
#if 1
    gFwdFd = open(RSWITCH2_FWD_DEV_NAME, O_RDWR | O_SYNC);



    if (gFwdFd < 0)

    {

        fprintf(stderr, "\n ERROR : FWD Open '%s' failed : %s \n", RSWITCH2_FWD_DEV_NAME, strerror(errno));

        return FALSE;

    }

#endif
    //gFwdFd = 0;

    return TRUE;

}



/*

*   FWD_Close_Driver : Function to close the Forwarding Engine Driver File descriptor

*/

extern bool FWD_Close_Driver(void)

{

    if (gFwdFd != -1)

    {

        close(gFwdFd);

        gFwdFd = -1;

    }

    return TRUE;

}
