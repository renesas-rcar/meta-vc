/*

*  Rswitch2 Configuration Tool - Forwarding Engine

*

*  Copyright (C) 2014 Renesas Electronics Corporation

*

*  This program is free software; you can redistribute it and/or modify it

*  under the terms and conditions of the GNU General Public License,

*  version 2, as published by the Free Software Foundation.

*

*  This program is distributed in the hope it will be useful, but WITHOUT

*  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or

*  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for

*  more details.

*  You should have received a copy of the GNU General Public License along wit

*  this program; if not, write to the Free Software Foundation, Inc.,

*  51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.

*

*  The full GNU General Public License is included in this distribution in

*  the file called "COPYING".

*/



#include "rswitch2tool.h"

#include "rswitch2_FWD.h"

#include <stdlib.h>

#include <math.h>

#include <inttypes.h>

#include <drivers/net/ethernet/renesas/rswitch2/rswitch2_fwd.h>






#define DEFAULT_REPORT_PRINT '-'

#define INVALID_THRESHOLD_CONFIG_VAL 20

#define MAX_CSDN 255

#define MAX_PRIORITY 7


static struct rswitch2_port_look_up_table {
	char portname[5];
	int portnumber_vc2;
	int portnumber_vc3;
}   _port_look_up_table[] = {


	{ "tsn0",0,0 },
	{ "tsn1",1,-1 },
	{ "tsn2",2,-1 },
	{ "tsn3",3,-1 },
	{ "tsn4",-1,3 },
	{ "tsn5",-1,2 },
	{ "tsn6",-1,0 },
	{ "tsn7",-1,1 },
	{ "eth1",-1,0 }
};

unsigned int           G_Reconfig = 0;
unsigned int           def_port_count = 0;
extern char          * gOptConfigFile;

static int             gFwdFd          = -1;

char gMACArray[RENESAS_RSWITCH2_MAX_FWD_TBL_ENTRY][18];

char gIPV4Array[RENESAS_RSWITCH2_MAX_IPV4_ENTRY][16];

struct rswitch2_fwd_config FWDConfig_t;
struct rswitch2_fwd_config FWDConfig_o;






bool Set_Integer_Frm_String(char const * ch, uint32_t *structure, uint32_t ulimit, char const * const Tag)
{
	uint64_t Data = 0;
	char * endptr = NULL;
	Data = strtol(ch,&endptr,0);
	if (endptr[0] != '\0') {
		fprintf(stderr, "Invalid <%s> - Appended with %s \n", Tag, endptr);

		return FALSE;
	}
	if (Data > ulimit)

	{


		fprintf(stderr, "Invalid <%s> - cannot be larger than %u", Tag, ulimit);

		return FALSE;

	}

	*structure = Data;

	return TRUE;
}

bool SetConfig_Integer(mxml_node_t * ParentNode, char const * const Tag, uint32_t *structure, uint32_t ulimit)

{

	uint64_t Data = 0;

	char const * ch = NULL;
	char * endptr = NULL;

	if ((ch = SetConfig_GetText(ParentNode, ParentNode, Tag)) != NULL)

	{
		Data = strtol(ch,&endptr,0);
		if (endptr[0] != '\0') {
			fprintf(stderr, "Invalid <%s> - Appended with %s \n", Tag, endptr);

			return FALSE;
		}
		if (Data > ulimit)

		{


			fprintf(stderr, "Invalid <%s> - cannot be larger than %u", Tag, ulimit);

			return FALSE;

		}

		*structure = Data;

		return TRUE;

	}

	return FALSE;

}





static bool SetConfig_BinaryText(mxml_node_t * ParentNode, char const * const Tag, uint32_t *structure,

                                 char const * const s1, char const * const s2, uint32_t l1, uint32_t l2)

{

	char const * ch = NULL;

	if ((ch = SetConfig_GetText(ParentNode, ParentNode, Tag)) != NULL)

	{

		if (strncasecmp(ch, s1, l1) == 0)

		{



			*structure = TRUE;

			return TRUE;

		}

		else if (strncasecmp(ch, s2, l2) == 0)

		{



			*structure = FALSE;

			return TRUE;

		}

		else

		{

			fprintf(stderr, "\nInvalid <%s> - can only be \"%s\" or \"%s\"\n",

			        Tag, s1, s2);

			return FALSE;

		}

	}

	return FALSE;

}

static bool SetConfig_loopNode(mxml_node_t *Node, uint32_t *structure, uint32_t Count, const char * const Tag, uint32_t max_value )
{
    uint32_t Int = 0;
    mxml_node_t *value = NULL;
    unsigned char  * ch;


    if (strcasecmp(Tag, Node->value.element.name) == 0)
    {
        if ((value = mxmlGetFirstChild(Node)) == NULL)
        {
            fprintf(stderr, "\n No %s", Tag);
            return FALSE;
        }
        if (value->type != MXML_TEXT)
        {
            fprintf(stderr, "\n Invalid  %s \n", Tag);
            return FALSE;

        }

        ch = value->value.text.string;

        if (sscanf(ch, "%u", &Int) != 1)
        {
            fprintf(stderr, "\n Invalid  <%s> \n", Tag);
            return FALSE;
        }

        if (Int >= max_value)
        {
            fprintf(stderr, "\nInvalid  <%s>, Range (0-%d)\n", Tag, (max_value-1));
            return FALSE;
        }

        *structure = Int;
    }
    return TRUE;
}



bool Reverse_lookup_PortName_PortNumber(uint32_t PortNumber, char *PortName)
{
	uint32_t agent_count = 0;
	for (agent_count = 0; agent_count < ARRAY_SIZE(_port_look_up_table); agent_count++) {
		if (board_version == 0x02) {
			if ( _port_look_up_table[agent_count].portnumber_vc2 == PortNumber) {
				strcpy(PortName, _port_look_up_table[agent_count].portname);
				break;
			}
		}
		else if (board_version == 0x03) {
			if ( _port_look_up_table[agent_count].portnumber_vc3 == PortNumber) {
				strcpy(PortName, _port_look_up_table[agent_count].portname);

				break;
			}

		}
	}
	return TRUE;


}

static bool SetConfig_lookupstragent(mxml_node_t *portnumber, uint32_t *structure,const char * const Tag, uint32_t PortCount, uint32_t *cpu)
{
	uint32_t PortInt = 0;
	mxml_node_t *value = NULL;
	unsigned char  * PortChar[RENESAS_RSWITCH2_MAX_ETHERNET_PORTS];
	uint32_t agent_count = 0;

	if (strcasecmp(Tag, portnumber->value.element.name) == 0) {

		if ((value = mxmlGetFirstChild(portnumber)) == NULL) {
			fprintf(stderr, "\n No <%s>",Tag);
			return FALSE;
		}
		if (value->type != MXML_TEXT) {
			fprintf(stderr, "\n Invalid  <%s>",Tag);
			return FALSE;

		}


		PortChar[PortCount] = value->value.text.string;
		if(strcmp(PortChar[PortCount], "cpu") == 0x0) {
			if(*cpu == TRUE) {
				fprintf(stderr, "\n Duplicate CPU in <%s>",Tag);
				return FALSE;
			}
			*cpu = TRUE;
			return TRUE;
		}
		for (agent_count = 0; agent_count < ARRAY_SIZE(_port_look_up_table); agent_count++) {
			if (strcmp(PortChar[PortCount], _port_look_up_table[agent_count].portname) == 0x0) {
				if (board_version == 0x02) {
					PortInt =  _port_look_up_table[agent_count].portnumber_vc2;
				}
				else if (board_version == 0x03) {
					PortInt =  _port_look_up_table[agent_count].portnumber_vc3;
				}

				break;
			}


		}


		if (PortInt >= max_port_number) {
			fprintf(stderr, "\nInvalid  <%s>, Range (0-%d)\n", Tag, (max_port_number-1));
			return FALSE;
		}

		*structure = PortInt;
		return TRUE;
	}

	return FALSE;

}




bool SetConfig_lookupstrportnumber(mxml_node_t *portnumber, uint32_t *structure,const char * const Tag, uint32_t PortCount)
{
	uint32_t PortInt = 0;
	mxml_node_t *value = NULL;
	unsigned char  * PortChar[RENESAS_RSWITCH2_MAX_ETHERNET_PORTS];
	uint32_t agent_count = 0;

	if (strcasecmp(Tag, portnumber->value.element.name) == 0) {

		if ((value = mxmlGetFirstChild(portnumber)) == NULL) {
			fprintf(stderr, "\n No <%s>",Tag);
			return FALSE;
		}
		if (value->type != MXML_TEXT) {
			fprintf(stderr, "\n Invalid  <%s>",Tag);
			return FALSE;

		}
		PortChar[PortCount] = value->value.text.string;

		for (agent_count = 0; agent_count < ARRAY_SIZE(_port_look_up_table); agent_count++) {
			if (strcmp(PortChar[PortCount], _port_look_up_table[agent_count].portname) == 0x0) {
				if (board_version == 0x02) {
					PortInt =  _port_look_up_table[agent_count].portnumber_vc2;
				}
				else if (board_version == 0x03) {
					PortInt =  _port_look_up_table[agent_count].portnumber_vc3;
				}
				break;
			}

			
		}
		if(agent_count == ARRAY_SIZE(_port_look_up_table)) {
			return FALSE;
		}

		if (PortInt >= max_port_number) {
			fprintf(stderr, "\nInvalid  <%s>, Range (0-%d)\n", Tag, (max_port_number-1));
			return FALSE;
		}

		*structure = PortInt;
		return TRUE;
	}

	return FALSE;

}









void FWD_Print_Configuration()
{
	int Count = 0;
	int Count2 = 0;

	char first_print = 0;
	char PortName[5];
	/*MAC Printing*/
	printf("\n======================================= FORWARDING ENGINE =====================================\n");
	if (FWDConfig_t.fwd_gen_config.bEnable) {
		printf("----------------------------  General Configuration  ---------------------------------\n");
		printf("VLAN-MODE    STT      CTT\n");
		if (FWDConfig_t.fwd_gen_config.vlan_mode == 0x0) {
			printf("%s", "NO-VLAN");
		}
		if (FWDConfig_t.fwd_gen_config.vlan_mode == 0x1) {
			printf("%s", "CTAG");
		}
		if (FWDConfig_t.fwd_gen_config.vlan_mode == 0x2) {
			printf("%s", "STAG");
		}
		printf("%10x", FWDConfig_t.fwd_gen_config.stag_tpid);
		printf("%10x", FWDConfig_t.fwd_gen_config.ctag_tpid);
		for (Count = 0; Count < (max_port_number  + 1); Count++) {
			printf("\n-----------------------------  AGENT Specific   ------------------------------------\n");
			if (!FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].cpu) {
				printf("Port=");
				Reverse_lookup_PortName_PortNumber(FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].portnumber, PortName);
				printf("%-12s \n", PortName);
			}
			else {
				printf("CPU \n");

			}
			printf("VLAN-Reject-Unknown-Secure      VLAN-Reject-Unknown      VLAN-Search-Active    \n");
			printf("%s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].vlan_reject_unknown_secure ? "Enable" : "Disable");
			printf("%32s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].vlan_reject_unknown ? "Enable" : "Disable");
			printf("%25s\n", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].vlan_search_active ? "Enable" : "Disable");

			printf("MAC-HW-Migration   MAC-HW-LEARN   \n");
			printf("%s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].mac_hw_migration_active ? "Enable" : "Disable");
			printf("%19s \n", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].mac_hw_learn_active ? "Enable" : "Disable");
			printf("MAC-Reject-Unknown-Src-Secure   MAC-Reject-Unknown-Src      MAC-Src-Search-Active    \n");
			printf("%s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].mac_reject_unknown_src_secure_addr ? "Enable" : "Disable");
			printf("%32s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].mac_reject_unknown_src_addr ? "Enable" : "Disable");
			printf("%28s\n", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].mac_src_search_active ? "Enable" : "Disable");
			printf("MAC-Reject-Unknown-Dest-Secure   MAC-Reject-Unknown-Dest      MAC-Dest-Search-Active    \n");
			printf("%s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].mac_reject_unknown_dest_secure_addr ? "Enable" : "Disable");
			printf("%33s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].mac_reject_unknown_dest_addr ? "Enable" : "Disable");
			printf("%29s\n", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].mac_dest_search_active ? "Enable" : "Disable");
			printf("IP-HW-Migration   IP-HW-LEARN   \n");
			printf("%s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ip_hw_migration_active ? "Enable" : "Disable");
			printf("%18s \n", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ip_hw_learn_active ? "Enable" : "Disable");
			printf("IP-Reject-Unknown-Src-Secure   IP-Reject-Unknown-Src      IP-Src-Search-Active    \n");
			printf("%s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ip_reject_unknown_src_secure_addr ? "Enable" : "Disable");
			printf("%31s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ip_reject_unknown_src_addr ? "Enable" : "Disable");
			printf("%27s\n", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ip_src_search_active ? "Enable" : "Disable");
			printf("IP-Reject-Unknown-Dest-Secure   IP-Reject-Unknown-Dest      IP-Dest-Search-Active    \n");
			printf("%s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ip_reject_unknown_dest_secure_addr ? "Enable" : "Disable");
			printf("%32s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ip_reject_unknown_dest_addr ? "Enable" : "Disable");
			printf("%28s\n", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ip_dest_search_active ? "Enable" : "Disable");
			printf("IPV6-Extract   IPV4-Extract     L2-Stream        \n");
			printf("%s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ipv6_extract_active ? "Enable" : "Disable");
			printf("%15s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ipv4_extract_active ? "Enable" : "Disable");
			printf("%17s\n", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].l2_stream_enabled ? "Enable" : "Disable");
			printf("IPV6-Other   IPV6-TCP     IPV6-UDP       \n");
			printf("%s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ipv6_other_enabled ? "Enable" : "Disable");
			printf("%13s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ipv6_tcp_enabled ? "Enable" : "Disable");
			printf("%13s\n", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ipv6_udp_enabled ? "Enable" : "Disable");
			printf("IPV4-Other   IPV4-TCP     IPV4-UDP       \n");
			printf("%s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ipv4_other_enabled ? "Enable" : "Disable");
			printf("%13s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ipv4_tcp_enabled ? "Enable" : "Disable");
			printf("%13s\n", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ipv4_udp_enabled ? "Enable" : "Disable");
			printf("L3-Reject-Unknown-Secure-Stream   L3-Reject-Unknown-Stream     L3-Table       \n");
			printf("%s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].l3_reject_unknown_secure_stream ? "Enable" : "Disable");
			printf("%34s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].l3_reject_unknown_stream ? "Enable" : "Disable");
			printf("%29s\n", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].l3_tbl_active ? "Enable" : "Disable");
			if (FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].port_forwarding.bEnable) {
				printf("-----------------------------  Source Port Forwarding   ------------------------------------\n");
				printf("Force-Frame-Priority   IPV6-Priority-Decode    IPV4-Priority-Decode       \n");
				printf("%s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].port_forwarding.force_frame_priority ? "Enable" : "Disable");
				printf("%34s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].port_forwarding.ipv6_priority_decode ? "Enable" : "Disable");
				printf("%29s\n", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].port_forwarding.ipv4_priority_decode ? "Enable" : "Disable");
				printf("IPV4-Priority-Decode-Mode   Security    Eth-Mirror    CPU-Mirror    IPV-Update       \n");
				printf("%s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].port_forwarding.ipv4_priority_decode_mode ? "Yes" : "No");
				printf("%34s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].port_forwarding.security_learn ? "ALL" : "UNSECURE");
				printf("%29s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].port_forwarding.mirroring_config.eth_mirror_enable ? "Yes" : "No");
				printf("%29s", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].port_forwarding.mirroring_config.cpu_mirror_enable ? "Yes" : "No");
				if (FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].port_forwarding.mirroring_config.ipv_config.ipv_update_enable) {
					printf("%29d\n", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].port_forwarding.mirroring_config.ipv_config.ipv_value);
				}
				else {
					printf("%29s\n","No");
				}
				printf("-----------------------------  Broadcast Port  ------------------------------------\n");
				for (Count2 = 0; Count2 < FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].port_forwarding.destination_vector_config.dest_eth_ports; Count2++) {
					Reverse_lookup_PortName_PortNumber(FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].port_forwarding.
					                                   destination_vector_config.port_number[Count2], PortName);
					printf("%1s ", PortName);
				}
				printf("\n");
				if (FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].port_forwarding.destination_vector_config.cpu) {
					printf("Broadcast CPU CSDN = %d\n", FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].port_forwarding.csdn);
				}

				printf("\n");
			}
		}
	}
	if (FWDConfig_t.rx_mcast_config.entries) {
		printf("\n-----------------------------  CPU-RX-MCAST   ------------------------------------\n");
		for(Count = 0; Count < FWDConfig_t.rx_mcast_config.entries; Count++) {
			if(FWDConfig_t.rx_mcast_config.entry[Count].base_entry) {
				printf("Chain-Entry-Number:%d \n", FWDConfig_t.rx_mcast_config.entry[Count].entry_num);
				printf("NextNumber: \n");
				for(Count2 = Count + 1; Count2 <= Count + FWDConfig_t.rx_mcast_config.entry[Count].next_entries; Count2++) {
					if(FWDConfig_t.rx_mcast_config.entry[Count2 -1].base_entry) {
						printf("%d\n", FWDConfig_t.rx_mcast_config.entry[Count2 -1].next_entry_num);
					} else {
						printf("%d\n", FWDConfig_t.rx_mcast_config.entry[Count2].entry_num);
					}
				}
				
			}
			
		}
	}
	if (FWDConfig_t.l3_stream_fwd.bEnable) {
		printf("\n-----------------------------  L3-Stream-Forwading   ------------------------------------\n");
		printf("MAX-L3-Unsecure-Entry   MAX-L3-Collision  L3-Hash-Equation\n");
		printf("%d", FWDConfig_t.l3_stream_fwd.max_l3_unsecure_entry);
		printf("%24d", FWDConfig_t.l3_stream_fwd.max_l3_collision);
		printf("%18d", FWDConfig_t.l3_stream_fwd.l3_hash_eqn);
		if(FWDConfig_t.l3_stream_fwd.fwd_filter_config.num_two_byte_filters) {
			printf("\n----------  TwoByte-Filter  ----------------\n");
			printf("FilterNum	Unit-Mode	Offset	Value0	Value1\n");
			for(Count = 0; Count < FWDConfig_t.l3_stream_fwd.fwd_filter_config.num_two_byte_filters; Count++) {
				printf("%d", FWDConfig_t.l3_stream_fwd.fwd_filter_config.two_byte[Count].filter_number);
				
				if(FWDConfig_t.l3_stream_fwd.fwd_filter_config.two_byte[Count].unit_mode == mask) {
					printf("%20s","Mask");
				} else if(FWDConfig_t.l3_stream_fwd.fwd_filter_config.two_byte[Count].unit_mode == precise) {
					printf("%22s","Precise");
				} else if(FWDConfig_t.l3_stream_fwd.fwd_filter_config.two_byte[Count].unit_mode == expand) {
					printf("%21s","Expand");
				}
				if(FWDConfig_t.l3_stream_fwd.fwd_filter_config.two_byte[Count].offset_mode == offset) {
					printf("%15x",FWDConfig_t.l3_stream_fwd.fwd_filter_config.two_byte[Count].offset);
				} else {
					if(FWDConfig_t.l3_stream_fwd.fwd_filter_config.two_byte[Count].offset == 0x0) {
						printf("%15s","STAG");
					} else if(FWDConfig_t.l3_stream_fwd.fwd_filter_config.two_byte[Count].offset == 0x2) {
						printf("%15s","CTAG");
					}
				}
				printf("%8x", FWDConfig_t.l3_stream_fwd.fwd_filter_config.two_byte[Count].value0);
				printf("%8x\n", FWDConfig_t.l3_stream_fwd.fwd_filter_config.two_byte[Count].value1);
				
			}
			
		}
		if(FWDConfig_t.l3_stream_fwd.fwd_filter_config.num_three_byte_filters) {
			printf("\n----------  ThreeByte-Filter  ----------------\n");
			printf("FilterNum	Unit-Mode	Offset	Value0	Value1\n");
			for(Count = 0; Count < FWDConfig_t.l3_stream_fwd.fwd_filter_config.num_three_byte_filters; Count++) {
				printf("%d", FWDConfig_t.l3_stream_fwd.fwd_filter_config.three_byte[Count].filter_number);
				
				if(FWDConfig_t.l3_stream_fwd.fwd_filter_config.three_byte[Count].unit_mode == mask) {
					printf("%20s","Mask");
				} else if(FWDConfig_t.l3_stream_fwd.fwd_filter_config.three_byte[Count].unit_mode == precise) {
					printf("%22s","Precise");
				} else if(FWDConfig_t.l3_stream_fwd.fwd_filter_config.three_byte[Count].unit_mode == expand) {
					printf("%21s","Expand");
				}
				printf("%15x",FWDConfig_t.l3_stream_fwd.fwd_filter_config.three_byte[Count].offset);
				
				printf("%8x", FWDConfig_t.l3_stream_fwd.fwd_filter_config.three_byte[Count].value0);
				printf("%8x\n", FWDConfig_t.l3_stream_fwd.fwd_filter_config.three_byte[Count].value1);
				
			}
			
		}
		if(FWDConfig_t.l3_stream_fwd.fwd_filter_config.num_four_byte_filters) {
			printf("\n----------  FourByte-Filter  ----------------\n");
			printf("FilterNum	Unit-Mode	Offset		Value0		Value1\n");
			for(Count = 0; Count < FWDConfig_t.l3_stream_fwd.fwd_filter_config.num_four_byte_filters; Count++) {
				printf("%d", FWDConfig_t.l3_stream_fwd.fwd_filter_config.four_byte[Count].filter_number);
				
				if(FWDConfig_t.l3_stream_fwd.fwd_filter_config.four_byte[Count].unit_mode == mask) {
					printf("%20s","Mask");
				} else if(FWDConfig_t.l3_stream_fwd.fwd_filter_config.four_byte[Count].unit_mode == precise) {
					printf("%22s","Precise");
				} else if(FWDConfig_t.l3_stream_fwd.fwd_filter_config.four_byte[Count].unit_mode == expand) {
					printf("%21s","Expand");
				}
				printf("%16x",FWDConfig_t.l3_stream_fwd.fwd_filter_config.four_byte[Count].offset);
				
				printf("%16x", FWDConfig_t.l3_stream_fwd.fwd_filter_config.four_byte[Count].value0);
				printf("%16x\n", FWDConfig_t.l3_stream_fwd.fwd_filter_config.four_byte[Count].value1);
				
			}
			
		}
		if(FWDConfig_t.l3_stream_fwd.fwd_filter_config.num_range_filters) {
			printf("\n----------  Range-Filter  ----------------\n");
			printf("FilterNum	Range	Offset		Value0	Value1\n");
			for(Count = 0; Count < FWDConfig_t.l3_stream_fwd.fwd_filter_config.num_range_filters; Count++) {
				printf("%d", FWDConfig_t.l3_stream_fwd.fwd_filter_config.range[Count].filter_number);
				printf("%16x",FWDConfig_t.l3_stream_fwd.fwd_filter_config.range[Count].range);
				
				if(FWDConfig_t.l3_stream_fwd.fwd_filter_config.range[Count].offset_mode == offset) {
					printf("%16d",FWDConfig_t.l3_stream_fwd.fwd_filter_config.range[Count].offset);
				} else {
					if(FWDConfig_t.l3_stream_fwd.fwd_filter_config.range[Count].offset == 0x0) {
						printf("%16s","STAG-Byte0");
					} else if(FWDConfig_t.l3_stream_fwd.fwd_filter_config.range[Count].offset == 0x1) {
						printf("%16s","STAG-Byte1");
					} else if(FWDConfig_t.l3_stream_fwd.fwd_filter_config.range[Count].offset == 0x2) {
						printf("%16s","CTAG-Byte0");
					} else if(FWDConfig_t.l3_stream_fwd.fwd_filter_config.range[Count].offset == 0x3) {
						printf("%16s","CTAG-Byte1");
					}
				}
				printf("%8x", FWDConfig_t.l3_stream_fwd.fwd_filter_config.range[Count].value0);
				printf("%8x\n", FWDConfig_t.l3_stream_fwd.fwd_filter_config.range[Count].value1);
				
			}
			
		}
		if(FWDConfig_t.l3_stream_fwd.fwd_filter_config.num_cascade_filters) {
			printf("\n----------  Cascade-Filter  ----------------\n");
			printf("FilterNum	PframeValid		EframeValid		Filter-ID\n");
			for(Count = 0; Count < FWDConfig_t.l3_stream_fwd.fwd_filter_config.num_cascade_filters; Count++) {
				printf("%d", FWDConfig_t.l3_stream_fwd.fwd_filter_config.cascade[Count].filter_number);
				printf("%12s","");
				for(Count2 = 0; Count2 < FWDConfig_t.l3_stream_fwd.fwd_filter_config.cascade[Count].
						pframe_valid.dest_eth_ports; Count2++) {
					Reverse_lookup_PortName_PortNumber(FWDConfig_t.l3_stream_fwd.
						fwd_filter_config.cascade[Count].
						pframe_valid.port_number[Count2], PortName);
					printf("%1s ", PortName);
				}
				printf("%8s","");
				if(FWDConfig_t.l3_stream_fwd.
					fwd_filter_config.cascade[Count].
					eframe_valid.cpu) {
					printf("%1s", "CPU ");
				} 
				for(Count2 = 0; Count2 < FWDConfig_t.l3_stream_fwd.fwd_filter_config.cascade[Count].
						eframe_valid.dest_eth_ports; Count2++) {
					
					Reverse_lookup_PortName_PortNumber(FWDConfig_t.l3_stream_fwd.
						fwd_filter_config.cascade[Count].
						eframe_valid.port_number[Count2], PortName);
					printf("%1s ", PortName);
					
				}
				for(Count2 = 0; Count2 < FWDConfig_t.l3_stream_fwd.fwd_filter_config.cascade[Count].
						used_filter_ids; Count2++) {
					
					printf("%1d ", FWDConfig_t.l3_stream_fwd.fwd_filter_config.
						cascade[Count].used_filter_id_num[Count2]);
				}
				printf("\n");
			}
		}

	}
	if (FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.bEnable) {
		printf("\n-----------------------------  IPV4-Stream-Forwading   ------------------------------------\n");
		printf("IPV4-Hash-Equation   Hash-Destination-Port  Hash-Source-Port\n");
		printf("%d", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.hash_configuration.ipv4_hash_eqn);
		printf("%27s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.destination_port ? "Include" : "Exclude");
		printf("%23s\n", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.source_port ? "Include" : "Exclude");
		printf("Hash-Source-IP    Hash-Dest-IP   Hash-protocol  \n");
		printf("%s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.source_ip ? "Include" : "Exclude");
		printf("%18s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.destination_ip ? "Include" : "Exclude");
		printf("%15s\n", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.protocol ? "Include" : "Exclude");
		printf("Hash-CTAG-DEI    Hash-CTAG-PCP   Hash-CTAG-ID  \n");
		printf("%s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.ctag_dei ? "Include" : "Exclude");
		printf("%17s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.ctag_pcp ? "Include" : "Exclude");
		printf("%16s\n", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.ctag_vlan ? "Include" : "Exclude");
		printf("Hash-STAG-DEI    Hash-STAG-PCP   Hash-STAG-ID  \n");
		printf("%s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.stag_dei ? "Include" : "Exclude");
		printf("%17s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.stag_pcp ? "Include" : "Exclude");
		printf("%16s\n", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.stag_vlan ? "Include" : "Exclude");
		printf("Hash-STAG-DEI    Hash-STAG-PCP   Hash-STAG-ID  \n");
		printf("%s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.stag_dei ? "Include" : "Exclude");
		printf("%17s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.stag_pcp ? "Include" : "Exclude");
		printf("%16s\n", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.stag_vlan ? "Include" : "Exclude");
		printf("Hash-Dest-MAC    Hash-Src-MAC   \n");
		printf("%s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.dest_mac ? "Include" : "Exclude");
		printf("%17s\n", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.src_mac ? "Include" : "Exclude");
		printf("Destination-Port  Dest-IP    Source-IP \n");
		printf("%s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.destination_port ? "Include" : "Exclude");
		printf("%18s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.destination_ip ? "Include" : "Exclude");
		printf("%11s\n", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.source_ip ? "Include" : "Exclude");
		printf("CTAG-DEI  CTAG-PCP    CTAG-ID \n");
		printf("%s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ctag_dei ? "Include" : "Exclude");
		printf("%10s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ctag_pcp ? "Include" : "Exclude");
		printf("%12s\n", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ctag_vlan ? "Include" : "Exclude");
		printf("STAG-DEI  STAG-PCP    STAG-ID \n");
		printf("%s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.stag_dei ? "Include" : "Exclude");
		printf("%10s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.stag_pcp ? "Include" : "Exclude");
		printf("%12s\n", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.stag_vlan ? "Include" : "Exclude");
		if (FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entries) {
			printf("\n\n\n---------------------------  L3-IPV4-Stream-Entries  ------------------------------\n");
			printf("Dest-IP-Addr                  Src-IP-Addr                   Dest-MAC                   Src-MAC\n");
			printf("-------------------------------------------------------------------------------\n");
			for (Count = 0; Count < FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entries; Count++) {
				if(FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.
				ipv4_stream_fwd_entry[Count].filter_enable) {
					printf("-------------------------------------------------------------------------------\n");
					continue;
				}
				printf("%d.%d.%d.%d", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].destination_ip_addr[0],
				       FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].destination_ip_addr[1],
				       FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].destination_ip_addr[2],
				       FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].destination_ip_addr[3]);
				printf("%19d.%d.%d.%d", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].source_ip_addr[0],
				       FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].source_ip_addr[1],
				       FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].source_ip_addr[2],
				       FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].source_ip_addr[3]);
				printf("                       %02x:%02x:%02x:%02x:%02x:%02x   ", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.
				       ipv4_stream_fwd_entry[Count].dest_mac[0],
				       FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].dest_mac[1],
				       FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].dest_mac[2],
				       FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].dest_mac[3],
				       FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].dest_mac[4],
				       FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].dest_mac[5]);
				printf("       %02x:%02x:%02x:%02x:%02x:%02x \n", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.
				       ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].src_mac[0],
				       FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].src_mac[1],
				       FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].src_mac[2],
				       FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].src_mac[3],
				       FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].src_mac[4],
				       FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].src_mac[5]);

			}
			printf("Destination-Port     Source-Port      CTAG--DEI      CTAG--PCP      CTAG-ID      STAG--DEI      STAG--PCP      STAG-ID\n");
			printf("-------------------------------------------------------------------------------\n");
			for (Count = 0; Count < FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entries; Count++) {
				if(FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.
				ipv4_stream_fwd_entry[Count].filter_enable) {
					printf("%17s \n","---------------------------------------------------");
					continue;
				}
				printf("%d ", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].destination_port);
								printf("%17d ", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].source_port);
				

				printf("%17d", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].ctag_dei);
				printf("%15d", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].ctag_pcp);
				printf("%15d", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].ctag_vlan);
				printf("%15d", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].stag_dei);
				printf("%15d", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].stag_pcp);
				printf("%15d\n", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].stag_vlan);
			}

			printf("Security-Learn     Frame-Fmt-Code         Routing-Number      Routing-Valid      CPU-Mirror      Eth-Mirror      IPV-Update      IPV-Value\n");
			printf("-------------------------------------------------------------------------------\n");
			for (Count = 0; Count < FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entries; Count++) {
				printf("%s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].security_learn ? "ALL" : "UNSECURE");
				if(!FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.
				ipv4_stream_fwd_entry[Count].filter_enable) {
					if (FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].ipv4_stream_frame_format_code == ipv4_notcp_noudp) {
						printf("%34s", "IPV4-NO-TCP-No-UDP");
					}
					else if (FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].ipv4_stream_frame_format_code == ipv4_udp) {
						printf("%34s", "UDP");
					}
					else if (FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].ipv4_stream_frame_format_code == ipv4_tcp) {
						printf("%34s", "TCP");
					}
				} else {
					printf("%34s", "---");
				}
					
				printf("%6d", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].routing_number);
				printf("%22s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].routing_valid ? "Yes" : "No");
				
				printf("%18s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.
					ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].mirroring_config.
				       	cpu_mirror_enable ? "Yes" : "No");
					printf("%16s", FWDConfig_t.l3_stream_fwd.
					ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].mirroring_config.
				       	eth_mirror_enable ? "Yes" : "No");
				printf("%16s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.
					ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].mirroring_config.
				       	ipv_config.ipv_update_enable ? "Yes" : "No");
				if (FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.
					ipv4_stream_fwd_entry[Count].mirroring_config.ipv_config.ipv_update_enable) {
					printf("%18d\n",FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.
					ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].mirroring_config.ipv_config.ipv_value);
				}
				else {
					printf("                   - \n");
				}
				
			}
			printf("Source UnLock Ports \n");
			printf("-------------------------------------------------------------------------------\n");
			for (Count = 0; Count < FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entries; Count++) {
				if (FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.
				        ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].source_lock.cpu) {
					printf("%s\n", "CPU");
				}
				for (Count2 = 0; Count2 < FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.
				        ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].source_lock.source_ports; Count2++) {
					Reverse_lookup_PortName_PortNumber(FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.
					                                   ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].source_lock.source_port_number[Count2], PortName);
					printf("%s\n",PortName);

				}
				
				
			}
			printf("Cascade-Filter-Number \n");
			printf("-------------------------------------------------------------------------------\n");
			for (Count = 0; Count < FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entries; Count++) {
				
				if(FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.
				ipv4_stream_fwd_entry[Count].filter_enable) {
					printf("%48d \n", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.
						ipv4_stream_fwd_entry[Count].filter_number);
				} else {
					printf("%48s \n", "--");
				}
				
			}
			printf("Dest-Port-Number         \n");
			printf("-------------------------------------------------------------------------------\n");
			for (Count = 0; Count < FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entries; Count++) {
				for (Count2 = 0; Count2 < FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.
				        ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].destination_vector_config.dest_eth_ports; Count2++) {

					Reverse_lookup_PortName_PortNumber(FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
					                                   destination_vector_config.port_number[Count2], PortName);
					printf("%1s ", PortName);
				}
				printf("\n");
			}
			printf("Dest-CPU       CSDN     \n");
			for (Count = 0; Count < FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entries; Count++) {
				printf("%s", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].destination_vector_config.
				       cpu ? "Yes" : "No");
				if (FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].destination_vector_config.
				        cpu) {
					printf("%15d\n", FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].csdn);
				}
				else {
					printf("                 -\n");
				}
			}
		}
	}
	if (FWDConfig_t.ipv_fwd_config.bEnable) {
		printf("------------------------------------------------------------------------------------------------------------------------------\n");
		printf("--------------------------------------IP-Forwarding-----------------------------------------------------\n");
		printf("MAX-Unsecure-Hash     MAX-Hash-Collision     IP-Hash-Equation  \n");
		printf("%-3d%20d%23d\n",FWDConfig_t.ipv_fwd_config.max_unsecure_hash_entry,FWDConfig_t.ipv_fwd_config.max_hash_collision,
		       FWDConfig_t.ipv_fwd_config.ipv_hash_eqn);
		if (FWDConfig_t.ipv_fwd_config.ipv_fwd_config_entries) {
			printf("--------------------------------------IP-Table-----------------------------------------------------\n");
			for (Count = 0; Count < FWDConfig_t.ipv_fwd_config.ipv_fwd_config_entries; Count++) {
				printf("IP               Src-Learn-Disable    Static-Dynamic-Mode    Security-Level   Dest-Unlock-Port    Dest-Unlock-CPU\n");
				printf("%-3d.%3d.%3d.%3d", FWDConfig_t.ipv_fwd_config.entry[Count].ipaddr[0],
				       FWDConfig_t.ipv_fwd_config.entry[Count].ipaddr[1],
				       FWDConfig_t.ipv_fwd_config.entry[Count].ipaddr[2],
				       FWDConfig_t.ipv_fwd_config.entry[Count].ipaddr[3]
				       );
				if (FWDConfig_t.ipv_fwd_config.entry[Count].ipv_learn_disable) {
					printf("%18s", "Yes");
				}
				else {
					printf("%18s", "No");
				}
				if (FWDConfig_t.ipv_fwd_config.entry[Count].ipv_dynamic_learn) {
					printf("%20s", "Dynamic");
				}
				else {
					printf("%20s", "Static");
				}
				if (FWDConfig_t.ipv_fwd_config.entry[Count].ipv_security_learn) {
					printf("%18s", "ALL");
				}
				else {
					printf("%18s", "UNSECURE");
				}
				for (Count2 = 0; Count2 < FWDConfig_t.ipv_fwd_config.entry[Count].destination_source.source_ports; Count2++) {
					Reverse_lookup_PortName_PortNumber(FWDConfig_t.ipv_fwd_config.entry[Count].destination_source.source_port_number[Count2],
					                                   PortName);
					printf(" %1s", PortName);
				}
				printf("%16s", FWDConfig_t.ipv_fwd_config.entry[Count].destination_source.cpu ? "Yes\n" : "No\n");
				if (!first_print) {
					printf("Src-Unlock-Port    Src-Unlock-CPU     Dest-PortNumber    Dest-CPU     Eth-Mirror    Eth-CPU    IPV-Update  Routing#\n");
					first_print = 1;
				}
				for (Count2 = 0; Count2 < FWDConfig_t.ipv_fwd_config.entry[Count].source_source.source_ports; Count2++) {
					Reverse_lookup_PortName_PortNumber(FWDConfig_t.ipv_fwd_config.entry[Count].source_source.source_port_number[Count2],
					                                   PortName);
					printf("%-2s ", PortName);
				}
				printf("%25s", FWDConfig_t.ipv_fwd_config.entry[Count].destination_source.cpu ? "Yes" : "No");
				for (Count2 = 0; Count2 < FWDConfig_t.ipv_fwd_config.entry[Count].destination_vector_config.dest_eth_ports; Count2++) {
					Reverse_lookup_PortName_PortNumber(FWDConfig_t.ipv_fwd_config.entry[Count].destination_vector_config.port_number[Count2],
					                                   PortName);
					printf(" %2s", PortName);
				}
				if (FWDConfig_t.ipv_fwd_config.entry[Count].destination_vector_config.cpu) {
					printf("%14d", FWDConfig_t.ipv_fwd_config.entry[Count].csdn);
				}
				else {
					printf("%14s","No");
				}
				printf("%13s", FWDConfig_t.ipv_fwd_config.entry[Count].mirroring_config.eth_mirror_enable ? "Yes" : "No");
				printf("%14s", FWDConfig_t.ipv_fwd_config.entry[Count].mirroring_config.cpu_mirror_enable ? "Yes" : "No");
				if (FWDConfig_t.ipv_fwd_config.entry[Count].mirroring_config.ipv_config.ipv_update_enable) {
					printf("%12d", FWDConfig_t.ipv_fwd_config.entry[Count].mirroring_config.ipv_config.ipv_value);
				}
				else {
					printf("%12s","No");
				}
				if (FWDConfig_t.ipv_fwd_config.entry[Count].routing_valid) {
					printf("%12d\n", FWDConfig_t.ipv_fwd_config.entry[Count].routing_number);
				}
				else {
					printf("%12s\n","No");
				}
			}
		}
		
	}
	if (FWDConfig_t.l2_fwd_config.bEnable) {
		printf("------------------------------------------------------------------------------------------------------------------------------\n");
		printf("--------------------------------------Layer2-Forwarding-----------------------------------------------------\n");
		printf("MAX-Unsecure-Hash     MAX-Hash-Collision     MAC-Hash-Equation   MAX-Unsecure-VLAN\n");
		printf("%-3d%20d%23d%21d\n",FWDConfig_t.l2_fwd_config.max_unsecure_hash_entry,FWDConfig_t.l2_fwd_config.max_hash_collision,
		       FWDConfig_t.l2_fwd_config.mac_hash_eqn,FWDConfig_t.l2_fwd_config.max_unsecure_vlan_entry);
		printf("MAC-Aging             MAC-Aging-Prescalar    MAC-Aging-Time      MAC-Aging-Security\n");

		printf("%-3s%20d%23d%21s\n",FWDConfig_t.l2_fwd_config.mac_aging_config.on_off?"Yes":"No",FWDConfig_t.l2_fwd_config.mac_aging_config.mac_aging_prescalar,
		       FWDConfig_t.l2_fwd_config.mac_aging_config.mac_aging_time_sec,
		       FWDConfig_t.l2_fwd_config.mac_aging_config.mac_aging_security?"ALL\n":"UNSECURE\n");
		printf("------------------------------------------------------------------------------------------------------------------------------\n");
		if (FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entries) {
			printf("--------------------------------------MAC-Table-----------------------------------------------------\n");
			for (Count = 0; Count < FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entries; Count++) {
				printf("MAC               Src-Learn-Disable    Static-Dynamic-Mode    Security-Level   Dest-Unlock-Port    Dest-Unlock-CPU\n");
				printf("%-2x:%2x:%2x:%2x:%2x:%2x", FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].mac[0],
				       FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].mac[1],
				       FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].mac[2],
				       FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].mac[3],
				       FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].mac[4],
				       FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].mac[5]);
				if (FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].mac_learn_disable) {
					printf("%18s", "Yes");
				}
				else {
					printf("%18s", "No");
				}
				if (FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].mac_dynamic_learn) {
					printf("%20s", "Dynamic");
				}
				else {
					printf("%20s", "Static");
				}
				if (FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].mac_security_learn) {
					printf("%18s", "ALL");
				}
				else {
					printf("%18s", "UNSECURE");
				}
				for (Count2 = 0; Count2 < FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].destination_source.source_ports; Count2++) {
					Reverse_lookup_PortName_PortNumber(FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].destination_source.source_port_number[Count2],
					                                   PortName);
					printf(" %1s", PortName);
				}
				printf("%16s", FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].destination_source.cpu ? "Yes\n" : "No\n");
				if (!first_print) {
					printf("Src-Unlock-Port    Src-Unlock-CPU     Dest-PortNumber    Dest-CPU     Eth-Mirror    Eth-CPU    IPV-Update \n");
					first_print = 1;
				}
				for (Count2 = 0; Count2 < FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].source_source.source_ports; Count2++) {
					Reverse_lookup_PortName_PortNumber(FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].source_source.source_port_number[Count2],
					                                   PortName);
					printf("%-2s ", PortName);
				}
				printf("%25s", FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].destination_source.cpu ? "Yes" : "No");
				for (Count2 = 0; Count2 < FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].destination_vector_config.dest_eth_ports; Count2++) {
					Reverse_lookup_PortName_PortNumber(FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].destination_vector_config.port_number[Count2],
					                                   PortName);
					printf(" %2s", PortName);
				}
				if (FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].destination_vector_config.cpu) {
					printf("%14d", FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].csdn);
				}
				else {
					printf("%14s","No");
				}
				printf("%13s", FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].mirroring_config.eth_mirror_enable ? "Yes" : "No");
				printf("%14s", FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].mirroring_config.cpu_mirror_enable ? "Yes" : "No");
				if (FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].mirroring_config.ipv_config.ipv_update_enable) {
					printf("%12d\n", FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].mirroring_config.ipv_config.ipv_value);
				}
				else {
					printf("%12s\n","No");
				}
			}
		}
		first_print = 0;
		if (FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entries) {
			printf("--------------------------------------VLAN-Table-----------------------------------------------------\n");
			for (Count = 0; Count < FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entries; Count++) {
				printf("VLAN-ID    VLAN-Learn-Disable    Security-Level    Source-Unlock-Port    Source-Unlock-CPU  \n");
				printf("%-7x", FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].vlan_id);
				if (FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].vlan_learn_disable) {
					printf("%20s", "Yes");
				}
				else {
					printf("%20s", "No");
				}
				if (FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].vlan_security_learn) {
					printf("%20s", "ALL");
				}
				else {
					printf("%20s", "UNSECURE");
				}
				for (Count2 = 0; Count2 < FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].source_lock.source_ports; Count2++) {
					Reverse_lookup_PortName_PortNumber(FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].source_lock.source_port_number[Count2],
					                                   PortName);
					printf(" %1s", PortName);
				}
				printf("%22s", FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].source_lock.cpu ? "Yes\n" : "No\n");
				if (!first_print) {
					printf("Dest-PortNumber    Dest-CPU     Eth-Mirror    Eth-CPU    IPV-Update \n");
					first_print = 1;
				}

				for (Count2 = 0; Count2 < FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].destination_vector_config.dest_eth_ports; Count2++) {
					Reverse_lookup_PortName_PortNumber(FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].destination_vector_config.port_number[Count2],
					                                   PortName);
					printf("%-4s ", PortName);
				}
				if (FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].destination_vector_config.cpu) {
					printf("%19d", FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].csdn);
				}
				else {
					printf("%19s","No");
				}
				printf("%15s", FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].mirroring_config.eth_mirror_enable ? "Yes" : "No");
				printf("%11s", FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].mirroring_config.cpu_mirror_enable ? "Yes" : "No");
				if (FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].mirroring_config.ipv_config.ipv_update_enable) {
					printf("%15d\n", FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].mirroring_config.ipv_config.ipv_value);
				}
				else {
					printf("%15s\n","No\n");
				}
			}
		}
	}
	first_print = 0;
	if (FWDConfig_t.l23_update.entries) {
		printf("------------------------------------------------------------------------------------------------------------------------------\n");
		printf("--------------------------------------Routing-Update-Table-----------------------------------------------------\n");
		printf("Routing-Number    RTAG      STAG-DEI    STAG-PCP    STAG-ID     CTAG-DEI    CTAG-PCP    CTAG-ID \n");
		for (Count = 0; Count < FWDConfig_t.l23_update.entries; Count++) {
			printf("%d", FWDConfig_t.l23_update.l23_update_config[Count].routing_number);
			printf("%18d", FWDConfig_t.l23_update.l23_update_config[Count].rtag);
			if (FWDConfig_t.l23_update.l23_update_config[Count].stag_dei_update) {
				printf("%10d", FWDConfig_t.l23_update.l23_update_config[Count].stag_dei);
			}
			else {
				printf("%10s", "-");
			}
			if (FWDConfig_t.l23_update.l23_update_config[Count].stag_pcp_update) {
				printf("%12d", FWDConfig_t.l23_update.l23_update_config[Count].stag_pcp);
			}
			else {
				printf("%12s", "-");
			}
			if (FWDConfig_t.l23_update.l23_update_config[Count].stag_vlan_update) {
				printf("%13d", FWDConfig_t.l23_update.l23_update_config[Count].stag_vlan);
			}
			else {
				printf("%13s", "-");
			}
			if (FWDConfig_t.l23_update.l23_update_config[Count].ctag_dei_update) {
				printf("%11d", FWDConfig_t.l23_update.l23_update_config[Count].ctag_dei);
			}
			else {
				printf("%11s", "-");
			}
			if (FWDConfig_t.l23_update.l23_update_config[Count].ctag_pcp_update) {
				printf("%12d", FWDConfig_t.l23_update.l23_update_config[Count].ctag_pcp);
			}
			else {
				printf("%12s", "-");
			}
			if (FWDConfig_t.l23_update.l23_update_config[Count].ctag_vlan_update) {
				printf("%13d\n", FWDConfig_t.l23_update.l23_update_config[Count].ctag_vlan);
			}
			else {
				printf("%13s", "-\n");
			}
			if (!first_print) {
				printf("TTL-Update    Src-MAC-Update      Dest-MAC             Routing-Ports     Routing-CPU \n");
				first_print = 1;
			}
			if (FWDConfig_t.l23_update.l23_update_config[Count].ttl_update) {
				printf("%s", "Yes");
			}
			else {
				printf("%s", "No");
			}
			if (FWDConfig_t.l23_update.l23_update_config[Count].src_mac_update) {
				printf("%14s", "Yes");
			}
			else {
				printf("%14s", "No");
			}
			if (FWDConfig_t.l23_update.l23_update_config[Count].dest_mac_update) {
				printf("%20x:%2x:%2x:%2x:%2x:%2x",FWDConfig_t.l23_update.l23_update_config[Count].dest_mac[0],FWDConfig_t.l23_update.l23_update_config[Count].dest_mac[1]
				       ,FWDConfig_t.l23_update.l23_update_config[Count].dest_mac[2],FWDConfig_t.l23_update.l23_update_config[Count].dest_mac[3]
				       ,FWDConfig_t.l23_update.l23_update_config[Count].dest_mac[4],FWDConfig_t.l23_update.l23_update_config[Count].dest_mac[5]);
			}
			else {
				printf("%8s:%2s:%2s:%2s:%2s:%2s", "--","--","--","--","--","--");
			}
			for (Count2 = 0; Count2 < FWDConfig_t.l23_update.l23_update_config[Count].routing_port_update.dest_eth_ports; Count2++) {
				Reverse_lookup_PortName_PortNumber(FWDConfig_t.l23_update.l23_update_config[Count].routing_port_update.port_number[Count2],
				                                   PortName);
				printf("%1s", PortName);
			}
			printf("%16s", FWDConfig_t.l23_update.l23_update_config[Count].routing_port_update.cpu ? "Yes\n" : "No\n");
		}
	}
}
static bool Is_Any_Duplicate_MAC(char MACAddr[][18], int MACSize)

{

	char temp[18];

	int j, i;



	//~ // Sorting strings using bubble sort

	for (j = 0; j < MACSize - 1; j++)

	{

		for (i = j + 1; i < MACSize; i++)

		{

			if (strcmp(MACAddr[j], MACAddr[i]) > 0)

			{

				strcpy(temp, MACAddr[j]);

				strcpy(MACAddr[j], MACAddr[i]);

				strcpy(MACAddr[i], temp);

			}

		}

	}

	for (i = 0; i < MACSize; i++)

	{

		if (strcmp(MACAddr[i], MACAddr[i+1]) == 0)

		{

			fprintf(stderr, "\nDuplicate MAC Address with MAC : %s\n", MACAddr[i]);

			return FALSE;

		}

	}

	return TRUE;

}



static bool Is_Any_Duplicate_IPV4(char IPV4Add[][16], int IPV4Size)

{

	char temp[18];

	int j, i;





	for (j = 0; j < IPV4Size - 1; j++)

	{

		for (i = j + 1; i < IPV4Size; i++)

		{

			if (strcmp(IPV4Add[j], IPV4Add[i]) > 0)

			{

				strcpy(temp, IPV4Add[j]);

				strcpy(IPV4Add[j], IPV4Add[i]);

				strcpy(IPV4Add[i], temp);

			}

		}

	}

	for (i = 0; i < IPV4Size; i++)

	{

		if (strcmp(IPV4Add[i], IPV4Add[i+1]) == 0)

		{

			fprintf(stderr, "\nDuplicate IPV4 Address with IP : %s\n", IPV4Add[i]);

			return FALSE;

		}

	}

	return TRUE;

}



static bool SetConfig_MAC(mxml_node_t * ParentNode, uint32_t structure[], const char * const Tag, uint32_t Count)

{

	char const    * XMLResult = NULL;

	char            MACChar0[32];

	char            MACChar1[32];

	char            MACChar2[32];

	char            MACChar3[32];

	char            MACChar4[32];

	char            MACChar5[32];

	uint8_t         sMAC[6];

	mxml_node_t   * MAC = NULL;
	if ((MAC = mxmlFindElement(ParentNode, ParentNode, Tag, NULL, NULL, MXML_DESCEND_FIRST)) != NULL)

	{

		if ((XMLResult = SetConfig_GetText(ParentNode, ParentNode, Tag)) != NULL)

		{

			if (strlen(XMLResult) != 17)

			{

				fprintf(stderr, "\nInvalid <%s> (length) '%.31s'\n", Tag, XMLResult);

				return FALSE;

			}



			strcpy (gMACArray[Count], XMLResult);



			if (sscanf(XMLResult, "%2s:%2s:%2s:%2s:%2s:%2s", MACChar0, MACChar1, MACChar2, MACChar3, MACChar4, MACChar5) != 6)

			{

				fprintf(stderr, "\nInvalid <%s> (hex) '%.31s'\n",

				        Tag, XMLResult);

				return FALSE;

			}



			sMAC[0] = strtoul(MACChar0, 0, 16);

			sMAC[1] = strtoul(MACChar1, 0, 16);

			sMAC[2] = strtoul(MACChar2, 0, 16);

			sMAC[3] = strtoul(MACChar3, 0, 16);

			sMAC[4] = strtoul(MACChar4, 0, 16);

			sMAC[5] = strtoul(MACChar5, 0, 16);

			structure[0] = sMAC[0];

			structure[1] = sMAC[1];

			structure[2] = sMAC[2];

			structure[3] = sMAC[3];

			structure[4] = sMAC[4];

			structure[5] = sMAC[5];

		}

	}
	else {
		return FALSE;
	}

	if (NOT Is_Any_Duplicate_MAC(gMACArray, Count))

	{

		fprintf(stderr, "ERROR : Duplicate <MAC> in file %s\n", gOptConfigFile);

		return FALSE;

	}

	return TRUE;

}


static bool SetConfig_IPV4(mxml_node_t * ParentNode, uint32_t structure[], const char * const Tag, uint32_t Count)

{

	char const    * XMLResult = NULL;

	char            IPV4Char[4][32];

	uint32_t i  =0 ;
	uint32_t j = 0;
	uint32_t k = 0;



	uint8_t         sIPV4[6];

	mxml_node_t   * IPV4 = NULL;

	if ((IPV4 = mxmlFindElement(ParentNode, ParentNode, Tag, NULL, NULL, MXML_DESCEND_FIRST)) != NULL)

	{

		if ((XMLResult = SetConfig_GetText(ParentNode, ParentNode, Tag)) != NULL)

		{

			if (strlen(XMLResult) > 15)

			{

				fprintf(stderr, "\nInvalid <%s> (length) '%.31s'\n", Tag, XMLResult);

				return FALSE;

			}



			strcpy (gIPV4Array[Count], XMLResult);
			i = 0;
			j = 0;
			k = 0;
			while (XMLResult[i] != '\0') {
				/* Stop looping when we reach the null-character. */
				while (XMLResult[i] != '.') {


					IPV4Char[j][k] = XMLResult[i];
					k++;
					i++;
					if (XMLResult[i] == '\0') {
						IPV4Char[j][k] = '\0';
						break;
					}
				}
				if (XMLResult[i] != '\0') {
					i++;
					IPV4Char[j][k] = '\0';
					k = 0;
				}
				j++;
			}




			sIPV4[0] = strtoul(IPV4Char[0], 0, 0);

			sIPV4[1] = strtoul(IPV4Char[1], 0, 0);

			sIPV4[2] = strtoul(IPV4Char[2], 0, 0);

			sIPV4[3] = strtoul(IPV4Char[3], 0, 0);



			structure[0] = sIPV4[0];

			structure[1] = sIPV4[1];

			structure[2] = sIPV4[2];

			structure[3] = sIPV4[3];

		}

	}
	else {

		return FALSE;
	}

	if (NOT Is_Any_Duplicate_IPV4(gIPV4Array, Count))

	{

		fprintf(stderr, "ERROR : Duplicate <IP> in xml %s\n", gOptConfigFile);

		return FALSE;

	}

	return TRUE;

}


static bool Set_Config_L2VLANTbl(mxml_node_t * L2L3UpdateNode)
{
	/*Entry*/
	mxml_node_t   * portnumber = NULL;
	mxml_node_t   * SecondNode = NULL;
	mxml_node_t   * PortLockNode = NULL;
	uint32_t      Count = 0;
	uint32_t      SourceLockCount = 0;
	uint32_t      PortCount = 0;
	if ((SecondNode = mxmlFindElement(L2L3UpdateNode, L2L3UpdateNode, "VLAN-Entry", NULL, NULL, MXML_DESCEND_FIRST)) == NULL) {

		fprintf(stderr, "\nERROR : No <VLAN-Entry> in <VLAN-Table>  in <Layer2-Forwarding> in <Forwarding> in '%s'\n",

		        gOptConfigFile);

		return FALSE;

	}
	else {
		Count = 0;

		for (; SecondNode != NULL; SecondNode = mxmlWalkNext(SecondNode, L2L3UpdateNode, MXML_NO_DESCEND)) {
			if (SecondNode->type != MXML_ELEMENT) {
				continue;
			}
			if (Count >= RSWITCH2_MAX_L2_FWD_VLAN_ENTRIES) {
				fprintf(stderr, "ERROR : A maximum of %d <VLAN-Entry> in <VLAN-Table>  in <Layer2-Forwarding> in <Forwarding> in %s\n",
				        RSWITCH2_MAX_L2_FWD_ENTRIES, gOptConfigFile);
				return FALSE;
			}
			/* Check This Logic */
			if ((portnumber = mxmlFindElement(SecondNode, SecondNode, "Dest-PortNumber", NULL, NULL, MXML_DESCEND_FIRST)) == NULL) {

				if (NOT SetConfig_Integer(SecondNode, "Dest-CPU", &FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].csdn,RSWITCH2_MAX_CSDN)) {
					fprintf(stderr, "\nERROR : No <Dest-CPU> or <Dest-PortNumber> in <VLAN-Entry> in <VLAN-Table>  in <Layer2-Forwarding> in <Forwarding> in '%s'\n",
					        gOptConfigFile);
					return FALSE;
				}
				else {
					FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].destination_vector_config.cpu = 1;
				}
			}
			else {
				if (NOT SetConfig_Integer(SecondNode, "Dest-CPU", &FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].csdn,RSWITCH2_MAX_CSDN)) {
					FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].destination_vector_config.cpu = 0;
				}
				else {
					FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].destination_vector_config.cpu = 1;
				}
				PortCount = 0;
				for (; portnumber != NULL; portnumber = mxmlWalkNext(portnumber, SecondNode, MXML_NO_DESCEND)) {
					if (portnumber->type != MXML_ELEMENT) {
						continue;
					}
					if (NOT SetConfig_lookupstrportnumber(portnumber,
					                                      &FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].destination_vector_config.port_number[PortCount], "Dest-PortNumber", PortCount)) {
						continue;
					}
					for (int i = 0; i < PortCount; i++) {
						if (FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].destination_vector_config.port_number[PortCount] ==
						        FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].destination_vector_config.port_number[i]) {
							fprintf(stderr, "\nERROR: Duplicate <Dest-PortNumber> '%d' <VLAN-Entry> in <VLAN-Table>  in <Layer2-Forwarding> in <Forwarding> in '%s'\n",
							        FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].destination_vector_config.port_number[PortCount], gOptConfigFile);
							return FALSE;

						}

					}
					PortCount++;
				}

				FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].destination_vector_config.dest_eth_ports = PortCount;

			}
			if (NOT SetConfig_Integer(SecondNode, "IPV-Update",&FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].mirroring_config.ipv_config.ipv_value,
			                          RSWITCH2_MAX_IPV)) {

			}
			else {
				FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].mirroring_config.ipv_config.ipv_update_enable = 1;

			}
			if (SetConfig_Integer(SecondNode, "VLAN-ID",&FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].vlan_id,
			                      RSWITCH2_MAX_CTAG_VLAN)) {

			}
			if (NOT SetConfig_BinaryText(SecondNode, "VLAN-Learn-Disable", &FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].vlan_learn_disable,"Yes", "No", 3, 2)) {
			}
			if (NOT SetConfig_BinaryText(SecondNode, "Security-Level", &FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].vlan_security_learn,"ALL", "UNSECURE", 3, 8)) {
				FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].vlan_security_learn = 0;
			}
			/*Source-LOck-CPU*/
			if (NOT SetConfig_BinaryText(SecondNode, "Source-Unlock-CPU", &FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].source_lock.cpu,
			                             "Yes", "No", 3, 2)) {
				FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].source_lock.cpu = 0;
			}
			if ((PortLockNode = mxmlFindElement(SecondNode, SecondNode, "Source-Unlock-Port", NULL, NULL, MXML_DESCEND_FIRST)) == NULL) {
				if (!FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].source_lock.cpu) {
					for (def_port_count = 0;
					        def_port_count < FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].destination_vector_config.dest_eth_ports;
					        def_port_count++) {

						FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].source_lock.
						source_port_number[def_port_count] =
						    FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].destination_vector_config.port_number[def_port_count];

					}
					FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].source_lock.cpu =
					    FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].destination_vector_config.cpu;
					FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].source_lock.source_ports =
					    FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].destination_vector_config.dest_eth_ports;
				}
			}
			SourceLockCount = 0;
			for (; PortLockNode != NULL; PortLockNode = mxmlWalkNext(PortLockNode, SecondNode, MXML_NO_DESCEND)) {
				if (PortLockNode->type != MXML_ELEMENT) {
					continue;
				}
				if (NOT SetConfig_lookupstrportnumber(PortLockNode, &FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].source_lock.
				                                      source_port_number[SourceLockCount], "Source-Unlock-Port",SourceLockCount)) {
					continue;
				}
				for (int i = 0; i < SourceLockCount; i++) {
					if ((FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].source_lock.
					        source_port_number[SourceLockCount] == FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].source_lock.
					        source_port_number[i]) && (FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].source_lock.cpu== 0)) {
						fprintf(stderr, "\nERROR: Duplicate <Source-Unlock-Port> %d  in <VLAN-Entry> in <VLAN-Table> in \
                            <Layer2-Forwarding> in <Forwarding> '%s'\n",
						        FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].source_lock.
						        source_port_number[SourceLockCount], gOptConfigFile);
						return FALSE;
					}
				}
				SourceLockCount++;


			}
			if (SourceLockCount) {
				FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].source_lock.source_ports = SourceLockCount;
			}
			if (NOT SetConfig_BinaryText(SecondNode, "CPU-Mirror",
			                             &FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].mirroring_config.cpu_mirror_enable,"Yes", "No", 3, 2)) {
			}
			if (NOT SetConfig_BinaryText(SecondNode, "Eth-Mirror",
			                             &FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entry[Count].mirroring_config.eth_mirror_enable,"Yes", "No", 3, 2)) {
			}
			Count++;
		}
		FWDConfig_t.l2_fwd_config.l2_fwd_vlan_config_entries = Count;

	}

	return TRUE;
}



static bool Set_Config_L2MACTbl(mxml_node_t * L2L3UpdateNode)
{
	/*Entry*/
	mxml_node_t   * portnumber = NULL;
	mxml_node_t   * SecondNode = NULL;
	mxml_node_t   * PortLockNode = NULL;
	uint32_t      Count = 0;
	uint32_t      SourceLockCount = 0;
	uint32_t      PortCount = 0;
	if ((SecondNode = mxmlFindElement(L2L3UpdateNode, L2L3UpdateNode, "MAC-Entry", NULL, NULL, MXML_DESCEND_FIRST)) == NULL) {

		fprintf(stderr, "\nERROR : No <MAC-Entry> in <RMAC-Table>  in <Layer2-Forwarding> in <Forwarding> in '%s'\n",

		        gOptConfigFile);

		return FALSE;

	}
	else {
		Count = 0;

		for (; SecondNode != NULL; SecondNode = mxmlWalkNext(SecondNode, L2L3UpdateNode, MXML_NO_DESCEND)) {
			if (SecondNode->type != MXML_ELEMENT) {
				continue;
			}
			if (Count >= RSWITCH2_MAX_L2_FWD_ENTRIES) {
				fprintf(stderr, "ERROR : A maximum of %d <MAC-Entry> in <MAC-Table>  in <Layer2-Forwarding> in <Forwarding> in %s\n",
				        RSWITCH2_MAX_L2_FWD_ENTRIES, gOptConfigFile);
				return FALSE;
			}
			/* Check This Logic */
			if ((portnumber = mxmlFindElement(SecondNode, SecondNode, "Dest-PortNumber", NULL, NULL, MXML_DESCEND_FIRST)) == NULL) {

				if (NOT SetConfig_Integer(SecondNode, "Dest-CPU", &FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].csdn,RSWITCH2_MAX_CSDN)) {
					fprintf(stderr, "\nERROR : No <Dest-CPU> or <Dest-PortNumber> in <MAC-Entry> in <MAC-Table>  in <Layer2-Forwarding> in <Forwarding> in '%s'\n",
					        gOptConfigFile);
					return FALSE;
				}
				else {
					FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].destination_vector_config.cpu = 1;
				}
			}
			else {
				if (NOT SetConfig_Integer(SecondNode, "Dest-CPU", &FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].csdn,RSWITCH2_MAX_CSDN)) {
					FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].destination_vector_config.cpu = 0;
				}
				else {
					FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].destination_vector_config.cpu = 1;
				}
				PortCount = 0;
				for (; portnumber != NULL; portnumber = mxmlWalkNext(portnumber, SecondNode, MXML_NO_DESCEND)) {
					if (portnumber->type != MXML_ELEMENT) {
						continue;
					}
					if (NOT SetConfig_lookupstrportnumber(portnumber,
					                                      &FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].destination_vector_config.port_number[PortCount],"Dest-PortNumber", PortCount)) {
						continue;
					}
					for (int i = 0; i < PortCount; i++) {
						if (FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].destination_vector_config.port_number[PortCount] ==
						        FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].destination_vector_config.port_number[i]) {
							fprintf(stderr, "\nERROR: Duplicate <Dest-PortNumber> '%d' <MAC-Entry> in <MAC-Table>  in <Layer2-Forwarding> in <Forwarding> in '%s'\n",
							        FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].destination_vector_config.port_number[PortCount], gOptConfigFile);
							return FALSE;

						}

					}
					PortCount++;
				}

				FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].destination_vector_config.dest_eth_ports = PortCount;

			}
			if (NOT SetConfig_Integer(SecondNode, "IPV-Update",&FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].mirroring_config.ipv_config.ipv_value,
			                          RSWITCH2_MAX_IPV)) {

			}
			else {
				FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].mirroring_config.ipv_config.ipv_update_enable = 1;

			}
			if (NOT SetConfig_MAC(SecondNode,  FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].mac, "MAC", Count)) {
			}
			if (NOT SetConfig_BinaryText(SecondNode, "Src-Learn-Disable", &FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].mac_learn_disable,"Yes", "No", 3, 2)) {
			}
			if (NOT SetConfig_BinaryText(SecondNode, "Entry-Mode", &FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].mac_dynamic_learn,"Dynamic", "Static", 7, 6)) {
			}
			if (NOT SetConfig_BinaryText(SecondNode, "Security-Level", &FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].mac_security_learn,"ALL", "UNSECURE", 3, 8)) {
				FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].mac_security_learn = 0;
			}
			/*Source-LOck-CPU*/
			if (NOT SetConfig_BinaryText(SecondNode, "Dest-Src-Unlock-CPU", &FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].destination_source.cpu,
			                             "Yes", "No", 3, 2)) {
				FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].destination_source.cpu = 0;
			}
			if ((PortLockNode = mxmlFindElement(SecondNode, SecondNode, "Dest-Src-Unlock-Port", NULL, NULL, MXML_DESCEND_FIRST)) == NULL) {
				if (!FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].destination_source.cpu) {
					for (def_port_count = 0; def_port_count <= max_port_number; def_port_count++) {
						if (def_port_count < max_port_number) {
							FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].
							destination_source.source_port_number[def_port_count] = def_port_count;
						}
						else {

							FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].destination_source.cpu = 1;
						}
					}
					FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].destination_source.source_ports = max_port_number;
				}

			}
			SourceLockCount = 0;
			for (; PortLockNode != NULL; PortLockNode = mxmlWalkNext(PortLockNode, SecondNode, MXML_NO_DESCEND)) {
				if (PortLockNode->type != MXML_ELEMENT) {
					continue;
				}
				if (NOT SetConfig_lookupstrportnumber(PortLockNode, &FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].destination_source.
				                                      source_port_number[SourceLockCount], "Dest-Src-Unlock-Port",SourceLockCount)) {
					continue;
				}
				for (int i = 0; i < SourceLockCount; i++) {
					if ((FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].destination_source.
					        source_port_number[SourceLockCount] == FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].destination_source.
					        source_port_number[i]) && (FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].destination_source.cpu== 0)) {
						fprintf(stderr, "\nERROR: Duplicate <Dest-Src-Unlock-Port> %d  in <MAC-Entry> in <MAC-Table> in \
                            <Layer2-Forwarding> in <Forwarding> '%s'\n",
						        FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].destination_source.
						        source_port_number[SourceLockCount], gOptConfigFile);
						return FALSE;
					}
				}
				SourceLockCount++;


			}
			if (SourceLockCount != 0) {
				FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].destination_source.source_ports = SourceLockCount;
			}
			/*Source-LOck-CPU*/
			if (NOT SetConfig_BinaryText(SecondNode, "Src-Src-Unlock-CPU", &FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].source_source.cpu,
			                             "Yes", "No", 3, 2)) {
				FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].source_source.cpu = 0;
			}
			if ((PortLockNode = mxmlFindElement(SecondNode, SecondNode, "Src-Src-Unlock-Port", NULL, NULL, MXML_DESCEND_FIRST)) == NULL) {
				if (!FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].source_source.cpu) {
					for (def_port_count = 0; def_port_count <= max_port_number; def_port_count++) {
						if (def_port_count < max_port_number) {
							FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].
							source_source.source_port_number[def_port_count] = def_port_count;
						}
						else {

							FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].source_source.cpu = 1;
						}
					}
					FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].source_source.source_ports = max_port_number;
				}
			}
			SourceLockCount = 0;
			for (; PortLockNode != NULL; PortLockNode = mxmlWalkNext(PortLockNode, SecondNode, MXML_NO_DESCEND)) {
				if (PortLockNode->type != MXML_ELEMENT) {
					continue;
				}
				if (NOT SetConfig_lookupstrportnumber(PortLockNode, &FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].source_source.
				                                      source_port_number[SourceLockCount], "Src-Src-Unlock-Port",SourceLockCount)) {
					continue;
				}
				for (int i = 0; i < SourceLockCount; i++) {
					if ((FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].source_source.
					        source_port_number[SourceLockCount] == FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].source_source.
					        source_port_number[i]) && (FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].source_source.cpu== 0)) {
						fprintf(stderr, "\nERROR: Duplicate <Src-Src-Unlock-Port> %d  in <MAC-Entry> in <MAC-Table> in \
                            <Layer2-Forwarding> in <Forwarding> '%s'\n",
						        FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].source_source.
						        source_port_number[SourceLockCount], gOptConfigFile);
						return FALSE;
					}
				}
				SourceLockCount++;


			}
			if (SourceLockCount != 0) {
				FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].source_source.source_ports = SourceLockCount;
			}
			if (NOT SetConfig_BinaryText(SecondNode, "CPU-Mirror",
			                             &FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].mirroring_config.cpu_mirror_enable,"Yes", "No", 3, 2)) {
			}
			if (NOT SetConfig_BinaryText(SecondNode, "Eth-Mirror",
			                             &FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entry[Count].mirroring_config.eth_mirror_enable,"Yes", "No", 3, 2)) {
			}
			Count++;
		}
		FWDConfig_t.l2_fwd_config.l2_fwd_mac_config_entries = Count;

	}

	return TRUE;
}

static bool Set_Config_rx_mcast(mxml_node_t * McastNode)
{
	/*Entry*/
	mxml_node_t   * SecondNode = NULL;
	mxml_node_t   * NextEntryNode = NULL;
	uint32_t	Count = 0;
	uint32_t	NextCount = 0;
	uint32_t 	entrycount = 0;
	uint32_t	next = 0;
	memset(&FWDConfig_t.rx_mcast_config,0, sizeof(struct rswitch2_cpu_rx_mcast_config) );
	if ((SecondNode = mxmlFindElement(McastNode, McastNode, "Chain", NULL, NULL, MXML_DESCEND_FIRST)) == NULL) {

		fprintf(stderr, "\nERROR : No <Chain> in <CPU-RX-Multicast>  in <Forwarding> in '%s'\n",

		        gOptConfigFile);

		return FALSE;

	}
	else {
		Count = 0;

		for (; SecondNode != NULL; SecondNode = mxmlWalkNext(SecondNode, McastNode, MXML_NO_DESCEND)) {
			if (SecondNode->type != MXML_ELEMENT) {
				continue;
			}
			if(strcmp(SecondNode->value.element.name, "Chain") != 0) {
				continue;
			}
			if (Count >= RSWITCH2_MAX_MCAST_CHAINS) {
				fprintf(stderr, "ERROR : A maximum of %d <Chain> in <CPU-RX-Multicast> in <Forwarding> in %s\n",
				        RSWITCH2_MAX_MCAST_CHAINS, gOptConfigFile);
				return FALSE;
			}
			
			if (NOT SetConfig_Integer(SecondNode, "EntryNumber",&FWDConfig_t.rx_mcast_config.entry[entrycount].entry_num,
			                          RSWITCH2_MAX_MCAST_CHAINS - 1)) {

			} 
			FWDConfig_t.rx_mcast_config.entry[entrycount].base_entry = 1;
			for(int i = 0; i < entrycount; i++) {
				if((FWDConfig_t.rx_mcast_config.entry[i].base_entry) && 
					(FWDConfig_t.rx_mcast_config.entry[entrycount].base_entry)){
					if(FWDConfig_t.rx_mcast_config.entry[entrycount].entry_num < 
					FWDConfig_t.rx_mcast_config.entry[i].entry_num){
						fprintf(stderr, "ERROR :  <Chain> <EntryNumber> for each chain should be greater \
							than previous chain in <CPU-RX-Multicast> in <Forwarding> in %s\n",
								gOptConfigFile);
						return FALSE;
					}
				}
			}
			entrycount++;
			NextCount = 1;
			if ((NextEntryNode = mxmlFindElement(SecondNode, SecondNode, "NextNumber", NULL, NULL, MXML_DESCEND_FIRST)) != NULL) {
				for (; NextEntryNode != NULL; NextEntryNode = mxmlWalkNext(NextEntryNode, SecondNode, MXML_NO_DESCEND)) {
					if (NextEntryNode->type != MXML_ELEMENT) {
						continue;
					}
					if(strcmp(NextEntryNode->value.element.name, "NextNumber") != 0) {
						continue;
					}
					if (NextCount >= RSWITCH2_MAX_NEXT_ENTRIES) {
						fprintf(stderr, "ERROR : A maximum of %d <Next Entry> in <Chain> in <CPU-RX-Multicast> in <Forwarding> in %s\n",
							RSWITCH2_MAX_NEXT_ENTRIES, gOptConfigFile);
						return FALSE;
					}
					if (NOT SetConfig_loopNode(NextEntryNode, &FWDConfig_t.rx_mcast_config.entry[entrycount].entry_num, 
						Count, "NextNumber", RSWITCH2_MAX_MCAST_CHAINS - 1 )) {
						continue;
					}
#if 0
					if(FWDConfig_t.rx_mcast_config.entry[entrycount].entry_num <= 
						FWDConfig_t.rx_mcast_config.entry[entrycount - 1].entry_num) {
						fprintf(stderr, "ERROR : Next Entry %d in <Chain>  %d in <CPU-RX-Multicast> \
							in <Forwarding> in %s cannot be greater than or eqaual to Entry Number %d\n",
				        		FWDConfig_t.rx_mcast_config.entry[entrycount].entry_num,Count,
							gOptConfigFile, FWDConfig_t.rx_mcast_config.entry[entrycount -1].entry_num);
						return FALSE;
					}
#endif
					entrycount++;
					NextCount++;
					
				}
				
			}
			
			Count++;
		}
		for(int i = 0; i < entrycount; i++) {
			FWDConfig_t.rx_mcast_config.entry[i].next_entry_num = FWDConfig_t.rx_mcast_config.entry[i + 1].entry_num;
			
			
			if((FWDConfig_t.rx_mcast_config.entry[i].base_entry) && (i != 0))  {
				FWDConfig_t.rx_mcast_config.entry[i - next].next_entries = next -1;
				FWDConfig_t.rx_mcast_config.entry[i - 1].next_entry_num = 0;
				FWDConfig_t.rx_mcast_config.entry[i - 1].end_entry = 1;
				next = 0;
			}
			next++;
		}
		FWDConfig_t.rx_mcast_config.entry[entrycount - next].next_entries = next -1;
		
		
		for(int i = 0; i < entrycount -1; i++) {    
			for(int j = i + 1; j < entrycount - 1; j++) {    
				
				if(FWDConfig_t.rx_mcast_config.entry[i].entry_num == FWDConfig_t.rx_mcast_config.entry[j].entry_num) {  
					if(FWDConfig_t.rx_mcast_config.entry[i + 1].base_entry) {
						FWDConfig_t.rx_mcast_config.entry[i].next_entries = 
							FWDConfig_t.rx_mcast_config.entry[j].next_entries;
						FWDConfig_t.rx_mcast_config.entry[i].next_entry_num = 
							FWDConfig_t.rx_mcast_config.entry[j].next_entry_num;
						FWDConfig_t.rx_mcast_config.entry[i].base_entry = 
							FWDConfig_t.rx_mcast_config.entry[j].base_entry;
						for(int k = j; k < entrycount -1 ; k++){
							FWDConfig_t.rx_mcast_config.entry[k].entry_num = 
								FWDConfig_t.rx_mcast_config.entry[k + 1].entry_num;
							FWDConfig_t.rx_mcast_config.entry[k].next_entries = 
								FWDConfig_t.rx_mcast_config.entry[k + 1].next_entries;
							FWDConfig_t.rx_mcast_config.entry[k].next_entry_num = 
								FWDConfig_t.rx_mcast_config.entry[k + 1].next_entry_num;
							FWDConfig_t.rx_mcast_config.entry[k].base_entry =
								FWDConfig_t.rx_mcast_config.entry[k + 1].base_entry;
							
						}
						entrycount--;
						j--;
					} else {
						if((FWDConfig_t.rx_mcast_config.entry[i + 1].entry_num != 
							FWDConfig_t.rx_mcast_config.entry[j + 1].entry_num) && 
							(!FWDConfig_t.rx_mcast_config.entry[j].end_entry)) {
							fprintf(stderr, "ERROR : Divergent \
									Entry %d->%d  in  and  Entry %d->%d  in\
									<CPU-RX-Multicast> in <Forwarding> in %s \n",
				        				FWDConfig_t.rx_mcast_config.entry[i ].entry_num ,
									FWDConfig_t.rx_mcast_config.entry[i + 1].entry_num,
									FWDConfig_t.rx_mcast_config.entry[j ].entry_num ,
									FWDConfig_t.rx_mcast_config.entry[j + 1].entry_num,
									gOptConfigFile);
									return FALSE;
						} else {
							if(!FWDConfig_t.rx_mcast_config.entry[j].end_entry) {
								FWDConfig_t.rx_mcast_config.entry[i].next_entries = 
									FWDConfig_t.rx_mcast_config.entry[j].next_entries;
								FWDConfig_t.rx_mcast_config.entry[i].next_entry_num = 
									FWDConfig_t.rx_mcast_config.entry[j].next_entry_num;
								FWDConfig_t.rx_mcast_config.entry[i].base_entry = 
									FWDConfig_t.rx_mcast_config.entry[j].base_entry;
							}
							for(int k = j; k < entrycount -1 ; k++){
								FWDConfig_t.rx_mcast_config.entry[k].entry_num =
									 FWDConfig_t.rx_mcast_config.entry[k + 1].entry_num;
								FWDConfig_t.rx_mcast_config.entry[k].next_entries =
									 FWDConfig_t.rx_mcast_config.entry[k + 1].next_entries;
								FWDConfig_t.rx_mcast_config.entry[k].next_entry_num =
									 FWDConfig_t.rx_mcast_config.entry[k + 1].next_entry_num;
								FWDConfig_t.rx_mcast_config.entry[k].base_entry =
									 FWDConfig_t.rx_mcast_config.entry[k + 1].base_entry;
							
							}
							entrycount--;
							j--;
						}
					}
				}
			}
			
    		}
		for(int i = 0;  i < entrycount -1;  i++) {
			if(FWDConfig_t.rx_mcast_config.entry[i].entry_num == FWDConfig_t.rx_mcast_config.entry[entrycount -1].entry_num) {
				entrycount--;
				break;
			}
		}
#if 0 
		for(int i = 0;  i < entrycount;  i++) {
			printf("Entry=%d Next=%d Base=%d NumNext=%d\n",
				FWDConfig_t.rx_mcast_config.entry[i].entry_num,
				FWDConfig_t.rx_mcast_config.entry[i].next_entry_num,
				FWDConfig_t.rx_mcast_config.entry[i].base_entry,
				FWDConfig_t.rx_mcast_config.entry[i].next_entries);
		}
#endif
		FWDConfig_t.rx_mcast_config.entries = entrycount;
    	}    
		
	
	return TRUE;
}


static bool SetConfig_Port_Forwarding(mxml_node_t * PortFwdNode, uint32_t Count)
{
	mxml_node_t   *PortNode;
	uint32_t PortCount = 0;
	mxml_node_t   * portnumber = NULL;
	if (NOT SetConfig_BinaryText(PortFwdNode, "Force-Frame-Priority", &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].port_forwarding.force_frame_priority,
	                             "Enable", "Disable", 6, 7)) {
	}
	if (NOT SetConfig_BinaryText(PortFwdNode, "IPV6-Priority-Decode", &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].port_forwarding.ipv6_priority_decode,
	                             "Enable", "Disable", 6, 7)) {
	}
	if (NOT SetConfig_BinaryText(PortFwdNode, "IPV4-Priority-Decode", &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].port_forwarding.ipv4_priority_decode,
	                             "Enable", "Disable", 6, 7)) {
	}
	if (NOT SetConfig_BinaryText(PortFwdNode, "IPV4-Priority-Decode-Mode", &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].port_forwarding.ipv4_priority_decode_mode,
	                             "TOS", "Precedent", 3, 9)) {
	}
	if (NOT SetConfig_BinaryText(PortFwdNode, "Security-Level", &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].port_forwarding.security_learn,"ALL", "UNSECURE", 3, 8)) {
		FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].port_forwarding.security_learn = 0;
	}
	if (NOT SetConfig_BinaryText(PortFwdNode, "CPU-Mirror",
	                             &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].port_forwarding.mirroring_config.cpu_mirror_enable,"Yes", "No", 3, 2)) {
	}
	if (NOT SetConfig_BinaryText(PortFwdNode, "Eth-Mirror",
	                             &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].port_forwarding.mirroring_config.eth_mirror_enable,"Yes", "No", 3, 2)) {
	}
	if (NOT SetConfig_Integer(PortFwdNode, "IPV-Update",
	                          &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].port_forwarding.mirroring_config.ipv_config.ipv_value, RSWITCH2_MAX_IPV)) {
	}
	else {
		FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].port_forwarding.mirroring_config.ipv_config.ipv_update_enable = 1;

	}
	if ((PortNode = mxmlFindElement(PortFwdNode, PortFwdNode, "Broadcast", NULL, NULL, MXML_DESCEND_FIRST)) != NULL) {
		if ((portnumber = mxmlFindElement(PortNode, PortNode, "PortNumber", NULL, NULL, MXML_DESCEND_FIRST)) == NULL) {
			if (NOT SetConfig_Integer(PortNode, "CPU", &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].port_forwarding.csdn,RSWITCH2_MAX_CSDN)) {
				//fprintf(stderr, "\nERROR : No <CPU> or <PortNumber> in <Broadcast> in <Port-Specific> in <Forwarding> in '%s'\n",
				  //      gOptConfigFile);
				//return FALSE;
				FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].port_forwarding.bEnable = 1;
				return TRUE;
			}
			else {
				FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].port_forwarding.destination_vector_config.cpu = 1;
			}
		}
		else {
			if (NOT SetConfig_Integer(PortNode, "CPU", &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].port_forwarding.csdn,RSWITCH2_MAX_CSDN)) {

			}
			else {
				FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].port_forwarding.destination_vector_config.cpu = 1;
			}
			PortCount = 0;
			for (; portnumber != NULL; portnumber = mxmlWalkNext(portnumber, PortNode, MXML_NO_DESCEND)) {
				if (portnumber->type != MXML_ELEMENT) {
					continue;
				}
				if (NOT SetConfig_lookupstrportnumber(portnumber,
				                                      &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].port_forwarding.destination_vector_config.port_number[PortCount], "PortNumber",PortCount)) {
					continue;
				}
				for (int i = 0; i < PortCount; i++) {
					if (FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].port_forwarding.destination_vector_config.port_number[PortCount] ==
					        FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].port_forwarding.destination_vector_config.port_number[i]) {
						fprintf(stderr, "\nERROR: Duplicate <PortNumber> '%d' <Broadcast> in <Port-Specific> in <Forwarding> in '%s'\n",
						        FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].port_forwarding.destination_vector_config.port_number[PortCount], gOptConfigFile);
						return FALSE;

					}

				}
				PortCount++;
			}

			FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].port_forwarding.destination_vector_config.dest_eth_ports = PortCount;

		}

	}
	FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].port_forwarding.bEnable = TRUE;
	return TRUE;
}

static bool Set_Config_Two_Byte_Filters(mxml_node_t	*FilterNode, mxml_node_t	*StreamNode)
{
	uint32_t Count = 0;
	char const *ch = NULL;
	uint32_t vlan_mode = 0;
	Count = 0;
	for (; FilterNode != NULL; FilterNode = mxmlWalkNext(FilterNode, StreamNode, MXML_NO_DESCEND)) {
		if (FilterNode->type != MXML_ELEMENT) {
			continue;
		}
		if(strcmp(FilterNode->value.element.name, "2-Byte-Filter") != 0) {
			continue;
		}
		if (Count >= RSWITCH2_MAX_TWO_BYTE_FILTERS) {
			fprintf(stderr, "ERROR : A maximum of %d <2-Byte-Filter>  allowed \
				in <Stream-Forwarding> in <Forwarding> in %s\n",RSWITCH2_MAX_TWO_BYTE_FILTERS, gOptConfigFile);
			return FALSE;
		}
		if (NOT SetConfig_Integer(FilterNode, "Number",
	            	&FWDConfig_t.l3_stream_fwd.fwd_filter_config.two_byte[Count].filter_number,
			RSWITCH2_MAX_TWO_BYTE_FILTERS - 1)) {
			fprintf(stderr, "\nERROR : No <Number> in <2-Byte-Filter>  \
				in <Stream-Forwarding> in <Forwarding> in '%s'\n", gOptConfigFile);
			return FALSE;
		}
		if ((ch = SetConfig_GetText(FilterNode, FilterNode, "Offset")) != NULL) {
			if (strcasecmp(ch, "STAG") == 0) {
				if(FWDConfig_o.config_done) {
					vlan_mode = FWDConfig_o.fwd_gen_config.vlan_mode;
				} else {
					vlan_mode = FWDConfig_t.fwd_gen_config.vlan_mode;
				}
				if(vlan_mode == 0x01) {
					fprintf(stderr, "\nERROR : Invalid <Offset> STAG in <2-Byte-Filter>  \
					Forwarding-Eng Mode CTAG not allowed in <Stream-Forwarding> in <Forwarding> in '%s'\n", 
					gOptConfigFile);
					return FALSE;
				} else {
					FWDConfig_t.l3_stream_fwd.fwd_filter_config.two_byte[Count].offset = 0;
					FWDConfig_t.l3_stream_fwd.fwd_filter_config.two_byte[Count].offset_mode = vlan_tag;
				} 
			} else if (strcasecmp(ch, "CTAG") == 0) {
				FWDConfig_t.l3_stream_fwd.fwd_filter_config.two_byte[Count].offset = 2;
				FWDConfig_t.l3_stream_fwd.fwd_filter_config.two_byte[Count].offset_mode = vlan_tag;	
			} else if (Set_Integer_Frm_String(ch, &FWDConfig_t.l3_stream_fwd.fwd_filter_config.two_byte[Count].offset,
					 RSWITCH2_MAX_FILTER_OFFSET, "Offset")) {
				FWDConfig_t.l3_stream_fwd.fwd_filter_config.two_byte[Count].offset_mode = offset;
			} else {
				fprintf(stderr, "\nERROR : Invalid <Offset> in <2-Byte-Filter>  \
					in <Stream-Forwarding> in <Forwarding> in '%s'\n", gOptConfigFile);
				return FALSE;

			}
		} else {
			fprintf(stderr, "\nERROR : No <Offset> in <2-Byte-Filter>  \
				in <Stream-Forwarding> in <Forwarding> in '%s'\n", gOptConfigFile);
			return FALSE;
		}
		if ((ch = SetConfig_GetText(FilterNode, FilterNode, "Unit-Mode")) != NULL) {
			if (strcasecmp(ch, "Mask") == 0) {
				FWDConfig_t.l3_stream_fwd.fwd_filter_config.two_byte[Count].unit_mode = mask;
			} else if (strcasecmp(ch, "Precise") == 0) {
				FWDConfig_t.l3_stream_fwd.fwd_filter_config.two_byte[Count].unit_mode = precise;
			} else if (strcasecmp(ch, "Expand") == 0) {
				if(FWDConfig_t.l3_stream_fwd.fwd_filter_config.two_byte[Count].offset_mode == vlan_tag) {
					fprintf(stderr, "\nERROR : Invalid <Unit-Mode> Expand in <2-Byte-Filter>  with Offset as Tag \
						in <Stream-Forwarding> in <Forwarding> in '%s'\n", gOptConfigFile);
					return FALSE;
				} else {
					FWDConfig_t.l3_stream_fwd.fwd_filter_config.two_byte[Count].unit_mode = expand;
				}
			} else {
				fprintf(stderr, "\nERROR : Invalid <Unit-Mode> in <2-Byte-Filter>  \
					in <Stream-Forwarding> in <Forwarding> in '%s'\n", gOptConfigFile);
				return FALSE;
			}
		} else {
			fprintf(stderr, "\nERROR : No <Unit-Mode> in <2-Byte-Filter>  \
				in <Stream-Forwarding> in <Forwarding> in '%s'\n", gOptConfigFile);
			return FALSE;
		}
		if (NOT SetConfig_Integer(FilterNode, "Value0",
	            	&FWDConfig_t.l3_stream_fwd.fwd_filter_config.two_byte[Count].value0,
			RSWITCH2_MAX_TWO_BYTE_VALUE)) {
			fprintf(stderr, "\nERROR : No <Value0> in <2-Byte-Filter>  \
				in <Stream-Forwarding> in <Forwarding> in '%s'\n", gOptConfigFile);
			return FALSE;
		}
		if (NOT SetConfig_Integer(FilterNode, "Mask-or-Value1",
	            	&FWDConfig_t.l3_stream_fwd.fwd_filter_config.two_byte[Count].value1,
			RSWITCH2_MAX_TWO_BYTE_VALUE)) {
			fprintf(stderr, "\nERROR : No <Mask-or-Value1> in <2-Byte-Filter>  \
				in <Stream-Forwarding> in <Forwarding> in '%s'\n", gOptConfigFile);
			return FALSE;
		}
		Count++;
	}
	
	FWDConfig_t.l3_stream_fwd.fwd_filter_config.num_two_byte_filters = Count;
	return TRUE;		
}

static bool Set_Config_Three_Byte_Filters(mxml_node_t	*FilterNode, mxml_node_t	*StreamNode)
{
	uint32_t Count = 0;
	char const *ch = NULL;
	Count = 0;
	for (; FilterNode != NULL; FilterNode = mxmlWalkNext(FilterNode, StreamNode, MXML_NO_DESCEND)) {
		if (FilterNode->type != MXML_ELEMENT) {
			continue;
		}
		if(strcmp(FilterNode->value.element.name, "3-Byte-Filter") != 0) {
			continue;
		}
		if (Count >= RSWITCH2_MAX_THREE_BYTE_FILTERS) {
			fprintf(stderr, "ERROR : A maximum of %d <3-Byte-Filter>  allowed \
				in <Stream-Forwarding> in <Forwarding> in %s\n",RSWITCH2_MAX_THREE_BYTE_FILTERS, gOptConfigFile);
			return FALSE;
		}
		if (NOT SetConfig_Integer(FilterNode, "Number",
	            	&FWDConfig_t.l3_stream_fwd.fwd_filter_config.three_byte[Count].filter_number,
			RSWITCH2_MAX_THREE_BYTE_FILTERS - 1)) {
			fprintf(stderr, "\nERROR : No <Number> in <3-Byte-Filter>  \
				in <Stream-Forwarding> in <Forwarding> in '%s'\n", gOptConfigFile);
			return FALSE;
		}
		if (NOT SetConfig_Integer(FilterNode, "Offset",
	            	&FWDConfig_t.l3_stream_fwd.fwd_filter_config.three_byte[Count].offset,
			RSWITCH2_MAX_FILTER_OFFSET)) {
			fprintf(stderr, "\nERROR : No <Offset> in <3-Byte-Filter>  \
				in <Stream-Forwarding> in <Forwarding> in '%s'\n", gOptConfigFile);
			return FALSE;
		}
		
		if ((ch = SetConfig_GetText(FilterNode, FilterNode, "Unit-Mode")) != NULL) {
			if (strcasecmp(ch, "Mask") == 0) {
				FWDConfig_t.l3_stream_fwd.fwd_filter_config.three_byte[Count].unit_mode = mask;
			} else if (strcasecmp(ch, "Precise") == 0) {
				FWDConfig_t.l3_stream_fwd.fwd_filter_config.three_byte[Count].unit_mode = precise;
			} else if (strcasecmp(ch, "Expand") == 0) {
				FWDConfig_t.l3_stream_fwd.fwd_filter_config.three_byte[Count].unit_mode = expand;
			} else {
				fprintf(stderr, "\nERROR : Invalid <Unit-Mode> in <3-Byte-Filter>  \
					in <Stream-Forwarding> in <Forwarding> in '%s'\n", gOptConfigFile);
				return FALSE;
			}
		} else {
			fprintf(stderr, "\nERROR : No <Unit-Mode> in <3-Byte-Filter>  \
				in <Stream-Forwarding> in <Forwarding> in '%s'\n", gOptConfigFile);
			return FALSE;
		}
		if (NOT SetConfig_Integer(FilterNode, "Value0",
	            	&FWDConfig_t.l3_stream_fwd.fwd_filter_config.three_byte[Count].value0,
			RSWITCH2_MAX_THREE_BYTE_VALUE)) {
			fprintf(stderr, "\nERROR : No <Value0> in <3-Byte-Filter>  \
				in <Stream-Forwarding> in <Forwarding> in '%s'\n", gOptConfigFile);
			return FALSE;
		}
		if (NOT SetConfig_Integer(FilterNode, "Mask-or-Value1",
	            	&FWDConfig_t.l3_stream_fwd.fwd_filter_config.three_byte[Count].value1,
			RSWITCH2_MAX_THREE_BYTE_VALUE)) {
			fprintf(stderr, "\nERROR : No <Mask-or-Value1> in <3-Byte-Filter>  \
				in <Stream-Forwarding> in <Forwarding> in '%s'\n", gOptConfigFile);
			return FALSE;
		}
		Count++;
	}
	
	FWDConfig_t.l3_stream_fwd.fwd_filter_config.num_three_byte_filters = Count;
	return TRUE;		
}
static bool Set_Config_Four_Byte_Filters(mxml_node_t	*FilterNode, mxml_node_t	*StreamNode)
{
	uint32_t Count = 0;
	char const *ch = NULL;
	Count = 0;
	for (; FilterNode != NULL; FilterNode = mxmlWalkNext(FilterNode, StreamNode, MXML_NO_DESCEND)) {
		if (FilterNode->type != MXML_ELEMENT) {
			continue;
		}
		if(strcmp(FilterNode->value.element.name, "4-Byte-Filter") != 0) {
			continue;
		}
		if (Count >= RSWITCH2_MAX_FOUR_BYTE_FILTERS) {
			fprintf(stderr, "ERROR : A maximum of %d <4-Byte-Filter>  allowed \
				in <Stream-Forwarding> in <Forwarding> in %s\n",RSWITCH2_MAX_FOUR_BYTE_FILTERS, gOptConfigFile);
			return FALSE;
		}
		if (NOT SetConfig_Integer(FilterNode, "Number",
	            	&FWDConfig_t.l3_stream_fwd.fwd_filter_config.four_byte[Count].filter_number,
			RSWITCH2_MAX_FOUR_BYTE_FILTERS - 1)) {
			fprintf(stderr, "\nERROR : No <Number> in <4-Byte-Filter>  \
				in <Stream-Forwarding> in <Forwarding> in '%s'\n", gOptConfigFile);
			return FALSE;
		}
		if (NOT SetConfig_Integer(FilterNode, "Offset",
	            	&FWDConfig_t.l3_stream_fwd.fwd_filter_config.four_byte[Count].offset,
			RSWITCH2_MAX_FILTER_OFFSET)) {
			fprintf(stderr, "\nERROR : No <Offset> in <4-Byte-Filter>  \
				in <Stream-Forwarding> in <Forwarding> in '%s'\n", gOptConfigFile);
			return FALSE;
		}
		
		if ((ch = SetConfig_GetText(FilterNode, FilterNode, "Unit-Mode")) != NULL) {
			if (strcasecmp(ch, "Mask") == 0) {
				FWDConfig_t.l3_stream_fwd.fwd_filter_config.four_byte[Count].unit_mode = mask;
			} else if (strcasecmp(ch, "Precise") == 0) {
				FWDConfig_t.l3_stream_fwd.fwd_filter_config.four_byte[Count].unit_mode = precise;
			} else if (strcasecmp(ch, "Expand") == 0) {
				FWDConfig_t.l3_stream_fwd.fwd_filter_config.four_byte[Count].unit_mode = expand;
			} else {
				fprintf(stderr, "\nERROR : Invalid <Unit-Mode> in <4-Byte-Filter>  \
					in <Stream-Forwarding> in <Forwarding> in '%s'\n", gOptConfigFile);
				return FALSE;
			}
		} else {
			fprintf(stderr, "\nERROR : No <Unit-Mode> in <4-Byte-Filter>  \
				in <Stream-Forwarding> in <Forwarding> in '%s'\n", gOptConfigFile);
			return FALSE;
		}
		if (NOT SetConfig_Integer(FilterNode, "Value0",
	            	&FWDConfig_t.l3_stream_fwd.fwd_filter_config.four_byte[Count].value0,
			RSWITCH2_MAX_FOUR_BYTE_VALUE)) {
			fprintf(stderr, "\nERROR : No <Value0> in <4-Byte-Filter>  \
				in <Stream-Forwarding> in <Forwarding> in '%s'\n", gOptConfigFile);
			return FALSE;
		}
		if (NOT SetConfig_Integer(FilterNode, "Mask-or-Value1",
	            	&FWDConfig_t.l3_stream_fwd.fwd_filter_config.four_byte[Count].value1,
			RSWITCH2_MAX_FOUR_BYTE_VALUE)) {
			fprintf(stderr, "\nERROR : No <Mask-or-Value1> in <4-Byte-Filter>  \
				in <Stream-Forwarding> in <Forwarding> in '%s'\n", gOptConfigFile);
			return FALSE;
		}
		Count++;
	}
	
	FWDConfig_t.l3_stream_fwd.fwd_filter_config.num_four_byte_filters = Count;
	return TRUE;		
}

static bool Set_Config_Range_Filters(mxml_node_t	*FilterNode, mxml_node_t	*StreamNode)
{
	uint32_t Count = 0;
	char const *ch = NULL;
	uint32_t vlan_mode = 0;
	Count = 0;
	for (; FilterNode != NULL; FilterNode = mxmlWalkNext(FilterNode, StreamNode, MXML_NO_DESCEND)) {
		if (FilterNode->type != MXML_ELEMENT) {
			continue;
		}
		if(strcmp(FilterNode->value.element.name, "Range-Filter") != 0) {
			continue;
		}
		if (Count >= RSWITCH2_MAX_RANGE_FILTERS) {
			fprintf(stderr, "ERROR : A maximum of %d <Range-Filter>  allowed \
				in <Stream-Forwarding> in <Forwarding> in %s\n",RSWITCH2_MAX_RANGE_FILTERS, gOptConfigFile);
			return FALSE;
		}
		if (NOT SetConfig_Integer(FilterNode, "Number",
	            	&FWDConfig_t.l3_stream_fwd.fwd_filter_config.range[Count].filter_number,
			RSWITCH2_MAX_RANGE_FILTERS - 1)) {
			fprintf(stderr, "\nERROR : No <Number> in <Range-Filter>  \
				in <Stream-Forwarding> in <Forwarding> in '%s'\n", gOptConfigFile);
			return FALSE;
		}
		if ((ch = SetConfig_GetText(FilterNode, FilterNode, "Offset")) != NULL) {
			if(FWDConfig_o.config_done) {
				vlan_mode = FWDConfig_o.fwd_gen_config.vlan_mode;
			} else {
				vlan_mode = FWDConfig_t.fwd_gen_config.vlan_mode;
			}
			if (strcasecmp(ch, "STAG-Byte0") == 0) {
				if(vlan_mode == 0x01) {
					fprintf(stderr, "\nERROR : Invalid <Offset> STAG-Byte0 in <Range-Filter>  \
					Forwarding-Eng Mode CTAG not allowed in <Stream-Forwarding> in <Forwarding> in '%s'\n", 
					gOptConfigFile);
					return FALSE;
				} else {
					FWDConfig_t.l3_stream_fwd.fwd_filter_config.range[Count].offset = 0;
					FWDConfig_t.l3_stream_fwd.fwd_filter_config.range[Count].offset_mode = vlan_tag;
				} 
			} else if (strcasecmp(ch, "STAG-Byte1") == 0) {
				if(vlan_mode == 0x01) {
					fprintf(stderr, "\nERROR : Invalid <Offset> STAG-Byte1 in <Range-Filter>  \
					Forwarding-Eng Mode CTAG not allowed in <Stream-Forwarding> in <Forwarding> in '%s'\n", 
					gOptConfigFile);
					return FALSE;
				} else {
					FWDConfig_t.l3_stream_fwd.fwd_filter_config.range[Count].offset = 1;
					FWDConfig_t.l3_stream_fwd.fwd_filter_config.range[Count].offset_mode = vlan_tag;
				} 
			} else if (strcasecmp(ch, "CTAG-Byte0") == 0) {
				FWDConfig_t.l3_stream_fwd.fwd_filter_config.range[Count].offset = 2;
				FWDConfig_t.l3_stream_fwd.fwd_filter_config.range[Count].offset_mode = vlan_tag;	
			} else if (strcasecmp(ch, "CTAG-Byte1") == 0) {
				FWDConfig_t.l3_stream_fwd.fwd_filter_config.range[Count].offset = 3;
				FWDConfig_t.l3_stream_fwd.fwd_filter_config.range[Count].offset_mode = vlan_tag;	
			} else if (Set_Integer_Frm_String(ch, &FWDConfig_t.l3_stream_fwd.fwd_filter_config.range[Count].offset,
					 RSWITCH2_MAX_FILTER_OFFSET, "Offset")) {
				FWDConfig_t.l3_stream_fwd.fwd_filter_config.range[Count].offset_mode = offset;
			} else {
				fprintf(stderr, "\nERROR : Invalid <Offset> in <Range-Filter>  \
					in <Stream-Forwarding> in <Forwarding> in '%s'\n", gOptConfigFile);
				return FALSE;

			}
		} else {
			fprintf(stderr, "\nERROR : No <Offset> in <Range-Filter>  \
				in <Stream-Forwarding> in <Forwarding> in '%s'\n", gOptConfigFile);
			return FALSE;
		}
		if (NOT SetConfig_Integer(FilterNode, "Range",
	            	&FWDConfig_t.l3_stream_fwd.fwd_filter_config.range[Count].range,
			RSWITCH2_MAX_RANGE)) {
			fprintf(stderr, "\nERROR : No <Range> in <Range-Filter>  \
				in <Stream-Forwarding> in <Forwarding> in '%s'\n", gOptConfigFile);
			return FALSE;
		}
		if (NOT SetConfig_Integer(FilterNode, "Value0",
	            	&FWDConfig_t.l3_stream_fwd.fwd_filter_config.range[Count].value0,
			RSWITCH2_MAX_RANGE_VALUE)) {
			fprintf(stderr, "\nERROR : No <Value0> in <Range-Filter>  \
				in <Stream-Forwarding> in <Forwarding> in '%s'\n", gOptConfigFile);
			return FALSE;
		}
		if (NOT SetConfig_Integer(FilterNode, "Value1",
	            	&FWDConfig_t.l3_stream_fwd.fwd_filter_config.range[Count].value1,
			RSWITCH2_MAX_RANGE_VALUE)) {
			fprintf(stderr, "\nERROR : No <Value1> in <Range-Filter>  \
				in <Stream-Forwarding> in <Forwarding> in '%s'\n", gOptConfigFile);
			return FALSE;
		}
		Count++;
	}
	
	FWDConfig_t.l3_stream_fwd.fwd_filter_config.num_range_filters = Count;
	return TRUE;		
}
static bool Set_Config_Cascade_Filters(mxml_node_t	*CasFilterNode, mxml_node_t	*StreamNode)
{
	uint32_t usedfiltercount = 0;
	mxml_node_t *usedfilterid = NULL;
	mxml_node_t   * portnumber = NULL;
	uint32_t Count = 0;
	uint32_t PortCount = 0;
	uint32_t cpu = 0;
	Count = 0;
	for (; CasFilterNode != NULL; CasFilterNode = mxmlWalkNext(CasFilterNode, StreamNode, MXML_NO_DESCEND)) {
		if (CasFilterNode->type != MXML_ELEMENT) {
			continue;
		}
		if(strcmp(CasFilterNode->value.element.name, "Cascade-Filter") != 0) {
			continue;
		}
		if (Count >= RSWITCH2_MAX_CASCADE_FILTERS) {
			fprintf(stderr, "ERROR : A maximum of %d <Cascade-Filter>  allowed \
				in <Stream-Forwarding> in <Forwarding> in %s\n",RSWITCH2_MAX_CASCADE_FILTERS, gOptConfigFile);
			return FALSE;
		}
		if (NOT SetConfig_Integer(CasFilterNode, "Number",
	            	&FWDConfig_t.l3_stream_fwd.fwd_filter_config.cascade[Count].filter_number,
			RSWITCH2_MAX_CASCADE_FILTERS - 1)) {
		}
		if ((portnumber = mxmlFindElement(CasFilterNode, CasFilterNode, "Src-PortNumber-pFrames",
			NULL, NULL, MXML_DESCEND_FIRST)) == NULL) {
			fprintf(stderr, "\nERROR : No <Src-PortNumber-pFrames> in <Cascade-Filter>  \
				in <Stream-Forwarding> in <Forwarding> in '%s'\n", gOptConfigFile);
			return FALSE;
		} else {
			PortCount = 0;
			for (; portnumber != NULL; portnumber = mxmlWalkNext(portnumber, CasFilterNode, MXML_NO_DESCEND)) {
				if (portnumber->type != MXML_ELEMENT) {
					continue;
				}
				if (NOT SetConfig_lookupstrportnumber(portnumber,
		                	&FWDConfig_t.l3_stream_fwd.fwd_filter_config.cascade[Count].
					pframe_valid.port_number[PortCount], "Src-PortNumber-pFrames",PortCount)) {
					continue;
				}
				for (int i = 0; i < PortCount; i++) {
					if (FWDConfig_t.l3_stream_fwd.fwd_filter_config.cascade[Count].
						pframe_valid.port_number[PortCount] ==
						FWDConfig_t.l3_stream_fwd.fwd_filter_config.cascade[Count].
						pframe_valid.port_number[i]) {
						fprintf(stderr, "\nERROR: Duplicate <Src-PortNumber-pFrames> '%d' in <Cascade-Filter>\
							in <Stream-Forwarding> in <Forwarding> '%s'\n",
							FWDConfig_t.l3_stream_fwd.fwd_filter_config.cascade[Count].
							pframe_valid.port_number[PortCount], gOptConfigFile);
						return FALSE;
					}

				}
				PortCount++;

			}
			FWDConfig_t.l3_stream_fwd.fwd_filter_config.cascade[Count].
							pframe_valid.dest_eth_ports = PortCount;
		}
		if ((portnumber = mxmlFindElement(CasFilterNode, CasFilterNode, "Src-PortNumber-eFrames",
			NULL, NULL, MXML_DESCEND_FIRST)) == NULL) {
			fprintf(stderr, "\nERROR : No <Src-PortNumber-eFrames> in <Cascade-Filter>  \
				in <Stream-Forwarding> in <Forwarding> in '%s'\n", gOptConfigFile);
			return FALSE;
		} else {
			PortCount = 0;
			cpu = 0;
			for (; portnumber != NULL; portnumber = mxmlWalkNext(portnumber, CasFilterNode, MXML_NO_DESCEND)) {
				if (portnumber->type != MXML_ELEMENT) {
					continue;
				}
				
				if (NOT SetConfig_lookupstragent(portnumber,
		                	&FWDConfig_t.l3_stream_fwd.fwd_filter_config.cascade[Count].
					eframe_valid.port_number[PortCount], "Src-PortNumber-eFrames",PortCount,
					&FWDConfig_t.l3_stream_fwd.fwd_filter_config.cascade[Count].
					eframe_valid.cpu)) {
					continue;
				}
				if(cpu != FWDConfig_t.l3_stream_fwd.fwd_filter_config.cascade[Count].
					eframe_valid.cpu) {
					cpu = 1;
					continue;
				}
				for (int i = 0; i < PortCount; i++) {	
					
					if (FWDConfig_t.l3_stream_fwd.fwd_filter_config.cascade[Count].
						eframe_valid.port_number[PortCount] ==
						FWDConfig_t.l3_stream_fwd.fwd_filter_config.cascade[Count].
						eframe_valid.port_number[i]) {
						fprintf(stderr, "\nERROR: Duplicate <Src-PortNumber-eFrames> '%d' in <Cascade-Filter> \
in <Stream-Forwarding> in <Forwarding> '%s'\n",
							FWDConfig_t.l3_stream_fwd.fwd_filter_config.cascade[Count].
							eframe_valid.port_number[PortCount], gOptConfigFile);
						return FALSE;
					}

				}

				PortCount++;

			}
			FWDConfig_t.l3_stream_fwd.fwd_filter_config.cascade[Count].
								eframe_valid.dest_eth_ports = PortCount;

		}
		if ((usedfilterid = mxmlFindElement(CasFilterNode, CasFilterNode, "Used-FilterID",
			NULL, NULL, MXML_DESCEND_FIRST)) == NULL) {
			fprintf(stderr, "\nERROR : No <Used-FilterID> in <Cascade-Filter>  in \
				<Stream-Forwarding> in <Forwarding> in '%s'\n", gOptConfigFile);
			return FALSE;
		} else {
			usedfiltercount = 0;
			for (; usedfilterid != NULL; usedfilterid = mxmlWalkNext(usedfilterid, CasFilterNode, MXML_NO_DESCEND)) {
				if (usedfilterid->type != MXML_ELEMENT) {
					continue;
				}
				if (usedfiltercount >= RSWITCH2_MAX_USED_CASCADE_FILTERS) {
					fprintf(stderr, "ERROR : A maximum of %d <Used-FilterID> allowed in <Cascade-Filter>\
					   in <Stream-Forwarding> in <Forwarding> in %s\n",RSWITCH2_MAX_USED_CASCADE_FILTERS, gOptConfigFile);
					return FALSE;
				}
				if (NOT SetConfig_loopNode(usedfilterid, &FWDConfig_t.l3_stream_fwd.
					fwd_filter_config.cascade[Count].
					used_filter_id_num[usedfiltercount], usedfiltercount, "Used-FilterID",
					RSWITCH2_MAX_USED_CASCADE_FILTERS_NUM )) {
					continue;
				}
				for (int i = 0; i < usedfiltercount; i++) {
					if (FWDConfig_t.l3_stream_fwd.fwd_filter_config.cascade[Count].
						used_filter_id_num[usedfiltercount] ==
						FWDConfig_t.l3_stream_fwd.fwd_filter_config.cascade[Count].
						used_filter_id_num[i]) {
						fprintf(stderr, "\nERROR: Duplicate <Used-Filter-ID> '%d' in <Cascade-Filter>\
							  in <Stream-Forwarding> in <Forwarding> '%s'\n",
							FWDConfig_t.l3_stream_fwd.fwd_filter_config.cascade[Count].
							used_filter_id_num[usedfiltercount], gOptConfigFile);
						return FALSE;
					}

				}

				usedfiltercount++;

			}
			FWDConfig_t.l3_stream_fwd.fwd_filter_config.cascade[Count].
								used_filter_ids = usedfiltercount;

		}
		Count++;
	}
	
	FWDConfig_t.l3_stream_fwd.fwd_filter_config.num_cascade_filters = Count;
	return TRUE;		
}


static bool Set_Config_L2L3_Update(mxml_node_t * L2L3UpdateNode)
{
	/*Entry*/
	mxml_node_t   * portnumber = NULL;
	mxml_node_t   * SecondNode = NULL;

	uint32_t routing_count = 0;
	uint32_t    Count = 0;

	uint32_t    PortCount = 0;
	if ((SecondNode = mxmlFindElement(L2L3UpdateNode, L2L3UpdateNode, "Entry", NULL, NULL, MXML_DESCEND_FIRST)) == NULL) {

		fprintf(stderr, "\nERROR : No <Entry> in <Routing-Update-Table>  in <Forwarding> in '%s'\n",

		        gOptConfigFile);

		return FALSE;

	}
	else {
		Count = 0;

		for (; SecondNode != NULL; SecondNode = mxmlWalkNext(SecondNode, L2L3UpdateNode, MXML_NO_DESCEND)) {
			if (SecondNode->type != MXML_ELEMENT) {
				continue;
			}
			if (Count >= RSWITCH2_MAX_L2_3_UPDATE_ENTRIES) {
				fprintf(stderr, "ERROR : A maximum of %d <Entry> entries allowed in <Routing-Update-Table> in <Forwarding> in %s\n",
				        RSWITCH2_MAX_L2_3_UPDATE_ENTRIES, gOptConfigFile);
				return FALSE;
			}
			/* Check This Logic */
			if ((portnumber = mxmlFindElement(SecondNode, SecondNode, "Routing-Port", NULL, NULL, MXML_DESCEND_FIRST)) == NULL) {
				if (NOT SetConfig_BinaryText(SecondNode, "Routing-CPU", &FWDConfig_t.l23_update.l23_update_config[Count].routing_port_update.cpu,
				                             "Yes", "No", 3, 2)) {
					fprintf(stderr, "\nERROR : No <Routing-CPU> or <Routing-Port> in <Entry>  in <Routing-Update-Table> in <Forwarding> in '%s'\n",
					        gOptConfigFile);
					return FALSE;
				}
			}
			else {
				if (NOT SetConfig_BinaryText(SecondNode, "Routing-CPU", &FWDConfig_t.l23_update.l23_update_config[Count].routing_port_update.cpu,
				                             "Yes", "No", 3, 2)) {
				}
				PortCount = 0;
				for (; portnumber != NULL; portnumber = mxmlWalkNext(portnumber, SecondNode, MXML_NO_DESCEND)) {
					if (portnumber->type != MXML_ELEMENT) {
						continue;
					}
					if (NOT SetConfig_lookupstrportnumber(portnumber,
					                                      &FWDConfig_t.l23_update.l23_update_config[Count].routing_port_update.port_number[PortCount],"Routing-Port", PortCount)) {
						continue;
					}
					for (int i = 0; i < PortCount; i++) {
						if (FWDConfig_t.l23_update.l23_update_config[Count].routing_port_update.port_number[PortCount] ==
						        FWDConfig_t.l23_update.l23_update_config[Count].routing_port_update.port_number[i]) {
							fprintf(stderr, "\nERROR: Duplicate <Routing-Port> '%d' in <Entry> in <Routing-Update-Table>  in <Forwarding> in '%s'\n",
							        FWDConfig_t.l23_update.l23_update_config[Count].routing_port_update.port_number[PortCount], gOptConfigFile);
							return FALSE;

						}

					}
					PortCount++;
				}

				FWDConfig_t.l23_update.l23_update_config[Count].routing_port_update.dest_eth_ports = PortCount;

			}


			if (NOT SetConfig_Integer(SecondNode, "Routing-Number",
			                          &FWDConfig_t.l23_update.l23_update_config[Count].routing_number, RSWITCH2_MAX_ROUTING_NUMBER)) {
			}
			for (routing_count = 0; routing_count < Count; routing_count++) {
				if (FWDConfig_t.l23_update.l23_update_config[Count].routing_number ==
				        FWDConfig_t.l23_update.l23_update_config[routing_count].routing_number) {
					fprintf(stderr, "\nERROR: Duplicate <Routing-Number> '%d' in <Entry> in <Routing-Update-Table>  in <Forwarding> in '%s'\n",
					        FWDConfig_t.l23_update.l23_update_config[Count].routing_number, gOptConfigFile);

					return FALSE;

				}

			}

			if (NOT SetConfig_Integer(SecondNode, "RTAG-Update",
			                          &FWDConfig_t.l23_update.l23_update_config[Count].rtag, RSWITCH2_MAX_RTAG)) {
			}
			if (NOT SetConfig_Integer(SecondNode, "STAG-DEI",
			                          &FWDConfig_t.l23_update.l23_update_config[Count].stag_dei, RSWITCH2_MAX_STAG_DEI)) {
			}
			else {
				FWDConfig_t.l23_update.l23_update_config[Count].stag_dei_update = enable;
			}
			if (NOT SetConfig_Integer(SecondNode, "STAG-PCP",
			                          &FWDConfig_t.l23_update.l23_update_config[Count].stag_pcp, RSWITCH2_MAX_STAG_PCP)) {
			}
			else {
				FWDConfig_t.l23_update.l23_update_config[Count].stag_pcp_update = enable;
			}
			if (NOT SetConfig_Integer(SecondNode, "STAG-ID",
			                          &FWDConfig_t.l23_update.l23_update_config[Count].stag_vlan, RSWITCH2_MAX_STAG_VLAN)) {
			}
			else {
				FWDConfig_t.l23_update.l23_update_config[Count].stag_vlan_update = enable;
			}
			if (NOT SetConfig_Integer(SecondNode, "CTAG-DEI",
			                          &FWDConfig_t.l23_update.l23_update_config[Count].ctag_dei, RSWITCH2_MAX_CTAG_DEI)) {
			}
			else {
				FWDConfig_t.l23_update.l23_update_config[Count].ctag_dei_update = enable;
			}
			if (NOT SetConfig_Integer(SecondNode, "CTAG-PCP",
			                          &FWDConfig_t.l23_update.l23_update_config[Count].ctag_pcp, RSWITCH2_MAX_CTAG_PCP)) {
			}
			else {
				FWDConfig_t.l23_update.l23_update_config[Count].ctag_pcp_update = enable;
			}
			if (NOT SetConfig_Integer(SecondNode, "CTAG-ID",
			                          &FWDConfig_t.l23_update.l23_update_config[Count].ctag_vlan, RSWITCH2_MAX_CTAG_VLAN)) {
			}
			else {
				FWDConfig_t.l23_update.l23_update_config[Count].ctag_vlan_update = enable;
			}
			if (NOT SetConfig_MAC(SecondNode,  FWDConfig_t.l23_update.l23_update_config[Count].dest_mac, "Dest-MAC", Count)) {
			}
			else {
				FWDConfig_t.l23_update.l23_update_config[Count].dest_mac_update = enable;
			}
			if (NOT SetConfig_BinaryText(SecondNode, "Src-MAC-Update", &FWDConfig_t.l23_update.l23_update_config[Count].src_mac_update,"Enable", "Disable", 6, 7)) {
			}
			if (NOT SetConfig_BinaryText(SecondNode, "TTL-Update", &FWDConfig_t.l23_update.l23_update_config[Count].ttl_update,"Enable", "Disable", 6, 7)) {
			}
			Count++;
		}
		FWDConfig_t.l23_update.entries = Count;

	}

	return TRUE;
}

static bool Set_Config_IPTbl(mxml_node_t * IPTbl) 
{
	/*Entry*/
	mxml_node_t   * portnumber = NULL;
	mxml_node_t   * SecondNode = NULL;
	mxml_node_t   * PortLockNode = NULL;
	uint32_t      Count = 0;
	uint32_t      SourceLockCount = 0;
	uint32_t      PortCount = 0;
	if ((SecondNode = mxmlFindElement(IPTbl, IPTbl, "IP-Entry", NULL, NULL, MXML_DESCEND_FIRST)) == NULL) {

		fprintf(stderr, "\nERROR : No <IP-Entry> in <IP-Table>  in <IP-Forwarding> in <Forwarding> in '%s'\n",

		        gOptConfigFile);

		return FALSE;

	}
	else {
		Count = 0;

		for (; SecondNode != NULL; SecondNode = mxmlWalkNext(SecondNode, IPTbl, MXML_NO_DESCEND)) {
			if (SecondNode->type != MXML_ELEMENT) {
				continue;
			}
			if (Count >= RSWITCH2_MAX_IP_FWD_ENTRIES) {
				fprintf(stderr, "ERROR : A maximum of %d <IP-Entry> in <IP-Table>  in <IP-Forwarding> in <Forwarding> in %s\n",
				        RSWITCH2_MAX_IP_FWD_ENTRIES, gOptConfigFile);
				return FALSE;
			}
			/* Check This Logic */
			if ((portnumber = mxmlFindElement(SecondNode, SecondNode, "Dest-PortNumber", NULL, NULL, MXML_DESCEND_FIRST)) == NULL) {

				if (NOT SetConfig_Integer(SecondNode, "Dest-CPU", &FWDConfig_t.ipv_fwd_config.entry[Count].csdn,RSWITCH2_MAX_CSDN)) {
					fprintf(stderr, "\nERROR : No <Dest-CPU> or <Dest-PortNumber> in <IP-Entry> in <IP-Table>  in <IP-Forwarding> in <Forwarding> in '%s'\n",
					        gOptConfigFile);
					return FALSE;
				}
				else {
					FWDConfig_t.ipv_fwd_config.entry[Count].destination_vector_config.cpu = 1;
				}
			}
			else {
				if (NOT SetConfig_Integer(SecondNode, "Dest-CPU", &FWDConfig_t.ipv_fwd_config.entry[Count].csdn,RSWITCH2_MAX_CSDN)) {
					FWDConfig_t.ipv_fwd_config.entry[Count].destination_vector_config.cpu = 0;
				}
				else {
					FWDConfig_t.ipv_fwd_config.entry[Count].destination_vector_config.cpu = 1;
				}
				PortCount = 0;
				for (; portnumber != NULL; portnumber = mxmlWalkNext(portnumber, SecondNode, MXML_NO_DESCEND)) {
					if (portnumber->type != MXML_ELEMENT) {
						continue;
					}
					if (NOT SetConfig_lookupstrportnumber(portnumber,
					                                      &FWDConfig_t.ipv_fwd_config.entry[Count].destination_vector_config.port_number[PortCount],"Dest-PortNumber", PortCount)) {
						continue;
					}
					for (int i = 0; i < PortCount; i++) {
						if (FWDConfig_t.ipv_fwd_config.entry[Count].destination_vector_config.port_number[PortCount] ==
						        FWDConfig_t.ipv_fwd_config.entry[Count].destination_vector_config.port_number[i]) {
							fprintf(stderr, "\nERROR: Duplicate <Dest-PortNumber> '%d' IP-Entry> in <IP-Table>  in <IP-Forwarding> in <Forwarding> in '%s'\n",
							        FWDConfig_t.ipv_fwd_config.entry[Count].destination_vector_config.port_number[PortCount], gOptConfigFile);
							return FALSE;

						}

					}
					PortCount++;
				}

				FWDConfig_t.ipv_fwd_config.entry[Count].destination_vector_config.dest_eth_ports = PortCount;

			}
			if (NOT SetConfig_Integer(SecondNode, "IPV-Update",&FWDConfig_t.ipv_fwd_config.entry[Count].mirroring_config.ipv_config.ipv_value,
			                          RSWITCH2_MAX_IPV)) {

			}
			else {
				FWDConfig_t.ipv_fwd_config.entry[Count].mirroring_config.ipv_config.ipv_update_enable = 1;

			}
			if (NOT SetConfig_Integer(SecondNode, "IP-Routing-Number",&FWDConfig_t.ipv_fwd_config.entry[Count].routing_number,
			                          RSWITCH2_MAX_ROUTING_NUMBER)) {

			} else {
				FWDConfig_t.ipv_fwd_config.entry[Count].routing_valid = 1;

			}
			if (NOT SetConfig_IPV4(SecondNode, FWDConfig_t.ipv_fwd_config.entry[Count].ipaddr,
					                       "IP-ADDR", Count)) {
			}
			if (NOT SetConfig_BinaryText(SecondNode, "Src-Learn-Disable", &FWDConfig_t.ipv_fwd_config.entry[Count].ipv_learn_disable,"Yes", "No", 3, 2)) {
			}
			if (NOT SetConfig_BinaryText(SecondNode, "Entry-Mode", &FWDConfig_t.ipv_fwd_config.entry[Count].ipv_dynamic_learn,"Dynamic", "Static", 7, 6)) {
			}
			if (NOT SetConfig_BinaryText(SecondNode, "IP-Type", &FWDConfig_t.ipv_fwd_config.entry[Count].ipv_dynamic_learn,"IPV6", "IPV4", 7, 6)) {
			}
			if (NOT SetConfig_BinaryText(SecondNode, "Security-Level", &FWDConfig_t.ipv_fwd_config.entry[Count].ipv_security_learn,"ALL", "UNSECURE", 3, 8)) {
				FWDConfig_t.ipv_fwd_config.entry[Count].ipv_security_learn = 0;
			}
			/*Source-LOck-CPU*/
			if (NOT SetConfig_BinaryText(SecondNode, "Dest-Src-Unlock-CPU", &FWDConfig_t.ipv_fwd_config.entry[Count].destination_source.cpu,
			                             "Yes", "No", 3, 2)) {
				FWDConfig_t.ipv_fwd_config.entry[Count].destination_source.cpu = 0;
			}
			if ((PortLockNode = mxmlFindElement(SecondNode, SecondNode, "Dest-Src-Unlock-Port", NULL, NULL, MXML_DESCEND_FIRST)) == NULL) {
				if (!FWDConfig_t.ipv_fwd_config.entry[Count].destination_source.cpu) {
					for (def_port_count = 0; def_port_count <= max_port_number; def_port_count++) {
						if (def_port_count < max_port_number) {
							FWDConfig_t.ipv_fwd_config.entry[Count].
							destination_source.source_port_number[def_port_count] = def_port_count;
						}
						else {

							FWDConfig_t.ipv_fwd_config.entry[Count].destination_source.cpu = 1;
						}
					}
					FWDConfig_t.ipv_fwd_config.entry[Count].destination_source.source_ports = max_port_number;
				}

			}
			SourceLockCount = 0;
			for (; PortLockNode != NULL; PortLockNode = mxmlWalkNext(PortLockNode, SecondNode, MXML_NO_DESCEND)) {
				if (PortLockNode->type != MXML_ELEMENT) {
					continue;
				}
				if (NOT SetConfig_lookupstrportnumber(PortLockNode, &FWDConfig_t.ipv_fwd_config.entry[Count].destination_source.
				                                      source_port_number[SourceLockCount], "Dest-Src-Unlock-Port",SourceLockCount)) {
					continue;
				}
				for (int i = 0; i < SourceLockCount; i++) {
					if ((FWDConfig_t.ipv_fwd_config.entry[Count].destination_source.
					        source_port_number[SourceLockCount] == FWDConfig_t.ipv_fwd_config.entry[Count].destination_source.
					        source_port_number[i]) && (FWDConfig_t.ipv_fwd_config.entry[Count].destination_source.cpu== 0)) {
						fprintf(stderr, "\nERROR: Duplicate <Dest-Src-Unlock-Port> %d  in <IP-Entry> in <IP-Table> in \
                            <IP-Forwarding> in <Forwarding> '%s'\n",
						        FWDConfig_t.ipv_fwd_config.entry[Count].destination_source.
						        source_port_number[SourceLockCount], gOptConfigFile);
						return FALSE;
					}
				}
				SourceLockCount++;


			}
			if (SourceLockCount != 0) {
				FWDConfig_t.ipv_fwd_config.entry[Count].destination_source.source_ports = SourceLockCount;
			}
			/*Source-LOck-CPU*/
			if (NOT SetConfig_BinaryText(SecondNode, "Src-Src-Unlock-CPU", &FWDConfig_t.ipv_fwd_config.entry[Count].source_source.cpu,
			                             "Yes", "No", 3, 2)) {
				FWDConfig_t.ipv_fwd_config.entry[Count].source_source.cpu = 0;
			}
			if ((PortLockNode = mxmlFindElement(SecondNode, SecondNode, "Src-Src-Unlock-Port", NULL, NULL, MXML_DESCEND_FIRST)) == NULL) {
				if (!FWDConfig_t.ipv_fwd_config.entry[Count].source_source.cpu) {
					for (def_port_count = 0; def_port_count <= max_port_number; def_port_count++) {
						if (def_port_count < max_port_number) {
							FWDConfig_t.ipv_fwd_config.entry[Count].
							source_source.source_port_number[def_port_count] = def_port_count;
						}
						else {

							FWDConfig_t.ipv_fwd_config.entry[Count].source_source.cpu = 1;
						}
					}
					FWDConfig_t.ipv_fwd_config.entry[Count].source_source.source_ports = max_port_number;
				}
			}
			SourceLockCount = 0;
			for (; PortLockNode != NULL; PortLockNode = mxmlWalkNext(PortLockNode, SecondNode, MXML_NO_DESCEND)) {
				if (PortLockNode->type != MXML_ELEMENT) {
					continue;
				}
				if (NOT SetConfig_lookupstrportnumber(PortLockNode, &FWDConfig_t.ipv_fwd_config.entry[Count].source_source.
				                                      source_port_number[SourceLockCount], "Src-Src-Unlock-Port",SourceLockCount)) {
					continue;
				}
				for (int i = 0; i < SourceLockCount; i++) {
					if ((FWDConfig_t.ipv_fwd_config.entry[Count].source_source.
					        source_port_number[SourceLockCount] == FWDConfig_t.ipv_fwd_config.entry[Count].source_source.
					        source_port_number[i]) && (FWDConfig_t.ipv_fwd_config.entry[Count].source_source.cpu== 0)) {
						fprintf(stderr, "\nERROR: Duplicate <Src-Src-Unlock-Port> %d  in <IP-Entry> in <IP-Table> in \
                            <IP-Forwarding> in <Forwarding> '%s'\n",
						        FWDConfig_t.ipv_fwd_config.entry[Count].source_source.
						        source_port_number[SourceLockCount], gOptConfigFile);
						return FALSE;
					}
				}
				SourceLockCount++;


			}
			if (SourceLockCount != 0) {
				FWDConfig_t.ipv_fwd_config.entry[Count].source_source.source_ports = SourceLockCount;
			}
			if (NOT SetConfig_BinaryText(SecondNode, "CPU-Mirror",
			                             &FWDConfig_t.ipv_fwd_config.entry[Count].mirroring_config.cpu_mirror_enable,"Yes", "No", 3, 2)) {
			}
			if (NOT SetConfig_BinaryText(SecondNode, "Eth-Mirror",
			                             &FWDConfig_t.ipv_fwd_config.entry[Count].mirroring_config.eth_mirror_enable,"Yes", "No", 3, 2)) {
			}
			
			Count++;
		}
		FWDConfig_t.ipv_fwd_config.ipv_fwd_config_entries = Count;

	}

	return TRUE;



}

static bool Set_Config_IPForwarding(mxml_node_t * IPFwdNode) 
{
	mxml_node_t   *IPtblNode = NULL;
	if (NOT SetConfig_Integer(IPFwdNode, "MAX-Unsecure-Hash",
		&FWDConfig_t.ipv_fwd_config.max_unsecure_hash_entry, RSWITCH2_MAX_UNSECURE_ENTRY)) {
		FWDConfig_t.ipv_fwd_config.max_unsecure_hash_entry = RSWITCH2_MAX_UNSECURE_ENTRY;

	}
	if (NOT SetConfig_Integer(IPFwdNode, "MAX-Hash-Collision",
		&FWDConfig_t.ipv_fwd_config.max_hash_collision, RSWITCH2_MAX_L3_COLLISION)) {
		FWDConfig_t.ipv_fwd_config.max_hash_collision = 0x3FF;

	}
	if (NOT SetConfig_Integer(IPFwdNode, "IPV-Hash-Equation",
		&FWDConfig_t.ipv_fwd_config.ipv_hash_eqn, RENESAS_RSWITCH2_MAX_HASH_EQUATION)) {
		FWDConfig_t.ipv_fwd_config.ipv_hash_eqn = 0x1; // Allow at least 1 unsecure entry by default

	}
	if ((IPtblNode = mxmlFindElement(IPFwdNode, IPFwdNode, "IP-Table", NULL, NULL, MXML_DESCEND_FIRST)) != NULL) {
		if (NOT Set_Config_IPTbl(IPtblNode)) {
				return FALSE;
		}

	}
	return TRUE;

}

static bool Set_Config(mxml_node_t * Tree, const char * const PortNode)

{
	mxml_node_t   * L2L3UpdateNode;
	mxml_node_t   * ForwardingEngine = NULL;
	mxml_node_t   * StreamNode = NULL;
	mxml_node_t   * PortLockNode = NULL;
	mxml_node_t   * AgingNode  = NULL;
	uint32_t SourceLockCount = 0;
	mxml_node_t   * portnumber = NULL;
	mxml_node_t   * VlantblNode = NULL;
	mxml_node_t   * IpNode = NULL;

	mxml_node_t   * FirstNode = NULL;

	mxml_node_t   * SecondNode = NULL;


	mxml_node_t   * PortFwdNode = NULL;

	mxml_node_t   * MactblNode = NULL;
	mxml_node_t   * L2Node = NULL;




	uint32_t    Count = 0;

	uint32_t    PortCount = 0;




	char  const   * ch = NULL;







	unsigned int GenCPU = 0;
	unsigned int GenPort = 0;
	mxml_node_t     *McastNode = NULL;
	mxml_node_t	*FilterNode = NULL;

	if ((ForwardingEngine = mxmlFindElement(Tree, Tree, PortNode, NULL, NULL, MXML_DESCEND_FIRST)) == NULL)

	{

		fprintf(stderr, "\nERROR : Unable to find <%s> in '%s'\n",

		        PortNode, gOptConfigFile);

		return FALSE;

	}

	if ((FirstNode = mxmlFindElement(ForwardingEngine, ForwardingEngine, "General-Configuration", NULL, NULL, MXML_DESCEND_FIRST)) != NULL)

	{
		/*VLAN-Mode*/

		if ((ch = SetConfig_GetText(FirstNode, FirstNode, "VLAN-Mode")) != NULL)

		{

			if (strcasecmp(ch, "No-VLAN") == 0)

			{

				FWDConfig_t.fwd_gen_config.vlan_mode = 0;

			}

			else if (strcasecmp(ch, "CTAG") == 0)

			{

				FWDConfig_t.fwd_gen_config.vlan_mode = 1;

			}

			else if (strcasecmp(ch, "STAG") == 0)

			{

				FWDConfig_t.fwd_gen_config.vlan_mode = 2;

			}



			else

			{

				fprintf(stderr, "\nERROR: Invalid <VLAN-Mode> in <General-Configuration> in <Forwarding> in '%s'\n",

				        gOptConfigFile);

				return FALSE;

			}

		}
		else {
			fprintf(stderr, "\nERROR: No <VLAN-Mode> in <General-Configuration> in <Forwarding> in '%s'\n",

			        gOptConfigFile);

			return FALSE;

		}


		/*CTAG*/

		if ((NOT SetConfig_Integer(FirstNode, "CTT",

		                           &FWDConfig_t.fwd_gen_config.ctag_tpid, RSWITCH2_MAX_TPID)))

		{
			FWDConfig_t.fwd_gen_config.ctag_tpid = 0x8100;




		}
		if ((NOT SetConfig_Integer(FirstNode, "STT",

		                           &FWDConfig_t.fwd_gen_config.stag_tpid, RSWITCH2_MAX_TPID)))

		{
			FWDConfig_t.fwd_gen_config.stag_tpid = 0x88A8;




		}


		/*Port-Specific*/

		if ((SecondNode = mxmlFindElement(FirstNode, FirstNode, "Port-Specific", NULL, NULL, MXML_DESCEND_FIRST)) == NULL)

		{
			FWDConfig_t.fwd_gen_config.bEnable = TRUE;
			FWDConfig_t.fwd_gen_config.vlan_mode_config_only = TRUE;

		}
		else

		{


			Count = 0;

			for (; SecondNode != NULL; SecondNode = mxmlWalkNext(SecondNode, FirstNode, MXML_NO_DESCEND))

			{

				if (SecondNode->type != MXML_ELEMENT)

				{

					continue;

				}



				if (Count >= (max_port_number  + 1))

				{

					fprintf(stderr, "ERROR : A maximum of %d <Port-Specific> entries allowed in <General-Configuration> in <Forwarding> in %s\n",

					        (max_port_number  + 1), gOptConfigFile);

					return FALSE;

				}






				/*portnumber*/
				if ((portnumber = mxmlFindElement(SecondNode, SecondNode, "PortNumber", NULL, NULL, MXML_DESCEND_FIRST)) == NULL)

				{
					/*CPU*/

					if (NOT SetConfig_BinaryText(SecondNode, "CPU", &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].cpu,

					                             "Yes", "No", 3, 2))

					{
						fprintf(stderr, "\nERROR: Unable to find <CPU> or <Portnumber> in <Port-Specific> in <General-Configuration> in <Forwarding> in '%s'\n",

						        gOptConfigFile);

						return FALSE;



					}
					else if (GenCPU == 1) {


						fprintf(stderr, "\nERROR: Multiple <CPU>  in <Port-Specific> in <General-Configuration> in <Forwarding> in '%s'\n",

						        gOptConfigFile);

						return FALSE;




					}
					else {

						GenCPU = 1;
					}




				}
				else {
					GenPort = 1;
				}

				if (GenPort) {
					if (NOT SetConfig_lookupstrportnumber(portnumber, &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].portnumber,"PortNumber", Count))
					{
					}
					GenPort = 0;
				}

				/*VLAN-Reject-Unknown-Secure*/
				if (NOT SetConfig_BinaryText(SecondNode, "VLAN-Reject-Unknown-Secure", &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].vlan_reject_unknown_secure,
				                             "Enable", "Disable", 6, 7))
				{
				}

				/*VLAN-Reject-Unknown*/
				if (NOT SetConfig_BinaryText(SecondNode, "VLAN-Reject-Unknown", &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].vlan_reject_unknown,
				                             "Enable", "Disable", 6, 7))
				{
					FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].vlan_reject_unknown = 1;
				}

				/*VLAN-Search-Active*/
				if (NOT SetConfig_BinaryText(SecondNode, "VLAN-Search-Active", &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].vlan_search_active,
				                             "Enable", "Disable", 6, 7))
				{
				}

				/*MAC-Hardware-Migration-Active*/
				if (NOT SetConfig_BinaryText(SecondNode, "MAC-Hardware-Migration-Active", &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].mac_hw_migration_active,
				                             "Enable", "Disable", 6, 7))
				{
				}

				/*MAC-Hardware-Learning-Active*/
				if (NOT SetConfig_BinaryText(SecondNode, "MAC-Hardware-Learning-Active", &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].mac_hw_learn_active,
				                             "Enable", "Disable", 6, 7))
				{
				}

				/*MAC-Reject-Unknown-Src-Secure-Addr*/
				if (NOT SetConfig_BinaryText(SecondNode, "MAC-Reject-Unknown-Src-Secure-Addr",
				                             &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].mac_reject_unknown_src_secure_addr,
				                             "Enable", "Disable", 6, 7))
				{
				}

				/*MAC-Reject-Unknown-Src-Addr*/
				if (NOT SetConfig_BinaryText(SecondNode, "MAC-Reject-Unknown-Src-Addr",
				                             &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].mac_reject_unknown_src_addr,

				                             "Enable", "Disable", 6, 7))

				{



				}
				/*MAC-Src-Search-Active*/

				if (NOT SetConfig_BinaryText(SecondNode, "MAC-Src-Search-Active",
				                             &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].mac_src_search_active,

				                             "Enable", "Disable", 6, 7))

				{
					FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].mac_src_search_active = 1;


				}
				/*MAC-Reject-Unknown-Dest-Secure-Addr*/

				if (NOT SetConfig_BinaryText(SecondNode, "MAC-Reject-Unknown-Dest-Secure-Addr",
				                             &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].mac_reject_unknown_dest_secure_addr,

				                             "Enable", "Disable", 6, 7))

				{



				}
				/*MAC-Reject-Unknown-Dest-Addr*/

				if (NOT SetConfig_BinaryText(SecondNode, "MAC-Reject-Unknown-Dest-Addr",
				                             &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].mac_reject_unknown_dest_addr,

				                             "Enable", "Disable", 6, 7))

				{



				}
				/*MAC-Dest-Search-Active*/

				if (NOT SetConfig_BinaryText(SecondNode, "MAC-Dest-Search-Active",
				                             &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].mac_dest_search_active,

				                             "Enable", "Disable", 6, 7))

				{
					FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].mac_dest_search_active = 1;


				}
				/*IP-Hardware-Migration-Active*/

				if (NOT SetConfig_BinaryText(SecondNode, "IP-Hardware-Migration-Active",
				                             &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ip_hw_migration_active,

				                             "Enable", "Disable", 6, 7))

				{



				}
				/*IP-Hardware-Learning-Active*/

				if (NOT SetConfig_BinaryText(SecondNode, "IP-Hardware-Learning-Active",
				                             &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ip_hw_learn_active,

				                             "Enable", "Disable", 6, 7))

				{



				}

				/*IP-Reject-Unknown-Src-Secure-Addr*/

				if (NOT SetConfig_BinaryText(SecondNode, "IP-Reject-Unknown-Src-Secure-Addr",
				                             &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ip_reject_unknown_src_secure_addr,

				                             "Enable", "Disable", 6, 7))

				{



				}
				/*IP-Reject-Unknown-Src-Addr*/

				if (NOT SetConfig_BinaryText(SecondNode, "IP-Reject-Unknown-Src-Addr",
				                             &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ip_reject_unknown_src_addr,

				                             "Enable", "Disable", 6, 7))

				{



				}

				/*IP-Src-Search-Active*/

				if (NOT SetConfig_BinaryText(SecondNode, "IP-Src-Search-Active",
				                             &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ip_src_search_active,

				                             "Enable", "Disable", 6, 7))

				{



				}
				/*IP-Reject-Unknown-Dest-Secure-Addr*/

				if (NOT SetConfig_BinaryText(SecondNode, "IP-Reject-Unknown-Dest-Secure-Addr",
				                             &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ip_reject_unknown_dest_secure_addr,

				                             "Enable", "Disable", 6, 7))

				{



				}
				/*IP-Reject-Unknown-Dest-Addr*/

				if (NOT SetConfig_BinaryText(SecondNode, "IP-Reject-Unknown-Dest-Addr",
				                             &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ip_reject_unknown_dest_addr,

				                             "Enable", "Disable", 6, 7))

				{



				}

				/*IP-Dest-Search-Active*/

				if (NOT SetConfig_BinaryText(SecondNode, "IP-Dest-Search-Active",
				                             &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ip_dest_search_active,

				                             "Enable", "Disable", 6, 7))

				{



				}
				/*IPV6-Extract-Active*/

				if (NOT SetConfig_BinaryText(SecondNode, "IPV6-Extract-Active",
				                             &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ipv6_extract_active,

				                             "Enable", "Disable", 6, 7))

				{



				}
				/*IPV4-Extract-Active*/

				if (NOT SetConfig_BinaryText(SecondNode, "IPV4-Extract-Active",
				                             &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ipv4_extract_active,

				                             "Enable", "Disable", 6, 7))

				{



				}
				/*L2-Stream-Enabled*/

				if (NOT SetConfig_BinaryText(SecondNode, "L2-Stream",
				                             &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].l2_stream_enabled,

				                             "Enable", "Disable", 6, 7))

				{



				}
				/*IPV6-OTHER*/

				if (NOT SetConfig_BinaryText(SecondNode, "IPV6-OTHER",
				                             &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ipv6_other_enabled,

				                             "Enable", "Disable", 6, 7))

				{



				}
				/*IPV6-TCP*/

				if (NOT SetConfig_BinaryText(SecondNode, "IPV6-TCP",
				                             &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ipv6_tcp_enabled,

				                             "Enable", "Disable", 6, 7))

				{



				}
				/*IPV6-UDP*/

				if (NOT SetConfig_BinaryText(SecondNode, "IPV6-UDP",
				                             &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ipv6_udp_enabled,

				                             "Enable", "Disable", 6, 7))

				{



				}
				/*IPV4-OTHER*/

				if (NOT SetConfig_BinaryText(SecondNode, "IPV4-OTHER",
				                             &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ipv4_other_enabled,

				                             "Enable", "Disable", 6, 7))

				{

					FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ipv4_other_enabled = 1;

				}
				/*IPV4-TCP*/

				if (NOT SetConfig_BinaryText(SecondNode, "IPV4-TCP",
				                             &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ipv4_tcp_enabled,

				                             "Enable", "Disable", 6, 7))

				{
					FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ipv4_tcp_enabled = 1;


				}
				/*IPV4-UDP*/

				if (NOT SetConfig_BinaryText(SecondNode, "IPV4-UDP",
				                             &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ipv4_udp_enabled,

				                             "Enable", "Disable", 6, 7))

				{
					FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].ipv4_udp_enabled = 1;


				}
				/*L3-Reject-Unknown-Secure-Stream*/
				if (NOT SetConfig_BinaryText(SecondNode, "L3-Reject-Unknown-Secure-Stream",
				                             &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].l3_reject_unknown_secure_stream,

				                             "Enable", "Disable", 6, 7))

				{



				}
				/*L3-Reject-Unknown-Stream*/
				if (NOT SetConfig_BinaryText(SecondNode, "L3-Reject-Unknown-Stream",
				                             &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].l3_reject_unknown_stream,

				                             "Enable", "Disable", 6, 7))

				{



				}
				/*L3-Table-Active*/
				if (NOT SetConfig_BinaryText(SecondNode, "L3-Table-Active",
				                             &FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].l3_tbl_active,

				                             "Enable", "Disable", 6, 7))

				{

					FWDConfig_t.fwd_gen_config.fwd_gen_port_config[Count].l3_tbl_active = 1;

				}
				if ((PortFwdNode = mxmlFindElement(SecondNode, SecondNode, "Port-Forwarding", NULL, NULL, MXML_DESCEND_FIRST)) != NULL) {
					SetConfig_Port_Forwarding(PortFwdNode, Count);
				}

				Count++;


			}
			if (Count < (max_port_number  + 1)) {
				fprintf(stderr, "\nERROR : <Port-Specific> in  <General-Configuratio> in <Forwarding> in '%s' should have entries for all Ports\n",

				        gOptConfigFile);

				return FALSE;

			}
			else {
				FWDConfig_t.fwd_gen_config.bEnable = TRUE;

			}
		}
	}
	else {



	}
	if ((McastNode = mxmlFindElement(ForwardingEngine, ForwardingEngine, "CPU-RX-Multicast", NULL, NULL, MXML_DESCEND_FIRST)) != NULL) {
			Set_Config_rx_mcast(McastNode);
		
	}
	if ((L2Node = mxmlFindElement(ForwardingEngine, ForwardingEngine, "Layer2-Forwarding", NULL, NULL, MXML_DESCEND_FIRST)) != NULL) {
		
		if (NOT SetConfig_Integer(L2Node, "MAX-Unsecure-Hash",

		                          &FWDConfig_t.l2_fwd_config.max_unsecure_hash_entry, RSWITCH2_MAX_UNSECURE_ENTRY)) {
			FWDConfig_t.l2_fwd_config.max_unsecure_hash_entry = RSWITCH2_MAX_UNSECURE_ENTRY;

		}
		if (NOT SetConfig_Integer(L2Node, "MAX-Hash-Collision",

		                          &FWDConfig_t.l2_fwd_config.max_hash_collision, RSWITCH2_MAX_L3_COLLISION)) {
			FWDConfig_t.l2_fwd_config.max_hash_collision = 0x3FF;

		}
		if (NOT SetConfig_Integer(L2Node, "MAC-Hash-Equation",

		                          &FWDConfig_t.l2_fwd_config.mac_hash_eqn, RENESAS_RSWITCH2_MAX_HASH_EQUATION)) {
			FWDConfig_t.l2_fwd_config.mac_hash_eqn = 0x1; // Allow at least 1 unsecure entry by default

		}
		if (NOT SetConfig_Integer(L2Node, "MAX-Unsecure-VLAN-Entries",

		                          &FWDConfig_t.l2_fwd_config.max_unsecure_vlan_entry, RENESAS_RSWITCH2_MAX_UNSECURE_VLAN)) {
			FWDConfig_t.l2_fwd_config.max_unsecure_vlan_entry = RENESAS_RSWITCH2_MAX_UNSECURE_VLAN;

		}
		if ((AgingNode = mxmlFindElement(L2Node, L2Node, "MAC-AGING", NULL, NULL, MXML_DESCEND_FIRST)) != NULL) {

			if (NOT SetConfig_BinaryText(AgingNode, "Security-Level",
			                             &FWDConfig_t.l2_fwd_config.mac_aging_config.mac_aging_security,"ALL", "UNSECURE", 3, 8)) {
				FWDConfig_t.l2_fwd_config.mac_aging_config.mac_aging_security = 1;
			}
			if ((ch = SetConfig_GetText(AgingNode, AgingNode, "Time")) != NULL) {
				if (strcasecmp(ch, "Off") == 0) {
					FWDConfig_t.l2_fwd_config.mac_aging_config.on_off = FALSE;
					FWDConfig_t.l2_fwd_config.mac_aging_config.mac_aging_security = 0;
					FWDConfig_t.l2_fwd_config.mac_aging_config.mac_aging_time_sec = 0;
					FWDConfig_t.l2_fwd_config.mac_aging_config.mac_aging_prescalar = 0;

				}
				else if (NOT SetConfig_Integer(AgingNode, "Time",

				                               &FWDConfig_t.l2_fwd_config.mac_aging_config.mac_aging_time_sec, RENESAS_RSWITCH2_MAX_HASH_EQUATION)) {
					return FALSE;
				}
				else {
					FWDConfig_t.l2_fwd_config.mac_aging_config.mac_aging_prescalar = platform_clock_khz/1000;
					FWDConfig_t.l2_fwd_config.mac_aging_config.on_off = TRUE;
				}
			}
			else {
				FWDConfig_t.l2_fwd_config.mac_aging_config.mac_aging_time_sec = 5 * 60; // 5 minutes default
				FWDConfig_t.l2_fwd_config.mac_aging_config.mac_aging_prescalar = platform_clock_khz/1000;
				FWDConfig_t.l2_fwd_config.mac_aging_config.on_off = TRUE;

			}
			FWDConfig_t.l2_fwd_config.mac_aging_config.bEnable = TRUE;

		}
		if ((MactblNode = mxmlFindElement(L2Node, L2Node, "MAC-Table", NULL, NULL, MXML_DESCEND_FIRST)) != NULL) {
			if (NOT Set_Config_L2MACTbl(MactblNode)) {
				return FALSE;
			}
			else {
				FWDConfig_t.l2_fwd_config.bEnable = TRUE;
			}
		}
		if ((VlantblNode = mxmlFindElement(L2Node, L2Node, "VLAN-Table", NULL, NULL, MXML_DESCEND_FIRST)) != NULL) {
			if (NOT Set_Config_L2VLANTbl(VlantblNode)) {
				return FALSE;
			}
			else {
				FWDConfig_t.l2_fwd_config.bEnable = TRUE;
			}
		}
		FWDConfig_t.l2_fwd_config.bEnable = TRUE; // Just in case you dont have VLAN and MAC table

	}
	if ((IpNode = mxmlFindElement(ForwardingEngine, ForwardingEngine, "IP-Forwarding", NULL, NULL, MXML_DESCEND_FIRST)) != NULL) {
		if (NOT Set_Config_IPForwarding(IpNode)) {
			return FALSE;
		}
		else {
			FWDConfig_t.ipv_fwd_config.bEnable = TRUE;
		}
		
	}
	if ((L2L3UpdateNode = mxmlFindElement(ForwardingEngine, ForwardingEngine, "Routing-Update-Table", NULL, NULL, MXML_DESCEND_FIRST)) != NULL) {
		if (NOT Set_Config_L2L3_Update(L2L3UpdateNode)) {
			return FALSE;
		}
	}
	if ((StreamNode = mxmlFindElement(ForwardingEngine, ForwardingEngine, "Stream-Forwarding", NULL, NULL, MXML_DESCEND_FIRST)) != NULL) {
		if (NOT SetConfig_Integer(StreamNode, "MAX-L3-Unsecure-Entry",

		                          &FWDConfig_t.l3_stream_fwd.max_l3_unsecure_entry, RSWITCH2_MAX_UNSECURE_ENTRY)) {
			FWDConfig_t.l3_stream_fwd.max_l3_unsecure_entry = RSWITCH2_MAX_UNSECURE_ENTRY;

		}
		if (NOT SetConfig_Integer(StreamNode, "MAX-L3-Collision",

		                          &FWDConfig_t.l3_stream_fwd.max_l3_collision, RSWITCH2_MAX_L3_COLLISION)) {
			FWDConfig_t.l3_stream_fwd.max_l3_collision = RSWITCH2_MAX_L3_COLLISION;

		}
		if (NOT SetConfig_Integer(StreamNode, "L3-Hash-Equation",

		                          &FWDConfig_t.l3_stream_fwd.l3_hash_eqn, RENESAS_RSWITCH2_MAX_HASH_EQUATION)) {
			FWDConfig_t.l3_stream_fwd.l3_hash_eqn = 0x1;

		}
		if ((FilterNode = mxmlFindElement(StreamNode, StreamNode, "Cascade-Filter", NULL, NULL, MXML_DESCEND_FIRST)) != NULL) {
			Set_Config_Cascade_Filters(FilterNode, StreamNode);
		}
		if ((FilterNode = mxmlFindElement(StreamNode, StreamNode, "2-Byte-Filter", NULL, NULL, MXML_DESCEND_FIRST)) != NULL) {
			Set_Config_Two_Byte_Filters(FilterNode, StreamNode);
		}
		if ((FilterNode = mxmlFindElement(StreamNode, StreamNode, "3-Byte-Filter", NULL, NULL, MXML_DESCEND_FIRST)) != NULL) {
			Set_Config_Three_Byte_Filters(FilterNode, StreamNode);
		}
		if ((FilterNode = mxmlFindElement(StreamNode, StreamNode, "4-Byte-Filter", NULL, NULL, MXML_DESCEND_FIRST)) != NULL) {
			Set_Config_Four_Byte_Filters(FilterNode, StreamNode);
		}
		if ((FilterNode = mxmlFindElement(StreamNode, StreamNode, "Range-Filter", NULL, NULL, MXML_DESCEND_FIRST)) != NULL) {
			Set_Config_Range_Filters(FilterNode, StreamNode);
		}
		if ((FirstNode = mxmlFindElement(StreamNode, StreamNode, "IP-Streams", NULL, NULL, MXML_DESCEND_FIRST)) != NULL) {
			if (NOT SetConfig_BinaryText(FirstNode, "Destination-Port", &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.destination_port,

			                             "Include", "Exclude", 7, 7))

			{



			}
			if (NOT SetConfig_BinaryText(FirstNode, "Dest-IPAddr", &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.destination_ip,

			                             "Include", "Exclude", 7, 7))

			{



			}
			if (NOT SetConfig_BinaryText(FirstNode, "Src-IPAddr", &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.source_ip,

			                             "Include", "Exclude", 7, 7))

			{



			}
			if (NOT SetConfig_BinaryText(FirstNode, "CTag-DEI", &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ctag_dei,

			                             "Include", "Exclude", 7, 7))

			{



			}
			if (NOT SetConfig_BinaryText(FirstNode, "CTag-PCP", &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ctag_pcp,

			                             "Include", "Exclude", 7, 7))

			{



			}
			if (NOT SetConfig_BinaryText(FirstNode, "CTag-ID", &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ctag_vlan,

			                             "Include", "Exclude", 7, 7))

			{



			}
			if (NOT SetConfig_BinaryText(FirstNode, "STag-DEI", &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.stag_dei,

			                             "Include", "Exclude", 7, 7))

			{



			}
			if (NOT SetConfig_BinaryText(FirstNode, "STag-PCP", &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.stag_pcp,

			                             "Include", "Exclude", 7, 7))

			{



			}
			if (NOT SetConfig_BinaryText(FirstNode, "STag-ID", &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.stag_vlan,

			                             "Include", "Exclude", 7, 7))

			{



			}
			if (NOT SetConfig_BinaryText(FirstNode, "Hash-Destination-Port",
			                             &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.destination_port,

			                             "Include", "Exclude", 7, 7))

			{



			}
			if (NOT SetConfig_BinaryText(FirstNode, "Hash-Source-Port",
			                             &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.source_port,

			                             "Include", "Exclude", 7, 7))

			{



			}
			if (NOT SetConfig_BinaryText(FirstNode, "Hash-Dest-IPAddr",
			                             &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.destination_ip,

			                             "Include", "Exclude", 7, 7))

			{



			}
			if (NOT SetConfig_BinaryText(FirstNode, "Hash-Src-IPAddr",
			                             &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.source_ip,

			                             "Include", "Exclude", 7, 7))

			{



			}
			if (NOT SetConfig_BinaryText(FirstNode, "Hash-protocol",
			                             &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.protocol,

			                             "Include", "Exclude", 7, 7))

			{



			}
			if (NOT SetConfig_BinaryText(FirstNode, "Hash-CTag-DEI",
			                             &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.ctag_dei,

			                             "Include", "Exclude", 7, 7))

			{



			}
			if (NOT SetConfig_BinaryText(FirstNode, "Hash-CTag-PCP",
			                             &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.ctag_pcp,

			                             "Include", "Exclude", 7, 7))

			{



			}
			if (NOT SetConfig_BinaryText(FirstNode, "Hash-CTag-ID",
			                             &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.ctag_vlan,

			                             "Include", "Exclude", 7, 7))

			{



			}
			if (NOT SetConfig_BinaryText(FirstNode, "Hash-STag-DEI",
			                             &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.stag_dei,

			                             "Include", "Exclude", 7, 7))

			{



			}
			if (NOT SetConfig_BinaryText(FirstNode, "Hash-STag-PCP",
			                             &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.stag_pcp,

			                             "Include", "Exclude", 7, 7))

			{



			}
			if (NOT SetConfig_BinaryText(FirstNode, "Hash-STag-ID",
			                             &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.stag_vlan,

			                             "Include", "Exclude", 7, 7))

			{



			}
			if (NOT SetConfig_BinaryText(FirstNode, "Hash-Dest-MAC",
			                             &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.dest_mac,

			                             "Include", "Exclude", 7, 7))

			{



			}
			if (NOT SetConfig_BinaryText(FirstNode, "Hash-Src-MAC",
			                             &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_hash_configuration.src_mac,

			                             "Include", "Exclude", 7, 7))

			{



			}

			if (NOT SetConfig_Integer(FirstNode, "IPV4-Hash-Equation",

			                          &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.hash_configuration.ipv4_hash_eqn, RENESAS_RSWITCH2_MAX_HASH_EQUATION))

			{

				FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.hash_configuration.ipv4_hash_eqn = 1;

			}
			FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.bEnable = 1;
			FWDConfig_t.l3_stream_fwd.bEnable = 1;


			/*Entry*/

			if ((SecondNode = mxmlFindElement(FirstNode, FirstNode, "Entry", NULL, NULL, MXML_DESCEND_FIRST)) == NULL)

			{

				fprintf(stderr, "\nERROR : No <Entry> in <IP-Streams> in <Stream-Forwarding> in <Forwarding> in '%s'\n",

				        gOptConfigFile);

				return FALSE;

			}
			else

			{


				Count = 0;

				for (; SecondNode != NULL; SecondNode = mxmlWalkNext(SecondNode, FirstNode, MXML_NO_DESCEND))

				{

					if (SecondNode->type != MXML_ELEMENT)

					{

						continue;

					}



					if (Count >= RSWITCH2_MAX_IPV4_STREAM_ENTRIES)

					{

						fprintf(stderr, "ERROR : A maximum of %d <Entry> entries allowed in <IP-Streams> in <Stream-Forwarding> in <Forwarding> in %s\n",

						        RSWITCH2_MAX_IPV4_STREAM_ENTRIES, gOptConfigFile);

						return FALSE;

					}
					/* Check This Logic */
					if ((portnumber = mxmlFindElement(SecondNode, SecondNode, "Dest-PortNumber", NULL, NULL, MXML_DESCEND_FIRST)) == NULL)

					{

						if (NOT SetConfig_Integer(SecondNode, "Dest-CPU",

						                          &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].csdn, RSWITCH2_MAX_CSDN)) {

							fprintf(stderr, "\nERROR : No <Dest-Port-Number> or <Dest-CPU> in <Entry>  in <IP-Streams> in <Stream-Forwarding> in <Forwarding> in '%s'\n",

							        gOptConfigFile);

							return FALSE;
						}
						else {

							FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
							destination_vector_config.cpu = 1;

						}


					}

					else {
						if (NOT SetConfig_Integer(SecondNode, "Dest-CPU",

						                          &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].csdn, RSWITCH2_MAX_CSDN)) {
							FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
							destination_vector_config.cpu = 0;

						}
						else {
							FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
							destination_vector_config.cpu = 1;

						}
						PortCount = 0;

						for (; portnumber != NULL; portnumber = mxmlWalkNext(portnumber, SecondNode, MXML_NO_DESCEND)) {

							if (portnumber->type != MXML_ELEMENT)

							{

								continue;

							}



							if (NOT SetConfig_lookupstrportnumber(portnumber,
							                                      &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
							                                      destination_vector_config.port_number[PortCount], "Dest-PortNumber",PortCount))

							{
								continue;


							}

							for (int i = 0; i < PortCount; i++)

							{

								if (FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
								        destination_vector_config.port_number[PortCount] ==
								        FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
								        destination_vector_config.port_number[i])

								{

									fprintf(stderr, "\nERROR: Duplicate <PortNumber> '%d' in <Entry> in <IP-Streams>  in <Stream-Forwarding> in <Forwarding> in '%s'\n",

									        FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
									        destination_vector_config.port_number[PortCount], gOptConfigFile);

									return FALSE;

								}

							}

							PortCount++;

						}

						FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
						destination_vector_config.dest_eth_ports = PortCount;

					}


					/*Source-LOck-CPU*/
					if (NOT SetConfig_BinaryText(SecondNode, "Source-Unlock-CPU", &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.
					                             ipv4_stream_fwd_entry[Count].
					                             source_lock.cpu,
					                             "Yes", "No", 3, 2)) {
						FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.
						ipv4_stream_fwd_entry[Count].
						source_lock.cpu = 0;
					}
					if ((PortLockNode = mxmlFindElement(SecondNode, SecondNode, "Source-Unlock-Port", NULL, NULL, MXML_DESCEND_FIRST)) == NULL) {
						if (!FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.
						        ipv4_stream_fwd_entry[Count].source_lock.cpu) {
							for (def_port_count = 0; def_port_count <= max_port_number; def_port_count++) {
								if (def_port_count < max_port_number) {
									FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.
									ipv4_stream_fwd_entry[Count].source_lock.source_port_number[def_port_count] = def_port_count;
								}
								else {

									FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.
									ipv4_stream_fwd_entry[Count].source_lock.cpu = 1;
								}
							}
							FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.
							ipv4_stream_fwd_entry[Count].source_lock.source_ports = max_port_number;
						}
					}
					SourceLockCount = 0;
					for (; PortLockNode != NULL; PortLockNode = mxmlWalkNext(PortLockNode, SecondNode, MXML_NO_DESCEND)) {
						if (PortLockNode->type != MXML_ELEMENT) {
							continue;
						}



						{

							if (NOT SetConfig_lookupstrportnumber(PortLockNode, &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.
							                                      ipv4_stream_fwd_entry[Count].source_lock.source_port_number[SourceLockCount], "Source-Unlock-Port",SourceLockCount)) {

								continue;
							}
							for (int i = 0; i < SourceLockCount; i++) {
								if ((FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
								        source_lock.source_port_number[SourceLockCount] ==
								        FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
								        source_lock.source_port_number[i]) && (FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
								                source_lock.cpu == 0)) {
									fprintf(stderr, "\nERROR: Duplicate <PortNumber> %d <Source-Unlock-Port> in <Entry> in <IP-Streams> in \
                                            <Stream-Forwarding> in <Forwarding> '%s'\n",
									        FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
									        source_lock.source_port_number[SourceLockCount], gOptConfigFile);
									return FALSE;
								}
							}
							SourceLockCount++;

						}

					}


					if (SourceLockCount) {
						FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
						source_lock.source_ports = SourceLockCount;
					}
					if (NOT SetConfig_Integer(SecondNode, "DestTCPUDP-Port",

					                          &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
					                          destination_port, RSWITCH2_MAX_TCPUDP_PORTNUMBER))

					{

					}
					if (NOT SetConfig_Integer(SecondNode, "SourceTCPUDP-Port",

					                          &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].source_port, RSWITCH2_MAX_TCPUDP_PORTNUMBER))

					{

					}
					if (NOT SetConfig_Integer(SecondNode, "CTAG-DEI",

					                          &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].ctag_dei, RSWITCH2_MAX_CTAG_DEI))

					{

					}
					if (NOT SetConfig_Integer(SecondNode, "CTAG-PCP",

					                          &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].ctag_pcp, RSWITCH2_MAX_CTAG_PCP))

					{

					}
					if (NOT SetConfig_Integer(SecondNode, "CTAG-ID",

					                          &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].ctag_vlan, RSWITCH2_MAX_CTAG_VLAN))

					{

					}
					if (NOT SetConfig_Integer(SecondNode, "STAG-DEI",

					                          &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].stag_dei, RSWITCH2_MAX_STAG_DEI))

					{

					}
					if (NOT SetConfig_Integer(SecondNode, "STAG-PCP",

					                          &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].stag_pcp, RSWITCH2_MAX_STAG_PCP))

					{

					}
					if (NOT SetConfig_Integer(SecondNode, "STAG-ID",

					                          &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].stag_vlan, RSWITCH2_MAX_STAG_VLAN))

					{

					}
					if (NOT SetConfig_Integer(SecondNode, "Cascade-Filter-Number",

					                          &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].filter_number, RSWITCH2_MAX_FILTER_NUM))

					{

					} else {
						FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.
						ipv4_stream_fwd_entry[Count].filter_enable = TRUE;
					}
					if (NOT SetConfig_BinaryText(SecondNode, "Security-Level",
					                             &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
					                             security_learn,"ALL", "UNSECURE", 3, 8)) {
						FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
						security_learn = 0;
					}
					/*VLAN-Mode*/

					if ((ch = SetConfig_GetText(SecondNode, SecondNode, "TCPUDPSUPPORT")) != NULL)

					{

						if (strncasecmp(ch, "Others", 8) == 0)

						{

							FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
							ipv4_stream_frame_format_code = ipv4_notcp_noudp;

						}

						else if (strncasecmp(ch, "UDP", 3) == 0)

						{

							FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].ipv4_stream_frame_format_code = ipv4_udp;

						}

						else if (strncasecmp(ch, "TCP", 3) == 0)

						{

							FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].ipv4_stream_frame_format_code = ipv4_tcp;

						}

						else

						{

							fprintf(stderr, "\nERROR: Invalid <Frame-Fmt-Code> in <Entry> in <IP-Streams> in <Stream-Forwarding> in <Forwarding> in '%s'\n",

							        gOptConfigFile);

							return FALSE;

						}

					}
					if (NOT SetConfig_Integer(SecondNode, "Routing-Number",

					                          &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].routing_number, RSWITCH2_MAX_ROUTING_NUMBER))

					{

					}
					else {
						FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
						routing_valid = 1;


					}

					/*Dest-MAC*/

					if (NOT SetConfig_MAC(SecondNode, FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].dest_mac,
					                      "Dest-MAC", Count))

					{



					}
					/*Src-MAC*/

					if (NOT SetConfig_MAC(SecondNode, FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].src_mac,
					                      "Src-MAC", Count))

					{



					}
					/*Dest-IP*/

					if (NOT SetConfig_IPV4(SecondNode, FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.
					                       ipv4_stream_fwd_entry[Count].destination_ip_addr,
					                       "Dest-IP-Addr", Count))

					{



					}

					/*Dest-IP*/

					if (NOT SetConfig_IPV4(SecondNode, FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].source_ip_addr,
					                       "Src-IP-Addr", Count))

					{



					}
					if (NOT SetConfig_BinaryText(SecondNode, "CPU-Mirror",
					                             &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
					                             mirroring_config.cpu_mirror_enable,"Yes", "No", 3, 2)) {
					}
					if (NOT SetConfig_BinaryText(SecondNode, "Eth-Mirror",
					                             &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
					                             mirroring_config.eth_mirror_enable,"Yes", "No", 3, 2)) {
					}

					if (NOT SetConfig_Integer(SecondNode, "IPV-Update",

					                          &FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].mirroring_config.ipv_config.ipv_value,
					                          RSWITCH2_MAX_IPV)) {

					}
					else {
						FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entry[Count].
						mirroring_config.ipv_config.ipv_update_enable = 1;

					}
					Count++;
				}
				FWDConfig_t.l3_stream_fwd.ipv4_ipv6_stream_config.ipv4_stream_fwd_config.ipv4_stream_fwd_entries = Count;
			}


		}
		else {
			fprintf(stderr, "\nERROR : Unable to find <IP-Streams> in <Stream-Forwarding> in <Forwarding> in '%s'\n",

			        gOptConfigFile);

			return FALSE;


		}
		
	}
	

	return TRUE;


}
/*

* FWD_Set_Config : Function called by rswitch tool to update the FWD Configuration

* Tree           : TSN XML Tree

*/

extern bool FWD_Set_Config(mxml_node_t * Tree)

{
	int ret  = 0;
	if ((ret = ioctl(gFwdFd, RSWITCH2_FWD_GET_CONFIG, &FWDConfig_o)) != 0)
	{
		fprintf(stderr, "\nERROR : RSWITCH_FWD_GET_CONFIG failed (%d) : %s\n", ret, strerror(errno));
		return FALSE;
	}
	if (NOT Set_Config(Tree, "Forwarding")) {
		FWD_Report_Device();
		return FALSE;
	}
	FWDConfig_t.config_done = TRUE;
	return TRUE;

}



extern bool FWD_Configure_Device(void)

{

	int ret = 0;

	if (gFwdFd != -1)

	{
		if ((ret = ioctl(gFwdFd, RSWITCH2_FWD_SET_CONFIG, &FWDConfig_t)) != 0)

		{

			fprintf(stderr, "\nERROR : RSWITCH_FWD_SET_CONFIG failed (%d) : %s\n", ret, strerror(errno));

			return FALSE;

		}

	}

	else

	{

		fprintf(stderr, "WARNING, Omitting RSWITCH_FWD_SET_CONFIG as module not open\n");

	}

	return TRUE;

}



extern bool FWD_Report_Device(void)

{

	int ret = 0;

	probe_max_port();
	if (gFwdFd != -1)

	{
		if ((ret = ioctl(gFwdFd, RSWITCH2_FWD_GET_CONFIG, &FWDConfig_t)) != 0)

		{

			fprintf(stderr, "\nERROR : RSWITCH_FWD_GET_CONFIG failed (%d) : %s\n", ret, strerror(errno));

			return FALSE;

		}

		FWD_Print_Configuration();

	}

	else

	{

		fprintf(stderr, "WARNING, Omitting RSWITCH_FWD_GET_CONFIG as module not open\n");

	}

	return TRUE;

}





/*

*   FWD_Open_Driver : Function to open the Forwarding Engine Driver File descriptor

*/



extern bool FWD_Open_Driver(void)

{

	gFwdFd = open(RSWITCH2_FWD_DEV_NAME, O_RDWR | O_SYNC);



	if (gFwdFd < 0)

	{

		fprintf(stderr, "\n ERROR : FWD Open '%s' failed : %s \n", RSWITCH2_FWD_DEV_NAME, strerror(errno));

		return FALSE;

	}




	return TRUE;

}



/*

*   FWD_Close_Driver : Function to close the Forwarding Engine Driver File descriptor

*/

extern bool FWD_Close_Driver(void)

{

	if (gFwdFd != -1)

	{

		close(gFwdFd);

		gFwdFd = -1;

	}

	return TRUE;

}
