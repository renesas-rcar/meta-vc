/*
*  Rswitch2 Configuration Tool - Ethernet TSN Port
*
*  Copyright (C) 2014 Renesas Electronics Corporation
*
*  This program is free software; you can redistribute it and/or modify it
*  under the terms and conditions of the GNU General Public License,
*  version 2, as published by the Free Software Foundation.
*
*  This program is distributed in the hope it will be useful, but WITHOUT
*  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
*  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
*  more details.
*  You should have received a copy of the GNU General Public License along wit
*  this program; if not, write to the Free Software Foundation, Inc.,
*  51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
*
*  The full GNU General Public License is included in this distribution in
*  the file called "COPYING".
*/

#include "rswitch2tool.h"
#include "rswitch2_TSN.h"
#include <math.h>
#include <inttypes.h>

#include <drivers/net/ethernet/renesas/rswitch2/rswitch2_eth_usr.h>

#define  DEFAULT_REPORT_PRINT '-'

extern char          * gOptConfigFile;
long double     SystemFreq = 0.0;
struct rswitch2_eth_config   TSNConfig_t;



static int             gEthFd          = -1;

/*
* TSN_Print_Configuration() : Prints the configuration report of TSN
*
*/
void TSN_Print_Configuration()
{



	printf("\n======================================= TSN Configuration ======================================\n");
	printf("MCAST-RX-Desc-Test=%s\n", TSNConfig_t.mcast_rx_desc_test_enable?"Yes":"No");

}





static bool SetConfig_BinaryText(mxml_node_t * ParentNode, char const * const Tag, uint32_t *structure,
                                 char const * const s1, char const * const s2, uint32_t l1, uint32_t l2)
{
	char const * ch = NULL;
	if ((ch = SetConfig_GetText(ParentNode, ParentNode, Tag)) != NULL) {
		if (strncasecmp(ch, s1, l1) == 0) {

			*structure = TRUE;
			return TRUE;
		}
		else if (strncasecmp(ch, s2, l2) == 0) {

			*structure = FALSE;
			return TRUE;
		}
		else {
			fprintf(stderr, "\nInvalid <%s> - can only be \"%s\" or \"%s\"\n",
			        Tag, s1, s2);
			return FALSE;
		}
	}
	return FALSE;
}




/*
* Set_Config()                : Update the TSN Port Configuration from the input XML configuration
* arg1 -     Tree             : Configuration XML Tree for TSN Port
* arg2 -     PortNode         : Port Node Name for TSN Port
*/
static bool Set_Config(mxml_node_t * Tree, const char * const PortNode)
{
	mxml_node_t   * TopNode    = NULL;
	if ((TopNode = mxmlFindElement(Tree, Tree, PortNode, NULL, NULL, MXML_DESCEND_FIRST)) == NULL) {
		fprintf(stderr, "\nERROR: Unable to find <%s> in '%s'\n", PortNode, gOptConfigFile);
		return FALSE;
	}
	if (NOT SetConfig_BinaryText(TopNode, "MCAST-RX-Desc-Test", &TSNConfig_t.mcast_rx_desc_test_enable,
	                             "Yes", "No", 3, 2)) {

	}

	TSN_Print_Configuration();
	return TRUE;
}

/*
* TSN_Set_Config : Function called by rswitch tool to update the TSN Configuration
* Tree           : TSN XML Tree
*/
extern bool TSN_Set_Config(mxml_node_t * Tree)
{
	if (NOT Set_Config(Tree, "Ethernet-Ports")) {
		return FALSE;
	}
	return TRUE;
}


/*
* TSN_Reset_Configuration : Function called by rswitch tool to reset the TSN Configuration
*/
void TSN_Reset_Configuration(void)
{
	memset(&TSNConfig_t, 0, sizeof(struct rswitch2_eth_config));
}

/*
* TSN_Report_Device : Function called by rswitch tool to report full system TSN configuration
*/
extern bool TSN_Report_Device(void)
{
	int ret = 0;


	if (gEthFd != -1) { //tbern
		if ((ret = ioctl(gEthFd, RSWITCH2_GET_CONFIG, &TSNConfig_t)) != 0) { //disable for testing with no driver -tbern
			fprintf(stderr, "\nERROR: RSWITCH2_GET_CONFIG failed due to %s\n", strerror(errno));
			return FALSE;
		}
		TSN_Print_Configuration();
	}
	else {
		fprintf(stderr, "WARNING: Omiting RSWITCH2_GET_CONFIG as module not open\n");
	}
	return TRUE;
}

/*
* TSN_Configure_Device : Function called by rswitch tool to configure full system TSN configuration
*/
extern bool TSN_Configure_Device(void)
{
	int ret = 0;

	if (gEthFd != -1) {
		if ((ret = ioctl(gEthFd, RSWITCH2_SET_CONFIG, &TSNConfig_t)) != 0) { //disable for testing with no driver -tbern
			fprintf(stderr, "\nERROR: RSWITCH2_SET_CONFIG  Failed due to %s\n", strerror(errno));
			return FALSE; //tbern
		}
	}
	else {
		fprintf(stderr, "WARNING: Omiting RSWITCH2_SET_CONFIG as module not open\n");
	}
	return TRUE;
}

/*
* TSN_Open_Driver : Function to open the TSN Driver File descriptor
*/
extern bool TSN_Open_Driver(void)   //disable for testing when no driver present -tbern
{
	gEthFd = open(SWITCH_AVB_TSN_DEV_NAME, O_RDWR | O_SYNC);

	if (gEthFd < 0) {
		fprintf(stderr, "\n ERROR : TSN Open '%s' failed : %s \n", SWITCH_AVB_TSN_DEV_NAME, strerror(errno));
		return FALSE;
	}
	return TRUE;
}

/*
* TSN_Close_Driver : Function to close the TSN Driver File descriptor
*/
extern bool TSN_Close_Driver(void)
{
	if (gEthFd != -1) {
		close(gEthFd);
		gEthFd = -1;
	}
	return TRUE;
}


/*
* Change History

*/

/*
* Local variables:
* Mode: C
* tab-width: 4
* indent-tabs-mode: nil
* c-basic-offset: 4
* End:
* vim: ts=4 expandtab sw=4
*/
