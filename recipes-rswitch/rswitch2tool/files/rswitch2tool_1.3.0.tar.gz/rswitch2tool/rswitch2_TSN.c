/*
*  Rswitch2 Configuration Tool - Ethernet TSN Port
*
*  Copyright (C) 2014 Renesas Electronics Corporation
*
*  This program is free software; you can redistribute it and/or modify it
*  under the terms and conditions of the GNU General Public License,
*  version 2, as published by the Free Software Foundation.
*
*  This program is distributed in the hope it will be useful, but WITHOUT
*  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
*  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
*  more details.
*  You should have received a copy of the GNU General Public License along wit
*  this program; if not, write to the Free Software Foundation, Inc.,
*  51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
*
*  The full GNU General Public License is included in this distribution in
*  the file called "COPYING".
*/

#include "rswitch2tool.h"
#include "rswitch2_TSN.h"
#include <math.h>
#include <inttypes.h>

#include <drivers/net/ethernet/renesas/rswitch2/rswitch2_eth_usr.h>

#define  DEFAULT_REPORT_PRINT '-'

extern char          * gOptConfigFile;
long double     SystemFreq = 0.0;
struct rswitch2_eth_config   TSNConfig_t;
static uint32_t        gTSN_XML_Port;


static int             gEthFd          = -1;

/*
* TSN_Print_Configuration() : Prints the configuration report of TSN
*
*/
void TSN_Print_Configuration()
{

	char PortName[5];
	uint32_t port;
	printf("\n======================================= TSN Configuration ======================================\n");
	for (port = 0; port < TSNConfig_t.ports; port++) {
		printf("Agent = ");
		if (TSNConfig_t.eth_port_config[port].cpu) {
			printf("CPU \n");
		} else {
			Reverse_lookup_PortName_PortNumber(TSNConfig_t.eth_port_config[port].port_number, PortName);
			printf("%-12s \n", PortName);
		}
		if (TSNConfig_t.eth_port_config[port].eth_vlan_tag_config.bEnable) {
			printf("Egress-VLAN-Mode   Ingress-VLAN-Mode    \n");
			if (TSNConfig_t.eth_port_config[port].eth_vlan_tag_config.egress_vlan_mode == rswitch2_eth_egress_vlan_none) {
				printf("%s","None");
			} else if (TSNConfig_t.eth_port_config[port].eth_vlan_tag_config.egress_vlan_mode == rswitch2_eth_egress_vlan_ctag) {
				printf("%s","CTAG");
			} else if (TSNConfig_t.eth_port_config[port].eth_vlan_tag_config.egress_vlan_mode == rswitch2_eth_egress_vlan_hw_ctag) {
				printf("%s","HW-CTAG");
			} else if (TSNConfig_t.eth_port_config[port].eth_vlan_tag_config.egress_vlan_mode == rswitch2_eth_egress_vlan_stag) {
				printf("%s","STAG");
			} else if (TSNConfig_t.eth_port_config[port].eth_vlan_tag_config.egress_vlan_mode == rswitch2_eth_egress_vlan_hw_stag) {
				printf("%s","HW-STAG");
			}
			if (TSNConfig_t.eth_port_config[port].eth_vlan_tag_config.ingress_vlan_mode == rswitch2_eth_ingress_vlan_incoming) {
				printf("%32s","Incoming \n");
			} else if (TSNConfig_t.eth_port_config[port].eth_vlan_tag_config.ingress_vlan_mode == rswitch2_eth_ingress_vlan_port_based) {
				printf("%32s","Port-Based \n");
			}
			printf("CTAG-ID     CTAG-PCP    CTAG-DEI    STAG-ID     STAG-PCP    STAG-DEI \n");
			printf("%d %16d %16d %16d %16d %16d \n", TSNConfig_t.eth_port_config[port].eth_vlan_tag_config.vlan_tag_config.ctag_vlan,
			       TSNConfig_t.eth_port_config[port].eth_vlan_tag_config.vlan_tag_config.ctag_pcp,
			       TSNConfig_t.eth_port_config[port].eth_vlan_tag_config.vlan_tag_config.ctag_dei,
			       TSNConfig_t.eth_port_config[port].eth_vlan_tag_config.vlan_tag_config.stag_vlan,
			       TSNConfig_t.eth_port_config[port].eth_vlan_tag_config.vlan_tag_config.stag_pcp,
			       TSNConfig_t.eth_port_config[port].eth_vlan_tag_config.vlan_tag_config.stag_dei);
			printf("VLAN Filtering \n");
			printf("Unknown Tag = %s \n", TSNConfig_t.eth_port_config[port].eth_vlan_tag_config.vlan_filtering.unknown_tag?"Reject":"Pass");
			printf("SCR Tag = %s \n", TSNConfig_t.eth_port_config[port].eth_vlan_tag_config.vlan_filtering.scr_tag?"Reject":"Pass");
			printf("SC Tag = %s \n", TSNConfig_t.eth_port_config[port].eth_vlan_tag_config.vlan_filtering.sc_tag?"Reject":"Pass");
			printf("CR Tag = %s \n", TSNConfig_t.eth_port_config[port].eth_vlan_tag_config.vlan_filtering.cr_tag?"Reject":"Pass");
			printf("C Tag = %s \n", TSNConfig_t.eth_port_config[port].eth_vlan_tag_config.vlan_filtering.c_tag?"Reject":"Pass");
			printf("COSR Tag = %s \n", TSNConfig_t.eth_port_config[port].eth_vlan_tag_config.vlan_filtering.cosr_tag?"Reject":"Pass");
			printf("COS Tag = %s \n", TSNConfig_t.eth_port_config[port].eth_vlan_tag_config.vlan_filtering.cos_tag?"Reject":"Pass");
			printf("R Tag = %s \n", TSNConfig_t.eth_port_config[port].eth_vlan_tag_config.vlan_filtering.r_tag?"Reject":"Pass");
			printf("No Tag = %s \n", TSNConfig_t.eth_port_config[port].eth_vlan_tag_config.vlan_filtering.no_tag?"Reject":"Pass");
		}
	}

}





static bool SetConfig_BinaryText(mxml_node_t * ParentNode, char const * const Tag, uint32_t *structure,
                                 char const * const s1, char const * const s2, uint32_t l1, uint32_t l2)
{
	char const * ch = NULL;
	if ((ch = SetConfig_GetText(ParentNode, ParentNode, Tag)) != NULL) {
		if (strncasecmp(ch, s1, l1) == 0) {

			*structure = TRUE;
			return TRUE;
		} else if (strncasecmp(ch, s2, l2) == 0) {

			*structure = FALSE;
			return TRUE;
		} else {
			fprintf(stderr, "\nInvalid <%s> - can only be \"%s\" or \"%s\"\n",
			        Tag, s1, s2);
			return FALSE;
		}
	}
	return FALSE;
}

/*
* Set_Config_VLAN()           : Update the VLAN Configuration from the input XML configuration
* arg1 -     Node             : VLAN Tag Node
*/
static bool Set_Config_VLAN(mxml_node_t * Node)
{
	mxml_node_t *vlan_filter_node = NULL;
	char const * XMLResult = NULL;
	if  ((XMLResult = SetConfig_GetText(Node, Node, "EgressMode")) != NULL) {
		if (strcasecmp(XMLResult, "None") == 0) {
			TSNConfig_t.eth_port_config[gTSN_XML_Port].eth_vlan_tag_config.egress_vlan_mode = rswitch2_eth_egress_vlan_none;
		} else if (strcasecmp(XMLResult, "CTAG") == 0) {
			TSNConfig_t.eth_port_config[gTSN_XML_Port].eth_vlan_tag_config.egress_vlan_mode = rswitch2_eth_egress_vlan_ctag;
		} else if (strcasecmp(XMLResult, "HW-CTAG") == 0) {
			TSNConfig_t.eth_port_config[gTSN_XML_Port].eth_vlan_tag_config.egress_vlan_mode = rswitch2_eth_egress_vlan_hw_ctag;
		} else if (strcasecmp(XMLResult, "STAG") == 0) {
			TSNConfig_t.eth_port_config[gTSN_XML_Port].eth_vlan_tag_config.egress_vlan_mode = rswitch2_eth_egress_vlan_stag;
		} else if (strcasecmp(XMLResult, "HW-STAG") == 0) {
			TSNConfig_t.eth_port_config[gTSN_XML_Port].eth_vlan_tag_config.egress_vlan_mode = rswitch2_eth_egress_vlan_hw_stag;
		} else {
			fprintf(stderr, "\nERROR: Invalid <EgressMode> '%.31s' in <VLAN-Tag> in <Port> '%u' in <Ethernet-Ports> in '%s'\n",
			        XMLResult, TSNConfig_t.eth_port_config[gTSN_XML_Port].port_number, gOptConfigFile);
			return FALSE;

		}
	} else {
		fprintf(stderr, "\n No <IngressMode> in <VLAN-Tag> in <Port> %u in <Ethernet-Ports> in '%s' \n",
		        TSNConfig_t.eth_port_config[gTSN_XML_Port].port_number, gOptConfigFile);
		return FALSE;

	}
	if  ((XMLResult = SetConfig_GetText(Node, Node, "IngressMode")) != NULL) {
		if (strcasecmp(XMLResult, "Incoming") == 0) {
			TSNConfig_t.eth_port_config[gTSN_XML_Port].eth_vlan_tag_config.ingress_vlan_mode = rswitch2_eth_ingress_vlan_incoming;
		} else if (strcasecmp(XMLResult, "Port-Based") == 0) {
			TSNConfig_t.eth_port_config[gTSN_XML_Port].eth_vlan_tag_config.ingress_vlan_mode = rswitch2_eth_ingress_vlan_port_based;
		} else {
			fprintf(stderr, "\nERROR: Invalid <IngressMode> '%.31s' in <VLAN-Tag> in <Port> '%u' in <Ethernet-Ports> in '%s'\n",
			        XMLResult, TSNConfig_t.eth_port_config[gTSN_XML_Port].port_number, gOptConfigFile);
			return FALSE;

		}
	} else {
		fprintf(stderr, "\n No <EgressMode> in <VLAN-Tag> in <Port> %u in <Ethernet-Ports> in '%s' \n",
		        TSNConfig_t.eth_port_config[gTSN_XML_Port].port_number, gOptConfigFile);
		return FALSE;

	}
	if (NOT SetConfig_Integer(Node, "STAG-ID",
	                          &TSNConfig_t.eth_port_config[gTSN_XML_Port].eth_vlan_tag_config.vlan_tag_config.stag_vlan,
	                          RSWITCH2_MAX_STAG_VLAN)) {
	}
	if (NOT SetConfig_Integer(Node, "STAG-PCP",
	                          &TSNConfig_t.eth_port_config[gTSN_XML_Port].eth_vlan_tag_config.vlan_tag_config.stag_pcp,
	                          RSWITCH2_MAX_STAG_PCP)) {
	}
	if (NOT SetConfig_Integer(Node, "STAG-DEI",
	                          &TSNConfig_t.eth_port_config[gTSN_XML_Port].eth_vlan_tag_config.vlan_tag_config.stag_dei,
	                          RSWITCH2_MAX_STAG_DEI)) {
	}
	if (NOT SetConfig_Integer(Node, "CTAG-ID",
	                          &TSNConfig_t.eth_port_config[gTSN_XML_Port].eth_vlan_tag_config.vlan_tag_config.ctag_vlan,
	                          RSWITCH2_MAX_CTAG_VLAN)) {
	}
	if (NOT SetConfig_Integer(Node, "CTAG-PCP",
	                          &TSNConfig_t.eth_port_config[gTSN_XML_Port].eth_vlan_tag_config.vlan_tag_config.ctag_pcp,
	                          RSWITCH2_MAX_CTAG_PCP)) {
	}
	if (NOT SetConfig_Integer(Node, "CTAG-DEI",
	                          &TSNConfig_t.eth_port_config[gTSN_XML_Port].eth_vlan_tag_config.vlan_tag_config.ctag_dei,
	                          RSWITCH2_MAX_CTAG_DEI)) {
	}
	/*Get the VLAN Filtering  Node from configuration file */
	if ((vlan_filter_node = mxmlFindElement(Node, Node, "Filtering", NULL, NULL, MXML_DESCEND_FIRST)) != NULL) {
		if (NOT SetConfig_BinaryText(vlan_filter_node, "Unknown-Tag",
		                             &TSNConfig_t.eth_port_config[gTSN_XML_Port].eth_vlan_tag_config.vlan_filtering.unknown_tag,"Reject", "Pass", 6, 4)) {
		}
		if (NOT SetConfig_BinaryText(vlan_filter_node, "SC-Tag",
		                             &TSNConfig_t.eth_port_config[gTSN_XML_Port].eth_vlan_tag_config.vlan_filtering.sc_tag,"Reject", "Pass", 6, 4)) {
		}
		if (NOT SetConfig_BinaryText(vlan_filter_node, "SCR-Tag",
		                             &TSNConfig_t.eth_port_config[gTSN_XML_Port].eth_vlan_tag_config.vlan_filtering.scr_tag,"Reject", "Pass", 6, 4)) {
		}
		if (NOT SetConfig_BinaryText(vlan_filter_node, "C-Tag",
		                             &TSNConfig_t.eth_port_config[gTSN_XML_Port].eth_vlan_tag_config.vlan_filtering.c_tag,"Reject", "Pass", 6, 4)) {
		}
		if (NOT SetConfig_BinaryText(vlan_filter_node, "CR-Tag",
		                             &TSNConfig_t.eth_port_config[gTSN_XML_Port].eth_vlan_tag_config.vlan_filtering.cr_tag,"Reject", "Pass", 6, 4)) {
		}
		if (NOT SetConfig_BinaryText(vlan_filter_node, "COS-Tag",
		                             &TSNConfig_t.eth_port_config[gTSN_XML_Port].eth_vlan_tag_config.vlan_filtering.c_tag,"Reject", "Pass", 6, 4)) {
		}
		if (NOT SetConfig_BinaryText(vlan_filter_node, "No-Tag",
		                             &TSNConfig_t.eth_port_config[gTSN_XML_Port].eth_vlan_tag_config.vlan_filtering.no_tag,"Reject", "Pass", 6, 4)) {
		}
		if (NOT SetConfig_BinaryText(vlan_filter_node, "COSR-Tag",
		                             &TSNConfig_t.eth_port_config[gTSN_XML_Port].eth_vlan_tag_config.vlan_filtering.cosr_tag,"Reject", "Pass", 6, 4)) {
		}
		if (NOT SetConfig_BinaryText(vlan_filter_node, "R-Tag",
		                             &TSNConfig_t.eth_port_config[gTSN_XML_Port].eth_vlan_tag_config.vlan_filtering.r_tag,"Reject", "Pass", 6, 4)) {
		}

	} else {
		fprintf(stderr, "\n No <Filtering> in <VLAN-Tag> in <Port> %u in <Ethernet-Ports> in '%s' \n",
		        TSNConfig_t.eth_port_config[gTSN_XML_Port].port_number, gOptConfigFile);
		return FALSE;

	}
	return TRUE;
}

/*
* Set_Config()                : Update the TSN Port Configuration from the input XML configuration
* arg1 -     Tree             : Configuration XML Tree for TSN Port
* arg2 -     PortNode         : Port Node Name for TSN Port
*/
static bool Set_Config(mxml_node_t * Tree, const char * const PortNode)
{
	mxml_node_t   * TopNode    = NULL;
	mxml_node_t   * Port       = NULL;
	mxml_node_t    * XMLResult  = NULL;
	mxml_node_t   *vlan_tag_node = NULL;
	char  const   * cpu = NULL;

	if ((TopNode = mxmlFindElement(Tree, Tree, PortNode, NULL, NULL, MXML_DESCEND_FIRST)) == NULL) {
		fprintf(stderr, "\nERROR: Unable to find <%s> in '%s'\n", PortNode, gOptConfigFile);
		return FALSE;
	}
	/*Get the TSN Port XML Node from configuration file */
	if ((Port = mxmlFindElement(TopNode, TopNode, "Port", NULL, NULL, MXML_DESCEND_FIRST)) == NULL) {
		fprintf(stderr, "\nERROR: Unable to find <Port> in '%s'\n", gOptConfigFile);
		return FALSE;
	}
	for (; Port!= NULL; Port = mxmlWalkNext(Port, TopNode, MXML_NO_DESCEND)) {
		if (Port->type != MXML_ELEMENT) {
			continue;
		}

		/*Get Port*/
		if (strcasecmp("Port", Port->value.element.name) == 0) {
			/*Get PortNumber XML Node and update the strucutre*/
			if  ((XMLResult = mxmlFindElement(Port, Port, "PortNumber",NULL, NULL, MXML_DESCEND_FIRST)) == NULL) {
				fprintf(stderr, "\n ERROR: No <PortNumber> in <Port> %u in <%s> in '%s' \n",
				        gTSN_XML_Port, PortNode, gOptConfigFile);
				return FALSE;
			} else {
				if (SetConfig_lookupstrportnumber(XMLResult,
				                                  &TSNConfig_t.eth_port_config[gTSN_XML_Port].port_number,"PortNumber", gTSN_XML_Port)) {
				} else if ((cpu = SetConfig_GetText(Port, Port, "PortNumber")) != NULL) {
					if (strcasecmp(cpu,"CPU")==0) {
						TSNConfig_t.eth_port_config[gTSN_XML_Port].cpu = 1;
					}
				} else {
					fprintf(stderr, "\n ERROR: Invalid <Portnumber> in <Port> %u in <%s> in '%s' \n",
					        gTSN_XML_Port, PortNode, gOptConfigFile);
					return FALSE;
				}
			}

			if ( gTSN_XML_Port >= (RENESAS_RSWITCH2_MAX_ETHERNET_PORTS + 1)) {
				fprintf(stderr, "\nERROR: Invalid <Port> '%u' in <Ethernet-Ports> in '%s' - out of range (0 to %lu)\n",
				        gTSN_XML_Port, gOptConfigFile, ARRAY_SIZE(TSNConfig_t.eth_port_config) );
				return FALSE;
			}
			/*Get the VLAN Tag  Node from configuration file */
			if ((vlan_tag_node = mxmlFindElement(Port, Port, "VLAN-Tag", NULL, NULL, MXML_DESCEND_FIRST)) != NULL) {
				if (NOT Set_Config_VLAN(vlan_tag_node)) {
					return FALSE;
				} else {
					TSNConfig_t.eth_port_config[gTSN_XML_Port].eth_vlan_tag_config.bEnable = TRUE;
				}
			}


			gTSN_XML_Port++;

		}
	}
	TSNConfig_t.ports = gTSN_XML_Port;

	//TSN_Print_Configuration();
	return TRUE;
}

/*
* TSN_Set_Config : Function called by rswitch tool to update the TSN Configuration
* Tree           : TSN XML Tree
*/
extern bool TSN_Set_Config(mxml_node_t * Tree)
{
	if (NOT Set_Config(Tree, "Ethernet-Ports")) {
		return FALSE;
	}
	return TRUE;
}


/*
* TSN_Reset_Configuration : Function called by rswitch tool to reset the TSN Configuration
*/
void TSN_Reset_Configuration(void)
{
	memset(&TSNConfig_t, 0, sizeof(struct rswitch2_eth_config));
}

/*
* TSN_Report_Device : Function called by rswitch tool to report full system TSN configuration
*/
extern bool TSN_Report_Device(void)
{
	int ret = 0;


	if (gEthFd != -1) { //tbern
		if ((ret = ioctl(gEthFd, RSWITCH2_GET_CONFIG, &TSNConfig_t)) != 0) { //disable for testing with no driver -tbern
			fprintf(stderr, "\nERROR: RSWITCH2_GET_CONFIG failed due to %s\n", strerror(errno));
			return FALSE;
		}
		TSN_Print_Configuration();
	} else {
		fprintf(stderr, "WARNING: Omiting RSWITCH2_GET_CONFIG as module not open\n");
	}
	return TRUE;
}

/*
* TSN_Configure_Device : Function called by rswitch tool to configure full system TSN configuration
*/
extern bool TSN_Configure_Device(void)
{
	int ret = 0;

	if (gEthFd != -1) {
		if ((ret = ioctl(gEthFd, RSWITCH2_SET_CONFIG, &TSNConfig_t)) != 0) { //disable for testing with no driver -tbern
			fprintf(stderr, "\nERROR: RSWITCH2_SET_CONFIG  Failed due to %s\n", strerror(errno));
			return FALSE; //tbern
		}
	} else {
		fprintf(stderr, "WARNING: Omiting RSWITCH2_SET_CONFIG as module not open\n");
	}
	return TRUE;
}

/*
* TSN_Open_Driver : Function to open the TSN Driver File descriptor
*/
extern bool TSN_Open_Driver(void)   //disable for testing when no driver present -tbern
{
	gEthFd = open(SWITCH_AVB_TSN_DEV_NAME, O_RDWR | O_SYNC);

	if (gEthFd < 0) {
		fprintf(stderr, "\n ERROR : TSN Open '%s' failed : %s \n", SWITCH_AVB_TSN_DEV_NAME, strerror(errno));
		return FALSE;
	}
	return TRUE;
}

/*
* TSN_Close_Driver : Function to close the TSN Driver File descriptor
*/
extern bool TSN_Close_Driver(void)
{
	if (gEthFd != -1) {
		close(gEthFd);
		gEthFd = -1;
	}
	return TRUE;
}


/*
* Change History

*/

/*
* Local variables:
* Mode: C
* tab-width: 4
* indent-tabs-mode: nil
* c-basic-offset: 4
* End:
* vim: ts=4 expandtab sw=4
*/
