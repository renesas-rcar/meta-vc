
echo "  #========================#"
echo "  # Sending frames on e430 #"
echo "  #========================#"

echo "    Test frame 1: L0 -> tsn4 = ETHA3"
snott -1 -i enx00e04c68994b -n1 -S 08:80:80:80:80:80 -m D4:23:EF:76:BA:00
sleep 2

echo "    Test frame 2: L1 -> tsn5 = ETHA2"
snott -1 -i enx00e04c68994a -n1 -S 18:81:81:81:81:81 -m A1:11:22:33:44:04
sleep 2

echo "    Test frame 3: L2 -> tsn6 = ETHA0"
snott -1 -i enx00e04c689949 -n1 -S 28:82:82:82:82:82 -m A1:11:22:33:44:05
sleep 2

echo "    Test frame 4: L3 -> tsn7 = ETHA1"
snott -1 -i enx00e04c689948 -n1 -S 38:83:83:83:83:83 -m A1:11:22:33:44:06
sleep 2

echo "    Test frame 5: L0 -> tsn4 = ETHA3"
snott -1 -i enx00e04c68994b -n1 -S 08:80:80:80:80:80 -m A1:11:22:33:44:07
sleep 2

echo "    Test frame 6: L1 -> tsn5 = ETHA2"
snott -1 -i enx00e04c68994a -n1 -S 18:81:81:81:81:81 -m B2:66:77:88:99:AA
sleep 2

echo "    Test frame 7: L2 -> tsn6 = ETHA0"
snott -1 -i enx00e04c689949 -n1 -S 28:82:82:82:82:82 -m B2:66:77:88:99:AA
sleep 2

echo "    Test frame 8: L3 -> tsn7 = ETHA1"
snott -1 -i enx00e04c689948 -n1 -S 38:83:83:83:83:83 -m C3:BB:CC:DD:EE:FF
sleep 2

echo "    Test frame 9: L0 -> tsn4 = ETHA3"
snott -1 -i enx00e04c68994b -n1 -S 08:80:80:80:80:80 -m C3:BB:CC:DD:EE:FF
sleep 2


