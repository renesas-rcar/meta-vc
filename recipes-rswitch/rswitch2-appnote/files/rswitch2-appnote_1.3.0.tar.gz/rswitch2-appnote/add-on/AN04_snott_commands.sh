
echo "  #========================#"
echo "  # Sending frames on e430 #"
echo "  #========================#"

echo "  Destination MAC Address known, VLAN ID matched port of MAC Address"
echo "  ------------------------------------------------------------------"

echo "    Test frame  1: Lp0 on tsn4 = ETHA3"
SNOTT -1 -i enx00e04c68994b -n1 -l100 -S 08:80:80:80:80:80 -m 18:81:81:81:81:81 -v 1
sleep 2

echo "    Test frame  2: Lp1 on tsn5 = ETHA2"
SNOTT -1 -i enx00e04c68994a -n1 -l100 -S 18:81:81:81:81:81 -m 28:82:82:82:82:82 -v 42
sleep 2

echo "    Test frame  3: Lp2 on tsn6 = ETHA0"
SNOTT -1 -i enx00e04c689949 -n1 -l100 -S 28:82:82:82:82:82 -m 38:83:83:83:83:83 -v 241
sleep 2

echo "    Test frame  4: Lp3 on tsn7 = ETHA1"
SNOTT -1 -i enx00e04c689948 -n1 -l100 -S 38:83:83:83:83:83 -m 08:80:80:80:80:80 -v 1983
sleep 2

echo "  Destination MAC Address unknown, VLAN ID in VLAN Table"
echo "  ------------------------------------------------------"

echo "    Test frame  5: Lp0 on tsn4 = ETHA3"
SNOTT -1 -i enx00e04c68994b -n1 -l100 -S 08:80:80:80:80:80 -m 1A:00:11:22:33:A1 -v 4094
sleep 2

echo "    Test frame  6: Lp1 on tsn5 = ETHA2"
SNOTT -1 -i enx00e04c68994a -n1 -l100 -S 18:81:81:81:81:81 -m 2A:44:55:66:77:A2 -v 1
sleep 2

echo "    Test frame  7: Lp2 on tsn6 = ETHA0"
SNOTT -1 -i enx00e04c689949 -n1 -l100 -S 28:82:82:82:82:82 -m 3A:88:99:AA:BB:A3 -v 42
sleep 2

echo "    Test frame  8: Lp3 on tsn7 = ETHA1"
SNOTT -1 -i enx00e04c689948 -n1 -l100 -S 38:83:83:83:83:83 -m 4A:CC:DD:EE:FF:A4 -v 241
sleep 2

echo "  Destination MAC Address known, VLAN ID not in VLAN Table"
echo "  --------------------------------------------------------"

echo "    Test frame  9: Lp0 on tsn4 = ETHA3"
SNOTT -1 -i enx00e04c68994b -n1 -l100 -S 08:80:80:80:80:80 -m 28:82:82:82:82:82 -v 1500
sleep 2

echo "    Test frame 10: Lp1 on tsn5 = ETHA2"
SNOTT -1 -i enx00e04c68994a -n1 -l100 -S 18:81:81:81:81:81 -m 1C:BB:AA:99:88:C1 -v 4023
sleep 2


