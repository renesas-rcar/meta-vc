========================================================================
(C) Copyright 2009-2012 Intel Corporation, All Rights Reserved
Author: Christopher Hall <christopher.s.hall@intel.com>
========================================================================

========================================================================
    CONSOLE APPLICATION : named_pipe_test Project Overview
========================================================================

An example application to interface with gptp/daemon_cl.  See ipcdef.hpp for message details.
