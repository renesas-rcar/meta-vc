# Version v1.0.0

## Release notes
gptp first release after separating gptp repo from OpenAvnu project.
More details on the restructuring can be found in AVnu/OpenAvnu/issues/800

## Change Log
#### Merged pull requests:
* gptp: Fix error logging for event pkt without timestamp AVnu/OpenAvnu#827
* Moving gptp folder outside OpenAVnu #1

#### Issues:
None
